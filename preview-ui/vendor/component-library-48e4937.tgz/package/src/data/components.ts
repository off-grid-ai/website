export interface ComponentData {
  name: string;
  library: string;
  url: string;
  description: string;
  category: string;
}

export const components: ComponentData[] = [
  {
    "name": "Text Generate Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/text-generate-effect",
    "description": "Fades in text word-by-word on page load",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Typewriter Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/typewriter-effect",
    "description": "Classic typing animation with cursor",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Flip Words",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/flip-words",
    "description": "Flips through word list with 3D rotation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Encrypted Text",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/encrypted-text",
    "description": "Gibberish-to-text reveal effect",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Colourful Text",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/colourful-text",
    "description": "Multi-color text with filter effects",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Hover Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/text-hover-effect",
    "description": "Gradient outline animation on hover (x.ai style)",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Container Text Flip",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/container-text-flip",
    "description": "Word flip with animated container width",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Layout Text Flip",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/layout-text-flip",
    "description": "Flips text affecting surrounding layout",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Hero Highlight",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/hero-highlight",
    "description": "Text highlight with background animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Reveal Card",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/text-reveal-card",
    "description": "Mouse-move reveals text content",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Animate",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/text-animate",
    "description": "General animation wrapper with presets",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Typing Animation",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/typing-animation",
    "description": "Character-by-character typewriter",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Animated Shiny Text",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/animated-shiny-text",
    "description": "Light glare shimmer panning across text",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Animated Gradient Text",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/animated-gradient-text",
    "description": "Moving gradient through text",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Aurora Text",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/aurora-text",
    "description": "Aurora borealis gradient animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Video Text",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/video-text",
    "description": "Text filled with video background",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Number Ticker",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/number-ticker",
    "description": "Animated counting with easing",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Reveal",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/text-reveal",
    "description": "Scroll-triggered text reveal",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Hyper Text",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/hyper-text",
    "description": "Scrambled text on hover",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Word Rotate",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/word-rotate",
    "description": "Rotating word animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Scroll Based Velocity",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/scroll-based-velocity",
    "description": "Text speed changes with scroll",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Sparkles Text",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/sparkles-text",
    "description": "Text with animated sparkles",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Morphing Text",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/morphing-text",
    "description": "Text morphs between words",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Spinning Text",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/spinning-text",
    "description": "Circular rotating text",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Line Shadow Text",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/line-shadow-text",
    "description": "Animated shadow line effect",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Comic Text",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/comic-text",
    "description": "Comic book style text",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Highlighter",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/highlighter",
    "description": "Animated highlighting effect",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Typing Text",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/typing",
    "description": "Typewriter character animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Morphing Text",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/morphing",
    "description": "Letters morph between strings",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Rolling Text",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/rolling",
    "description": "Vertical roll/scroll animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Rotating Text",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/rotating",
    "description": "Rotating word options",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Shimmering Text",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/shimmering",
    "description": "Shimmer shine across text",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Splitting Text",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/splitting",
    "description": "Character split animations",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Gradient Text",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/gradient",
    "description": "Animated gradient fill",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Highlight Text",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/highlight",
    "description": "Animated highlight marker",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Counting Number",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/counting-number",
    "description": "Number count animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Scrolling Number",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/scrolling-number",
    "description": "Ticker-style numbers",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Sliding Number",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/texts/sliding-number",
    "description": "Slide-in number animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Blur In Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/blur-in-text",
    "description": "Text animates with blur",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Fade Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/fade-text",
    "description": "Simple fade-in animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Wavy Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/wavy-text",
    "description": "Wave animation effect",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Gradual Spacing Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/gradual-spacing-text",
    "description": "Increasing letter spacing",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Letter Pull Up Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/letter-pull-up-text",
    "description": "Letters pull up individually",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Word Pull Up Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/word-pull-up-text",
    "description": "Words pull up on entrance",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Multi Direction Slide",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/multi-direction-slide-text",
    "description": "Slides from multiple directions",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Scale Letter Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/scale-letter-text",
    "description": "Letters scale individually",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Separate Away Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/seperate-away-text",
    "description": "Text separates vertically",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Dock Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/dock-text",
    "description": "macOS dock-style animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Font Weight Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/font-weight-text",
    "description": "Dynamic font weight changes",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Morphing Text",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/morphing-text",
    "description": "Text morphs between words",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Gradient",
    "library": "ABUI",
    "url": "https://www.abui.io/components/text-gradient",
    "description": "Scroll-based gradient animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Effect",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/text-effect",
    "description": "Per-character/word animations with presets",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Loop",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/text-loop",
    "description": "Cycles through text with transitions",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Morph",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/text-morph",
    "description": "Fluid letter morphing (Family app style)",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Roll",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/text-roll",
    "description": "Character rotation animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Scramble",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/text-scramble",
    "description": "Cryptographic character cycling",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Shimmer",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/text-shimmer",
    "description": "Shimmer gradient with spread control",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Shimmer Wave",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/text-shimmer-wave",
    "description": "Wave-style shimmer effect",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Animated Number",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/animated-number",
    "description": "Smooth number transitions",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Sliding Number",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/sliding-number",
    "description": "Slot machine number animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text GIF",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/text-gif",
    "description": "GIF as text background clip",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Gradient Heading",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/gradient-heading",
    "description": "Gradient text with variants",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Text Animate",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/text-animate",
    "description": "Various fade-in text animations",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Typewriter",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/typewriter",
    "description": "Multi-string typewriter effect",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Animated Number",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/animated-number",
    "description": "Spring physics number animation",
    "category": "TEXT ANIMATIONS"
  },
  {
    "name": "Moving Border",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/moving-border",
    "description": "Border animates around container",
    "category": "BUTTONS"
  },
  {
    "name": "Hover Border Gradient",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/hover-border-gradient",
    "description": "Gradient border expands on hover",
    "category": "BUTTONS"
  },
  {
    "name": "Stateful Button",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/stateful-button",
    "description": "Loading/success state transitions",
    "category": "BUTTONS"
  },
  {
    "name": "Tailwind CSS Buttons",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/tailwindcss-buttons",
    "description": "Curated collection of button styles",
    "category": "BUTTONS"
  },
  {
    "name": "Shimmer Button",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/shimmer-button",
    "description": "Shimmering light around perimeter",
    "category": "BUTTONS"
  },
  {
    "name": "Rainbow Button",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/rainbow-button",
    "description": "Animated rainbow gradient",
    "category": "BUTTONS"
  },
  {
    "name": "Ripple Button",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/ripple-button",
    "description": "Material Design ripple on click",
    "category": "BUTTONS"
  },
  {
    "name": "Shiny Button",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/shiny-button",
    "description": "Shine effect in dark/light mode",
    "category": "BUTTONS"
  },
  {
    "name": "Pulsating Button",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/pulsating-button",
    "description": "Attention-grabbing pulse animation",
    "category": "BUTTONS"
  },
  {
    "name": "Interactive Hover Button",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/interactive-hover-button",
    "description": "Interactive hover state animations",
    "category": "BUTTONS"
  },
  {
    "name": "Button",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/buttons/button",
    "description": "Base animated button (shadcn style)",
    "category": "BUTTONS"
  },
  {
    "name": "Copy Button",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/buttons/copy",
    "description": "Clipboard copy with feedback",
    "category": "BUTTONS"
  },
  {
    "name": "Flip Button",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/buttons/flip",
    "description": "3D flip between two states",
    "category": "BUTTONS"
  },
  {
    "name": "Liquid Button",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/buttons/liquid",
    "description": "Liquid fill animation on hover",
    "category": "BUTTONS"
  },
  {
    "name": "Ripple Button",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/buttons/ripple",
    "description": "Ripple with scale controls",
    "category": "BUTTONS"
  },
  {
    "name": "Icon Button",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/buttons/icon",
    "description": "Animated icon button",
    "category": "BUTTONS"
  },
  {
    "name": "Theme Toggler",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/buttons/theme-toggler",
    "description": "Dark/light mode toggle",
    "category": "BUTTONS"
  },
  {
    "name": "GitHub Stars Button",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/buttons/github-stars",
    "description": "Shows repo stars with animation",
    "category": "BUTTONS"
  },
  {
    "name": "Animated Shiny Button",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/animated-shiny-button",
    "description": "Shimmer shine effect",
    "category": "BUTTONS"
  },
  {
    "name": "Live Button",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/live-button",
    "description": "Hover effects with ripple",
    "category": "BUTTONS"
  },
  {
    "name": "Git Star Button",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/gitstarbutton",
    "description": "GitHub stars with shine",
    "category": "BUTTONS"
  },
  {
    "name": "Shimmer Button",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/shimmer-button",
    "description": "Shimmer animation",
    "category": "BUTTONS"
  },
  {
    "name": "Spotlight Button",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/spotlight-button",
    "description": "Spotlight hover effect",
    "category": "BUTTONS"
  },
  {
    "name": "Color Changing Button",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/color-changing-button",
    "description": "Dynamic color transitions",
    "category": "BUTTONS"
  },
  {
    "name": "Animated Border Button",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/animated-border-button",
    "description": "Animated border",
    "category": "BUTTONS"
  },
  {
    "name": "Interactive Button",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/interactive-button",
    "description": "Highly interactive states",
    "category": "BUTTONS"
  },
  {
    "name": "Hover Me Button",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/hover-me-button",
    "description": "Special hover interaction",
    "category": "BUTTONS"
  },
  {
    "name": "Button",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/button",
    "description": "6 variants, 4 sizes, asChild support",
    "category": "BUTTONS"
  },
  {
    "name": "Button Group",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/button-group",
    "description": "Grouped buttons with consistent styling",
    "category": "BUTTONS"
  },
  {
    "name": "Toggle",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/toggle",
    "description": "Two-state pressed button",
    "category": "BUTTONS"
  },
  {
    "name": "Toggle Group",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/toggle-group",
    "description": "Single/multiple toggle selection",
    "category": "BUTTONS"
  },
  {
    "name": "Neumorph Button",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/neumorph-button",
    "description": "Neumorphic soft UI shadows",
    "category": "BUTTONS"
  },
  {
    "name": "Family Button",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/family-button",
    "description": "Expansion button (Family app inspired)",
    "category": "BUTTONS"
  },
  {
    "name": "Texture Button",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/texture-button",
    "description": "Textured background, multiple variants",
    "category": "BUTTONS"
  },
  {
    "name": "Bg Animate Button",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/bg-animate-button",
    "description": "Animated gradient backgrounds",
    "category": "BUTTONS"
  },
  {
    "name": "3D Card Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/3d-card-effect",
    "description": "Perspective tilt with elevated elements",
    "category": "CARDS"
  },
  {
    "name": "Evervault Card",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/evervault-card",
    "description": "Encrypted text with mixed gradient",
    "category": "CARDS"
  },
  {
    "name": "Card Stack",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/card-stack",
    "description": "Cards stack after interval (testimonials)",
    "category": "CARDS"
  },
  {
    "name": "Card Hover Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/card-hover-effect",
    "description": "Effect slides to hovered card",
    "category": "CARDS"
  },
  {
    "name": "Wobble Card",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/wobble-card",
    "description": "Translates/scales on mousemove",
    "category": "CARDS"
  },
  {
    "name": "Expandable Card",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/expandable-card",
    "description": "Click to expand with more info",
    "category": "CARDS"
  },
  {
    "name": "Card Spotlight",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/card-spotlight",
    "description": "Spotlight reveals gradient background",
    "category": "CARDS"
  },
  {
    "name": "Focus Cards",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/focus-cards",
    "description": "Hover focus, blur others",
    "category": "CARDS"
  },
  {
    "name": "Draggable Card",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/draggable-card",
    "description": "Tiltable, draggable with bounds",
    "category": "CARDS"
  },
  {
    "name": "Comet Card",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/comet-card",
    "description": "Perplexity Comet-style 3D tilt",
    "category": "CARDS"
  },
  {
    "name": "Glare Card",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/glare-card",
    "description": "Glare effect on hover (Linear style)",
    "category": "CARDS"
  },
  {
    "name": "Direction Aware Hover",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/direction-aware-hover",
    "description": "Direction-aware hover animation",
    "category": "CARDS"
  },
  {
    "name": "Tooltip Card",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/tooltip-card",
    "description": "Follows mouse pointer on hover",
    "category": "CARDS"
  },
  {
    "name": "Glowing Stars",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/glowing-stars-effect",
    "description": "Star background animates on hover",
    "category": "CARDS"
  },
  {
    "name": "Magic Card",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/magic-card",
    "description": "Spotlight follows cursor",
    "category": "CARDS"
  },
  {
    "name": "Neon Gradient Card",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/neon-gradient-card",
    "description": "Animated neon gradient border",
    "category": "CARDS"
  },
  {
    "name": "Flip Card",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/community/flip-card",
    "description": "Card flips to reveal content",
    "category": "CARDS"
  },
  {
    "name": "Card Flip Hover",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/card-flip-hover",
    "description": "3D flip on hover",
    "category": "CARDS"
  },
  {
    "name": "Animated Card",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/animated-card",
    "description": "Engaging card animations",
    "category": "CARDS"
  },
  {
    "name": "Card",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/card",
    "description": "Header/content/footer sections",
    "category": "CARDS"
  },
  {
    "name": "Hover Card",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/hover-card",
    "description": "Preview card on hover",
    "category": "CARDS"
  },
  {
    "name": "Expandable Card",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/expandable",
    "description": "Condense/expand with direction options",
    "category": "CARDS"
  },
  {
    "name": "Expandable Screen",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/expandable-screen",
    "description": "Full-screen morphing expansion",
    "category": "CARDS"
  },
  {
    "name": "Minimal Card",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/minimal-card",
    "description": "Clean image card design",
    "category": "CARDS"
  },
  {
    "name": "Texture Card",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/texture-card",
    "description": "Neumorphic texture styling",
    "category": "CARDS"
  },
  {
    "name": "Shift Card",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/shift-card",
    "description": "Position animation on hover",
    "category": "CARDS"
  },
  {
    "name": "Background Beams",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/background-beams",
    "description": "Multiple beams following SVG paths",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Background Beams Collision",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/background-beams-with-collision",
    "description": "Exploding beams effect",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Background Lines",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/background-lines",
    "description": "Wave pattern animation (height.app)",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Aurora Background",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/aurora-background",
    "description": "Subtle aurora/southern lights",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Meteors",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/meteors",
    "description": "Meteor shower beams",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Wavy Background",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/wavy-background",
    "description": "Moving wave effect",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Background Boxes",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/background-boxes",
    "description": "Highlight boxes on hover",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Gradient Animation",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/background-gradient-animation",
    "description": "Position-changing gradient",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Grid and Dot Backgrounds",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/grid-and-dot-backgrounds",
    "description": "Simple grid/dot patterns",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Vortex",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/vortex",
    "description": "Swirly vortex for CTAs",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Shooting Stars",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/shooting-stars-and-stars-background",
    "description": "Starry sky with shooting stars",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Google Gemini Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/google-gemini-effect",
    "description": "SVG effect (Gemini website)",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Sparkles",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/sparkles",
    "description": "Configurable sparkle particles",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Dotted Glow Background",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/dotted-glow-background",
    "description": "Opacity animation with glow",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Background Ripple Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/background-ripple-effect",
    "description": "Grid cells ripple on click",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Webcam Pixel Grid",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/webcam-pixel-grid",
    "description": "Real-time webcam pixelation",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Noise Background",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/noise-background",
    "description": "Gradients with noise texture",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Particles",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/particles",
    "description": "Floating animated particles",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Dot Pattern",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/dot-pattern",
    "description": "Repeating dot pattern",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Grid Pattern",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/grid-pattern",
    "description": "Simple grid lines",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Animated Grid Pattern",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/animated-grid-pattern",
    "description": "Grid with animated elements",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Interactive Grid Pattern",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/interactive-grid-pattern",
    "description": "Mouse-responsive grid",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Flickering Grid",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/flickering-grid",
    "description": "Randomly flickering cells",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Retro Grid",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/retro-grid",
    "description": "80s-style perspective grid",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Ripple",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/ripple",
    "description": "Ripple behind elements",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Meteors",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/meteors",
    "description": "Meteor shower animation",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Striped Pattern",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/striped-pattern",
    "description": "Diagonal/horizontal stripes",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Light Rays",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/light-rays",
    "description": "Animated light beams",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Warp Background",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/warp-background",
    "description": "Star warp/hyperspace effect",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Bubble Background",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/backgrounds/bubble",
    "description": "Gooey gradient bubbles, mouse-following",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Fireworks Background",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/backgrounds/fireworks",
    "description": "Physics-based fireworks",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Gradient Background",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/backgrounds/gradient",
    "description": "Subtle animated gradients",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Gravity Stars",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/backgrounds/gravity-stars",
    "description": "Gravity-affected stars",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Hexagon Background",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/backgrounds/hexagon",
    "description": "Interactive hexagon grid",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Hole Background",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/backgrounds/hole",
    "description": "Animated hole/void effect",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Stars Background",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/backgrounds/stars",
    "description": "Animated starry space",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Hacker Background",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/hacker-background",
    "description": "Matrix-style code rain",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Novatrix Background",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/novatrix-background",
    "description": "Modern gradient animation",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Stripe Bg Guides",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/stripe-bg-guides",
    "description": "Stripe-style guide lines",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Texture Overlay",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/texture-overlay",
    "description": "Dots, grid, noise patterns",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Background Texture",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/bg-image-texture",
    "description": "Multiple texture variants",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Fractal Grid",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/bg-animated-fractal-grid",
    "description": "Interactive fractal dots",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Canvas Fractal Grid",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/canvas-fractal-grid",
    "description": "Canvas-rendered for performance",
    "category": "BACKGROUNDS"
  },
  {
    "name": "Floating Navbar",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/floating-navbar",
    "description": "Hides on scroll, reveals on scroll up",
    "category": "NAVIGATION"
  },
  {
    "name": "Navbar Menu",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/navbar-menu",
    "description": "Animated children for bignav",
    "category": "NAVIGATION"
  },
  {
    "name": "Sidebar",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/sidebar",
    "description": "Expandable on hover, mobile-responsive",
    "category": "NAVIGATION"
  },
  {
    "name": "Floating Dock",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/floating-dock",
    "description": "macOS-style dock navigation",
    "category": "NAVIGATION"
  },
  {
    "name": "Tabs",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/tabs",
    "description": "Background animation on switch",
    "category": "NAVIGATION"
  },
  {
    "name": "Resizable Navbar",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/resizable-navbar",
    "description": "Width changes on scroll",
    "category": "NAVIGATION"
  },
  {
    "name": "Sticky Banner",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/sticky-banner",
    "description": "Sticks top, hides on scroll",
    "category": "NAVIGATION"
  },
  {
    "name": "Dock",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/dock",
    "description": "macOS dock with magnification",
    "category": "NAVIGATION"
  },
  {
    "name": "Sidebar",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/sidebar",
    "description": "Composable, themeable animated sidebar",
    "category": "NAVIGATION"
  },
  {
    "name": "Tabs",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/animate/tabs",
    "description": "Layered panels with transitions",
    "category": "NAVIGATION"
  },
  {
    "name": "Radial Menu",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/community/radial-menu",
    "description": "Circular context menu",
    "category": "NAVIGATION"
  },
  {
    "name": "Radial Nav",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/community/radial-nav",
    "description": "Circular navigation with pointer",
    "category": "NAVIGATION"
  },
  {
    "name": "Navigation Menu",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/navigation-menu",
    "description": "Mega-menu style dropdowns",
    "category": "NAVIGATION"
  },
  {
    "name": "Menubar",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/menubar",
    "description": "Desktop app-style horizontal menu",
    "category": "NAVIGATION"
  },
  {
    "name": "Tabs",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/tabs",
    "description": "Tabbed interface with keyboard nav",
    "category": "NAVIGATION"
  },
  {
    "name": "Breadcrumb",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/breadcrumb",
    "description": "Page hierarchy navigation",
    "category": "NAVIGATION"
  },
  {
    "name": "Pagination",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/pagination",
    "description": "Page navigation controls",
    "category": "NAVIGATION"
  },
  {
    "name": "Dock",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/dock",
    "description": "macOS dock with magnification",
    "category": "NAVIGATION"
  },
  {
    "name": "Direction Aware Tabs",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/direction-aware-tabs",
    "description": "Animates based on nav direction",
    "category": "NAVIGATION"
  },
  {
    "name": "MacOS Dock",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/dock",
    "description": "macOS dock with hover magnification",
    "category": "NAVIGATION"
  },
  {
    "name": "Radio Tabs",
    "library": "ABUI",
    "url": "https://www.abui.io/components/radio-tabs",
    "description": "Radio functionality with tab UI",
    "category": "NAVIGATION"
  },
  {
    "name": "Animated Modal",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/animated-modal",
    "description": "Compound modal with transitions",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Animated Tooltip",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/animated-tooltip",
    "description": "Follows mouse pointer",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Link Preview",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/link-preview",
    "description": "Dynamic anchor previews",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Alert Dialog",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/alert-dialog",
    "description": "Animated entrance/exit",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Dialog",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/dialog",
    "description": "Animated modal dialog",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Sheet",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/sheet",
    "description": "Slide animation side panel",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Popover",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/popover",
    "description": "Animated floating panel",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Tooltip",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/animate/tooltip",
    "description": "Animated hover tooltip",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Dropdown Menu",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/dropdown-menu",
    "description": "Smooth opening animation",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Preview Link Card",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/preview-link-card",
    "description": "Animated link preview",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Alert Dialog",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/alert-dialog",
    "description": "Interrupting modal requiring response",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Dialog",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/dialog",
    "description": "Modal with focus trapping",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Drawer",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/drawer",
    "description": "Mobile-optimized slide panel (Vaul)",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Sheet",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/sheet",
    "description": "Slide-in from screen edges",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Popover",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/popover",
    "description": "Floating content panel",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Tooltip",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/tooltip",
    "description": "Hover-triggered info popup",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Dropdown Menu",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/dropdown-menu",
    "description": "Submenus, checkboxes, radio",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Context Menu",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/context-menu",
    "description": "Right-click menu",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Dialog",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/dialog",
    "description": "Customizable variants/transitions",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Morphing Dialog",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/morphing-dialog",
    "description": "Morphs from trigger to content",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Morphing Popover",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/morphing-popover",
    "description": "Transforms from trigger element",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Side Panel",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/side-panel",
    "description": "Expansion animation panel",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Floating Panel",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/floating-panel",
    "description": "Composable with Framer Motion",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Popover",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/popover",
    "description": "Small overlay next to trigger",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Popover Form",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/popover-form",
    "description": "Form inside popover",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Family Drawer",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/family-drawer",
    "description": "Slide-out control panel",
    "category": "MODALS & OVERLAYS"
  },
  {
    "name": "Parallax Scroll",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/parallax-scroll",
    "description": "Two columns scroll opposite directions",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Sticky Scroll Reveal",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/sticky-scroll-reveal",
    "description": "Sticky container with text reveal",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Macbook Scroll",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/macbook-scroll",
    "description": "Image emerges from screen (Fey.com)",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Container Scroll Animation",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/container-scroll-animation",
    "description": "3D rotation on scroll",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Hero Parallax",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/hero-parallax",
    "description": "Rotation, translation, opacity",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Tracing Beam",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/tracing-beam",
    "description": "Beam follows SVG path on scroll",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Scroll Based Velocity",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/scroll-based-velocity",
    "description": "Scroll-linked velocity animation",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Scroll Progress",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/scroll-progress",
    "description": "Scroll position indicator",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Scroll Progress",
    "library": "ABUI",
    "url": "https://www.abui.io/components/scroll-progress",
    "description": "Reading progress bar",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Scroll Reveal Content",
    "library": "ABUI",
    "url": "https://www.abui.io/blocks/scroll-reveal-content-a",
    "description": "3-part content with line animation",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "In View",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/in-view",
    "description": "Animates when entering viewport",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Scroll Progress",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/scroll-progress",
    "description": "Animated scroll position tracker",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Scroll Progress",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/animate/scroll-progress",
    "description": "Scroll position indicator",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Scroll Progress",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/scroll-progress",
    "description": "Progress bar showing scroll",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Blur Fade",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/blur-fade",
    "description": "Blur fade-in on viewport entry",
    "category": "SCROLL EFFECTS"
  },
  {
    "name": "Images Slider",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/images-slider",
    "description": "Full page with keyboard nav",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Carousel",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/carousel",
    "description": "Microinteractions and slider",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Apple Cards Carousel",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/apple-cards-carousel",
    "description": "Apple.com-style minimal carousel",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Animated Testimonials",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/animated-testimonials",
    "description": "Testimonial with image/quote",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Infinite Moving Cards",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/infinite-moving-cards",
    "description": "Infinite loop card scroll",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Marquee",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/marquee",
    "description": "Infinite scroll horizontal/vertical",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Motion Carousel",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/community/motion-carousel",
    "description": "Embla + Motion scaling, pill pagination",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Testimonial Slider",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/testimonal-slider",
    "description": "Auto-rotation timing",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Scale Slider",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/scale-slider",
    "description": "Slider with scaling animation",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Carousel",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/carousel",
    "description": "Embla-based with motion animations",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Slider",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/slider",
    "description": "Range input with draggable thumb",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Carousel",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/carousel",
    "description": "Flexible with navigation options",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Infinite Slider",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/infinite-slider",
    "description": "Infinite loop marquee",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Feature Carousel",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/feature-carousel",
    "description": "Feature showcase with transitions",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Loading Carousel",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/loading-carousel",
    "description": "Loading indicators, aspect ratios",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Logo Carousel",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/logo-carousel",
    "description": "Partner/client logo display",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "3D Carousel",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/three-d-carousel",
    "description": "3D perspective transformations",
    "category": "CAROUSELS & SLIDERS"
  },
  {
    "name": "Signup Form",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/signup-form",
    "description": "Framer Motion + shadcn inputs",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Placeholders Vanish Input",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/placeholders-and-vanish-input",
    "description": "Sliding placeholders, vanish on submit",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "File Upload",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/file-upload",
    "description": "Grid background, drag and drop",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Clerk OTP",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/clerk-otp",
    "description": "Animated OTP with random digits",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Input",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/input",
    "description": "All HTML input types",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Input Group",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/input-group",
    "description": "Input with prefix/suffix addons",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Input OTP",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/input-otp",
    "description": "OTP input with copy-paste",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Textarea",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/textarea",
    "description": "Multi-line with auto-resize",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Select",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/select",
    "description": "Dropdown selection list",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Native Select",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/native-select",
    "description": "Browser-native with styling",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Combobox",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/combobox",
    "description": "Searchable select autocomplete",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Checkbox",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/checkbox",
    "description": "Toggle with indeterminate state",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Radio Group",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/radio-group",
    "description": "Mutually exclusive selection",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Switch",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/switch",
    "description": "On/off toggle control",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Label",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/label",
    "description": "Accessible form label",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Form",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/form",
    "description": "React Hook Form integration",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Field",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/field",
    "description": "Label/description/error wrapper",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Calendar",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/calendar",
    "description": "Date picker (react-day-picker)",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Date Picker",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/date-picker",
    "description": "Calendar in popover",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Color Swatch Selector",
    "library": "ABUI",
    "url": "https://www.abui.io/components/color-swatch-selector",
    "description": "Visual color picking",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Label Selector",
    "library": "ABUI",
    "url": "https://www.abui.io/components/label-selector",
    "description": "Text-based option selection",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Radio Rows",
    "library": "ABUI",
    "url": "https://www.abui.io/components/radio-rows",
    "description": "Radio in row format",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Accordion Multiselect",
    "library": "ABUI",
    "url": "https://www.abui.io/components/accordion-multiselect",
    "description": "Expandable multi-selection",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Sortable List",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/sortable-list",
    "description": "Drag-and-drop reorderable",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Color Picker",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/color-picker",
    "description": "HSL color selection",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Checkbox",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/checkbox",
    "description": "Animated check indicator",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Switch",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/switch",
    "description": "Animated toggle",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Radio Group",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/radio-group",
    "description": "Animated radio selection",
    "category": "FORMS & INPUTS"
  },
  {
    "name": "Timeline",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/timeline",
    "description": "Sticky header with scroll beam",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Compare",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/compare",
    "description": "Image comparison slider",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Code Block",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/code-block",
    "description": "Configurable syntax highlighter",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Terminal",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/terminal",
    "description": "macOS terminal with typing",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Tweet Card",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/tweet-card",
    "description": "Styled Twitter embed",
    "category": "DATA DISPLAY"
  },
  {
    "name": "File Tree",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/file-tree",
    "description": "Animated file/folder structure",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Code Comparison",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/code-comparison",
    "description": "Side-by-side code diff",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Terminal",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/terminal",
    "description": "Typing with localhost notification",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Logo Timeline",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/logo-timeline",
    "description": "Brand logo timeline",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Code Snippet",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/code-snippet",
    "description": "Styled code display",
    "category": "DATA DISPLAY"
  },
  {
    "name": "GitHub Inline Comments",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/github-inline-comments",
    "description": "GitHub-style comments",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Table",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/table",
    "description": "Responsive with subcomponents",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Data Table",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/data-table",
    "description": "TanStack sorting/filtering",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Chart",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/chart",
    "description": "Recharts-powered visualization",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Progress",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/progress",
    "description": "Task completion indicator",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Timeline Steps",
    "library": "ABUI",
    "url": "https://www.abui.io/components/timeline-steps",
    "description": "Sequential process visualization",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Timeline (Gantt)",
    "library": "ABUI",
    "url": "https://www.abui.io/blocks/timeline",
    "description": "Draggable Gantt-style timeline",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Availability",
    "library": "ABUI",
    "url": "https://www.abui.io/blocks/availability",
    "description": "Weekly availability designer",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Calendar Year",
    "library": "ABUI",
    "url": "https://www.abui.io/blocks/calendar-year",
    "description": "Full year calendar view",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Animated Chart",
    "library": "ABUI",
    "url": "https://www.abui.io/blocks/animated-chart",
    "description": "Spring physics chart animations",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Table of Contents",
    "library": "ABUI",
    "url": "https://www.abui.io/components/toc",
    "description": "Active anchor tracking",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Code",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/animate/code",
    "description": "Animated code display",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Code Tabs",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/animate/code-tabs",
    "description": "Tabbed code with transitions",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Files",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/files",
    "description": "Animated file list/tree",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Code Block",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/code-block",
    "description": "Formatted code container",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Tweet Grid",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/tweet-grid",
    "description": "Masonry tweet layout",
    "category": "DATA DISPLAY"
  },
  {
    "name": "LightBoard",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/lightboard",
    "description": "LED text display/drawing",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Image Comparison",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/image-comparison",
    "description": "Draggable comparison slider",
    "category": "DATA DISPLAY"
  },
  {
    "name": "Safari",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/safari",
    "description": "Safari browser frame",
    "category": "DEVICE MOCKUPS"
  },
  {
    "name": "iPhone",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/iphone",
    "description": "iPhone device mockup",
    "category": "DEVICE MOCKUPS"
  },
  {
    "name": "Android",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/android",
    "description": "Android device frame",
    "category": "DEVICE MOCKUPS"
  },
  {
    "name": "Browser",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/browser",
    "description": "Generic browser frame",
    "category": "DEVICE MOCKUPS"
  },
  {
    "name": "Safari Browser",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/safari-browser",
    "description": "Safari-specific frame",
    "category": "DEVICE MOCKUPS"
  },
  {
    "name": "iPad",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/ipad",
    "description": "iPad device mockup",
    "category": "DEVICE MOCKUPS"
  },
  {
    "name": "iPhone 17 Pro",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/iphone-17-pro",
    "description": "Latest iPhone mockup",
    "category": "DEVICE MOCKUPS"
  },
  {
    "name": "MacBook Pro",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/macbook-pro",
    "description": "MacBook mockup",
    "category": "DEVICE MOCKUPS"
  },
  {
    "name": "Browser Window",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/mock-browser-window",
    "description": "Browser window container",
    "category": "DEVICE MOCKUPS"
  },
  {
    "name": "3D Pin",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/3d-pin",
    "description": "Gradient pin animates on hover",
    "category": "3D COMPONENTS"
  },
  {
    "name": "3D Marquee",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/3d-marquee",
    "description": "3D grid marquee effect",
    "category": "3D COMPONENTS"
  },
  {
    "name": "GitHub Globe",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/github-globe",
    "description": "Interactive globe (GitHub style)",
    "category": "3D COMPONENTS"
  },
  {
    "name": "World Map",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/world-map",
    "description": "Animated lines and dots",
    "category": "3D COMPONENTS"
  },
  {
    "name": "Globe",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/globe",
    "description": "Interactive 3D globe (Cobe)",
    "category": "3D COMPONENTS"
  },
  {
    "name": "Icon Cloud",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/icon-cloud",
    "description": "3D interactive icon cloud",
    "category": "3D COMPONENTS"
  },
  {
    "name": "Orbiting Circles",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/orbiting-circles",
    "description": "Circles orbiting center",
    "category": "3D COMPONENTS"
  },
  {
    "name": "Cobe Globe",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/cobe-globe",
    "description": "Multiple variants, customizable markers",
    "category": "3D COMPONENTS"
  },
  {
    "name": "Orbit Rotation",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/orbit-rotation",
    "description": "Icons in orbital patterns",
    "category": "3D COMPONENTS"
  },
  {
    "name": "Sphere Animation",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/sphereanimation",
    "description": "SVG sphere animation",
    "category": "3D COMPONENTS"
  },
  {
    "name": "Dotted Map",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/dotted-map",
    "description": "Interactive dotted world map",
    "category": "3D COMPONENTS"
  },
  {
    "name": "Map",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/map",
    "description": "Interactive map component",
    "category": "3D COMPONENTS"
  },
  {
    "name": "Tilt",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/tilt",
    "description": "3D tilt on mouse movement",
    "category": "3D COMPONENTS"
  },
  {
    "name": "Following Pointer",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/following-pointer",
    "description": "Custom pointer follows mouse",
    "category": "CURSORS & POINTERS"
  },
  {
    "name": "Pointer Highlight",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/pointer-highlight",
    "description": "Highlights text with pointer",
    "category": "CURSORS & POINTERS"
  },
  {
    "name": "Lens",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/lens",
    "description": "Zoom into images/videos",
    "category": "CURSORS & POINTERS"
  },
  {
    "name": "Pointer",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/pointer",
    "description": "Custom animated cursor",
    "category": "CURSORS & POINTERS"
  },
  {
    "name": "Smooth Cursor",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/smooth-cursor",
    "description": "Smooth following animation",
    "category": "CURSORS & POINTERS"
  },
  {
    "name": "Lens",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/lens",
    "description": "Magnifying lens on hover",
    "category": "CURSORS & POINTERS"
  },
  {
    "name": "Cursor",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/animate/cursor",
    "description": "Customizable cursor/follow elements",
    "category": "CURSORS & POINTERS"
  },
  {
    "name": "Cursor",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/cursor",
    "description": "Spring animated cursor",
    "category": "CURSORS & POINTERS"
  },
  {
    "name": "Magnetic",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/magnetic",
    "description": "Elements attracted to cursor",
    "category": "CURSORS & POINTERS"
  },
  {
    "name": "Shader Lens Blur",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/shader-lens-blur",
    "description": "Lens blur with shader effects",
    "category": "CURSORS & POINTERS"
  },
  {
    "name": "Multi Step Loader",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/multi-step-loader",
    "description": "Step loader for long loads",
    "category": "LOADERS & SPINNERS"
  },
  {
    "name": "Loader",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/loader",
    "description": "Set of minimal loaders",
    "category": "LOADERS & SPINNERS"
  },
  {
    "name": "Spinner",
    "library": "ABUI",
    "url": "https://www.abui.io/components/spinner",
    "description": "Customizable size/speed/color",
    "category": "LOADERS & SPINNERS"
  },
  {
    "name": "Spinner",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/spinner",
    "description": "Loading indicator animation",
    "category": "LOADERS & SPINNERS"
  },
  {
    "name": "Skeleton",
    "library": "shadcn/ui",
    "url": "https://ui.shadcn.com/docs/components/skeleton",
    "description": "Shimmer loading placeholder",
    "category": "LOADERS & SPINNERS"
  },
  {
    "name": "Progress",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/components/radix/progress",
    "description": "Animated progress indicator",
    "category": "LOADERS & SPINNERS"
  },
  {
    "name": "Animated Circular Progress",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/animated-circular-progress-bar",
    "description": "Circular progress with animation",
    "category": "LOADERS & SPINNERS"
  },
  {
    "name": "Spotlight",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/spotlight",
    "description": "Spotlight draws attention",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Spotlight New",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/spotlight-new",
    "description": "Configurable left/right spotlight",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Canvas Reveal Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/canvas-reveal-effect",
    "description": "Dot expand on hover (Clerk style)",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "SVG Mask Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/svg-mask-effect",
    "description": "Mask reveal on hover",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Lamp Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/lamp-effect",
    "description": "Lamp effect (Linear style)",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Glowing Effect",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/glowing-effect",
    "description": "Border glow (Cursor style)",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Pixelated Canvas",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/pixelated-canvas",
    "description": "Image pixelation with distortion",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Dither Shader",
    "library": "Aceternity",
    "url": "https://ui.aceternity.com/components/dither-shader",
    "description": "Real-time ordered dithering",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Confetti",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/confetti",
    "description": "Canvas confetti (fireworks, cannons)",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Animated Beam",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/animated-beam",
    "description": "Light beam along path",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Border Beam",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/border-beam",
    "description": "Beam travels along border",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Shine Border",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/shine-border",
    "description": "Shining gradient border",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Cool Mode",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/cool-mode",
    "description": "Particle explosion on interaction",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Pixel Image",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/pixel-image",
    "description": "Pixelated image reveal",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Progressive Blur",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/progressive-blur",
    "description": "Gradient blur fade",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Animated Theme Toggler",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/animated-theme-toggler",
    "description": "Dark/light toggle animation",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Shine Effect",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/effects/shine",
    "description": "Light sweep with triggers",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Magnetic Effect",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/effects/magnetic",
    "description": "Cursor attraction",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Particles Effect",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/effects/particles",
    "description": "Particle animations",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Tilt Effect",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/effects/tilt",
    "description": "3D tilt on hover",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Blur Effect",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/effects/blur",
    "description": "Animated blur",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Fade Effect",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/effects/fade",
    "description": "Fade in/out on view",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Zoom Effect",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/effects/zoom",
    "description": "Scale/zoom animation",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Image Zoom",
    "library": "Animate UI",
    "url": "https://animate-ui.com/docs/primitives/effects/image-zoom",
    "description": "Zoom on images",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "SVG Ripple Effect",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/svg-ripple-effect",
    "description": "SVG-based ripple",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Scratch To Reveal",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/scratchtoreveal",
    "description": "Interactive scratch-off",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Dynamic Square",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/dynamic-square",
    "description": "Animated dynamic element",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Integrations",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/integrations",
    "description": "Icons with marquee/fade",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Animated Frameworks",
    "library": "Eldora UI",
    "url": "https://www.eldoraui.site/docs/components/animated-frameworks",
    "description": "Animated framework icons",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Border Trail",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/border-trail",
    "description": "Animated border movement",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Glow Effect",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/glow-effect",
    "description": "Customizable glow with modes",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Spotlight",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/spotlight",
    "description": "Light follows cursor",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Spinning Text",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/spinning-text",
    "description": "Circular spinning text",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Progressive Blur",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/progressive-blur",
    "description": "Layered blur with masks",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Animated Background",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/animated-background",
    "description": "Background highlight on hover",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Animated Group",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/animated-group",
    "description": "Staggered child animations",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Disclosure",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/disclosure",
    "description": "Content show/hide toggle",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Transition Panel",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/transition-panel",
    "description": "Content switch with animations",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Toolbar Dynamic",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/toolbar-dynamic",
    "description": "Width-adjusting toolbar",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Toolbar Expandable",
    "library": "Motion Primitives",
    "url": "https://motion-primitives.com/docs/toolbar-expandable",
    "description": "Height-adjusting toolbar",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Dynamic Island",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/dynamic-island",
    "description": "Apple-style with size presets",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Timer",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/timer",
    "description": "Countdown/stopwatch",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Squiggle Arrow",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/squiggle-arrow",
    "description": "Decorative squiggly pointer",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Distorted Glass",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/distorted-glass",
    "description": "Frosted glass effect",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Intro Disclosure",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/intro-disclosure",
    "description": "Multi-step onboarding",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Hover Video Player",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/hover-video-player",
    "description": "Video plays on hover",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "YouTube Video Player",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/youtube-video-player",
    "description": "Modern YouTube player",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Bg Media Hero",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/bg-media",
    "description": "Full-screen background media",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Toolbar Expandable",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/toolbar-expandable",
    "description": "Step-based expanding toolbar",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Morph Surface",
    "library": "Cult UI",
    "url": "https://www.cult-ui.com/docs/components/morph-surface",
    "description": "Morphing surface animation",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Avatar Circles",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/avatar-circles",
    "description": "Stacked avatar display",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Animated List",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/animated-list",
    "description": "Staggered list items",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Bento Grid",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/bento-grid",
    "description": "Modular content grid",
    "category": "MISCELLANEOUS EFFECTS"
  },
  {
    "name": "Hero Video Dialog",
    "library": "Magic UI",
    "url": "https://magicui.design/docs/components/hero-video-dialog",
    "description": "Hero with video modal",
    "category": "MISCELLANEOUS EFFECTS"
  }
];
