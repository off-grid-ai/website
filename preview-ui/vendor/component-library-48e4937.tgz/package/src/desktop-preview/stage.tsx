import type { ReactNode } from "react";
import { cn } from "../sourced/coss/lib/utils";

/**
 * Preview layout only: one idea per stage, a sticky caption on the left and a
 * live specimen floating on the field on the right.
 */
export function Stage({
  index,
  kicker,
  title,
  children,
  description,
  sources,
  className,
  specimenClassName,
}: {
  index: number;
  kicker: string;
  title: string;
  description: ReactNode;
  sources?: string[];
  children: ReactNode;
  className?: string;
  specimenClassName?: string;
}) {
  return (
    <section
      data-og-reveal
      className={cn(
        "grid gap-10 border-t border-border/50 py-20 first:border-t-0 first:pt-0 lg:grid-cols-[15rem_minmax(0,1fr)] lg:gap-16",
        className,
      )}
    >
      <div className="self-start lg:sticky lg:top-28">
        <p className="font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
          <span className="text-primary">{String(index).padStart(2, "0")}</span>
          <span className="mx-2 text-muted-foreground/40">—</span>
          {kicker}
        </p>
        <h2 className="mt-5 text-[1.65rem] font-light leading-[1.15] tracking-[-0.025em]">
          {title}
        </h2>
        <div className="mt-4 text-[12.5px] leading-relaxed text-muted-foreground">
          {description}
        </div>
        {sources && sources.length > 0 && (
          <ul className="mt-6 flex flex-wrap gap-1.5">
            {sources.map((source) => (
              <li
                key={source}
                className="rounded-full px-2.5 py-1 font-mono text-[10px] text-muted-foreground shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-text)/0.08)]"
              >
                {source}
              </li>
            ))}
          </ul>
        )}
      </div>
      <div
        data-og-surface
        data-og-depth
        className={cn(
          "og-specimen relative flex min-h-[19rem] min-w-0 flex-col justify-center rounded-[28px] p-8 sm:p-12",
          specimenClassName,
        )}
      >
        {children}
      </div>
    </section>
  );
}
