// Composed adapters link to their main visual source. Exact secondary sources,
// local adaptations, and runtime versions are in the source/coverage documents.
export const sourceInventory = [
  {
    path: "operator/gradient-background",
    library: "Wednesday catalogue · Animate UI category",
    url: "https://github.com/wednesday-solutions/component-library-animations/blob/ca35d2f9004b212ea034b73109fcd2819a08816b/src/components/animate-ui/GradientBackground.tsx",
  },
  {
    path: "operator/animate/checkbox",
    library: "Animate UI",
    url: "https://github.com/imskyleen/animate-ui/tree/efeb96ffd7a3b7a4868667e4ac3c346620fb3044/apps/www/registry",
  },
  {
    path: "operator/animate/switch",
    library: "Animate UI",
    url: "https://github.com/imskyleen/animate-ui/tree/efeb96ffd7a3b7a4868667e4ac3c346620fb3044/apps/www/registry",
  },
  {
    path: "operator/animate/radio-group",
    library: "Animate UI",
    url: "https://github.com/imskyleen/animate-ui/tree/efeb96ffd7a3b7a4868667e4ac3c346620fb3044/apps/www/registry",
  },
  {
    path: "operator/text-effect",
    library: "Motion Primitives",
    url: "https://github.com/ibelick/motion-primitives/blob/120f64f6ca60348e251f929e9c81f11ccbe45eda/components/core/text-effect.tsx",
  },
  {
    path: "operator/chart",
    library: "shadcn/ui + Recharts",
    url: "https://github.com/shadcn-ui/ui/blob/30a58d4498f270af1c1e981a7d78a15cf5740841/apps/v4/registry/new-york-v4/ui/chart.tsx",
  },
  {
    path: "operator/workflows/pro-presentations",
    library: "Coss + Dice UI composition",
    url: "https://github.com/cosscom/ui/tree/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui",
  },
  {
    path: "operator/workflows/tool-timeline",
    library: "Dice UI + SmoothUI composition",
    url: "https://github.com/educlopez/smoothui/tree/b6312bce2b6f2ed95d8a6e98a592857884f5ea9e/packages/smoothui/components",
  },
  {
    path: "operator/workflows/attachments",
    library: "AI Elements + Coss composition",
    url: "https://github.com/vercel/ai-elements",
  },
  {
    path: "operator/workflows/voice-capture",
    library: "ElevenLabs + Coss composition",
    url: "https://github.com/elevenlabs/ui",
  },
  {
    path: "operator/media/video-player",
    library: "Media Chrome",
    url: "https://github.com/muxinc/media-chrome/tree/v4.17.2",
  },
  {
    path: "operator/media/file-preview",
    library: "Source renderer composition",
    url: "https://github.com/wednesday-solutions/component-library-animations",
  },
  {
    path: "operator/media/inline-completion",
    library: "CodeMirror AI 0.3.9 · source extension",
    url: "https://github.com/marimo-team/codemirror-ai/blob/aee0dddb2424edb4617e0a68dfbd8963f093ef40/src/inline-edit/inline-completion.ts",
  },
  {
    path: "operator/animate/dialog",
    library: "Animate UI",
    url: "https://github.com/imskyleen/animate-ui/blob/efeb96ffd7a3b7a4868667e4ac3c346620fb3044/apps/www/registry/components/base/dialog/index.tsx",
  },
  {
    path: "operator/animate/alert-dialog",
    library: "Animate UI",
    url: "https://github.com/imskyleen/animate-ui/blob/efeb96ffd7a3b7a4868667e4ac3c346620fb3044/apps/www/registry/components/base/alert-dialog/index.tsx",
  },

  {
    path: "operator/animate/sheet",
    library: "Animate UI",
    url: "https://github.com/imskyleen/animate-ui/blob/efeb96ffd7a3b7a4868667e4ac3c346620fb3044/apps/www/registry/components/radix/sheet/index.tsx",
  },
  {
    path: "operator/workflows/queue",
    library: "AI Elements + coss UI \u00b7 controlled composition",
    url: "https://github.com/vercel/ai-elements/blob/6a9d5b1822ffb10bba4bd97175f01edd7d8651cd/packages/elements/src/queue.tsx",
  },
  {
    path: "operator/workflows/secret-value",
    library: "coss UI \u00b7 controlled composition",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/field.tsx",
  },
  {
    path: "operator/virtual-list",
    library: "React Virtuoso 4.18.19 \u00b7 runtime reexport",
    url: "https://github.com/petyosi/react-virtuoso/tree/main/packages/react-virtuoso",
  },
  {
    path: "operator/media/lightbox",
    library: "Yet Another React Lightbox 3.32.2",
    url: "https://github.com/igordanchenko/yet-another-react-lightbox/tree/fb77cd0e2bbc39e0f4a55a89a3dee1d84baee88e",
  },
  {
    path: "operator/media/recording-frames",
    library: "YARL + coss UI \u00b7 controlled composition",
    url: "https://github.com/igordanchenko/yet-another-react-lightbox/tree/fb77cd0e2bbc39e0f4a55a89a3dee1d84baee88e",
  },
  {
    path: "operator/media/pdf",
    library: "React-PDF 9.2.1 + PDF.js 4.8.69",
    url: "https://github.com/wojtekmaj/react-pdf/tree/5e0d135f5d1d3a3cec4628a2fc05a4a8f0bed9e7",
  },
  {
    path: "operator/media/code-editor",
    library: "React CodeMirror 4.25.12",
    url: "https://github.com/uiwjs/react-codemirror/tree/1e2e11f865860c6bd5029d71a2a09bd894ed5bad",
  },
  {
    path: "operator/coss/pagination",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/pagination.tsx",
  },
  {
    path: "operator/coss/tabs",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/tabs.tsx",
  },
  {
    path: "operator/coss/card",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/card.tsx",
  },
  {
    path: "operator/coss/slider",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/slider.tsx",
  },
  {
    path: "operator/coss/input-group",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/input-group.tsx",
  },
  {
    path: "operator/coss/popover",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/popover.tsx",
  },
  {
    path: "operator/coss/progress",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/progress.tsx",
  },

  {
    path: "operator/coss/field",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/field.tsx",
  },
  {
    path: "operator/coss/toolbar",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/toolbar.tsx",
  },
  {
    path: "operator/coss/scroll-area",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/scroll-area.tsx",
  },
  {
    path: "operator/coss/label",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/label.tsx",
  },
  {
    path: "operator/coss/empty",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/empty.tsx",
  },
  {
    path: "operator/coss/tooltip",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/tooltip.tsx",
  },
  {
    path: "operator/coss/alert",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/alert.tsx",
  },
  {
    path: "operator/coss/combobox",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/combobox.tsx",
  },

  {
    path: "operator/coss/calendar",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/calendar.tsx",
  },
  {
    path: "operator/coss/command",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/command.tsx",
  },
  {
    path: "operator/coss/toggle-group",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/toggle-group.tsx",
  },

  {
    path: "operator/coss/kbd",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/kbd.tsx",
  },
  {
    path: "operator/coss/menu",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/menu.tsx",
  },
  {
    path: "operator/coss/badge",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/badge.tsx",
  },

  {
    path: "operator/coss/number-field",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/number-field.tsx",
  },

  {
    path: "operator/coss/table",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/table.tsx",
  },
  {
    path: "operator/coss/separator",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/separator.tsx",
  },
  {
    path: "operator/coss/button",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/button.tsx",
  },
  {
    path: "operator/coss/spinner",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/spinner.tsx",
  },
  {
    path: "operator/coss/collapsible",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/collapsible.tsx",
  },
  {
    path: "operator/coss/fieldset",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/fieldset.tsx",
  },
  {
    path: "operator/coss/select",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/select.tsx",
  },
  {
    path: "operator/coss/frame",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/frame.tsx",
  },
  {
    path: "operator/coss/textarea",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/textarea.tsx",
  },
  {
    path: "operator/coss/input",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/input.tsx",
  },
  {
    path: "operator/coss/autocomplete",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/autocomplete.tsx",
  },
  {
    path: "operator/coss/skeleton",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/skeleton.tsx",
  },
  {
    path: "operator/coss/context-menu",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/context-menu.tsx",
  },
  {
    path: "operator/coss/form",
    library: "coss UI",
    url: "https://github.com/cosscom/ui/blob/81bbc46dcbc9f5d91dc8b391b0e63415e250314e/apps/ui/registry/default/ui/form.tsx",
  },
  {
    path: "operator/dice/editable",
    library: "Dice UI",
    url: "https://github.com/sadmann7/diceui/blob/040e842d4119260c22a59bf7e9d5cc3808e09efb/docs/registry/bases/base/ui/editable.tsx",
  },

  {
    path: "operator/dice/time-picker",
    library: "Dice UI",
    url: "https://github.com/sadmann7/diceui/blob/040e842d4119260c22a59bf7e9d5cc3808e09efb/docs/registry/bases/base/ui/time-picker.tsx",
  },

  {
    path: "operator/dice/timeline",
    library: "Dice UI",
    url: "https://github.com/sadmann7/diceui/blob/040e842d4119260c22a59bf7e9d5cc3808e09efb/docs/registry/bases/base/ui/timeline.tsx",
  },

  {
    path: "operator/dice/key-value",
    library: "Dice UI",
    url: "https://github.com/sadmann7/diceui/blob/040e842d4119260c22a59bf7e9d5cc3808e09efb/docs/registry/bases/base/ui/key-value.tsx",
  },
  {
    path: "operator/dice/tags-input",
    library: "Dice UI",
    url: "https://github.com/sadmann7/diceui/blob/040e842d4119260c22a59bf7e9d5cc3808e09efb/docs/registry/bases/base/ui/tags-input.tsx",
  },
  {
    path: "operator/dice/stat",
    library: "Dice UI",
    url: "https://github.com/sadmann7/diceui/blob/040e842d4119260c22a59bf7e9d5cc3808e09efb/docs/registry/bases/base/ui/stat.tsx",
  },
  {
    path: "operator/dice/gauge",
    library: "Dice UI",
    url: "https://github.com/sadmann7/diceui/blob/040e842d4119260c22a59bf7e9d5cc3808e09efb/docs/registry/bases/base/ui/gauge.tsx",
  },

  {
    path: "operator/dice/sortable",
    library: "Dice UI",
    url: "https://github.com/sadmann7/diceui/blob/040e842d4119260c22a59bf7e9d5cc3808e09efb/docs/registry/bases/base/ui/sortable.tsx",
  },

  {
    path: "operator/elements/message",
    library: "AI Elements",
    url: "https://github.com/vercel/ai-elements/blob/6a9d5b1822ffb10bba4bd97175f01edd7d8651cd/packages/elements/src/message.tsx",
  },
  {
    path: "operator/elements/attachments",
    library: "AI Elements",
    url: "https://github.com/vercel/ai-elements/blob/6a9d5b1822ffb10bba4bd97175f01edd7d8651cd/packages/elements/src/attachments.tsx",
  },
  {
    path: "operator/elements/audio-player",
    library: "AI Elements",
    url: "https://github.com/vercel/ai-elements/blob/6a9d5b1822ffb10bba4bd97175f01edd7d8651cd/packages/elements/src/audio-player.tsx",
  },
  {
    path: "operator/elements/prompt-input",
    library: "AI Elements",
    url: "https://github.com/vercel/ai-elements/blob/6a9d5b1822ffb10bba4bd97175f01edd7d8651cd/packages/elements/src/prompt-input.tsx",
  },

  {
    path: "operator/elements/transcription",
    library: "AI Elements",
    url: "https://github.com/vercel/ai-elements/blob/6a9d5b1822ffb10bba4bd97175f01edd7d8651cd/packages/elements/src/transcription.tsx",
  },
  {
    path: "operator/elevenlabs/waveform",
    library: "ElevenLabs UI",
    url: "https://github.com/elevenlabs/ui/blob/23c31bd3088814215a8b5d0bfb56b327cad1a578/apps/www/registry/elevenlabs-ui/ui/waveform.tsx",
  },
  {
    path: "operator/ai-artifact",
    library: "SmoothUI",
    url: "https://github.com/educlopez/smoothui/blob/b6312bce2b6f2ed95d8a6e98a592857884f5ea9e/packages/smoothui/components/ai-artifact/index.tsx",
  },
  {
    path: "operator/animated-stepper",
    library: "SmoothUI",
    url: "https://github.com/educlopez/smoothui/blob/b6312bce2b6f2ed95d8a6e98a592857884f5ea9e/packages/smoothui/components/animated-stepper/index.tsx",
  },
  {
    path: "operator/panel-presence",
    library: "Animate UI",
    url: "https://github.com/imskyleen/animate-ui/tree/efeb96ffd7a3b7a4868667e4ac3c346620fb3044/apps/www/registry",
  },
  {
    path: "operator/sidebar",
    library: "Animate UI",
    url: "https://github.com/imskyleen/animate-ui/blob/efeb96ffd7a3b7a4868667e4ac3c346620fb3044/apps/www/registry/components/radix/sidebar/index.tsx",
  },
  {
    path: "operator/resizable",
    library: "shadcn/ui",
    url: "https://github.com/educlopez/smoothui/blob/b6312bce2b6f2ed95d8a6e98a592857884f5ea9e/packages/shadcn-ui/components/ui/resizable.tsx",
  },
  {
    path: "operator/spotlight",
    library: "Motion Primitives",
    url: "https://github.com/ibelick/motion-primitives/blob/120f64f6ca60348e251f929e9c81f11ccbe45eda/components/core/spotlight.tsx",
  },
] as const;
