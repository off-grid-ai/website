/// <reference types="vite/client" />
import { Segmented } from "@offgrid/ui/operator/segmented";
import { useEffect, useRef, useState } from "react";
import {
  AnimatePresence,
  motion,
  useInView,
  useReducedMotion,
} from "motion/react";
import { Film, RotateCcw } from "lucide-react";
import { Button } from "@offgrid/ui/operator/coss/button";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectPopup,
  SelectItem,
} from "@offgrid/ui/operator/coss/select";
import {
  AttachmentList,
  type ProcessingAttachment,
} from "@offgrid/ui/operator/workflows/attachments";
import {
  QueuedComposer,
  type QueuedMessage,
  type QueueEdit,
} from "@offgrid/ui/operator/workflows/queue";
import {
  VoiceCapture,
  type VoiceCapturePhase,
  type VoiceCaptureMode,
} from "@offgrid/ui/operator/workflows/voice-capture";
import {
  FilePreview,
  type FilePreviewState,
} from "@offgrid/ui/operator/media/file-preview";
import { Stage } from "./stage";
import testVideo from "./fixtures/video-test-pattern.webm?url";
import { AutoHeight, LiveStatus } from "@offgrid/ui/operator/presence";

const ease = [0.16, 1, 0.3, 1] as const;

const PHASE_LABELS: Record<VoiceCapturePhase, string> = {
  idle: "Ready",
  opening: "Opening microphone",
  listening: "Listening",
  recording: "Recording",
  transcribing: "Transcribing",
  suspended: "Paused",
  error: "Failed",
  "no-speech": "No speech",
  "permission-denied": "Access denied",
};
const DICTATION =
  "Review the local model results and confirm the release checklist before Friday.".split(
    " ",
  );

const SAMPLE_FILES: ProcessingAttachment[] = [
  {
    id: "meeting-audio",
    name: "meeting-audio.wav",
    size: "18.2 MB",
    mediaType: "audio/wav",
    status: "incoming",
    progress: 12,
  },
  {
    id: "notes",
    name: "notes.pdf",
    size: "240 KB",
    mediaType: "application/pdf",
    status: "processing",
    progress: 40,
  },
  {
    id: "scan",
    name: "scan.pdf",
    size: "3.1 MB",
    mediaType: "application/pdf",
    status: "error",
    message: "The file could not be decoded.",
  },
  {
    id: "shared-recording",
    name: "shared-recording.mp4",
    size: "96 MB",
    mediaType: "video/mp4",
    status: "unavailable",
  },
];

const PREVIEW_KINDS = [
  { id: "text", label: "Text" },
  { id: "video", label: "Video" },
  { id: "loading", label: "Loading" },
  { id: "empty", label: "Empty" },
  { id: "binary", label: "Binary" },
  { id: "unavailable", label: "Missing" },
  { id: "error", label: "Error" },
] as const;
type PreviewKind = (typeof PREVIEW_KINDS)[number]["id"];

const pending = (file: ProcessingAttachment) =>
  file.status === "incoming" || file.status === "processing";

/** One step of local, simulated file handling: receive, then process, then ready. */
function advance(file: ProcessingAttachment): ProcessingAttachment {
  if (!pending(file)) return file;
  const progress = Math.min(100, (file.progress ?? 0) + 2 + Math.random() * 5);
  if (progress < 100) return { ...file, progress };
  return file.status === "incoming"
    ? { ...file, status: "processing", progress: 0 }
    : { ...file, status: "ready", progress: undefined, message: undefined };
}

/** Ticks pending files forward while any are pending, then stops. */
function useProcessing(
  files: readonly ProcessingAttachment[],
  setFiles: (
    update: (current: ProcessingAttachment[]) => ProcessingAttachment[],
  ) => void,
  enabled = true,
) {
  const active = enabled && files.some(pending);
  useEffect(() => {
    if (!active) return;
    const id = setInterval(
      () => setFiles((current) => current.map(advance)),
      140,
    );
    return () => clearInterval(id);
  }, [active, setFiles]);
}

function VoiceStage() {
  const reduceMotion = useReducedMotion();
  const [phase, setPhase] = useState<VoiceCapturePhase>("idle");
  const [mode, setMode] = useState<VoiceCaptureMode>("tap");
  const [elapsed, setElapsed] = useState(0);
  const [levels, setLevels] = useState<number[]>(() => Array(28).fill(0.05));
  const [words, setWords] = useState(0);
  const [transcript, setTranscript] = useState("");
  const [notice, setNotice] = useState(
    "No microphone is opened in this preview.",
  );
  const timers = useRef<Array<ReturnType<typeof setTimeout>>>([]);
  const later = (fn: () => void, ms: number) =>
    timers.current.push(setTimeout(fn, ms));
  const clearTimers = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  const finishRef = useRef<() => void>(() => {});

  // While "recording", the signal scrolls and words arrive; it ends itself after 12 seconds.
  useEffect(() => {
    if (phase !== "recording") return;
    const started = performance.now();
    const stop = setTimeout(() => finishRef.current(), 12000);
    const id = setInterval(() => {
      const ms = performance.now() - started;
      setElapsed(ms);
      setWords(Math.min(DICTATION.length, Math.floor(ms / 320)));
      if (!reduceMotion)
        setLevels((current) => [
          ...current.slice(1),
          0.15 + Math.abs(Math.sin(ms / 170)) * 0.55 + Math.random() * 0.3,
        ]);
    }, 90);
    return () => {
      clearInterval(id);
      clearTimeout(stop);
    };
  }, [phase, reduceMotion]);

  const record = () => {
    clearTimers();
    setElapsed(0);
    setWords(0);
    setTranscript("");
    setLevels(Array(28).fill(0.05));
    setPhase("opening");
    later(() => setPhase("listening"), 600);
    later(() => setPhase("recording"), 1300);
  };
  const finish = () => {
    clearTimers();
    setPhase("transcribing");
    later(() => {
      setTranscript(DICTATION.join(" "));
      setPhase("idle");
      setNotice("Transcript ready.");
    }, 1200);
  };
  useEffect(() => {
    finishRef.current = finish;
  });
  const reset = (next: VoiceCapturePhase, message: string) => {
    clearTimers();
    setPhase(next);
    setTranscript("");
    setNotice(message);
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
          Dictation
        </span>
        <Select
          value={phase}
          onValueChange={(next) => {
            if (next)
              reset(
                next,
                `Showing the ${PHASE_LABELS[next].toLowerCase()} state.`,
              );
          }}
        >
          <SelectTrigger
            size="sm"
            aria-label="Voice state example"
            className="w-48"
          >
            <SelectValue>
              {(value: VoiceCapturePhase) => PHASE_LABELS[value]}
            </SelectValue>
          </SelectTrigger>
          <SelectPopup>
            {(Object.keys(PHASE_LABELS) as VoiceCapturePhase[]).map((entry) => (
              <SelectItem key={entry} value={entry}>
                {PHASE_LABELS[entry]}
              </SelectItem>
            ))}
          </SelectPopup>
        </Select>
      </div>
      <AutoHeight>
        <VoiceCapture
          phase={phase}
          mode={mode}
          onModeChange={setMode}
          elapsedMs={
            phase === "recording" || phase === "transcribing" ? elapsed : 0
          }
          amplitudes={phase === "recording" ? levels : undefined}
          interimTranscript={
            phase === "recording" && words > 0
              ? `${DICTATION.slice(0, words).join(" ")}…`
              : undefined
          }
          shortcutHint="Hold your configured voice shortcut to dictate."
          onStart={record}
          onStop={finish}
          onCancel={() => {
            reset("idle", "Recording discarded.");
            setWords(0);
          }}
          onResume={record}
          onOpenSettings={() => setNotice("Voice settings would open here.")}
        />
        <AnimatePresence initial={false}>
          {transcript && (
            <motion.figure
              key={transcript}
              initial={{ opacity: 0, y: 8, filter: "blur(6px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, filter: "blur(6px)" }}
              transition={{ duration: 0.5, ease }}
              className="mt-6 space-y-2 border-l border-primary/50 pl-4"
            >
              <figcaption className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                Transcript
              </figcaption>
              <blockquote className="text-[14px] font-light leading-relaxed">
                {transcript}
              </blockquote>
            </motion.figure>
          )}
        </AnimatePresence>
      </AutoHeight>
      <LiveStatus travel="across" as="span" className="block text-[11.5px]">
        {notice}
      </LiveStatus>
    </div>
  );
}

function AttachmentStage() {
  const [files, setFiles] = useState<ProcessingAttachment[]>(SAMPLE_FILES);
  const [notice, setNotice] = useState("");
  const root = useRef<HTMLDivElement>(null);
  const inView = useInView(root, { amount: 0.4 });
  useProcessing(files, setFiles, inView);
  const busy = files.some(pending);
  return (
    <div ref={root} className="space-y-6">
      <div aria-busy={busy}>
        <AttachmentList
          layout="rows"
          attachments={files}
          onOpen={(id) =>
            setNotice(
              `${files.find((file) => file.id === id)?.name} would open here.`,
            )
          }
          onRetry={(id) =>
            setFiles((current) =>
              current.map((file) =>
                file.id === id
                  ? {
                      ...file,
                      status: "incoming",
                      progress: 0,
                      message: undefined,
                    }
                  : file,
              ),
            )
          }
        />
      </div>
      <div className="flex flex-wrap items-center gap-4">
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            setFiles(SAMPLE_FILES);
            setNotice("");
          }}
        >
          <RotateCcw />
          Replay
        </Button>
        <LiveStatus travel="across" as="span" className="block text-[11.5px]">
          {notice ||
            (busy
              ? "Receiving and processing files…"
              : `${files.filter((file) => file.status === "ready").length} of ${files.length} files ready.`)}
        </LiveStatus>
      </div>
    </div>
  );
}

function QueueStage() {
  const [value, setValue] = useState("");
  const [items, setItems] = useState<QueuedMessage[]>([]);
  const [edit, setEdit] = useState<QueueEdit | null>(null);
  const [draftAttachments, setDraftAttachments] = useState<
    ProcessingAttachment[]
  >([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [suggestion, setSuggestion] = useState(
    "Summarize the attached notes in three bullets.",
  );
  const [notice, setNotice] = useState("");
  const fileInput = useRef<HTMLInputElement>(null);
  const objectUrls = useRef<string[]>([]);
  const timers = useRef<Array<ReturnType<typeof setTimeout>>>([]);
  useEffect(
    () => () => {
      objectUrls.current.forEach((url) => URL.revokeObjectURL(url));
      timers.current.forEach(clearTimeout);
    },
    [],
  );
  useProcessing(draftAttachments, setDraftAttachments);

  const queue = (
    text: string,
    attachments: readonly ProcessingAttachment[] = [],
  ) => {
    setItems((current) => [
      ...current,
      { id: crypto.randomUUID(), text, attachments, state: "queued" },
    ]);
    setValue("");
    setDraftAttachments([]);
    setNotice("Message queued.");
  };
  const update = (id: string, change: Partial<QueuedMessage>) =>
    setItems((current) =>
      current.map((item) => (item.id === id ? { ...item, ...change } : item)),
    );
  const deliver = (id: string) => {
    update(id, { state: "sending" });
    setNotice("Sending…");
    timers.current.push(
      setTimeout(() => {
        update(id, { state: "sent" });
        setNotice("Delivered to this preview. Nothing left the device.");
      }, 1100),
    );
  };

  return (
    <div className="space-y-5">
      <input
        ref={fileInput}
        type="file"
        multiple
        aria-label="Files for next message"
        className="sr-only"
        tabIndex={-1}
        onChange={(event) => {
          const files = Array.from(event.currentTarget.files || []);
          setDraftAttachments((current) => [
            ...current,
            ...files.map((file): ProcessingAttachment => {
              const url = URL.createObjectURL(file);
              objectUrls.current.push(url);
              return {
                id: crypto.randomUUID(),
                name: file.name,
                mediaType: file.type || "application/octet-stream",
                url,
                status: "incoming",
                progress: 0,
              };
            }),
          ]);
          event.currentTarget.value = "";
        }}
      />
      <AutoHeight>
        <QueuedComposer
          density="compact"
          items={items}
          edit={edit}
          value={value}
          onValueChange={setValue}
          onQueue={queue}
          draftAttachments={draftAttachments}
          onQueueWithAttachments={queue}
          onAddAttachments={() => fileInput.current?.click()}
          onRemoveDraftAttachment={(id) =>
            setDraftAttachments((current) =>
              current.filter((item) => item.id !== id),
            )
          }
          suggestion={!value && suggestion ? suggestion : undefined}
          onAcceptSuggestion={(text) => {
            setValue(text);
            setSuggestion("");
          }}
          onDismissSuggestion={() => setSuggestion("")}
          copiedId={copiedId}
          onCopy={async (id) => {
            const item = items.find((entry) => entry.id === id);
            if (!item) return;
            try {
              await navigator.clipboard.writeText(
                [
                  item.text,
                  ...(item.attachments || []).map((file) => file.name),
                ]
                  .filter(Boolean)
                  .join("\n"),
              );
              setCopiedId(id);
              setNotice("Message copied.");
            } catch {
              setCopiedId(null);
              setNotice("The message could not be copied.");
            }
          }}
          onEdit={(id) =>
            setEdit({
              id,
              text: items.find((item) => item.id === id)?.text || "",
            })
          }
          onEditChange={(text) =>
            setEdit((current) => (current ? { ...current, text } : null))
          }
          onSaveEdit={() => {
            if (edit) update(edit.id, { text: edit.text });
            setEdit(null);
            setNotice("Message updated.");
          }}
          onCancelEdit={() => setEdit(null)}
          onMove={(id, direction) =>
            setItems((current) => {
              const next = [...current];
              const index = next.findIndex((item) => item.id === id);
              [next[index], next[index + direction]] = [
                next[index + direction],
                next[index],
              ];
              return next;
            })
          }
          onSendNow={deliver}
          onCancel={(id) => {
            update(id, { state: "cancelled" });
            setNotice("Message cancelled.");
          }}
          onRetry={deliver}
          onRemove={(id) =>
            setItems((current) => current.filter((item) => item.id !== id))
          }
        />
      </AutoHeight>
      <LiveStatus travel="across" as="span" className="block text-[11.5px]">
        {notice}
      </LiveStatus>
    </div>
  );
}

function PreviewStage() {
  const [kind, setKind] = useState<PreviewKind>("text");
  const [videoSrc, setVideoSrc] = useState(testVideo);
  const [videoName, setVideoName] = useState("Test pattern");
  const [notice, setNotice] = useState("");
  const videoInput = useRef<HTMLInputElement>(null);
  const objectUrl = useRef<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(
    () => () => {
      if (objectUrl.current) URL.revokeObjectURL(objectUrl.current);
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );

  const states: Record<PreviewKind, FilePreviewState> = {
    text: {
      kind: "text",
      text: "# Meeting notes\n\nReview the local model results.\nConfirm the release checklist.\nShare the summary with the team.\n",
      truncated: true,
    },
    video: { kind: "video", src: videoSrc },
    loading: { kind: "loading", message: "Reading meeting-notes.md…" },
    empty: { kind: "text", text: "" },
    binary: { kind: "binary" },
    unavailable: { kind: "unavailable" },
    error: { kind: "error", message: "The file could not be read." },
  };
  const choose = (next: PreviewKind) => {
    if (timer.current) clearTimeout(timer.current);
    setKind(next);
    setNotice("");
  };

  return (
    <div className="space-y-8">
      <Segmented
        label="File preview state"
        value={kind}
        options={PREVIEW_KINDS}
        onValueChange={(value) => choose(value as PreviewKind)}
      />
      <AutoHeight>
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.div
            key={kind === "video" ? `video-${videoSrc}` : kind}
            initial={{ opacity: 0, y: 8, filter: "blur(6px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            exit={{ opacity: 0, y: -4, filter: "blur(6px)" }}
            transition={{ duration: 0.4, ease }}
            // CodeMirror's default light theme wins over the operator theme
            // inside FilePreview; keep the editor on the specimen surface.
            className="overflow-hidden rounded-xl [&_.cm-activeLine]:bg-transparent! [&_.cm-activeLineGutter]:bg-transparent! [&_.cm-content]:py-3! [&_.cm-editor]:rounded-xl [&_.cm-editor]:bg-foreground/[0.03]! [&_.cm-editor]:text-[12.5px] [&_.cm-gutters]:border-border/40! [&_.cm-gutters]:bg-transparent! [&_.cm-gutters]:text-muted-foreground/60!"
          >
            <FilePreview
              preview={states[kind]}
              onRetry={() => {
                setKind("loading");
                setNotice("Reading the file again…");
                timer.current = setTimeout(() => {
                  setKind("text");
                  setNotice("Preview restored.");
                }, 1200);
              }}
              onOpenFull={() => setNotice("The full file would open here.")}
            />
          </motion.div>
        </AnimatePresence>
      </AutoHeight>
      <input
        ref={videoInput}
        type="file"
        accept="video/*"
        aria-label="Select a local video"
        className="sr-only"
        tabIndex={-1}
        onChange={(event) => {
          const file = event.currentTarget.files?.[0];
          if (!file) return;
          if (objectUrl.current) URL.revokeObjectURL(objectUrl.current);
          objectUrl.current = URL.createObjectURL(file);
          setVideoSrc(objectUrl.current);
          setVideoName(file.name);
          choose("video");
          event.currentTarget.value = "";
        }}
      />
      <div className="flex min-h-8 flex-wrap items-center gap-3">
        <AnimatePresence initial={false}>
          {kind === "video" && (
            <motion.span
              key="choose"
              initial={{ opacity: 0, x: -6, filter: "blur(4px)" }}
              animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, x: -6, filter: "blur(4px)" }}
              transition={{ duration: 0.35, ease }}
            >
              <Button
                size="sm"
                variant="outline"
                onClick={() => videoInput.current?.click()}
              >
                <Film />
                Choose a local video
              </Button>
            </motion.span>
          )}
          {kind === "video" && videoSrc !== testVideo && (
            <motion.span
              key="reset"
              initial={{ opacity: 0, x: -6, filter: "blur(4px)" }}
              animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, x: -6, filter: "blur(4px)" }}
              transition={{ duration: 0.35, ease }}
            >
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setVideoSrc(testVideo);
                  setVideoName("Test pattern");
                  choose("video");
                }}
              >
                Use test pattern
              </Button>
            </motion.span>
          )}
        </AnimatePresence>
        <span className="ml-auto">
          <LiveStatus travel="across" as="span" className="block text-[11.5px]">
            {notice || (kind === "video" ? `Playing: ${videoName}` : "")}
          </LiveStatus>
        </span>
      </div>
    </div>
  );
}

export function ChatCompletionWorkshop() {
  return (
    <div className="min-w-0">
      <Stage
        index={1}
        kicker="Voice"
        title="Dictation that shows it is listening"
        description="Start a recording and the signal scrolls, the clock runs and words appear as they are heard. Pick any state to see how failures read. No microphone is opened."
        sources={["Off Grid workflows", "ElevenLabs UI", "Coss"]}
      >
        <VoiceStage />
      </Stage>

      <Stage
        index={2}
        kicker="Attachments"
        title="Files that report their progress"
        description="Each file is received, then processed, with progress that eases forward. Failures say what went wrong and offer a retry in place."
        sources={["AI Elements", "Coss"]}
      >
        <AttachmentStage />
      </Stage>

      <Stage
        index={3}
        kicker="Queue"
        title="Messages that wait their turn"
        description="Write ahead while the model is busy. Queued messages can be edited, reordered, sent now or cancelled, and files must finish processing before they can join the queue."
        sources={["AI Elements", "Off Grid workflows", "Coss"]}
      >
        <QueueStage />
      </Stage>

      <Stage
        index={4}
        kicker="Previews"
        title="One surface for every kind of file"
        description="Text, video and every way a file can fail share one frame. Switching states cross-fades and the frame eases to its new height."
        sources={["CodeMirror", "Media Chrome", "Motion Primitives", "Coss"]}
      >
        <PreviewStage />
      </Stage>
    </div>
  );
}
