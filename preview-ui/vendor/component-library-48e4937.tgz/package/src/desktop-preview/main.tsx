/// <reference types="vite/client" />
import { StrictMode, Suspense, lazy, useEffect, useState } from "react";
import { createRoot } from "react-dom/client";
import { AnimatePresence, MotionConfig, motion } from "motion/react";
import { ArrowUpRight, Moon, Sun } from "lucide-react";
import { AliveProvider, LivingField } from "@offgrid/ui/operator/alive";
import { TextEffect } from "@offgrid/ui/operator/text-effect";
import { Input } from "@offgrid/ui/operator/coss/input";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "@offgrid/ui/operator/coss/table";
import { sourceInventory } from "./source-inventory";
import "./preview.css";

const WorkspaceWorkshop = lazy(() =>
  import("./workspace-workshop").then((module) => ({
    default: module.WorkspaceWorkshop,
  })),
);
const ControlsWorkshop = lazy(() =>
  import("./controls-workshop").then((module) => ({
    default: module.ControlsWorkshop,
  })),
);
const OverlaysWorkshop = lazy(() =>
  import("./overlays-workshop").then((module) => ({
    default: module.OverlaysWorkshop,
  })),
);
const CollectionsWorkshop = lazy(() =>
  import("./collections-workshop").then((module) => ({
    default: module.CollectionsWorkshop,
  })),
);
const ChatMediaWorkshop = lazy(() =>
  import("./chat-media-workshop").then((module) => ({
    default: module.ChatMediaWorkshop,
  })),
);
const VirtualWorkshop = lazy(() =>
  import("./virtual-workshop").then((module) => ({
    default: module.VirtualWorkshop,
  })),
);

const MediaWorkshop = lazy(() =>
  import("./media-workshop").then((module) => ({
    default: module.MediaWorkshop,
  })),
);
const CompletionWorkshop = lazy(() =>
  import("./completion-workshop").then((module) => ({
    default: module.CompletionWorkshop,
  })),
);
const InspectionWorkshop = lazy(() =>
  import("./inspection-workshop").then((module) => ({
    default: module.InspectionWorkshop,
  })),
);
const ProWorkshop = lazy(() =>
  import("./pro-workshop").then((module) => ({ default: module.ProWorkshop })),
);
const SetupWorkshop = lazy(() =>
  import("./setup-workshop").then((module) => ({
    default: module.SetupWorkshop,
  })),
);
const ChatCompletionWorkshop = lazy(() =>
  import("./chat-completion-workshop").then((module) => ({
    default: module.ChatCompletionWorkshop,
  })),
);
type View = { id: string; label: string; summary: string };

const views: View[] = [
  {
    id: "settings-workshop",
    label: "Controls & settings",
    summary: "Fields, switches and sliders that answer every touch.",
  },
  {
    id: "overlays-workshop",
    label: "Menus & dialogs",
    summary: "Surfaces that roll open from where you asked for them.",
  },
  {
    id: "collections-workshop",
    label: "Models & downloads",
    summary: "Catalogues, progress and installs that stay legible in motion.",
  },
  {
    id: "workspace-workshop",
    label: "Workspace & data",
    summary: "Tables, trees and panes for the work itself.",
  },
  {
    id: "chat-media-workshop",
    label: "Chat & media",
    summary: "Conversation, reasoning and tools, streamed as they happen.",
  },
  {
    id: "virtual-workshop",
    label: "Large collections",
    summary: "Thousands of rows that scroll like ten.",
  },
  {
    id: "media-workshop",
    label: "Media & documents",
    summary: "Recordings, PDFs and code in one visual language.",
  },
  {
    id: "completion-workshop",
    label: "Queue & secrets",
    summary: "Work in flight and values that should stay hidden.",
  },
  {
    id: "inspection-workshop",
    label: "Charts & artifacts",
    summary: "Numbers that move and artifacts you can open up.",
  },
  {
    id: "pro-workshop",
    label: "Tasks & daily work",
    summary: "Agenda, routines and the agent's running timeline.",
  },
  {
    id: "setup-workshop",
    label: "Setup & permissions",
    summary: "First run, consent and recovery, without the dread.",
  },
  {
    id: "chat-completion-workshop",
    label: "Voice & attachments",
    summary: "Capture, transcribe and attach, with the state always visible.",
  },
  {
    id: "sources",
    label: "Source inventory",
    summary: "Every component, the library it comes from, pinned.",
  },
];

const pad = (n: number) => String(n).padStart(2, "0");

function readView() {
  const section = window.location.hash.slice(1);
  return views.some(({ id }) => id === section) ? section : views[0].id;
}

function Rail({ view }: { view: string }) {
  return (
    <nav
      aria-label="Component collection"
      className="og-rail fixed inset-y-0 left-0 z-20 hidden w-[17rem] flex-col px-7 pb-8 pt-9 lg:flex"
    >
      <a href="#settings-workshop" className="group flex items-center gap-3">
        <span className="og-orb" aria-hidden />
        <span className="leading-tight">
          <span className="block text-[13px] tracking-tight">Off Grid</span>
          <span className="block text-[11px] text-muted-foreground">
            Operator UI
          </span>
        </span>
      </a>
      <p className="mt-14 mb-4 font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground/70">
        Collection
      </p>
      <ol className="-mx-3 flex flex-col">
        {views.map(({ id, label, summary }, index) => {
          const active = view === id;
          return (
            <li key={id} className="relative">
              {active && (
                <motion.span
                  layoutId="rail-active"
                  className="og-rail-active absolute inset-0 rounded-xl"
                  transition={{ type: "spring", stiffness: 380, damping: 34 }}
                />
              )}
              <a
                href={`#${id}`}
                aria-current={active ? "page" : undefined}
                className="og-rail-link relative flex flex-col px-3 py-[7px]"
              >
                <span className="flex items-baseline gap-3">
                  <span className="og-rail-index font-mono text-[10px] tabular-nums">
                    {pad(index + 1)}
                  </span>
                  <span className="og-rail-label text-[12.5px]">{label}</span>
                </span>
                <AnimatePresence initial={false}>
                  {active && (
                    <motion.span
                      initial={{ height: 0, opacity: 0, filter: "blur(4px)" }}
                      animate={{
                        height: "auto",
                        opacity: 1,
                        filter: "blur(0px)",
                      }}
                      exit={{ height: 0, opacity: 0, filter: "blur(4px)" }}
                      transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
                      className="block overflow-hidden pl-[1.85rem] text-[11px] leading-relaxed text-muted-foreground"
                    >
                      <span className="block pt-1 pb-1">{summary}</span>
                    </motion.span>
                  )}
                </AnimatePresence>
              </a>
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

const families = [
  ["coss", "Coss"],
  ["animate ui", "Animate UI"],
  ["ai elements", "AI Elements"],
  ["smoothui", "SmoothUI"],
  ["motion primitives", "Motion Primitives"],
] as const;

function familyOf(library: string) {
  const name = library.toLowerCase();
  return families.find(([key]) => name.includes(key))?.[1] ?? "Other";
}

const familyCounts = sourceInventory.reduce<Record<string, number>>(
  (counts, item) => {
    const family = familyOf(item.library);
    counts[family] = (counts[family] ?? 0) + 1;
    return counts;
  },
  {},
);
const familyChips = [
  ["All", sourceInventory.length] as const,
  ...[...families.map(([, label]) => label), "Other"]
    .filter((label) => familyCounts[label])
    .map((label) => [label, familyCounts[label]] as const),
];

function SourceInventory() {
  const [filter, setFilter] = useState("");
  const [family, setFamily] = useState("All");
  const rows = sourceInventory.filter(
    (item) =>
      (family === "All" || familyOf(item.library) === family) &&
      `${item.path} ${item.library}`
        .toLowerCase()
        .includes(filter.toLowerCase()),
  );
  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-6">
        <div className="w-full max-w-md">
          <label
            htmlFor="source-filter"
            className="mb-3 block font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground"
          >
            Find a component or library
          </label>
          <Input
            id="source-filter"
            placeholder="Try checkbox, chat, sidebar…"
            value={filter}
            onChange={(event) => setFilter(event.target.value)}
          />
        </div>
        <p
          role="status"
          className="font-mono text-[11px] tabular-nums text-muted-foreground"
        >
          {rows.length} of {sourceInventory.length} components
        </p>
      </div>
      <div
        role="radiogroup"
        aria-label="Library"
        className="flex flex-wrap gap-1.5"
      >
        {familyChips.map(([label, count]) => {
          const active = family === label;
          return (
            <button
              key={label}
              type="button"
              role="radio"
              aria-checked={active}
              onClick={() => setFamily(label)}
              className="relative rounded-full px-3 py-1.5 text-[11.5px] text-muted-foreground transition-colors duration-300 hover:text-foreground aria-checked:text-foreground"
            >
              {active && (
                <motion.span
                  layoutId="source-family"
                  className="absolute inset-0 rounded-full bg-primary/12 shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-primary)/0.4)]"
                  transition={{ type: "spring", bounce: 0.18, duration: 0.5 }}
                />
              )}
              <span className="relative">
                {label}
                <span className="ml-1.5 font-mono text-[10px] opacity-55">
                  {count}
                </span>
              </span>
            </button>
          );
        })}
      </div>
      <div className="og-glass overflow-x-auto rounded-2xl">
        <Table>
          <TableHeader>
            <TableRow className="font-mono text-[10px] uppercase tracking-[0.2em] [&_th]:font-normal [&_th]:text-muted-foreground">
              <TableHead>Import path</TableHead>
              <TableHead>Source library</TableHead>
              <TableHead className="text-right">Original source</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <AnimatePresence initial={false} mode="popLayout">
              {rows.map((item) => {
                const [scope, ...rest] = item.path.split("/");
                return (
                  <motion.tr
                    key={item.path}
                    layout="position"
                    initial={{ opacity: 0, y: -4, filter: "blur(3px)" }}
                    animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                    exit={{
                      opacity: 0,
                      filter: "blur(3px)",
                      transition: { duration: 0.18 },
                    }}
                    transition={{ duration: 0.38, ease: [0.16, 1, 0.3, 1] }}
                    data-slot="table-row"
                    className="og-source-row group relative border-b border-border/50 transition-colors duration-200 last:border-0 hover:bg-[rgb(var(--og-rgb-text)/0.025)]"
                  >
                    <TableCell>
                      <code className="font-mono text-[12px]">
                        <span className="text-muted-foreground/60">
                          {scope}/
                        </span>
                        {rest.join("/")}
                      </code>
                    </TableCell>
                    <TableCell className="text-[12.5px] text-muted-foreground">
                      {item.library}
                    </TableCell>
                    <TableCell className="text-right">
                      <a
                        className="inline-flex items-center gap-1.5 text-[12px] text-muted-foreground transition-colors duration-200 group-hover:text-brand"
                        href={item.url}
                        target="_blank"
                        rel="noreferrer"
                      >
                        View source
                        <ArrowUpRight
                          size={12}
                          className="transition-transform duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] group-hover:-translate-y-px group-hover:translate-x-px"
                        />
                      </a>
                    </TableCell>
                  </motion.tr>
                );
              })}
            </AnimatePresence>
          </TableBody>
        </Table>
        <AnimatePresence initial={false}>
          {rows.length === 0 && (
            <motion.p
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
              className="overflow-hidden px-4 text-center text-[12.5px] text-muted-foreground"
            >
              <span className="block py-10">
                Nothing matches “{filter}”. Try a library name such as Coss.
              </span>
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

export function App() {
  const [view, setView] = useState(readView);
  const [light, setLight] = useState(false);

  useEffect(() => {
    const sync = () => {
      const next = readView();
      if (window.location.hash.slice(1) !== next)
        window.history.replaceState(null, "", `#${next}`);
      setView((current) => {
        if (current !== next) window.scrollTo({ top: 0, behavior: "smooth" });
        return next;
      });
    };
    sync();
    window.addEventListener("hashchange", sync);
    return () => window.removeEventListener("hashchange", sync);
  }, []);
  useEffect(() => {
    document.documentElement.dataset.theme = light ? "light" : "dark";
    document.documentElement.classList.toggle("dark", !light);
  }, [light]);

  const index = views.findIndex(({ id }) => id === view);
  const current = views[index];

  return (
    <MotionConfig reducedMotion="user">
      <AliveProvider>
        <LivingField />
        <Rail view={view} />
        <div className="og-topbar fixed right-6 top-6 z-30 flex items-center gap-1 rounded-full p-1">
          <select
            aria-label="Section"
            className="og-section-select lg:hidden"
            value={view}
            onChange={(event) => {
              window.location.hash = event.target.value;
            }}
          >
            {views.map(({ id, label }) => (
              <option key={id} value={id}>
                {label}
              </option>
            ))}
          </select>
          <button
            type="button"
            className="og-pill-button"
            aria-label={
              light ? "Switch to dark theme" : "Switch to light theme"
            }
            onClick={() => setLight(!light)}
          >
            <AnimatePresence mode="popLayout" initial={false}>
              <motion.span
                key={light ? "moon" : "sun"}
                initial={{ rotate: -90, scale: 0.4, opacity: 0 }}
                animate={{ rotate: 0, scale: 1, opacity: 1 }}
                exit={{ rotate: 90, scale: 0.4, opacity: 0 }}
                transition={{ type: "spring", stiffness: 420, damping: 26 }}
                className="flex"
              >
                {light ? <Moon size={15} /> : <Sun size={15} />}
              </motion.span>
            </AnimatePresence>
          </button>
          <a
            className="og-pill-button gap-2 px-3 text-[11px]"
            href="https://github.com/wednesday-solutions/component-library-animations"
            target="_blank"
            rel="noreferrer"
          >
            Source <ArrowUpRight size={13} />
          </a>
        </div>

        <main className="relative min-h-dvh lg:pl-[17rem]">
          <div className="mx-auto w-full max-w-[1180px] px-6 pb-40 sm:px-10 lg:px-16">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={view}
                initial={{ opacity: 0, y: 24, filter: "blur(10px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -12, filter: "blur(8px)" }}
                transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
              >
                <header className="pb-20 pt-28 sm:pt-36">
                  <p className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                    <span className="og-live-dot" aria-hidden />
                    Chapter {pad(index + 1)}
                    <span className="text-muted-foreground/40">/</span>
                    {pad(views.length)}
                  </p>
                  <TextEffect
                    as="h1"
                    per="char"
                    preset="fade-in-blur"
                    speedReveal={2.4}
                    className="mt-6 text-[clamp(2.6rem,5.4vw,4.6rem)] font-light leading-[0.98] tracking-[-0.04em]"
                  >
                    {current.label}
                  </TextEffect>
                  <motion.p
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{
                      delay: 0.35,
                      duration: 0.6,
                      ease: [0.16, 1, 0.3, 1],
                    }}
                    className="mt-7 max-w-[34rem] text-[14px] leading-relaxed text-muted-foreground"
                  >
                    {current.summary}
                  </motion.p>
                </header>
                <section aria-label={current.label} className="og-stage">
                  <Suspense
                    fallback={
                      <div role="status" className="space-y-4">
                        <div
                          data-slot="skeleton"
                          className="h-10 w-72 rounded-xl bg-muted/40"
                        />
                        <div
                          data-slot="skeleton"
                          className="h-64 rounded-2xl bg-muted/30"
                        />
                        <span className="sr-only">Loading components…</span>
                      </div>
                    }
                  >
                    {view === "virtual-workshop" && <VirtualWorkshop />}
                    {view === "media-workshop" && <MediaWorkshop />}
                    {view === "inspection-workshop" && <InspectionWorkshop />}
                    {view === "pro-workshop" && <ProWorkshop />}
                    {view === "setup-workshop" && <SetupWorkshop />}
                    {view === "chat-completion-workshop" && (
                      <ChatCompletionWorkshop />
                    )}
                    {view === "completion-workshop" && <CompletionWorkshop />}
                    {view === "workspace-workshop" && <WorkspaceWorkshop />}
                    {view === "settings-workshop" && <ControlsWorkshop />}
                    {view === "overlays-workshop" && <OverlaysWorkshop />}
                    {view === "collections-workshop" && <CollectionsWorkshop />}
                    {view === "chat-media-workshop" && <ChatMediaWorkshop />}
                    {view === "sources" && <SourceInventory />}
                  </Suspense>
                </section>
                {index < views.length - 1 && (
                  <a
                    href={`#${views[index + 1].id}`}
                    className="og-next group mt-40 flex items-end justify-between gap-6 border-t border-border/60 pt-8"
                  >
                    <span>
                      <span className="block font-mono text-[10px] uppercase tracking-[0.24em] text-muted-foreground">
                        Next · {pad(index + 2)}
                      </span>
                      <span className="mt-3 block text-[clamp(1.6rem,3vw,2.4rem)] font-light tracking-[-0.03em]">
                        {views[index + 1].label}
                      </span>
                    </span>
                    <ArrowUpRight className="og-next-arrow mb-2 size-6 text-muted-foreground" />
                  </a>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </AliveProvider>
    </MotionConfig>
  );
}

const root = createRoot(document.getElementById("root")!);
root.render(
  <StrictMode>
    <App />
  </StrictMode>,
);

if (import.meta.hot) {
  import.meta.hot.dispose(() => root.unmount());
}
