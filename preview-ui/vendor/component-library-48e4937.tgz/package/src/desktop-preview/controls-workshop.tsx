import { useEffect, useRef, useState } from "react";
import { Segmented } from "@offgrid/ui/operator/segmented";
import { AnimatePresence, motion } from "motion/react";
import {
  Eye,
  EyeOff,
  Flame,
  Minus,
  MoreHorizontal,
  Plus,
  RefreshCw,
  Server,
  Settings2,
  Snowflake,
} from "lucide-react";
import { Button } from "@offgrid/ui/operator/coss/button";
import {
  Field,
  FieldLabel,
  FieldDescription,
  FieldError,
} from "@offgrid/ui/operator/coss/field";
import { Form } from "@offgrid/ui/operator/coss/form";
import { Input } from "@offgrid/ui/operator/coss/input";
import {
  InputGroup,
  InputGroupInput,
  InputGroupAddon,
} from "@offgrid/ui/operator/coss/input-group";
import { Textarea } from "@offgrid/ui/operator/coss/textarea";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectPopup,
  SelectItem,
} from "@offgrid/ui/operator/coss/select";
import {
  Combobox,
  ComboboxInput,
  ComboboxPopup,
  ComboboxList,
  ComboboxItem,
  ComboboxEmpty,
} from "@offgrid/ui/operator/coss/combobox";
import { Switch } from "@offgrid/ui/operator/animate/switch";
import { Checkbox } from "@offgrid/ui/operator/animate/checkbox";
import {
  RadioGroup,
  RadioGroupItem as Radio,
} from "@offgrid/ui/operator/animate/radio-group";
import { CopyButton } from "@offgrid/ui/operator/animate-ui/components/buttons/copy";
import ClickSpark from "@offgrid/ui/operator/bits/click-spark";
import ElasticSlider from "@offgrid/ui/operator/bits/elastic-slider";
import Counter from "@offgrid/ui/operator/bits/counter";
import { InteractiveHoverButton } from "@offgrid/ui/operator/magic/interactive-hover-button";
import { Magnetic } from "@offgrid/ui/operator/motion/magnetic";
import { TextMorph } from "@offgrid/ui/operator/motion/text-morph";
import { TextScramble } from "@offgrid/ui/operator/motion/text-scramble";
import { Stage } from "./stage";

const modelOptions = [
  "Gemma 4 · local",
  "Qwen 3.5 · local",
  "Llama 3.3 · local",
  "Custom model",
];
const runtimes = [
  { value: "automatic", label: "Automatic" },
  { value: "metal", label: "Metal · Apple GPU" },
  { value: "cpu", label: "CPU only" },
];
const presets = [
  {
    id: "precise",
    label: "Precise",
    temperature: 0.2,
    note: "Extraction and structured answers.",
  },
  {
    id: "balanced",
    label: "Balanced",
    temperature: 0.7,
    note: "Everyday questions and document work.",
  },
  {
    id: "creative",
    label: "Creative",
    temperature: 1.2,
    note: "Ideas and first drafts.",
  },
];
const EMERALD = "#34d399";
const ease = [0.16, 1, 0.3, 1] as const;

/** One quiet row: words on the left, the control on the right. */
function SettingRow({
  title,
  description,
  control,
  disabled,
}: {
  title: string;
  description: string;
  control: React.ReactNode;
  disabled?: boolean;
}) {
  return (
    <label
      data-disabled={disabled || undefined}
      className="group flex cursor-pointer items-center justify-between gap-8 py-5 data-disabled:cursor-not-allowed data-disabled:opacity-45"
    >
      <span className="min-w-0">
        <span className="block text-[13px] transition-colors group-hover:text-foreground">
          {title}
        </span>
        <span className="mt-1 block text-[11.5px] leading-relaxed text-muted-foreground">
          {description}
        </span>
      </span>
      {control}
    </label>
  );
}

/** Rolling digits with a calm stepper either side. */
function Stepper({
  label,
  value,
  onChange,
  min,
  max,
  step,
  disabled,
}: {
  label: string;
  value: number;
  onChange: (value: number) => void;
  min: number;
  max: number;
  step: number;
  disabled?: boolean;
}) {
  const set = (next: number) => onChange(Math.min(max, Math.max(min, next)));
  return (
    <div
      data-disabled={disabled || undefined}
      className="flex flex-col gap-4 transition-opacity data-disabled:opacity-40"
    >
      <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
        {label}
      </span>
      <div className="flex items-center gap-4">
        <Button
          size="icon-sm"
          variant="ghost"
          aria-label={`Decrease ${label}`}
          disabled={disabled || value <= min}
          onClick={() => set(value - step)}
        >
          <Minus />
        </Button>
        <span
          role="spinbutton"
          aria-label={label}
          aria-valuenow={value}
          aria-valuemin={min}
          aria-valuemax={max}
          aria-disabled={disabled || undefined}
          tabIndex={disabled ? -1 : 0}
          onKeyDown={(event) => {
            if (event.key === "ArrowUp") set(value + step);
            if (event.key === "ArrowDown") set(value - step);
          }}
          className="rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
        >
          <Counter
            value={value}
            fontSize={34}
            gap={1}
            horizontalPadding={2}
            fontWeight={300}
            gradientFrom="transparent"
            textColor="var(--foreground)"
          />
        </span>
        <Button
          size="icon-sm"
          variant="ghost"
          aria-label={`Increase ${label}`}
          disabled={disabled || value >= max}
          onClick={() => set(value + step)}
        >
          <Plus />
        </Button>
      </div>
    </div>
  );
}

/** Preview composition. Each stage pairs one control family with its sources. */
export function ControlsWorkshop() {
  // Actions
  const [check, setCheck] = useState<"idle" | "running" | "done">("idle");
  // Fields
  const [endpoint, setEndpoint] = useState("http://localhost:11434/v1");
  const [secret, setSecret] = useState("og_preview_key_not_a_secret");
  const [revealed, setRevealed] = useState(false);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved">(
    "idle",
  );
  const [savedProfile, setSavedProfile] = useState("");
  // Choices
  const [mode, setMode] = useState("balanced");
  const [background, setBackground] = useState(true);
  const [downloads, setDownloads] = useState(false);
  const [metered, setMetered] = useState(false);
  const [policy, setPolicy] = useState("ask");
  // Values
  const [temperature, setTemperature] = useState(0.7);
  const [context, setContext] = useState(8192);
  const [threads, setThreads] = useState(8);
  const [automaticThreads, setAutomaticThreads] = useState(true);
  // Pickers
  const [model, setModel] = useState<string | null>(modelOptions[0]);
  const [runtime, setRuntime] = useState<string | null>("automatic");
  const [cleanup, setCleanup] = useState<string | null>("ask");
  const [notice, setNotice] = useState("");

  const timers = useRef<Array<ReturnType<typeof setTimeout>>>([]);
  const later = (fn: () => void, ms: number) =>
    timers.current.push(setTimeout(fn, ms));
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const preset = presets.find(({ id }) => id === mode) ?? presets[1];
  const checkLabel =
    check === "running"
      ? "Checking models"
      : check === "done"
        ? "All models ready"
        : "Run model check";

  return (
    <div className="min-w-0">
      <Stage
        index={1}
        kicker="Actions"
        title="Buttons that answer back"
        description="Every press gives way and springs back. The primary action breathes, sparks where you click and says what it is doing in its own label."
        sources={[
          "Coss",
          "React Bits",
          "Motion Primitives",
          "Magic UI",
          "Animate UI",
        ]}
        specimenClassName="items-center"
      >
        <div className="flex flex-col items-center gap-12">
          <div className="flex flex-wrap items-center justify-center gap-4">
            <ClickSpark
              sparkColor={EMERALD}
              sparkCount={10}
              sparkRadius={26}
              style={{ width: "auto", height: "auto" }}
            >
              <Button
                size="lg"
                loading={false}
                aria-label={checkLabel}
                disabled={check === "running"}
                onClick={() => {
                  setCheck("running");
                  later(() => setCheck("done"), 1400);
                  later(() => setCheck("idle"), 3600);
                }}
                className="min-w-48"
              >
                <TextMorph as="span">{checkLabel}</TextMorph>
              </Button>
            </ClickSpark>
            <Button size="lg" variant="outline">
              Save draft
            </Button>
            <InteractiveHoverButton className="h-10 border-border/70 text-[13px] font-normal">
              Model library
            </InteractiveHoverButton>
          </div>
          <div className="flex items-center gap-2">
            {[
              { label: "Refresh", icon: RefreshCw },
              { label: "Settings", icon: Settings2 },
              { label: "More actions", icon: MoreHorizontal },
            ].map(({ label, icon: Icon }) => (
              <Magnetic key={label} intensity={0.35} range={90}>
                <Button size="icon" variant="ghost" aria-label={label}>
                  <Icon />
                </Button>
              </Magnetic>
            ))}
            <span className="mx-2 h-5 w-px bg-border" />
            <Magnetic intensity={0.35} range={90}>
              <CopyButton
                content="og_preview_key_not_a_secret"
                variant="ghost"
                aria-label="Copy access key"
              />
            </Magnetic>
          </div>
          <span role="status" className="sr-only">
            {check === "done" ? "All models ready." : ""}
          </span>
        </div>
      </Stage>

      <Stage
        index={2}
        kicker="Fields"
        title="Fields that light up while you type"
        description="Focus sends a beam around the edge, every keystroke ripples the field behind it, and errors rise in rather than appear."
        sources={["Coss", "Motion Primitives", "Off Grid alive"]}
      >
        <Form
          className="grid gap-x-8 gap-y-9 sm:grid-cols-2"
          onFormSubmit={(values) => {
            setSaveState("saving");
            const name = String(values.profileName);
            later(() => {
              setSavedProfile(name);
              setSaveState("saved");
            }, 650);
          }}
        >
          <Field name="profileName" validationMode="onBlur">
            <FieldLabel>Profile name</FieldLabel>
            <Input
              defaultValue="Local workspace"
              placeholder="Name this connection"
              required
              maxLength={64}
            />
            <FieldError match="valueMissing">Enter a profile name.</FieldError>
          </Field>
          <Field name="provider">
            <FieldLabel>Server type</FieldLabel>
            <Select
              defaultValue="ollama"
              items={[
                { value: "ollama", label: "Ollama" },
                { value: "compatible", label: "OpenAI-compatible" },
              ]}
              onValueChange={(value) =>
                setEndpoint(
                  value === "ollama"
                    ? "http://localhost:11434/v1"
                    : "http://localhost:8080/v1",
                )
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectPopup>
                <SelectItem value="ollama">Ollama</SelectItem>
                <SelectItem value="compatible">OpenAI-compatible</SelectItem>
              </SelectPopup>
            </Select>
          </Field>
          <Field
            name="endpoint"
            validationMode="onBlur"
            className="sm:col-span-2"
            validate={(value) => {
              if (!value) return "Enter the server address.";
              try {
                const url = new URL(String(value));
                if (!["http:", "https:"].includes(url.protocol))
                  return "Use an http or https address.";
              } catch {
                return "Enter a complete address, such as http://localhost:11434/v1.";
              }
              return null;
            }}
          >
            <FieldLabel>Server address</FieldLabel>
            <InputGroup>
              <InputGroupAddon>
                <Server aria-hidden="true" />
              </InputGroupAddon>
              <InputGroupInput
                value={endpoint}
                onValueChange={setEndpoint}
                placeholder="http://localhost:11434/v1"
                required
              />
            </InputGroup>
            <FieldDescription>
              Use the API address supplied by your server.
            </FieldDescription>
            <FieldError />
          </Field>
          <Field name="apiKey" className="sm:col-span-2">
            <FieldLabel>API key</FieldLabel>
            <InputGroup>
              <InputGroupInput
                type={revealed ? "text" : "password"}
                value={secret}
                onValueChange={setSecret}
                autoComplete="off"
              />
              <InputGroupAddon align="inline-end">
                <Button
                  size="icon-xs"
                  variant="ghost"
                  aria-label={revealed ? "Hide API key" : "Show API key"}
                  aria-pressed={revealed}
                  onClick={() => setRevealed(!revealed)}
                >
                  <AnimatePresence mode="popLayout" initial={false}>
                    <motion.span
                      key={revealed ? "hide" : "show"}
                      initial={{ opacity: 0, scale: 0.5, rotate: -30 }}
                      animate={{ opacity: 1, scale: 1, rotate: 0 }}
                      exit={{ opacity: 0, scale: 0.5, rotate: 30 }}
                      transition={{
                        type: "spring",
                        stiffness: 500,
                        damping: 28,
                      }}
                      className="flex"
                    >
                      {revealed ? <EyeOff /> : <Eye />}
                    </motion.span>
                  </AnimatePresence>
                </Button>
              </InputGroupAddon>
            </InputGroup>
            <FieldDescription>
              <TextScramble
                as="span"
                key={revealed ? "on" : "off"}
                duration={0.5}
                speed={0.03}
              >
                {revealed
                  ? "Visible on this device only."
                  : "Optional for local servers."}
              </TextScramble>
            </FieldDescription>
          </Field>
          <Field name="notes" className="sm:col-span-2">
            <FieldLabel>Connection notes</FieldLabel>
            <Textarea
              placeholder="Add context for this connection…"
              defaultValue="Use for local document search and quick drafts."
              rows={2}
            />
          </Field>
          <div className="flex flex-wrap items-center gap-4 sm:col-span-2">
            <Button
              type="submit"
              aria-label="Apply to preview"
              loading={saveState === "saving"}
            >
              Apply to preview
            </Button>
            <AnimatePresence mode="wait">
              <motion.span
                key={saveState}
                role="status"
                initial={{ opacity: 0, x: -6, filter: "blur(4px)" }}
                animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, x: 6, filter: "blur(4px)" }}
                transition={{ duration: 0.35, ease }}
                className="text-xs text-muted-foreground"
              >
                {saveState === "saving"
                  ? "Applying profile…"
                  : saveState === "saved"
                    ? `${savedProfile} applied to this preview.`
                    : ""}
              </motion.span>
            </AnimatePresence>
          </div>
        </Form>
      </Stage>

      <Stage
        index={3}
        kicker="Choices"
        title="Choices that settle into place"
        description="One pill glides between presets. Switches spring and bloom when they turn on, and dependent options wake only when they can be used."
        sources={["Motion Primitives", "Animate UI"]}
      >
        <div className="space-y-10">
          <div>
            <Segmented
              label="Generation preset"
              value={mode}
              options={presets}
              onValueChange={(value) => {
                const next = presets.find(({ id }) => id === value);
                if (!next) return;
                setMode(next.id);
                setTemperature(next.temperature);
              }}
            />
            <AnimatePresence mode="wait" initial={false}>
              <motion.p
                key={preset.id}
                initial={{ opacity: 0, y: 6, filter: "blur(4px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -6, filter: "blur(4px)" }}
                transition={{ duration: 0.35, ease }}
                className="mt-4 pl-2 text-[12px] text-muted-foreground"
              >
                {preset.note}
              </motion.p>
            </AnimatePresence>
          </div>

          <div className="divide-y divide-border/60">
            <SettingRow
              title="Run in the background"
              description="Keep local services available when the window is closed."
              control={
                <Switch checked={background} onCheckedChange={setBackground} />
              }
            />
            <SettingRow
              title="Download updates automatically"
              description="Prepare updates while the device is idle."
              control={
                <Switch checked={downloads} onCheckedChange={setDownloads} />
              }
            />
            <SettingRow
              title="Allow downloads on metered networks"
              description="Available when automatic downloads are on."
              disabled={!downloads}
              control={
                <Checkbox
                  checked={metered}
                  disabled={!downloads}
                  onCheckedChange={(checked) => setMetered(checked === true)}
                />
              }
            />
            <SettingRow
              title="Share device diagnostics"
              description="Disabled by the local-only policy."
              disabled
              control={<Switch disabled />}
            />
          </div>

          <fieldset>
            <legend className="mb-4 font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
              When a model is unavailable
            </legend>
            <RadioGroup
              value={policy}
              onValueChange={(value) => setPolicy(String(value))}
              aria-label="Model fallback"
              className="gap-4"
            >
              {[
                { value: "ask", label: "Ask me each time" },
                { value: "local", label: "Use another local model" },
                {
                  value: "remote",
                  label: "Use a remote server",
                  disabled: true,
                },
              ].map((option) => (
                <label
                  key={option.value}
                  className="flex cursor-pointer items-center gap-3 text-[13px] has-disabled:cursor-not-allowed has-disabled:opacity-45"
                >
                  <Radio value={option.value} disabled={option.disabled} />
                  {option.label}
                </label>
              ))}
            </RadioGroup>
          </fieldset>
        </div>
      </Stage>

      <Stage
        index={4}
        kicker="Values"
        title="Numbers you can feel"
        description="Drag past the end of a slider and it stretches. Counts roll digit by digit, so a change reads as movement, not a swap."
        sources={["React Bits"]}
      >
        <div className="space-y-14">
          <div className="flex flex-col items-center gap-2">
            <span className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
              Temperature
            </span>
            <ElasticSlider
              aria-label="Temperature"
              className="w-full max-w-md pt-4"
              value={temperature}
              onValueChange={(value: number) =>
                setTemperature(Math.round(value * 10) / 10)
              }
              startingValue={0}
              maxValue={2}
              isStepped
              stepSize={0.1}
              formatValue={(value) => value.toFixed(1)}
              leftIcon={<Snowflake className="size-4 text-muted-foreground" />}
              rightIcon={<Flame className="size-4 text-muted-foreground" />}
            />
            <p className="mt-6 text-[11.5px] text-muted-foreground">
              Lower values produce more consistent answers.
            </p>
          </div>
          <div className="grid gap-10 sm:grid-cols-2">
            <Stepper
              label="Context tokens"
              value={context}
              onChange={setContext}
              min={1024}
              max={131072}
              step={1024}
            />
            <div className="space-y-5">
              <Stepper
                label="CPU threads"
                value={threads}
                onChange={setThreads}
                min={1}
                max={32}
                step={1}
                disabled={automaticThreads}
              />
              <label className="flex cursor-pointer items-center gap-3 text-[12px] text-muted-foreground">
                <Switch
                  checked={automaticThreads}
                  onCheckedChange={setAutomaticThreads}
                  aria-label="Choose CPU threads automatically"
                />
                Choose automatically
              </label>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <Button
              variant="outline"
              onClick={() => {
                setTemperature(0.7);
                setContext(8192);
                setThreads(8);
                setAutomaticThreads(true);
                setMode("balanced");
                setNotice("Generation settings reset.");
              }}
            >
              Reset defaults
            </Button>
            <Button
              onClick={() =>
                setNotice(
                  `${preset.id} preset applied with ${context} context tokens.`,
                )
              }
            >
              Apply generation settings
            </Button>
            <AnimatePresence mode="wait">
              <motion.span
                key={notice}
                role="status"
                initial={{ opacity: 0, filter: "blur(4px)" }}
                animate={{ opacity: 1, filter: "blur(0px)" }}
                exit={{ opacity: 0, filter: "blur(4px)" }}
                className="text-xs text-muted-foreground"
              >
                {notice}
              </motion.span>
            </AnimatePresence>
          </div>
        </div>
      </Stage>

      <Stage
        index={5}
        kicker="Pickers"
        title="Lists that roll open from their trigger"
        description="Popups arrive as glass, their options cascade in, and the highlight leans toward the item you are about to choose."
        sources={["Coss", "Animate UI", "Off Grid alive"]}
      >
        <div className="grid gap-x-8 gap-y-9 sm:grid-cols-2">
          <Field className="sm:col-span-2">
            <FieldLabel>Default model</FieldLabel>
            <Combobox
              items={modelOptions}
              value={model}
              onValueChange={setModel}
            >
              <ComboboxInput
                placeholder="Search local models…"
                showClear
                triggerProps={{ "aria-label": "Show models" }}
                clearProps={{ "aria-label": "Clear model" }}
              />
              <ComboboxPopup>
                <ComboboxEmpty>No matching models.</ComboboxEmpty>
                <ComboboxList>
                  {(item: string) => (
                    <ComboboxItem key={item} value={item}>
                      {item}
                    </ComboboxItem>
                  )}
                </ComboboxList>
              </ComboboxPopup>
            </Combobox>
            <FieldDescription>
              The model used for new conversations.
            </FieldDescription>
          </Field>
          <Field>
            <FieldLabel>Runtime</FieldLabel>
            <Select items={runtimes} value={runtime} onValueChange={setRuntime}>
              <SelectTrigger>
                <SelectValue placeholder="Select a runtime" />
              </SelectTrigger>
              <SelectPopup>
                {runtimes.map((item) => (
                  <SelectItem key={item.value} value={item.value}>
                    {item.label}
                  </SelectItem>
                ))}
              </SelectPopup>
            </Select>
          </Field>
          <Field>
            <FieldLabel>Cache cleanup</FieldLabel>
            <Select
              items={[
                { value: "ask", label: "Ask before clearing" },
                {
                  value: "automatic",
                  label: "Clear unused cache automatically",
                },
              ]}
              value={cleanup}
              onValueChange={setCleanup}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectPopup>
                <SelectItem value="ask">Ask before clearing</SelectItem>
                <SelectItem value="automatic">
                  Clear unused cache automatically
                </SelectItem>
              </SelectPopup>
            </Select>
          </Field>
          <Field disabled className="sm:col-span-2">
            <FieldLabel>Model storage</FieldLabel>
            <Input
              value="~/Library/Application Support/Off Grid/models"
              readOnly
            />
            <FieldDescription>
              Managed by Off Grid for installed models.
            </FieldDescription>
          </Field>
          <p
            role="status"
            className="text-[12px] text-muted-foreground sm:col-span-2"
          >
            {model ? `${model} selected.` : "Select a model to continue."}
          </p>
        </div>
      </Stage>
    </div>
  );
}
