import {
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import {
  AnimatePresence,
  motion,
  useInView,
  useReducedMotion,
} from "motion/react";
import {
  Pause,
  Paperclip,
  Play,
  RefreshCw,
  RotateCcw,
  Send,
  Square,
} from "lucide-react";
import { Button } from "@offgrid/ui/operator/coss/button";
import { ScrollArea } from "@offgrid/ui/operator/coss/scroll-area";
import {
  ToggleGroup,
  ToggleGroupItem,
} from "@offgrid/ui/operator/coss/toggle-group";
import {
  Message,
  MessageContent,
  MessageResponse,
} from "@offgrid/ui/operator/elements/message";
import {
  Attachment,
  AttachmentInfo,
  AttachmentPreview,
  AttachmentRemove,
  Attachments,
} from "@offgrid/ui/operator/elements/attachments";
import {
  PromptInput,
  PromptInputActionAddAttachments,
  PromptInputActionMenu,
  PromptInputActionMenuContent,
  PromptInputActionMenuTrigger,
  PromptInputBody,
  PromptInputCommand,
  PromptInputCommandEmpty,
  PromptInputCommandGroup,
  PromptInputCommandInput,
  PromptInputCommandItem,
  PromptInputCommandList,
  PromptInputFooter,
  PromptInputHeader,
  PromptInputProvider,
  PromptInputSubmit,
  PromptInputTextarea,
  PromptInputTools,
  usePromptInputController,
  useProviderAttachments,
} from "@offgrid/ui/operator/elements/prompt-input";
import {
  Transcription,
  TranscriptionSegment,
} from "@offgrid/ui/operator/elements/transcription";
import { Waveform } from "@offgrid/ui/operator/elevenlabs/waveform";
import { TextShimmer } from "@offgrid/ui/operator/text-shimmer";
import { Stage } from "./stage";
import { AutoHeight } from "@offgrid/ui/operator/presence";

const PROMPT = "Summarize what changed in my local model notes.";
const RESPONSE = `## What changed this week

You moved private work to **local models**. Both are installed and the faster one is now the default.

| Model | Context | State |
| --- | ---: | --- |
| Qwen 3.5 | 32k | Ready |
| Gemma 4 | 16k | Available |

- [x] Read the source files
- [x] Keep code selectable
- [ ] Review the result

\`\`\`tsx
const result = await model.generate({
  prompt: "Summarize my notes",
  local: true,
});
\`\`\`

> Your files stay on your device. Links and code remain separate controls.

Inline math still renders: $$E = mc^2$$. [Read the component source](https://github.com/vercel/ai-elements).
`;

/** Streamdown fades each new word in, so text arrives as a flow, not a jump. */
const STREAM_ANIMATION = {
  animation: "blurIn",
  duration: 420,
  easing: "cubic-bezier(0.16, 1, 0.3, 1)",
  sep: "word",
} as const;

const COMMANDS = [
  { value: "/summarize", description: "Summarize the attached files" },
  { value: "/compare", description: "Compare two documents" },
  { value: "/extract", description: "Extract actions and decisions" },
];

const TONE_SECONDS = 6;
const TONE_SEGMENTS = [
  { text: "A low tone rises in,", startSecond: 0, endSecond: 1 },
  { text: "holds at 220 hertz", startSecond: 1, endSecond: 2 },
  { text: "and swells.", startSecond: 2, endSecond: 3 },
  { text: "It steps up", startSecond: 3, endSecond: 4 },
  { text: "to 330 hertz", startSecond: 4, endSecond: 5 },
  { text: "and fades out.", startSecond: 5, endSecond: 6 },
];

const EMERALD = "#34d399";
const ease = [0.16, 1, 0.3, 1] as const;
const rise = {
  initial: { opacity: 0, y: 8, filter: "blur(6px)" },
  animate: { opacity: 1, y: 0, filter: "blur(0px)" },
  exit: { opacity: 0, y: -4, filter: "blur(6px)" },
  transition: { duration: 0.45, ease },
};


// Local preview data only: PCM bytes and amplitude peaks describe the same six-second tone.
// There is no microphone, network request, or simulated model response.
function createTone() {
  const sampleRate = 8000;
  const count = sampleRate * TONE_SECONDS;
  const buffer = new ArrayBuffer(44 + count * 2);
  const view = new DataView(buffer);
  const text = (offset: number, value: string) => {
    for (let index = 0; index < value.length; index += 1)
      view.setUint8(offset + index, value.charCodeAt(index));
  };
  text(0, "RIFF");
  view.setUint32(4, buffer.byteLength - 8, true);
  text(8, "WAVE");
  text(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  text(36, "data");
  view.setUint32(40, count * 2, true);
  const peaks = Array<number>(120).fill(0);
  for (let index = 0; index < count; index += 1) {
    const time = index / sampleRate;
    const envelope =
      Math.sin((Math.PI * time) / TONE_SECONDS) ** 2 *
      (0.55 + 0.45 * Math.sin(time * 4) ** 2);
    const sample =
      Math.sin(time * Math.PI * 2 * (time < 3 ? 220 : 330)) * envelope * 0.18;
    view.setInt16(44 + index * 2, sample * 32767, true);
    const peak = Math.min(
      peaks.length - 1,
      Math.floor((index / count) * peaks.length),
    );
    peaks[peak] = Math.max(peaks[peak], Math.abs(sample) / 0.18);
  }
  return {
    url: URL.createObjectURL(new Blob([buffer], { type: "audio/wav" })),
    peaks,
  };
}

/** Advance to the end of the next word or two, so chunks never split a word. */
function nextChunk(text: string, from: number) {
  const target = Math.min(text.length, from + 10);
  const space = text.indexOf(" ", target);
  return space === -1 ? text.length : space + 1;
}

function formatTime(seconds: number) {
  const whole = Math.max(0, Math.floor(seconds));
  return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, "0")}`;
}

type StreamPhase = "waiting" | "thinking" | "streaming" | "done" | "stopped";

function StreamedConversation() {
  const reduceMotion = useReducedMotion();
  const root = useRef<HTMLDivElement>(null);
  const inView = useInView(root, { once: true, amount: 0.3 });
  const [phase, setPhase] = useState<StreamPhase>("waiting");
  const [shown, setShown] = useState(0);
  const [runs, setRuns] = useState(0);
  const viewport = useRef<HTMLDivElement>(null);
  const content = useRef<HTMLDivElement>(null);
  const stick = useRef(true);
  const autoTop = useRef(0);

  // Begin the first answer once the stage is actually on screen.
  useEffect(() => {
    if (!inView || phase !== "waiting") return;
    const id = setTimeout(() => setPhase("thinking"), 350);
    return () => clearTimeout(id);
  }, [inView, phase]);

  useEffect(() => {
    if (phase !== "thinking") return;
    const id = setTimeout(
      () => {
        if (reduceMotion) {
          setShown(RESPONSE.length);
          setPhase("done");
        } else setPhase("streaming");
      },
      reduceMotion ? 0 : 1100,
    );
    return () => clearTimeout(id);
  }, [phase, reduceMotion, runs]);

  useEffect(() => {
    if (phase !== "streaming") return;
    const id = setInterval(() => {
      setShown((count) => nextChunk(RESPONSE, count));
    }, 55);
    return () => clearInterval(id);
  }, [phase]);

  useEffect(() => {
    if (phase !== "streaming" || shown < RESPONSE.length) return;
    const id = setTimeout(() => setPhase("done"), 0);
    return () => clearTimeout(id);
  }, [phase, shown]);

  // Keep the newest words in view unless the reader has scrolled up.
  useEffect(() => {
    const element = viewport.current;
    const inner = content.current;
    if (!element || !inner) return;
    const observer = new ResizeObserver(() => {
      if (!stick.current) return;
      element.scrollTop = element.scrollHeight;
      autoTop.current = element.scrollTop;
    });
    observer.observe(inner);
    return () => observer.disconnect();
  }, []);

  const working = phase === "thinking" || phase === "streaming";
  const regenerate = () => {
    stick.current = true;
    autoTop.current = 0;
    viewport.current?.scrollTo({ top: 0 });
    setShown(0);
    setRuns((count) => count + 1);
    setPhase("thinking");
  };

  return (
    <div ref={root} className="space-y-5">
      <div
        ref={viewport}
        role="log"
        aria-label="Conversation"
        aria-busy={working}
        tabIndex={0}
        onScroll={(event) => {
          const element = event.currentTarget;
          // Our own scrolls report late; only a reader's scroll changes intent.
          if (Math.abs(element.scrollTop - autoTop.current) < 2) return;
          stick.current =
            element.scrollHeight - element.scrollTop - element.clientHeight <
            48;
        }}
        className="-mx-2 h-[26rem] overflow-y-auto overscroll-contain px-2 outline-none [mask-image:linear-gradient(to_bottom,transparent,#000_1.5rem,#000_calc(100%-1.5rem),transparent)] [scrollbar-color:rgb(var(--og-rgb-text)/0.12)_transparent] [scrollbar-width:thin]"
      >
        <div ref={content} className="space-y-6 py-6">
          <Message from="user">
            <MessageContent className="rounded-2xl! bg-foreground/[0.06]! px-4! py-2.5! text-[13px]">
              {PROMPT}
            </MessageContent>
          </Message>
          <Message from="assistant" className="max-w-full">
            <AnimatePresence mode="popLayout" initial={false}>
              {phase === "thinking" || (phase === "waiting" && !shown) ? (
                <motion.div key="thinking" {...rise} className="py-1">
                  <TextShimmer as="span" duration={1.6} className="text-[13px]">
                    Reading your notes…
                  </TextShimmer>
                </motion.div>
              ) : (
                <motion.div
                  key={`answer-${runs}`}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0, filter: "blur(6px)" }}
                  transition={{ duration: 0.3, ease }}
                >
                  <MessageContent className="w-full text-[13px] leading-relaxed [&_h2]:text-[1.15rem] [&_h2]:font-normal [&_h2]:tracking-[-0.015em] [&_li:has(>input)]:list-none [&_table]:text-[12.5px] [&_th]:font-normal [&_th]:text-muted-foreground">
                    <MessageResponse
                      isAnimating={phase === "streaming"}
                      animated={STREAM_ANIMATION}
                    >
                      {RESPONSE.slice(0, shown)}
                    </MessageResponse>
                  </MessageContent>
                </motion.div>
              )}
            </AnimatePresence>
          </Message>
        </div>
      </div>
      <div className="flex items-center gap-3 border-t border-border/50 pt-5">
        <Button
          size="sm"
          variant="outline"
          aria-label={working ? "Stop generating" : "Regenerate response"}
          disabled={phase === "waiting"}
          onClick={() => (working ? setPhase("stopped") : regenerate())}
        >
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.span
              key={working ? "stop" : "again"}
              initial={{ opacity: 0, scale: 0.5, rotate: -30 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.5, rotate: 30 }}
              transition={{ type: "spring", stiffness: 500, damping: 28 }}
              className="flex"
            >
              {working ? <Square className="size-3.5" /> : <RefreshCw />}
            </motion.span>
          </AnimatePresence>
          {working ? "Stop" : "Regenerate"}
        </Button>
        <span className="font-mono text-[10px] tabular-nums tracking-[0.12em] text-muted-foreground">
          {Math.round((shown / RESPONSE.length) * 100)}%
        </span>
        <span
          role="status"
          className="ml-auto text-[11.5px] text-muted-foreground"
        >
          {phase === "done"
            ? "Response complete."
            : phase === "stopped"
              ? "Stopped. The partial answer is kept."
              : ""}
        </span>
      </div>
    </div>
  );
}

function TonePlayer() {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [audio, setAudio] = useState<ReturnType<typeof createTone> | null>(
    null,
  );
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [hover, setHover] = useState<number | null>(null);
  const [audioError, setAudioError] = useState("");
  const scrubbing = useRef(false);

  useEffect(() => {
    const tone = createTone();
    // Publish the browser-owned audio URL and revoke it in the same lifecycle.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setAudio(tone);
    return () => URL.revokeObjectURL(tone.url);
  }, []);

  // timeupdate fires a few times a second; follow the playhead every frame instead.
  useEffect(() => {
    if (!playing) return;
    let frame = 0;
    const tick = () => {
      if (audioRef.current) setTime(audioRef.current.currentTime);
      frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [playing]);

  const seek = useCallback((seconds: number) => {
    const next = Math.min(TONE_SECONDS, Math.max(0, seconds));
    if (audioRef.current) audioRef.current.currentTime = next;
    setTime(next);
  }, []);

  const toSeconds = (element: HTMLElement, clientX: number) => {
    const rect = element.getBoundingClientRect();
    return ((clientX - rect.left) / rect.width) * TONE_SECONDS;
  };

  const progress = (time / TONE_SECONDS) * 100;

  if (!audio)
    return (
      <p role="status" className="text-[12px] text-muted-foreground">
        Preparing local audio…
      </p>
    );

  return (
    <div className="space-y-8">
      <audio
        ref={audioRef}
        src={audio.url}
        preload="metadata"
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => {
          setPlaying(false);
          setTime(TONE_SECONDS);
        }}
        onError={() =>
          setAudioError("The local test tone could not be played.")
        }
      />
      <div className="flex flex-wrap items-center gap-x-5 gap-y-4">
        <Button
          size="icon-lg"
          className="shrink-0 rounded-full"
          aria-label={playing ? "Pause test tone" : "Play test tone"}
          aria-pressed={playing}
          onClick={() => {
            const element = audioRef.current;
            if (!element) return;
            if (playing) element.pause();
            else {
              if (element.ended || time >= TONE_SECONDS) seek(0);
              void element
                .play()
                .catch(() =>
                  setAudioError("The local test tone could not be played."),
                );
            }
          }}
        >
          <AnimatePresence mode="popLayout" initial={false}>
            <motion.span
              key={playing ? "pause" : "play"}
              initial={{ opacity: 0, scale: 0.5, rotate: -30 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              exit={{ opacity: 0, scale: 0.5, rotate: 30 }}
              transition={{ type: "spring", stiffness: 500, damping: 28 }}
              className="flex"
            >
              {playing ? (
                <Pause className="fill-current" />
              ) : (
                <Play className="translate-x-px fill-current" />
              )}
            </motion.span>
          </AnimatePresence>
        </Button>
        <div
          role="slider"
          tabIndex={0}
          aria-label="Seek the test tone"
          aria-valuemin={0}
          aria-valuemax={TONE_SECONDS}
          aria-valuenow={Math.round(time * 10) / 10}
          aria-valuetext={`${formatTime(time)} of ${formatTime(TONE_SECONDS)}`}
          className="group relative order-last min-w-0 basis-full cursor-pointer sm:order-none sm:basis-0 sm:flex-1 touch-none rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
          onKeyDown={(event) => {
            if (event.key === "ArrowRight") seek(time + 0.5);
            if (event.key === "ArrowLeft") seek(time - 0.5);
            if (event.key === "Home") seek(0);
            if (event.key === "End") seek(TONE_SECONDS);
          }}
          onPointerDown={(event) => {
            scrubbing.current = true;
            event.currentTarget.setPointerCapture(event.pointerId);
            seek(toSeconds(event.currentTarget, event.clientX));
          }}
          onPointerMove={(event) => {
            const seconds = toSeconds(event.currentTarget, event.clientX);
            setHover(Math.min(TONE_SECONDS, Math.max(0, seconds)));
            if (scrubbing.current) seek(seconds);
          }}
          onPointerUp={() => (scrubbing.current = false)}
          onPointerLeave={() => setHover(null)}
        >
          <Waveform
            data={audio.peaks}
            height={64}
            barWidth={2}
            barGap={2}
            className="opacity-35"
            aria-hidden="true"
          />
          <div
            className="pointer-events-none absolute inset-0"
            style={{ clipPath: `inset(0 ${100 - progress}% 0 0)` }}
          >
            <Waveform
              data={audio.peaks}
              height={64}
              barWidth={2}
              barGap={2}
              barColor={EMERALD}
              aria-hidden="true"
              className="drop-shadow-[0_0_8px_rgb(52_211_153/0.55)]"
            />
          </div>
          <div
            className="pointer-events-none absolute inset-y-1 w-px bg-primary shadow-[0_0_12px_rgb(52_211_153/0.9)]"
            style={{ left: `${progress}%` }}
          />
          <AnimatePresence>
            {hover !== null && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="pointer-events-none absolute inset-y-3 w-px bg-foreground/30"
                style={{ left: `${(hover / TONE_SECONDS) * 100}%` }}
              />
            )}
          </AnimatePresence>
        </div>
        <span className="ml-auto shrink-0 font-mono text-[11px] tabular-nums text-muted-foreground sm:ml-0">
          <span className="text-foreground">{formatTime(time)}</span>
          <span className="mx-1 text-muted-foreground/50">/</span>
          {formatTime(TONE_SECONDS)}
        </span>
        <Button
          size="icon-sm"
          variant="ghost"
          aria-label="Back to start"
          disabled={time === 0}
          onClick={() => seek(0)}
        >
          <RotateCcw />
        </Button>
      </div>
      <div className="space-y-3">
        <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
          Follow along
        </p>
        <Transcription
          currentTime={time}
          onSeek={seek}
          segments={TONE_SEGMENTS}
          className="gap-x-1.5 text-[15px] font-light leading-relaxed"
        >
          {(segment, index) => (
            <TranscriptionSegment
              key={index}
              index={index}
              segment={segment}
              className="rounded-sm transition-[color,text-shadow] duration-500 ease-out data-[active=true]:[text-shadow:0_0_14px_rgb(52_211_153/0.55)]"
            />
          )}
        </Transcription>
        <p className="text-[11.5px] text-muted-foreground">
          Click a phrase to jump there. The phrases describe this test tone;
          they are not a speech transcript.
        </p>
      </div>
      <AnimatePresence>
        {audioError && (
          <motion.p
            role="alert"
            {...rise}
            className="text-[12px] text-destructive-foreground"
          >
            {audioError}
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}

function ComposerExample() {
  const controller = usePromptInputController();
  const attachments = useProviderAttachments();
  const [sent, setSent] = useState<Array<{ id: number; text: string }>>([]);
  const [error, setError] = useState("");
  const [commandSearch, setCommandSearch] = useState("");
  const [showCommands, setShowCommands] = useState(false);
  const [selectedMediaId, setSelectedMediaId] = useState("");
  const sentCount = useRef(0);
  const composer = useRef<HTMLDivElement>(null);
  const mediaFiles = attachments.files.filter((file) =>
    /^(image|video)\//.test(file.mediaType),
  );
  const selectedMedia =
    mediaFiles.find((file) => file.id === selectedMediaId) ?? mediaFiles[0];
  return (
    <div ref={composer} className="space-y-5">
      <AnimatePresence initial={false}>
        {sent.length > 0 && (
          <motion.div
            key="sent"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            transition={{ duration: 0.45, ease }}
          >
            <div
              role="log"
              aria-label="Sent messages"
              className="flex flex-col gap-2 pb-1"
            >
              <AnimatePresence initial={false}>
                {sent.map((message) => (
                  <motion.div
                    key={message.id}
                    layout
                    initial={{
                      opacity: 0,
                      y: 14,
                      scale: 0.97,
                      filter: "blur(6px)",
                    }}
                    animate={{
                      opacity: 1,
                      y: 0,
                      scale: 1,
                      filter: "blur(0px)",
                    }}
                    exit={{ opacity: 0, height: 0, filter: "blur(6px)" }}
                    transition={{ type: "spring", bounce: 0.2, duration: 0.55 }}
                    className="ml-auto max-w-[85%] origin-bottom-right rounded-2xl bg-foreground/[0.06] px-4 py-2.5 text-[13px]"
                  >
                    {message.text}
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <PromptInput
        multiple
        accept="image/*,video/*,audio/*,.txt,.md,.pdf"
        maxFiles={4}
        maxFileSize={20 * 1024 * 1024}
        onError={({ message }) => setError(message)}
        onSubmit={({ text, files }) => {
          const label = `${text || "Files selected"}${files.length ? ` · ${files.length} attachment${files.length === 1 ? "" : "s"}` : ""}`;
          sentCount.current += 1;
          setSent((current) => [
            ...current.slice(-2),
            { id: sentCount.current, text: label },
          ]);
          setShowCommands(false);
          setError("");
        }}
      >
        {attachments.files.length > 0 && (
          <PromptInputHeader>
            <Attachments variant="inline">
              <AnimatePresence initial={false}>
                {attachments.files.map((file) => (
                  <motion.div
                    key={file.id}
                    layout
                    initial={{ opacity: 0, scale: 0.85, filter: "blur(4px)" }}
                    animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                    exit={{ opacity: 0, scale: 0.85, filter: "blur(4px)" }}
                    transition={{ type: "spring", bounce: 0.2, duration: 0.45 }}
                  >
                    <Attachment
                      data={file}
                      onRemove={() => attachments.remove(file.id)}
                    >
                      <AttachmentPreview />
                      <AttachmentInfo />
                      <AttachmentRemove
                        label={`Remove ${file.filename || "file"}`}
                      />
                    </Attachment>
                  </motion.div>
                ))}
              </AnimatePresence>
            </Attachments>
          </PromptInputHeader>
        )}
        <PromptInputBody>
          <PromptInputTextarea
            aria-label="Compose a message"
            placeholder="Add an image or video, or type / for commands…"
            onChange={(event) => {
              setShowCommands(event.target.value.startsWith("/"));
              setCommandSearch(event.target.value.slice(1));
            }}
          />
        </PromptInputBody>
        <PromptInputFooter>
          <PromptInputTools>
            <PromptInputActionMenu>
              <PromptInputActionMenuTrigger aria-label="Add files">
                <Paperclip className="size-4" />
              </PromptInputActionMenuTrigger>
              <PromptInputActionMenuContent>
                <PromptInputActionAddAttachments label="Add image, video, audio, or document" />
              </PromptInputActionMenuContent>
            </PromptInputActionMenu>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              aria-expanded={showCommands}
              className="font-normal text-muted-foreground aria-expanded:text-foreground"
              onClick={() => setShowCommands((open) => !open)}
            >
              Commands
            </Button>
          </PromptInputTools>
          <PromptInputSubmit
            disabled={
              !controller.textInput.value.trim() &&
              attachments.files.length === 0
            }
          >
            <Send className="size-4" />
          </PromptInputSubmit>
        </PromptInputFooter>
      </PromptInput>
      <AnimatePresence initial={false}>
        {showCommands && (
          <motion.div
            key="commands"
            initial={{ opacity: 0, height: 0, filter: "blur(6px)" }}
            animate={{ opacity: 1, height: "auto", filter: "blur(0px)" }}
            exit={{ opacity: 0, height: 0, filter: "blur(6px)" }}
            transition={{ duration: 0.4, ease }}
            className="-mt-2 overflow-hidden"
          >
            <PromptInputCommand className="mt-2 rounded-xl bg-transparent shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-text)/0.08)]">
              <PromptInputCommandInput
                aria-label="Search commands"
                placeholder="Find a command…"
                value={commandSearch}
                onValueChange={setCommandSearch}
              />
              <PromptInputCommandList>
                <PromptInputCommandEmpty>
                  No command found.
                </PromptInputCommandEmpty>
                <PromptInputCommandGroup heading="Commands">
                  {COMMANDS.map((command) => (
                    <PromptInputCommandItem
                      key={command.value}
                      value={command.value}
                      onSelect={() => {
                        const next = `${command.value} `;
                        controller.textInput.setInput(next);
                        setShowCommands(false);
                        // Hand focus back with the caret after the command.
                        requestAnimationFrame(() => {
                          const field =
                            composer.current?.querySelector("textarea");
                          field?.focus();
                          field?.setSelectionRange(next.length, next.length);
                        });
                      }}
                    >
                      <span className="font-mono text-[12px]">
                        {command.value}
                      </span>
                      <span className="text-muted-foreground">
                        {command.description}
                      </span>
                    </PromptInputCommandItem>
                  ))}
                </PromptInputCommandGroup>
              </PromptInputCommandList>
            </PromptInputCommand>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence initial={false}>
        {error && (
          <motion.p
            key="error"
            role="alert"
            {...rise}
            className="text-[12px] text-destructive-foreground"
          >
            {error}
          </motion.p>
        )}
      </AnimatePresence>
      <AutoHeight>
        <AnimatePresence mode="popLayout" initial={false}>
          {selectedMedia ? (
            <motion.section
              key="filmstrip"
              {...rise}
              aria-label="Local media filmstrip"
              className="min-w-0 space-y-3"
            >
              <div className="relative overflow-hidden rounded-xl bg-foreground/[0.03]">
                <AnimatePresence mode="popLayout" initial={false}>
                  <motion.div
                    key={selectedMedia.id}
                    initial={{ opacity: 0, scale: 1.02, filter: "blur(8px)" }}
                    animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                    exit={{ opacity: 0, filter: "blur(8px)" }}
                    transition={{ duration: 0.45, ease }}
                  >
                    {selectedMedia.mediaType.startsWith("video/") ? (
                      <video
                        src={selectedMedia.url}
                        controls
                        preload="metadata"
                        className="max-h-64 w-full"
                        aria-label={selectedMedia.filename || "Selected video"}
                      />
                    ) : (
                      <img
                        src={selectedMedia.url}
                        alt={selectedMedia.filename || "Selected image"}
                        className="max-h-64 w-full object-contain"
                      />
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>
              <ScrollArea
                scrollbarGutter
                clampContentMinWidth={false}
                className="w-full"
              >
                <ToggleGroup
                  aria-label="Select media"
                  value={[selectedMedia.id]}
                  onValueChange={(values) => {
                    if (values[0]) setSelectedMediaId(String(values[0]));
                  }}
                  className="gap-1.5 border-0 bg-transparent p-0 shadow-none"
                >
                  {mediaFiles.map((file, index) => (
                    <ToggleGroupItem
                      key={file.id}
                      value={file.id}
                      aria-label={`Select ${file.filename || `media ${index + 1}`}`}
                      className="h-auto flex-col gap-1 rounded-lg p-1.5 opacity-60 transition-opacity hover:opacity-100 data-pressed:opacity-100 sm:h-auto"
                    >
                      {file.mediaType.startsWith("image/") ? (
                        <img
                          src={file.url}
                          alt=""
                          className="h-10 w-16 rounded object-cover"
                        />
                      ) : (
                        <video
                          src={file.url}
                          muted
                          preload="metadata"
                          className="h-10 w-16 rounded object-cover"
                        />
                      )}
                      <span className="max-w-24 truncate text-[11px]">
                        {file.filename || `Media ${index + 1}`}
                      </span>
                    </ToggleGroupItem>
                  ))}
                </ToggleGroup>
              </ScrollArea>
            </motion.section>
          ) : (
            <motion.p
              key="empty"
              {...rise}
              className="text-[11.5px] text-muted-foreground"
            >
              Messages and files stay in this local preview. Attach an image or
              video to inspect it here.
            </motion.p>
          )}
        </AnimatePresence>
      </AutoHeight>
    </div>
  );
}

export function ChatMediaWorkshop() {
  return (
    <div className="min-w-0">
      <Stage
        index={1}
        kicker="Responses"
        title="Answers that write themselves in"
        description="The model reads first, then the answer streams word by word. Tables, code and math take shape as they arrive, and you can stop or ask again at any point."
        sources={["AI Elements", "Streamdown", "Motion Primitives"]}
      >
        <StreamedConversation />
      </Stage>

      <Stage
        index={2}
        kicker="Audio"
        title="Sound you can see and scrub"
        description="The waveform fills with light as it plays. Drag across it to scrub, and the words underneath follow the playhead."
        sources={["ElevenLabs UI", "AI Elements"]}
      >
        <TonePlayer />
      </Stage>

      <Stage
        index={3}
        kicker="Composer"
        title="One box for words, files and commands"
        description="Files settle in as chips, slash opens a command list that rolls out of the composer, and sent messages rise into the thread."
        sources={["AI Elements", "Coss"]}
      >
        <PromptInputProvider>
          <ComposerExample />
        </PromptInputProvider>
      </Stage>
    </div>
  );
}
