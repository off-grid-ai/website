/// <reference types="vite/client" />
import { Segmented } from "@offgrid/ui/operator/segmented";
import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { Expand, FileUp, ImageUp, RotateCcw } from "lucide-react";
import { Prec } from "@codemirror/state";
import { Button } from "@offgrid/ui/operator/coss/button";
import {
  Alert,
  AlertDescription,
  AlertTitle,
} from "@offgrid/ui/operator/coss/alert";
import { Switch } from "@offgrid/ui/operator/animate/switch";
import {
  Lightbox,
  Zoom,
  Thumbnails,
  Captions,
  Fullscreen,
  lightboxTheme,
} from "@offgrid/ui/operator/media/lightbox";
import {
  RecordingFrames,
  type RecordingFrame,
} from "@offgrid/ui/operator/media/recording-frames";
import { PdfViewer } from "@offgrid/ui/operator/media/pdf";
import {
  CodeEditor,
  EditorView,
  javascript,
} from "@offgrid/ui/operator/media/code-editor";
import pdfWorkerUrl from "@offgrid/ui/pdf.worker.min.mjs?url";
import { Stage } from "./stage";

const ease = [0.16, 1, 0.3, 1] as const;
const rise = {
  initial: { opacity: 0, y: 6, filter: "blur(4px)" },
  animate: { opacity: 1, y: 0, filter: "blur(0px)" },
  exit: { opacity: 0, y: -6, filter: "blur(4px)" },
  transition: { duration: 0.35, ease },
};

// Real, deterministic SVG image bytes: signal plots used as recording-frame inputs.
// These are synthetic technical figures, not screenshots of private user activity.
// Drawn dark with an emerald trace so the frames sit inside the page, not on it.
function plotImage(seconds: number) {
  const points = Array.from(
    { length: 400 },
    (_, i) =>
      `${60 + i * 1.7},${200 - Math.sin(i / 18 + seconds) * 85 * (0.5 + i / 800)}`,
  ).join(" ");
  const grid = [90, 145, 255, 310]
    .map(
      (y) => `<path d="M60 ${y}H750" stroke="#ffffff" stroke-opacity="0.05"/>`,
    )
    .join("");
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="450" viewBox="0 0 800 450"><defs><linearGradient id="g" x1="0" x2="1"><stop offset="0" stop-color="#34d399" stop-opacity="0.35"/><stop offset="1" stop-color="#34d399"/></linearGradient></defs><rect width="800" height="450" fill="#0b0d0c"/><g fill="#a1a1aa" font-family="monospace"><text x="60" y="55" font-size="15" letter-spacing="3">SIGNAL · ${String(seconds).padStart(2, "0")}S</text><text x="60" y="390" font-size="13" fill-opacity="0.6">Synthetic signal data - local SVG fixture</text><text x="60" y="414" font-size="12" fill-opacity="0.4">400 samples | amplitude changes with sample index</text></g>${grid}<path d="M60 90V330 M60 200H750" fill="none" stroke="#ffffff" stroke-opacity="0.14"/><polyline points="${points}" fill="none" stroke="url(#g)" stroke-width="2.5" stroke-linecap="round"/></svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
const START_TIME = Date.UTC(2026, 9, 13, 9, 30);
const FRAMES: RecordingFrame[] = [0, 2, 12, 14].map((second, index) => ({
  id: `signal-${index}`,
  src: plotImage(second),
  timestamp: START_TIME + second * 1000,
  label: `Signal capture at 00:${String(second).padStart(2, "0")}`,
  alt: `A plot of 400 sine-wave samples at ${second} seconds`,
  width: 800,
  height: 450,
  ...(index === 2 ? { gapBeforeMs: 8000 } : {}),
}));
const LONG_FRAMES: RecordingFrame[] = Array.from({ length: 2000 }, (_, i) => ({
  ...FRAMES[i % FRAMES.length],
  id: `long-${i}`,
  gapBeforeMs: undefined,
  timestamp: START_TIME + i * 2000,
  label: `Signal capture ${i + 1}`,
}));
const SLIDES = FRAMES.map((frame) => ({
  ...frame,
  title: frame.label,
  description:
    "Local synthetic signal image. Zoom and pan to inspect individual samples.",
}));

/**
 * YARL reads these from the cascade. The source theme keeps its colours; this
 * quiets the chrome so captions read as a caption, not a banner.
 */
const quietLightbox = {
  "--yarl__container_background_color": "transparent",
  "--yarl__thumbnails_container_background_color": "transparent",
  "--yarl__slide_captions_container_background": "transparent",
  "--yarl__slide_captions_container_padding": "14px 18px",
  "--yarl__slide_title_font_size": "10.5px",
  "--yarl__slide_title_font_weight": "400",
  "--yarl__slide_title_color": "var(--muted-foreground)",
  "--yarl__slide_description_color":
    "color-mix(in oklab, var(--muted-foreground) 70%, transparent)",
  "--yarl__button_filter": "none",
  "--yarl__icon_size": "18px",
  "--yarl__toolbar_padding": "6px",
  "--yarl__thumbnails_thumbnail_border_radius": "8px",
  "--yarl__thumbnails_thumbnail_gap": "8px",
  "--yarl__thumbnails_thumbnail_padding": "0px",
  "--yarl__thumbnails_container_padding": "10px",
  "--yarl__thumbnails_thumbnail_border_color": "transparent",
  "--yarl__thumbnails_vignette_size": "0px",
} as React.CSSProperties;
const modalLightboxTheme = {
  ...lightboxTheme,
  root: {
    ...lightboxTheme.root,
    ...quietLightbox,
    "--yarl__color_backdrop": "rgb(5 6 6 / 0.82)",
    backdropFilter: "blur(18px) saturate(1.2)",
  },
};

const JAVASCRIPT = `// Local file preview. Editing never writes to disk.\nexport function summarize(frames) {\n  return frames.map(({ id, timestamp }) => ({\n    id,\n    time: new Date(timestamp).toISOString(),\n  }));\n}\n`;
/** Layered over CodeMirror's dark theme: no slab, hairline gutter, emerald caret. */
const quietCode = Prec.highest(
  EditorView.theme(
    {
      "&": {
        backgroundColor: "transparent",
        color: "var(--foreground)",
        fontSize: "12.5px",
      },
      "&.cm-focused": { outline: "none" },
      ".cm-scroller": { fontFamily: "var(--font-mono)", lineHeight: "1.75" },
      ".cm-content": { padding: "14px 0", caretColor: "var(--primary)" },
      ".cm-cursor": { borderLeftColor: "var(--primary)" },
      ".cm-gutters": {
        backgroundColor: "transparent",
        border: "none",
        color: "color-mix(in oklab, var(--muted-foreground) 45%, transparent)",
        paddingLeft: "8px",
      },
      ".cm-activeLine": {
        backgroundColor: "rgb(var(--og-rgb-primary) / 0.05)",
      },
      ".cm-activeLineGutter": {
        backgroundColor: "transparent",
        color: "var(--foreground)",
      },
      "&.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground, .cm-selectionBackground":
        { backgroundColor: "rgb(var(--og-rgb-primary) / 0.2)" },
      ".cm-foldGutter": { opacity: "0", transition: "opacity 240ms" },
      "&:hover .cm-foldGutter": { opacity: "1" },
    },
    { dark: true },
  ),
);
const JS_EXTENSIONS = [javascript({ jsx: true, typescript: true }), quietCode];
const PDF_OPTIONS = { useSystemFonts: true };

// Valid two-page PDF fixture with a real xref table, selectable text, and page objects.
function reportPdf() {
  const page = (title: string, text: string) =>
    `BT /F1 20 Tf 48 730 Td (${title}) Tj /F1 12 Tf 0 -40 Td (${text}) Tj ET`;
  const pages = [
    page(
      "Off Grid - local PDF fixture",
      "This page is selectable PDF text. Use the next page button to continue.",
    ),
    page(
      "Page two - viewer controls",
      "This is the second page. Zoom and text selection use PDF.js.",
    ),
  ];
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R 4 0 R] /Count 2 >>",
    ...[5, 6].map(
      (content) =>
        `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 7 0 R >> >> /Contents ${content} 0 R >>`,
    ),
    ...pages.map(
      (stream) =>
        `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
    ),
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
  ];
  let document = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((object, index) => {
    offsets.push(document.length);
    document += `${index + 1} 0 obj\n${object}\nendobj\n`;
  });
  const xref = document.length;
  document += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n${offsets
    .slice(1)
    .map((offset) => `${String(offset).padStart(10, "0")} 00000 n \n`)
    .join(
      "",
    )}trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return `data:application/pdf,${encodeURIComponent(document)}`;
}
const REPORT = reportPdf();
const INVALID_PDF =
  "data:application/pdf,This%20file%20has%20no%20PDF%20structure.";

/**
 * Chapter-scoped dressing for the third-party renderers. Their geometry and
 * behaviour stay upstream; this only sets the bed they sit on.
 */
/** A quiet button that opens the system file picker. */
function FilePick({
  label,
  accept,
  icon,
  onFile,
}: {
  label: string;
  accept: string;
  icon: React.ReactNode;
  onFile: (file: File) => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  return (
    <>
      <Button size="sm" variant="ghost" onClick={() => input.current?.click()}>
        {icon}
        {label}
      </Button>
      <input
        ref={input}
        type="file"
        accept={accept}
        aria-label={label}
        tabIndex={-1}
        className="sr-only"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (file) onFile(file);
        }}
      />
    </>
  );
}

export function MediaWorkshop() {
  const reducedMotion = useReducedMotion();
  // Recordings
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [largeRecording, setLargeRecording] = useState(false);
  const frames = largeRecording ? LONG_FRAMES : FRAMES;
  const [following, setFollowing] = useState(false);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [localImage, setLocalImage] = useState<File | null>(null);
  const [localUrl, setLocalUrl] = useState("");
  // Documents
  const [page, setPage] = useState(1);
  const [scale, setScale] = useState(1);
  const [pdfFile, setPdfFile] = useState<string | File>(REPORT);
  const [pdfIssue, setPdfIssue] = useState("");
  const [pdfNotice, setPdfNotice] = useState("");
  // Code
  const [code, setCode] = useState(JAVASCRIPT);
  const [editable, setEditable] = useState(false);
  const [codeNotice, setCodeNotice] = useState("");

  useEffect(() => {
    if (!localImage) return;
    const url = URL.createObjectURL(localImage);
    // Browser URL creation and revocation share this effect lifecycle.
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setLocalUrl(url);
    return () => URL.revokeObjectURL(url);
  }, [localImage]);
  const slides = useMemo(
    () =>
      localImage && localUrl
        ? [{ src: localUrl, alt: localImage.name, title: localImage.name }]
        : SLIDES,
    [localImage, localUrl],
  );
  const edited = code !== JAVASCRIPT;
  const lineCount = code.split("\n").length;

  return (
    <div className="min-w-0">
      <Stage
        index={1}
        kicker="Recordings"
        title="Frames you can scrub like film"
        description="Play through captured frames, drag the timeline or jump to the newest one. Long silences are capped, so a gap in capture never stalls playback."
        sources={[
          "Yet Another React Lightbox",
          "Virtuoso",
          "Coss",
          "Motion Primitives",
        ]}
      >
        <section aria-labelledby="frame-title" className="space-y-5">
          <h3 id="frame-title" className="sr-only">
            Recording frames and image inspection
          </h3>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <Segmented
              label="Recording length"
              value={largeRecording ? "long" : "short"}
              options={[
                { id: "short", label: "4 frames" },
                { id: "long", label: "2,000 frames" },
              ]}
              onValueChange={(id) => {
                setPlaying(false);
                setIndex(0);
                setFollowing(false);
                setLargeRecording(id === "long");
              }}
            />
            <div className="flex items-center gap-1">
              <FilePick
                label="Inspect your own image"
                accept="image/*"
                icon={<ImageUp />}
                onFile={(file) => {
                  setLocalImage(file);
                  setPlaying(false);
                  setLightboxOpen(true);
                }}
              />
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  setPlaying(false);
                  setLocalImage(null);
                  setLightboxOpen(true);
                }}
              >
                <Expand />
                Open image viewer
              </Button>
            </div>
          </div>
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={largeRecording ? "long" : "short"}
              {...rise}
              style={quietLightbox}
              className="og-media-frames text-[12px]"
            >
              <RecordingFrames
                frames={frames}
                playbackRate={playbackRate}
                onPlaybackRateChange={setPlaybackRate}
                index={index}
                onIndexChange={(value) => {
                  setIndex(value);
                  setFollowing(false);
                }}
                playing={playing}
                onPlayingChange={setPlaying}
                following={following}
                onFollowLatest={() => {
                  setPlaying(false);
                  setIndex(frames.length - 1);
                  setFollowing(true);
                }}
              />
            </motion.div>
          </AnimatePresence>
        </section>
        <Lightbox
          open={lightboxOpen}
          close={() => setLightboxOpen(false)}
          slides={slides}
          index={localImage ? 0 : Math.min(index, SLIDES.length - 1)}
          plugins={[Zoom, Thumbnails, Captions, Fullscreen]}
          zoom={{ maxZoomPixelRatio: 3 }}
          className="og-media-viewer"
          styles={modalLightboxTheme}
          controller={{ aria: true, closeOnBackdropClick: true }}
          animation={
            reducedMotion
              ? { fade: 0, swipe: 0, navigation: 0 }
              : {
                  fade: 420,
                  swipe: 520,
                  easing: {
                    fade: "cubic-bezier(0.16, 1, 0.3, 1)",
                    swipe: "cubic-bezier(0.16, 1, 0.3, 1)",
                  },
                }
          }
        />
      </Stage>

      <Stage
        index={2}
        kicker="Documents"
        title="PDFs that open in place"
        description="Real pages with selectable text, page turns and zoom, rendered on this device. A file that is not a PDF is turned away with a reason, never a blank page."
        sources={["React-PDF", "PDF.js", "Coss"]}
      >
        <section aria-labelledby="pdf-title" className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3
              id="pdf-title"
              className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground"
            >
              PDF documents
            </h3>
            <div className="flex items-center gap-1">
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setPdfFile(REPORT);
                  setPage(1);
                  setPdfIssue("");
                  setPdfNotice("Sample report loaded.");
                }}
              >
                <RotateCcw />
                Load sample
              </Button>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  setPdfFile(INVALID_PDF);
                  setPage(1);
                  setPdfNotice("Opening a file with no PDF structure.");
                }}
              >
                Try invalid file
              </Button>
              <FilePick
                label="Open a local PDF"
                accept="application/pdf,.pdf"
                icon={<FileUp />}
                onFile={(file) => {
                  if (
                    file.type !== "application/pdf" &&
                    !file.name.toLowerCase().endsWith(".pdf")
                  ) {
                    setPdfIssue(
                      "This viewer supports PDF files. Select a PDF to continue.",
                    );
                    return;
                  }
                  setPdfIssue("");
                  setPdfFile(file);
                  setPage(1);
                  setPdfNotice(`${file.name} opened.`);
                }}
              />
            </div>
          </div>
          <div className="og-media-pdf text-[12px]">
            <PdfViewer
              file={pdfFile}
              workerSrc={pdfWorkerUrl}
              pageNumber={page}
              onPageChange={setPage}
              scale={scale}
              onScaleChange={setScale}
              options={PDF_OPTIONS}
              width={440}
            />
          </div>
          <AnimatePresence initial={false}>
            {pdfIssue && (
              <motion.div key="issue" {...rise}>
                <Alert>
                  <AlertTitle>Unsupported file</AlertTitle>
                  <AlertDescription>{pdfIssue}</AlertDescription>
                </Alert>
              </motion.div>
            )}
          </AnimatePresence>
          <p role="status" className="sr-only">
            {pdfNotice}
          </p>
        </section>
      </Stage>

      <Stage
        index={3}
        kicker="Code"
        title="Code you read first, then edit"
        description="Syntax, selection, search and undo all belong to the editor. It opens read only; turning editing on wakes the caret, and edits stay in this page."
        sources={["CodeMirror", "Animate UI", "Coss"]}
      >
        <section
          aria-labelledby="code-title"
          className="overflow-hidden rounded-2xl bg-black/30 shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-text)/0.06)]"
        >
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border/50 px-4 py-2.5">
            <div className="flex min-w-0 items-center gap-3">
              <span className="flex gap-1.5" aria-hidden="true">
                {[0, 1, 2].map((dot) => (
                  <span
                    key={dot}
                    className="size-2 rounded-full bg-foreground/10"
                  />
                ))}
              </span>
              <h3
                id="code-title"
                className="truncate font-mono text-[11px] text-muted-foreground"
              >
                summarize.ts
              </h3>
              <AnimatePresence initial={false}>
                {edited && (
                  <motion.span
                    key="edited"
                    initial={{ opacity: 0, scale: 0.4 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.4 }}
                    transition={{ type: "spring", stiffness: 520, damping: 26 }}
                    aria-label="Edited"
                    className="size-1.5 rounded-full bg-primary shadow-[0_0_10px_rgb(var(--og-rgb-primary)/0.8)]"
                  />
                )}
              </AnimatePresence>
            </div>
            <div className="flex items-center gap-3">
              <AnimatePresence initial={false}>
                {edited && (
                  <motion.span key="reset" {...rise}>
                    <Button
                      size="xs"
                      variant="ghost"
                      onClick={() => {
                        setCode(JAVASCRIPT);
                        setCodeNotice("Sample restored.");
                      }}
                    >
                      Reset sample
                    </Button>
                  </motion.span>
                )}
              </AnimatePresence>
              <label className="flex cursor-pointer items-center gap-2.5 text-[12px] text-muted-foreground">
                <Switch
                  checked={editable}
                  onCheckedChange={(checked) => {
                    setEditable(checked);
                    setCodeNotice(checked ? "Editing on." : "Read only.");
                  }}
                  aria-label="Allow editing"
                />
                <span className="relative inline-grid w-14">
                  <AnimatePresence mode="popLayout" initial={false}>
                    <motion.span
                      key={editable ? "on" : "off"}
                      {...rise}
                      className="[grid-area:1/1]"
                    >
                      {editable ? "Editable" : "Read only"}
                    </motion.span>
                  </AnimatePresence>
                </span>
              </label>
            </div>
          </div>
          <CodeEditor
            value={code}
            onChange={setCode}
            readOnly={!editable}
            editable={editable}
            extensions={JS_EXTENSIONS}
            theme="dark"
            height="232px"
            indentWithTab={false}
            aria-label="Local TypeScript source"
          />
          <div className="flex items-center justify-between border-t border-border/50 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground/70">
            <span>TypeScript · {lineCount} lines</span>
            <span role="status" className="normal-case tracking-normal">
              {codeNotice}
            </span>
          </div>
        </section>
      </Stage>
    </div>
  );
}
