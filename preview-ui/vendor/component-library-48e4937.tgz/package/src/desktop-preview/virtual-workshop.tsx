import { useMemo, useRef, useState, type RefObject } from "react";
import { AnimatePresence, motion, useAnimate } from "motion/react";
import {
  ArrowDownToLineIcon,
  ArrowUpToLineIcon,
  SearchIcon,
} from "lucide-react";
import {
  Virtuoso,
  TableVirtuoso,
  type VirtuosoHandle,
  type TableVirtuosoHandle,
} from "@offgrid/ui/operator/virtual-list";
import { Button } from "@offgrid/ui/operator/coss/button";
import {
  InputGroup,
  InputGroupAddon,
  InputGroupInput,
} from "@offgrid/ui/operator/coss/input-group";
import { Tabs, TabsList, TabsTab } from "@offgrid/ui/operator/coss/tabs";
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
} from "@offgrid/ui/operator/coss/table";
import { AnimatedNumber } from "@offgrid/ui/operator/motion/animated-number";
import { Stage } from "./stage";

const ease = [0.16, 1, 0.3, 1] as const;
const spring = { type: "spring", stiffness: 420, damping: 36 } as const;
const eyebrow =
  "font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground";

const conversations = Array.from({ length: 5000 }, (_, index) => ({
  id: index + 1,
  title: `Conversation ${String(index + 1).padStart(4, "0")}`,
  summary: [
    "Project notes and next steps",
    "A short question",
    "Research with linked sources and a longer summary that wraps when space is limited",
  ][index % 3],
  tokens: 120 + ((index * 37) % 8000),
}));

const models = ["gemma-4", "qwen-3.5", "llama-3.3"];
const requests = Array.from({ length: 10000 }, (_, index) => {
  const status = index % 23 === 0 ? 500 : index % 11 === 0 ? 429 : 200;
  return {
    id: index + 1,
    request: `req_${(0x1a2b + index * 7919).toString(16).padStart(6, "0")}`,
    model: models[index % models.length],
    status,
    latency:
      status === 200 ? 80 + ((index * 53) % 1900) : 30 + ((index * 17) % 120),
    tokens: status === 200 ? 120 + ((index * 37) % 8000) : 0,
  };
});
const MAX_TOKENS = 8120;
const requestFilters = [
  { id: "all", label: "All", test: () => true },
  {
    id: "slow",
    label: "Slow",
    test: (r: (typeof requests)[number]) => r.latency > 1500,
  },
  {
    id: "errors",
    label: "Errors",
    test: (r: (typeof requests)[number]) => r.status !== 200,
  },
] as const;

/** Dissolve a long scroll into a cut: fade the viewport, jump, fade back in. */
function useSoftJump() {
  const [scope, animate] = useAnimate<HTMLDivElement>();
  const jump = async (move: () => void) => {
    if (!scope.current) return move();
    await animate(
      scope.current,
      { opacity: 0, filter: "blur(6px)" },
      { duration: 0.16, ease },
    );
    move();
    await new Promise((resolve) => requestAnimationFrame(resolve));
    await animate(
      scope.current,
      { opacity: 1, filter: "blur(0px)" },
      { duration: 0.42, ease },
    );
  };
  return [scope, jump] as const;
}

function JumpControls({
  disabled,
  onFirst,
  onLast,
}: {
  disabled: boolean;
  onFirst: () => void;
  onLast: () => void;
}) {
  return (
    <div className="flex items-center gap-1">
      <Button
        size="icon-sm"
        variant="ghost"
        aria-label="Back to first"
        disabled={disabled}
        onClick={onFirst}
      >
        <ArrowUpToLineIcon />
      </Button>
      <Button
        size="icon-sm"
        variant="ghost"
        aria-label="Jump to last"
        disabled={disabled}
        onClick={onLast}
      >
        <ArrowDownToLineIcon />
      </Button>
    </div>
  );
}

function RangeReadout({
  start,
  end,
  total,
}: {
  start: number;
  end: number;
  total: number;
}) {
  return (
    <p className="font-mono text-[10.5px] tabular-nums text-muted-foreground">
      Showing{" "}
      <AnimatedNumber
        value={total ? start + 1 : 0}
        springOptions={{ bounce: 0, duration: 400 }}
      />
      –
      <AnimatedNumber
        value={total ? end + 1 : 0}
        springOptions={{ bounce: 0, duration: 400 }}
      />{" "}
      of {total.toLocaleString()} · only these rows are mounted
    </p>
  );
}

const tableComponents = {
  // The Coss container scrolls on x, which would capture the sticky header.
  Table: (props: React.ComponentProps<typeof Table>) => (
    <Table
      {...props}
      render={<div style={{ overflow: "visible" }} />}
      className="table-fixed border-separate border-spacing-0"
    />
  ),
  TableHead: TableHeader,
  TableBody,
  TableRow: (props: React.ComponentProps<typeof TableRow>) => (
    <TableRow
      {...props}
      className="border-0 transition-colors duration-200 hover:bg-foreground/[0.035] [&>td]:border-b [&>td]:border-border/40"
    />
  ),
};

export function VirtualWorkshop() {
  const list = useRef<VirtuosoHandle>(null);
  const table = useRef<TableVirtuosoHandle>(null);
  const [listScope, jumpList] = useSoftJump();
  const [tableScope, jumpTable] = useSoftJump();
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState(1);
  const [listRange, setListRange] = useState({ startIndex: 0, endIndex: 0 });
  const [filter, setFilter] =
    useState<(typeof requestFilters)[number]["id"]>("all");
  const [tableRange, setTableRange] = useState({ startIndex: 0, endIndex: 0 });

  const rows = useMemo(
    () =>
      conversations.filter((item) =>
        `${item.title} ${item.summary}`
          .toLowerCase()
          .includes(query.toLowerCase()),
      ),
    [query],
  );
  const log = useMemo(() => {
    const test = requestFilters.find((item) => item.id === filter)!.test;
    return requests.filter((item) => test(item));
  }, [filter]);
  const active = conversations.find((item) => item.id === selected)!;

  const scrollTo = (
    ref: RefObject<VirtuosoHandle | TableVirtuosoHandle | null>,
    index: number,
  ) =>
    ref.current?.scrollToIndex({
      index,
      align: index ? "end" : "start",
      behavior: "auto",
    });

  return (
    <div className="min-w-0">
      <Stage
        index={1}
        kicker="Lists"
        title="Five thousand rows that scroll like ten"
        description="Only the rows on screen exist. The selection glides between them, the count rolls as you filter, and long jumps dissolve instead of flashing past."
        sources={["React Virtuoso", "Coss", "Motion Primitives"]}
      >
        <div className="flex flex-wrap items-center gap-3">
          <InputGroup className="max-w-xs flex-1">
            <InputGroupAddon>
              <SearchIcon aria-hidden="true" />
            </InputGroupAddon>
            <InputGroupInput
              aria-label="Filter large collection"
              placeholder="Filter conversations…"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
            />
          </InputGroup>
          <p
            role="status"
            className="font-mono text-[11px] tabular-nums text-muted-foreground"
          >
            <AnimatedNumber
              value={rows.length}
              springOptions={{ bounce: 0, duration: 500 }}
            />{" "}
            {rows.length === 1 ? "row" : "rows"}
          </p>
          <div className="ml-auto">
            <JumpControls
              disabled={!rows.length}
              onFirst={() => jumpList(() => scrollTo(list, 0))}
              onLast={() => jumpList(() => scrollTo(list, rows.length - 1))}
            />
          </div>
        </div>

        <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,1fr)_14rem]">
          <div ref={listScope} className="relative h-96 min-w-0">
            <AnimatePresence mode="wait" initial={false}>
              {rows.length ? (
                <motion.div
                  key="list"
                  className="h-full"
                  initial={{ opacity: 0, filter: "blur(4px)" }}
                  animate={{ opacity: 1, filter: "blur(0px)" }}
                  exit={{ opacity: 0, filter: "blur(4px)" }}
                  transition={{ duration: 0.3, ease }}
                >
                  <Virtuoso
                    ref={list}
                    className="h-full [mask-image:linear-gradient(to_bottom,transparent,#000_16px,#000_calc(100%-24px),transparent)]"
                    aria-label="Virtual conversation list"
                    data={rows}
                    computeItemKey={(_, item) => item.id}
                    rangeChanged={setListRange}
                    itemContent={(_, item) => (
                      <div className="py-0.5 pr-2">
                        <button
                          type="button"
                          aria-pressed={item.id === selected}
                          onClick={() => setSelected(item.id)}
                          className="group relative flex w-full items-start gap-4 rounded-xl px-3 py-2.5 text-left outline-none transition-colors duration-200 hover:bg-foreground/[0.035] focus-visible:ring-2 focus-visible:ring-ring/60"
                        >
                          {item.id === selected && (
                            <motion.span
                              layoutId="virtual-selection"
                              transition={spring}
                              className="absolute inset-0 rounded-xl bg-primary/10 shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-primary)/0.3)]"
                            />
                          )}
                          <span className="relative min-w-0 flex-1">
                            <span className="block text-[13px] transition-transform duration-300 group-hover:translate-x-0.5">
                              {item.title}
                            </span>
                            <span className="mt-0.5 block text-[11.5px] leading-relaxed text-muted-foreground">
                              {item.summary}
                            </span>
                          </span>
                          <span className="relative pt-0.5 font-mono text-[10.5px] tabular-nums text-muted-foreground">
                            {item.tokens.toLocaleString()} tok
                          </span>
                        </button>
                      </div>
                    )}
                  />
                </motion.div>
              ) : (
                <motion.div
                  key="empty"
                  className="flex h-full flex-col items-center justify-center text-center"
                  initial={{ opacity: 0, y: 8, filter: "blur(4px)" }}
                  animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                  exit={{ opacity: 0, y: -8, filter: "blur(4px)" }}
                  transition={{ duration: 0.35, ease }}
                >
                  <p className="text-[13px]">No matching conversations</p>
                  <p className="mt-1 text-[11.5px] text-muted-foreground">
                    Clear the filter to see all rows.
                  </p>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="mt-4"
                    onClick={() => setQuery("")}
                  >
                    Clear filter
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <aside
            aria-label="Conversation detail"
            className="lg:border-l lg:border-border/50 lg:pl-8"
          >
            <p className={eyebrow}>Selected</p>
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={active.id}
                initial={{ opacity: 0, y: 6, filter: "blur(4px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -6, filter: "blur(4px)" }}
                transition={{ duration: 0.3, ease }}
              >
                <h3 className="mt-4 text-lg font-light tracking-[-0.015em]">
                  {active.title}
                </h3>
                <p className="mt-2 text-[12px] leading-relaxed text-muted-foreground">
                  {active.summary}
                </p>
              </motion.div>
            </AnimatePresence>
            <div className="mt-6">
              <div className="flex items-baseline justify-between">
                <span className={eyebrow}>Tokens</span>
                <span className="font-mono text-[12px] tabular-nums">
                  <AnimatedNumber
                    value={active.tokens}
                    springOptions={{ bounce: 0, duration: 600 }}
                  />
                </span>
              </div>
              <div className="mt-2 h-1 overflow-hidden rounded-full bg-foreground/8">
                <motion.div
                  className="h-full origin-left rounded-full bg-primary shadow-[0_0_10px_rgb(var(--og-rgb-primary)/0.6)]"
                  initial={false}
                  animate={{ scaleX: active.tokens / MAX_TOKENS }}
                  transition={spring}
                />
              </div>
            </div>
            <p className="mt-6 text-[11px] leading-relaxed text-muted-foreground">
              Selection stays independent of the visible scroll range.
            </p>
          </aside>
        </div>
        <div className="mt-5">
          <RangeReadout
            start={listRange.startIndex}
            end={listRange.endIndex}
            total={rows.length}
          />
        </div>
      </Stage>

      <Stage
        index={2}
        kicker="Tables"
        title="A log you can read at any depth"
        description="Ten thousand requests behind a header that stays put. Filters reshape the set in place, and each row carries its weight as a quiet bar."
        sources={["React Virtuoso", "Coss", "Motion Primitives"]}
      >
        <div className="flex flex-wrap items-center gap-3">
          <Tabs
            value={filter}
            onValueChange={(value) => setFilter(value as typeof filter)}
          >
            <TabsList size="sm" aria-label="Request filter">
              {requestFilters.map((item) => (
                <TabsTab key={item.id} value={item.id}>
                  {item.label}
                </TabsTab>
              ))}
            </TabsList>
          </Tabs>
          <p
            role="status"
            className="font-mono text-[11px] tabular-nums text-muted-foreground"
          >
            <AnimatedNumber
              value={log.length}
              springOptions={{ bounce: 0, duration: 500 }}
            />{" "}
            requests
          </p>
          <div className="ml-auto">
            <JumpControls
              disabled={!log.length}
              onFirst={() => jumpTable(() => scrollTo(table, 0))}
              onLast={() => jumpTable(() => scrollTo(table, log.length - 1))}
            />
          </div>
        </div>
        <div ref={tableScope} className="mt-6 h-96">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={filter}
              className="h-full"
              initial={{ opacity: 0, y: 6, filter: "blur(4px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -6, filter: "blur(4px)" }}
              transition={{ duration: 0.3, ease }}
            >
              <TableVirtuoso
                ref={table}
                className="h-full"
                aria-label="Virtual request log"
                data={log}
                computeItemKey={(_, item) => item.id}
                rangeChanged={setTableRange}
                components={tableComponents}
                fixedHeaderContent={() => (
                  <tr>
                    {[
                      ["Request", "w-[28%] text-left"],
                      ["Model", "w-[22%] text-left"],
                      ["Status", "w-[14%] text-left"],
                      ["Latency", "w-[14%] text-right"],
                      ["Tokens", "text-right"],
                    ].map(([label, align]) => (
                      <th
                        key={label}
                        className={`border-b border-border/60 bg-background/95 px-3 pb-2.5 pt-1 font-mono text-[10px] font-normal uppercase tracking-[0.18em] text-muted-foreground backdrop-blur-md ${align}`}
                      >
                        {label}
                      </th>
                    ))}
                  </tr>
                )}
                itemContent={(_, item) => (
                  <>
                    <td className="truncate px-3 py-2.5 font-mono text-[11.5px]">
                      {item.request}
                    </td>
                    <td className="px-3 py-2.5 font-mono text-[11.5px] text-muted-foreground">
                      {item.model}
                    </td>
                    <td className="px-3 py-2.5">
                      <span className="inline-flex items-center gap-1.5 font-mono text-[11px]">
                        <span
                          aria-hidden
                          className={`size-1.5 rounded-full ${
                            item.status === 200
                              ? "bg-primary shadow-[0_0_6px_rgb(var(--og-rgb-primary)/0.8)]"
                              : item.status === 429
                                ? "bg-amber-400"
                                : "bg-red-400"
                          }`}
                        />
                        {item.status}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-[11.5px] tabular-nums text-muted-foreground">
                      {item.latency.toLocaleString()} ms
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center justify-end gap-3">
                        <span
                          aria-hidden
                          className="h-0.5 w-16 overflow-hidden rounded-full bg-foreground/8 data-empty:opacity-0"
                          data-empty={!item.tokens || undefined}
                        >
                          <span
                            className="block h-full origin-left rounded-full bg-primary/70"
                            style={{
                              transform: `scaleX(${item.tokens / MAX_TOKENS})`,
                            }}
                          />
                        </span>
                        <span className="w-12 text-right font-mono text-[11.5px] tabular-nums">
                          {item.tokens ? item.tokens.toLocaleString() : "—"}
                        </span>
                      </div>
                    </td>
                  </>
                )}
              />
            </motion.div>
          </AnimatePresence>
        </div>
        <div className="mt-5">
          <RangeReadout
            start={tableRange.startIndex}
            end={tableRange.endIndex}
            total={log.length}
          />
        </div>
      </Stage>
    </div>
  );
}
