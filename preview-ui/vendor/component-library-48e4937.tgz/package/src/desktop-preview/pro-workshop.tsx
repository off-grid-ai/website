import * as React from "react";
import { Segmented } from "@offgrid/ui/operator/segmented";
import { AnimatePresence, motion } from "motion/react";
import { CalendarDays, Check, FileText, Mail, Search } from "lucide-react";
import {
  SearchFacets,
  BrowserNavigation,
  RoutineSchedule,
  AgendaEvent,
  SecretInput,
  type RoutineScheduleValue,
  type AgendaPreparation,
} from "@offgrid/ui/operator/workflows/pro-presentations";
import {
  ToolTimeline,
  type ToolTraceEntry,
  type ToolTimelineProps,
} from "@offgrid/ui/operator/workflows/tool-timeline";
import { Button } from "@offgrid/ui/operator/coss/button";
import {
  InputGroup,
  InputGroupInput,
  InputGroupAddon,
} from "@offgrid/ui/operator/coss/input-group";
import { Skeleton } from "@offgrid/ui/operator/coss/skeleton";
import { TextMorph } from "@offgrid/ui/operator/motion/text-morph";
import { Stage } from "./stage";
import { Highlight, LiveStatus as Live } from "@offgrid/ui/operator/presence";

const ease = [0.16, 1, 0.3, 1] as const;
const spring = { type: "spring", stiffness: 420, damping: 34 } as const;
const eyebrow =
  "font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground";

const SEARCH_ROWS = [
  { title: "Release checklist", source: "notes", meta: "Edited yesterday" },
  {
    title: "Beta review reminder",
    source: "email",
    meta: "From the beta list",
  },
  { title: "Release planning", source: "calendar", meta: "Thursday · 11:00" },
  { title: "Test notes", source: "notes", meta: "Edited Monday" },
];
const SOURCE_ICON = { notes: FileText, email: Mail, calendar: CalendarDays };
const INITIAL_SCHEDULE: RoutineScheduleValue = {
  when: "daily",
  time: "09:00",
  hours: 2,
  dateTime: "",
  match: "",
};
const EVENT_LABEL: Record<string, string> = {
  "event:new_email": "When a new email arrives",
  "event:meeting_soon": "Before a meeting starts",
  "event:task_finished": "When a task finishes",
  "event:approval_waiting": "When an approval is waiting",
};



function describeSchedule(value: RoutineScheduleValue) {
  if (value.when === "daily") return `Every day · ${value.time || "--:--"}`;
  if (value.when === "weekdays") return `Weekdays · ${value.time || "--:--"}`;
  if (value.when === "interval")
    return value.hours ? `Every ${value.hours} h` : "Every few hours";
  if (value.when === "once")
    return value.dateTime
      ? `Once · ${value.dateTime.replace("T", " ")}`
      : "Once · pick a time";
  return EVENT_LABEL[value.when] ?? "On an event";
}

type AgendaItem = {
  id: string;
  title: string;
  time: string;
  location: string;
  state: "upcoming" | "current" | "ended";
  /** What preparing this meeting resolves to in the preview. */
  outcome: "notes" | "flaky";
};
const AGENDA: AgendaItem[] = [
  {
    id: "standup",
    title: "Team stand-up",
    time: "09:00",
    location: "Sample call link",
    state: "ended",
    outcome: "notes",
  },
  {
    id: "review",
    title: "Release review",
    time: "10:30",
    location: "Sample meeting room",
    state: "current",
    outcome: "notes",
  },
  {
    id: "partner",
    title: "Partner sync",
    time: "14:00",
    location: "Sample video call",
    state: "upcoming",
    outcome: "flaky",
  },
];

export function ProWorkshop() {
  const timers = React.useRef<Array<ReturnType<typeof setTimeout>>>([]);
  const later = React.useCallback((fn: () => void, ms: number) => {
    const timer = setTimeout(fn, ms);
    timers.current.push(timer);
    return timer;
  }, []);
  React.useEffect(() => () => timers.current.forEach(clearTimeout), []);

  // Search
  const [query, setQuery] = React.useState("");
  const [sources, setSources] = React.useState<string[]>([]);
  const [sort, setSort] = React.useState("source");
  const matched = SEARCH_ROWS.filter((row) =>
    row.title.toLowerCase().includes(query.trim().toLowerCase()),
  );
  const visible = matched
    .filter((row) => !sources.length || sources.includes(row.source))
    .sort((a, b) =>
      sort === "title"
        ? a.title.localeCompare(b.title)
        : a.source.localeCompare(b.source) || a.title.localeCompare(b.title),
    );

  // Browser
  const [active, setActive] = React.useState(true);
  const [loading, setLoading] = React.useState(false);
  const [address, setAddress] = React.useState("https://example.com/notes");
  const [history, setHistory] = React.useState([
    "https://example.com/",
    "https://example.com/notes",
  ]);
  const [position, setPosition] = React.useState(1);
  const [addressError, setAddressError] = React.useState("");
  const loadTimer = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const stopLoad = () => {
    if (loadTimer.current) clearTimeout(loadTimer.current);
    setLoading(false);
  };
  const load = () => {
    if (loadTimer.current) clearTimeout(loadTimer.current);
    setLoading(true);
    loadTimer.current = later(() => setLoading(false), 1300);
  };
  const navigate = () => {
    try {
      const url = new URL(address);
      if (!["http:", "https:"].includes(url.protocol)) throw new Error();
      setAddressError("");
      setHistory((previous) => [...previous.slice(0, position + 1), url.href]);
      setPosition(position + 1);
      setAddress(url.href);
      load();
    } catch {
      setAddressError("Enter a complete HTTP or HTTPS address.");
    }
  };
  const page = (() => {
    try {
      const url = new URL(history[position]);
      const slug = url.pathname.split("/").filter(Boolean).pop();
      return {
        host: url.host,
        title: slug
          ? slug.replace(/[-_]/g, " ").replace(/^./, (c) => c.toUpperCase())
          : "Home",
      };
    } catch {
      return { host: "", title: "Untitled" };
    }
  })();

  // Routine
  const [schedule, setSchedule] = React.useState(INITIAL_SCHEDULE);
  const [scheduleError, setScheduleError] = React.useState("");
  const [saving, setSaving] = React.useState(false);
  const [scheduleNotice, setScheduleNotice] = React.useState(
    "No routine saved yet.",
  );
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;

  // Agenda
  const [expanded, setExpanded] = React.useState<Record<string, boolean>>({
    review: true,
  });
  const [prep, setPrep] = React.useState<Record<string, AgendaPreparation>>({
    standup: {
      status: "ready",
      people: ["Sample teammate"],
      notes: ["Shared the beta numbers.", "Two release tasks still open."],
    },
  });
  const [attempts, setAttempts] = React.useState<Record<string, number>>({});
  const [agendaNotice, setAgendaNotice] = React.useState(
    "Release review is happening now.",
  );
  const prepare = (item: AgendaItem) => {
    const attempt = (attempts[item.id] ?? 0) + 1;
    setAttempts((current) => ({ ...current, [item.id]: attempt }));
    setPrep((current) => ({ ...current, [item.id]: { status: "loading" } }));
    later(() => {
      const next: AgendaPreparation =
        item.outcome === "flaky"
          ? attempt === 1
            ? {
                status: "error",
                message: "Sample calendar connection is unavailable.",
              }
            : { status: "ready", people: [], notes: [] }
          : {
              status: "ready",
              people: ["Sample teammate", "Sample reviewer"],
              notes: ["Check beta signups.", "Review open release tasks."],
            };
      setPrep((current) => ({ ...current, [item.id]: next }));
      setAgendaNotice(
        next.status === "error"
          ? `${item.title} could not be prepared.`
          : `${item.title} is prepared.`,
      );
    }, 1200);
  };

  // Secrets
  const [secret, setSecret] = React.useState("");
  const [confirmation, setConfirmation] = React.useState("");
  const [reveal, setReveal] = React.useState(false);
  const [revealConfirmation, setRevealConfirmation] = React.useState(false);
  const [secretError, setSecretError] = React.useState("");
  const [validating, setValidating] = React.useState(false);
  const [secretNotice, setSecretNotice] = React.useState(
    "Nothing entered yet.",
  );
  const matches = !!secret && secret === confirmation;

  return (
    <div className="min-w-0">
      <Stage
        index={1}
        kicker="Search"
        title="Find it across every source"
        description="Results reorder as you sort, filter and type, matches light up in place, and counts follow every keystroke. Sample records only."
        sources={["Off Grid workflows", "Coss", "Motion Primitives"]}
        specimenClassName="justify-start"
      >
        <div className="grid gap-10 sm:grid-cols-[10.5rem_minmax(0,1fr)]">
          <div>
            <SearchFacets
              value={sources}
              onValueChange={setSources}
              facets={["notes", "email", "calendar"].map((id) => ({
                id,
                label: id.charAt(0).toUpperCase() + id.slice(1),
                count: matched.filter((row) => row.source === id).length,
              }))}
            />
          </div>
          <div className="min-w-0 space-y-5">
            <InputGroup>
              <InputGroupAddon>
                <Search aria-hidden="true" />
              </InputGroupAddon>
              <InputGroupInput
                type="search"
                aria-label="Search sample records"
                placeholder="Search notes, email and calendar…"
                value={query}
                onValueChange={setQuery}
              />
            </InputGroup>
            <div className="flex items-center justify-between gap-4">
              <Live>{`${visible.length} ${visible.length === 1 ? "result" : "results"}`}</Live>
              <Segmented
                label="Sort results"
                size="sm"
                tone="quiet"
                value={sort}
                options={[
                  { id: "source", label: "Source" },
                  { id: "title", label: "Title" },
                ]}
                onValueChange={setSort}
              />
            </div>
            <ul aria-label="Search results" className="-mx-3 min-h-52">
              <AnimatePresence mode="popLayout" initial={false}>
                {visible.map((row, index) => {
                  const Icon =
                    SOURCE_ICON[row.source as keyof typeof SOURCE_ICON];
                  return (
                    <motion.li
                      key={row.title}
                      layout
                      initial={{ opacity: 0, y: 8, filter: "blur(4px)" }}
                      animate={{
                        opacity: 1,
                        y: 0,
                        filter: "blur(0px)",
                        transition: { ...spring, delay: index * 0.03 },
                      }}
                      exit={{
                        opacity: 0,
                        scale: 0.98,
                        filter: "blur(4px)",
                        transition: { duration: 0.2 },
                      }}
                      transition={spring}
                      className="group flex items-center gap-3 rounded-xl px-3 py-2.5 transition-colors duration-300 hover:bg-foreground/[0.035]"
                    >
                      <span className="grid size-7 shrink-0 place-items-center rounded-lg text-muted-foreground shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-text)/0.08)] transition-colors duration-300 group-hover:text-primary">
                        <Icon className="size-3.5" aria-hidden="true" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-[13px]">
                          <Highlight text={row.title} query={query.trim()} />
                        </span>
                        <span className="block text-[11px] text-muted-foreground">
                          {row.meta}
                        </span>
                      </span>
                      <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground/70 transition-colors duration-300 group-hover:text-muted-foreground">
                        {row.source}
                      </span>
                    </motion.li>
                  );
                })}
                {!visible.length && (
                  <motion.li
                    key="empty"
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.35, ease }}
                    className="flex flex-col items-start gap-3 px-3 py-6"
                  >
                    <span className="text-[13px]">No matching records.</span>
                    <span className="text-[12px] text-muted-foreground">
                      Change the query or clear the source filters.
                    </span>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="-ml-2"
                      onClick={() => {
                        setQuery("");
                        setSources([]);
                      }}
                    >
                      Clear search
                    </Button>
                  </motion.li>
                )}
              </AnimatePresence>
            </ul>
          </div>
        </div>
      </Stage>

      <Stage
        index={2}
        kicker="Browsing"
        title="A browser session you can steer"
        description="Back, forward, reload and stop answer at once. The page loads behind a slim progress line and the session can be ended and picked up again. Nothing is fetched."
        sources={["Off Grid workflows", "Coss"]}
      >
        <div className="space-y-4">
          <BrowserNavigation
            active={active}
            loading={loading}
            value={address}
            onValueChange={setAddress}
            canGoBack={position > 0}
            canGoForward={position < history.length - 1}
            onBack={() => {
              setPosition(position - 1);
              setAddress(history[position - 1]);
              load();
            }}
            onForward={() => {
              setPosition(position + 1);
              setAddress(history[position + 1]);
              load();
            }}
            onReload={load}
            onStop={stopLoad}
            onNavigate={navigate}
            error={addressError}
          />
          <div
            aria-busy={loading || undefined}
            aria-label="Page preview"
            className="relative min-h-44 overflow-hidden rounded-2xl p-6 shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-text)/0.07)]"
          >
            <motion.span
              aria-hidden="true"
              className="absolute inset-x-0 top-0 h-px origin-left bg-primary shadow-[0_0_10px_rgb(var(--og-rgb-primary)/0.9)]"
              initial={false}
              animate={
                loading
                  ? { scaleX: 0.82, opacity: 1 }
                  : { scaleX: 1, opacity: 0 }
              }
              transition={
                loading
                  ? {
                      scaleX: { duration: 1.2, ease },
                      opacity: { duration: 0.1 },
                    }
                  : {
                      scaleX: { duration: 0.25 },
                      opacity: { duration: 0.5, delay: 0.2 },
                    }
              }
            />
            <AnimatePresence mode="wait" initial={false}>
              {!active ? (
                <motion.div
                  key="ended"
                  initial={{ opacity: 0, filter: "blur(6px)" }}
                  animate={{ opacity: 1, filter: "blur(0px)" }}
                  exit={{ opacity: 0, filter: "blur(6px)" }}
                  transition={{ duration: 0.35, ease }}
                  className="flex flex-col items-start gap-3"
                >
                  <span className={eyebrow}>Session ended</span>
                  <span className="text-[13px] text-muted-foreground">
                    Last page · {history[position]}
                  </span>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setActive(true);
                      setAddress(history[position]);
                      load();
                    }}
                  >
                    Open last page
                  </Button>
                </motion.div>
              ) : loading ? (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.25 }}
                  className="space-y-3"
                >
                  <Skeleton className="h-2.5 w-24 rounded-full" />
                  <Skeleton className="h-4 w-2/5 rounded-full" />
                  <Skeleton className="h-2.5 w-4/5 rounded-full" />
                  <Skeleton className="h-2.5 w-3/5 rounded-full" />
                </motion.div>
              ) : (
                <motion.div
                  key={history[position]}
                  initial={{ opacity: 0, y: 6, filter: "blur(6px)" }}
                  animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                  exit={{ opacity: 0, y: -4, filter: "blur(6px)" }}
                  transition={{ duration: 0.4, ease }}
                  className="space-y-2"
                >
                  <span className={eyebrow}>{page.host}</span>
                  <h3 className="text-[17px] font-light tracking-[-0.01em]">
                    {page.title}
                  </h3>
                  <p className="max-w-md text-[12px] leading-relaxed text-muted-foreground">
                    A sample page for this preview. Address changes update the
                    session history; they do not open websites.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <div className="flex justify-end">
            <Button
              size="sm"
              variant="ghost"
              disabled={!active}
              onClick={() => {
                stopLoad();
                setActive(false);
                setAddressError("");
              }}
            >
              End session
            </Button>
          </div>
        </div>
      </Stage>

      <Stage
        index={3}
        kicker="Routines"
        title="Work that runs on its own schedule"
        description="Pick a rhythm or an event. The summary rewrites itself letter by letter, and saving settles into a confirmation instead of a reload."
        sources={["Off Grid workflows", "Dice UI", "Motion Primitives"]}
      >
        <div className="grid gap-10 sm:grid-cols-[minmax(0,1fr)_15rem]">
          <div>
            <RoutineSchedule
              value={schedule}
              onValueChange={(value) => {
                setSchedule(value);
                setScheduleError("");
              }}
              saving={saving}
              error={scheduleError}
              timeZone={timeZone}
              onSave={() => {
                if (
                  schedule.when === "once" &&
                  (!schedule.dateTime ||
                    new Date(schedule.dateTime).getTime() <= Date.now())
                ) {
                  setScheduleError("Choose a future date and time.");
                  return;
                }
                if (
                  schedule.when === "interval" &&
                  (schedule.hours === null || schedule.hours < 0.25)
                ) {
                  setScheduleError(
                    "Choose an interval of at least 15 minutes.",
                  );
                  return;
                }
                if (
                  (schedule.when === "daily" || schedule.when === "weekdays") &&
                  !schedule.time
                ) {
                  setScheduleError("Choose a run time.");
                  return;
                }
                setSaving(true);
                later(() => {
                  setSaving(false);
                  setScheduleNotice(
                    `Saved. ${describeSchedule(schedule)} in ${timeZone}.`,
                  );
                }, 900);
              }}
            />
          </div>
          <div className="flex flex-col gap-3 sm:border-l sm:border-border/50 sm:pl-8">
            <span className={eyebrow}>Runs</span>
            <TextMorph
              as="span"
              className="whitespace-nowrap text-[17px] font-light leading-snug tracking-[-0.015em]"
            >
              {describeSchedule(schedule)}
            </TextMorph>
            <span className="text-[11.5px] text-muted-foreground">
              Summarise new notes and email.
            </span>
            <div className="mt-auto pt-6">
              <Live>{scheduleNotice}</Live>
            </div>
          </div>
        </div>
      </Stage>

      <Stage
        index={4}
        kicker="Agenda"
        title="Walk into every meeting prepared"
        description="Each event opens to its preparation. Context gathers while you wait, failures offer a retry, and the meeting happening now carries a quiet pulse."
        sources={["Off Grid workflows", "Coss"]}
      >
        <div className="space-y-6">
          <ol aria-label="Today" className="divide-y divide-border/50">
            {AGENDA.map((item, index) => (
              <motion.li
                key={item.id}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ ...spring, delay: index * 0.07 }}
                data-state={item.state}
                className="py-5 first:pt-0 last:pb-0 transition-opacity duration-500 data-[state=ended]:opacity-55 data-[state=ended]:hover:opacity-90"
              >
                <div className="relative pl-6">
                  <span
                    aria-hidden="true"
                    className="absolute left-0 top-[13px] size-1.5 rounded-full bg-muted-foreground/40 data-[current]:bg-primary data-[current]:shadow-[0_0_10px_rgb(var(--og-rgb-primary)/0.9)]"
                    data-current={item.state === "current" || undefined}
                  >
                    {item.state === "current" && (
                      <motion.span
                        className="absolute inset-0 rounded-full bg-primary"
                        animate={{ scale: [1, 2.6], opacity: [0.6, 0] }}
                        transition={{
                          duration: 2,
                          repeat: Infinity,
                          ease: "easeOut",
                        }}
                      />
                    )}
                  </span>
                  <AgendaEvent
                    title={item.title}
                    time={item.time}
                    location={item.location}
                    state={item.state}
                    onOpen={() =>
                      setAgendaNotice(`${item.title} opened in this preview.`)
                    }
                    expanded={!!expanded[item.id]}
                    onExpandedChange={(open) =>
                      setExpanded((current) => ({
                        ...current,
                        [item.id]: open,
                      }))
                    }
                    preparation={prep[item.id] ?? { status: "idle" }}
                    onPrepare={() => prepare(item)}
                  />
                </div>
              </motion.li>
            ))}
          </ol>
          <Live>{agendaNotice}</Live>
        </div>
      </Stage>

      <Stage
        index={5}
        kicker="Secrets"
        title="Protected values, typed with care"
        description="Reveal toggles stay per field, the pair confirms itself as you type, and the values clear once accepted. Sample text only; nothing is stored."
        sources={["Off Grid workflows", "Coss"]}
      >
        <form
          className="mx-auto w-full max-w-md space-y-6"
          onSubmit={(event) => {
            event.preventDefault();
            if (!secret) {
              setSecretError("Enter a sample password.");
              return;
            }
            if (secret !== confirmation) {
              setSecretError("Passwords do not match.");
              return;
            }
            setSecretError("");
            setValidating(true);
            later(() => {
              setValidating(false);
              setSecret("");
              setConfirmation("");
              setReveal(false);
              setRevealConfirmation(false);
              setSecretNotice(
                "Sample password accepted and cleared. Nothing was stored.",
              );
            }, 700);
          }}
        >
          <SecretInput
            label="Sample password"
            value={secret}
            onValueChange={setSecret}
            revealed={reveal}
            onRevealedChange={setReveal}
            disabled={validating}
          />
          <SecretInput
            label="Confirm sample password"
            value={confirmation}
            onValueChange={(value) => {
              setConfirmation(value);
              setSecretError("");
            }}
            revealed={revealConfirmation}
            onRevealedChange={setRevealConfirmation}
            disabled={validating}
            error={secretError}
          />
          <div className="flex flex-wrap items-center gap-4">
            <Button
              type="submit"
              loading={validating}
              aria-label="Validate sample password"
            >
              Validate sample password
            </Button>
            <AnimatePresence initial={false}>
              {confirmation && (
                <motion.span
                  key="match"
                  initial={{ opacity: 0, x: -6 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -6 }}
                  transition={{ duration: 0.3, ease }}
                  className="flex items-center gap-1.5 text-[12px] text-muted-foreground data-[match]:text-primary"
                  data-match={matches || undefined}
                >
                  <motion.span
                    animate={{
                      scale: matches ? 1 : 0,
                      opacity: matches ? 1 : 0,
                    }}
                    transition={spring}
                    className="flex"
                  >
                    <Check className="size-3.5" aria-hidden="true" />
                  </motion.span>
                  <TextMorph as="span">
                    {matches ? "Matches" : "Not matching yet"}
                  </TextMorph>
                </motion.span>
              )}
            </AnimatePresence>
          </div>
          <Live>{secretNotice}</Live>
        </form>
      </Stage>

      <Stage
        index={6}
        kicker="Agent"
        title="Follow reasoning and actions"
        description="Thinking, tool calls and approvals in one timeline. Allow the write and watch it run, stop it midway, or run the whole trace again."
        sources={["Off Grid workflows", "Dice UI", "SmoothUI"]}
      >
        <ToolTimelineExample later={later} />
      </Stage>
    </div>
  );
}

const RUN_LABEL: Record<ToolTimelineProps["state"], string> = {
  "needs-attention": "Waiting for your approval to create a task.",
  working: "Creating the sample task…",
  stopped: "Stopped before writing. No task was created.",
  failed: "Creating the task failed.",
  done: "Sample task created.",
};

export function ToolTimelineExample({
  later,
}: {
  later: (fn: () => void, ms: number) => ReturnType<typeof setTimeout>;
}) {
  const [state, setState] =
    React.useState<ToolTimelineProps["state"]>("needs-attention");
  const [open, setOpen] = React.useState(true);
  const run = React.useRef(0);
  const start = () => {
    const id = ++run.current;
    setState("working");
    later(() => {
      if (run.current === id) setState("done");
    }, 1800);
  };
  const entries: ToolTraceEntry[] = [
    {
      id: "reason",
      kind: "thinking",
      time: "10:30:00",
      text: "Check the sample notes before creating the release task.",
      duration: 1.4,
    },
    {
      id: "read",
      kind: "tool",
      time: "10:30:02",
      name: "read_notes",
      state: "success",
      summary: "2 notes",
      args: "release",
      result: "Beta links and review notes found.",
    },
    {
      id: "write",
      kind: "tool",
      time: "10:30:03",
      name: "create_task",
      state:
        state === "working"
          ? "running"
          : state === "done"
            ? "success"
            : state === "failed"
              ? "error"
              : state,
      args: "Review the beta release",
      summary:
        state === "needs-attention"
          ? "Permission is needed to create a task."
          : state === "stopped"
            ? "Stopped before writing. No task was created."
            : undefined,
      result: state === "done" ? "Sample task created." : undefined,
      action:
        state === "needs-attention"
          ? { label: "Allow sample action", onAction: start }
          : state === "stopped"
            ? { label: "Resume sample action", onAction: start }
            : undefined,
    },
  ];
  return (
    <div className="space-y-6">
      <div aria-busy={state === "working" || undefined}>
        <ToolTimeline
          entries={entries}
          state={state}
          expanded={open}
          onExpandedChange={setOpen}
        />
      </div>
      <div className="flex flex-wrap items-center justify-between gap-4 border-t border-border/50 pt-5">
        <Live>{RUN_LABEL[state]}</Live>
        <AnimatePresence mode="popLayout" initial={false}>
          {state === "working" ? (
            <motion.span
              key="stop"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.25, ease }}
            >
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  run.current++;
                  setState("stopped");
                }}
              >
                Stop
              </Button>
            </motion.span>
          ) : state === "done" ? (
            <motion.span
              key="again"
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.25, ease }}
            >
              <Button
                size="sm"
                variant="ghost"
                onClick={() => setState("needs-attention")}
              >
                Run again
              </Button>
            </motion.span>
          ) : null}
        </AnimatePresence>
      </div>
    </div>
  );
}
