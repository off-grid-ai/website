import { useEffect, useRef, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  ArrowLeftIcon,
  ArrowRightIcon,
  EyeOffIcon,
  GripVerticalIcon,
  PencilIcon,
  PlusIcon,
  RotateCcwIcon,
  XIcon,
} from "lucide-react";
import {
  Editable,
  EditableLabel,
  EditableArea,
  EditablePreview,
  EditableInput,
  EditableToolbar,
  EditableTrigger,
  EditableSubmit,
  EditableCancel,
} from "@offgrid/ui/operator/dice/editable";
import {
  TagsInput,
  TagsInputLabel,
  TagsInputList,
  TagsInputItem,
  TagsInputInput,
} from "@offgrid/ui/operator/dice/tags-input";
import {
  KeyValue,
  KeyValueList,
  KeyValueItem,
  KeyValueKeyInput,
  KeyValueValueInput,
  KeyValueAdd,
  KeyValueRemove,
  KeyValueError,
} from "@offgrid/ui/operator/dice/key-value";
import {
  TimePicker,
  TimePickerLabel,
  TimePickerInputGroup,
  TimePickerInput,
  TimePickerSeparator,
  TimePickerTrigger,
  TimePickerContent,
  TimePickerHour,
  TimePickerMinute,
} from "@offgrid/ui/operator/dice/time-picker";
import {
  Sortable,
  SortableContent,
  SortableItem,
  SortableItemHandle,
  SortableOverlay,
} from "@offgrid/ui/operator/dice/sortable";
import {
  Timeline,
  TimelineItem,
  TimelineDot,
  TimelineConnector,
  TimelineContent,
  TimelineHeader,
  TimelineTitle,
  TimelineDescription,
  TimelineTime,
} from "@offgrid/ui/operator/dice/timeline";
import {
  Gauge,
  GaugeIndicator,
  GaugeRange,
  GaugeTrack,
  GaugeValueText,
} from "@offgrid/ui/operator/dice/gauge";
import { Button } from "@offgrid/ui/operator/coss/button";
import { Input } from "@offgrid/ui/operator/coss/input";
import {
  Field,
  FieldLabel,
  FieldDescription,
} from "@offgrid/ui/operator/coss/field";
import { Kbd, KbdGroup } from "@offgrid/ui/operator/coss/kbd";
import { Tabs, TabsList, TabsTab } from "@offgrid/ui/operator/coss/tabs";
import { Toolbar, ToolbarButton } from "@offgrid/ui/operator/coss/toolbar";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectPopup,
  SelectItem,
} from "@offgrid/ui/operator/coss/select";
import { Checkbox } from "@offgrid/ui/operator/animate/checkbox";
import Counter from "@offgrid/ui/operator/bits/counter";
import { AnimatedNumber } from "@offgrid/ui/operator/motion/animated-number";
import { Stage } from "./stage";

const ease = [0.16, 1, 0.3, 1] as const;
const spring = { type: "spring", stiffness: 420, damping: 34 } as const;
const blurIn = {
  initial: { opacity: 0, y: 6, filter: "blur(4px)" },
  animate: { opacity: 1, y: 0, filter: "blur(0px)" },
  exit: { opacity: 0, y: -6, filter: "blur(4px)" },
  transition: { duration: 0.35, ease },
};
const eyebrow =
  "font-mono text-[10px] sm:text-[10px] font-normal uppercase leading-none sm:leading-none tracking-[0.22em] text-muted-foreground";
const hairline = "shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-text)/0.08)]";
const ENV_NAME = /^[A-Z_][A-Z0-9_]*$/;

const initialBlocks = [
  {
    id: "inbox",
    title: "Review the inbox",
    detail: "Read new notes and decide what needs a task.",
  },
  {
    id: "focus",
    title: "Focus session",
    detail: "Work on the project with local models.",
  },
  {
    id: "review",
    title: "Review the day",
    detail: "Check completed work and write the next steps.",
  },
];
type Block = (typeof initialBlocks)[number];
type StageKey = "tabs" | "details" | "values" | "blocks" | "schedule";

/** A status line whose sentences trade places instead of swapping. */
function StatusLine({ children }: { children: ReactNode }) {
  return (
    <span
      role="status"
      className="relative block min-h-4 text-xs text-muted-foreground"
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span key={String(children)} className="block" {...blurIn}>
          {children}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}

/** Height-aware reveal for messages that come and go under a control. */
function Reveal({ show, children }: { show: boolean; children: ReactNode }) {
  return (
    <AnimatePresence initial={false}>
      {show && (
        <motion.div
          initial={{ opacity: 0, height: 0, filter: "blur(4px)" }}
          animate={{ opacity: 1, height: "auto", filter: "blur(0px)" }}
          exit={{ opacity: 0, height: 0, filter: "blur(4px)" }}
          transition={{ duration: 0.32, ease }}
          className="overflow-hidden"
        >
          {children}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/** A title that crosses itself out when its block is done. */
function DoneTitle({ done, children }: { done: boolean; children: ReactNode }) {
  return (
    <span
      data-done={done || undefined}
      className="relative text-[13px] transition-colors duration-500 data-done:text-muted-foreground"
    >
      {children}
      <span
        aria-hidden
        className="absolute inset-x-0 top-1/2 h-px origin-left scale-x-0 bg-current transition-[scale] duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] in-data-done:scale-x-100"
      />
    </span>
  );
}

/** Local workspace examples built from exported library controls. */
export function WorkspaceWorkshop() {
  const [title, setTitle] = useState("Project planning");
  const [titleEditing, setTitleEditing] = useState(false);
  const [tags, setTags] = useState(["research", "local"]);
  const [environment, setEnvironment] = useState([
    { id: "env-1", key: "MODEL_PATH", value: "./models" },
    { id: "env-2", key: "LOG_LEVEL", value: "info" },
  ]);
  const [savedEnvironment, setSavedEnvironment] = useState(environment);
  const [savingValues, setSavingValues] = useState(false);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("09:00");
  const [repeat, setRepeat] = useState("Once");
  const [schedule, setSchedule] = useState("");
  const [savingSchedule, setSavingSchedule] = useState(false);
  const [blocks, setBlocks] = useState(initialBlocks);
  const [hidden, setHidden] = useState<string[]>([]);
  const [leaving, setLeaving] = useState<string[]>([]);
  const [completed, setCompleted] = useState<string[]>([]);
  const [shortcut, setShortcut] = useState(["Ctrl", "Shift", "P"]);
  const [shortcutDraft, setShortcutDraft] = useState(shortcut);
  const [capturing, setCapturing] = useState(false);
  const [shortcutError, setShortcutError] = useState("");
  const [workspaceTabs, setWorkspaceTabs] = useState([
    {
      id: "tab-1",
      label: "Project notes",
      history: ["https://example.com/notes"],
      position: 0,
    },
    {
      id: "tab-2",
      label: "Research",
      history: ["https://example.com/research"],
      position: 0,
    },
  ]);
  const [activeTab, setActiveTab] = useState("tab-1");
  const [nextTab, setNextTab] = useState(3);
  const [addressDraft, setAddressDraft] = useState("https://example.com/notes");
  const [addressError, setAddressError] = useState("");
  const [navigating, setNavigating] = useState(false);
  const [activity, setActivity] = useState([
    {
      id: 0,
      title: "Workspace opened",
      detail: "All actions affect this preview only.",
      time: "Start",
    },
  ]);
  const [notes, setNotes] = useState<Record<StageKey, string>>({
    tabs: "The address bar keeps local history and never loads external pages.",
    details: "Edit the title, add a tag, or record a new shortcut.",
    values: "Sample values are not written to your environment.",
    blocks: "Drag a handle, or focus it and use Space and the arrow keys.",
    schedule: "No schedule saved.",
  });

  const timers = useRef<Array<ReturnType<typeof setTimeout>>>([]);
  const later = (fn: () => void, ms: number) =>
    timers.current.push(setTimeout(fn, ms));
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const visibleBlocks = blocks.filter((block) => !hidden.includes(block.id));
  const hiddenBlocks = blocks.filter((block) => hidden.includes(block.id));
  const currentTab = workspaceTabs.find((tab) => tab.id === activeTab)!;
  const currentAddress = new URL(currentTab.history[currentTab.position]);
  const doneCount = blocks.filter((block) =>
    completed.includes(block.id),
  ).length;

  const record = (stage: StageKey, message: string, detail = "") => {
    setNotes((previous) => ({ ...previous, [stage]: message }));
    setActivity((previous) => [
      ...previous.slice(-3),
      {
        id: previous[previous.length - 1].id + 1,
        title: message,
        detail,
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        }),
      },
    ]);
  };
  const selectTab = (id: string) => {
    const tab = workspaceTabs.find((item) => item.id === id);
    if (!tab) return;
    setActiveTab(id);
    setAddressDraft(tab.history[tab.position]);
    setAddressError("");
  };
  const moveHistory = (offset: number) => {
    const position = currentTab.position + offset;
    if (position < 0 || position >= currentTab.history.length) return;
    setWorkspaceTabs((previous) =>
      previous.map((tab) =>
        tab.id === activeTab ? { ...tab, position } : tab,
      ),
    );
    setAddressDraft(currentTab.history[position]);
    setAddressError("");
  };
  const goToAddress = () => {
    let address: URL;
    try {
      address = new URL(addressDraft);
      if (!["https:", "http:"].includes(address.protocol))
        throw new Error("Unsupported protocol");
    } catch {
      setAddressError("Enter a full http or https address.");
      return;
    }
    setAddressError("");
    setNavigating(true);
    later(() => {
      setWorkspaceTabs((previous) =>
        previous.map((tab) =>
          tab.id === activeTab
            ? {
                ...tab,
                history: [
                  ...tab.history.slice(0, tab.position + 1),
                  address.href,
                ],
                position: tab.position + 1,
              }
            : tab,
        ),
      );
      setAddressDraft(address.href);
      setNavigating(false);
      record("tabs", "Preview address changed", address.href);
    }, 520);
  };
  const closeTab = (id: string, label: string) => {
    const index = workspaceTabs.findIndex((item) => item.id === id);
    const remaining = workspaceTabs.filter((item) => item.id !== id);
    setWorkspaceTabs(remaining);
    if (activeTab === id) {
      const next = remaining[Math.max(0, index - 1)];
      setActiveTab(next.id);
      setAddressDraft(next.history[next.position]);
      setAddressError("");
    }
    record("tabs", `Closed ${label}`);
  };
  const addTab = () => {
    const tab = {
      id: `tab-${nextTab}`,
      label: `Workspace ${nextTab}`,
      history: ["https://example.com/"],
      position: 0,
    };
    setWorkspaceTabs((previous) => [...previous, tab]);
    setNextTab(nextTab + 1);
    setActiveTab(tab.id);
    setAddressDraft(tab.history[0]);
    record("tabs", `Added ${tab.label}`);
  };
  const hideBlock = (block: Block) => {
    setLeaving((previous) => [...previous, block.id]);
    later(() => {
      setHidden((previous) => [...previous, block.id]);
      setLeaving((previous) => previous.filter((id) => id !== block.id));
      record("blocks", `Hidden ${block.title}`);
    }, 340);
  };
  const pageTitle =
    currentAddress.pathname
      .split("/")
      .filter(Boolean)
      .pop()
      ?.replace(/[-_]/g, " ") || "Home";

  return (
    <div className="min-w-0">
      <Stage
        index={1}
        kicker="Tabs"
        title="Tabs that make room for each other"
        description="New tabs slide in and their neighbours step aside. The address bar keeps its own history, and a page eases in once it has loaded."
        sources={["Coss", "Off Grid alive"]}
      >
        <Tabs
          value={activeTab}
          onValueChange={(value) => selectTab(String(value))}
        >
          <div className="flex items-center gap-2">
            <TabsList size="sm" className="max-w-full overflow-x-auto">
              <AnimatePresence initial={false} mode="popLayout">
                {workspaceTabs.map((tab) => (
                  <motion.div
                    key={tab.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9, filter: "blur(4px)" }}
                    animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                    exit={{ opacity: 0, scale: 0.9, filter: "blur(4px)" }}
                    transition={spring}
                    className="group/tab flex items-center"
                  >
                    <TabsTab value={tab.id}>{tab.label}</TabsTab>
                    <Button
                      variant="ghost"
                      size="icon-xs"
                      aria-label={`Close ${tab.label}`}
                      disabled={workspaceTabs.length === 1}
                      onClick={() => closeTab(tab.id, tab.label)}
                      className="opacity-45 transition-opacity group-hover/tab:opacity-100 focus-visible:opacity-100"
                    >
                      <XIcon />
                    </Button>
                  </motion.div>
                ))}
              </AnimatePresence>
            </TabsList>
            <motion.div layout transition={spring}>
              <Button
                variant="ghost"
                size="icon-sm"
                aria-label="Add workspace tab"
                onClick={addTab}
              >
                <PlusIcon />
              </Button>
            </motion.div>
          </div>

          <div className={`mt-6 overflow-hidden rounded-2xl ${hairline}`}>
            <Toolbar
              aria-label="Preview address toolbar"
              className="relative gap-1 rounded-none border-0 border-b border-border/50 bg-transparent p-2"
            >
              <ToolbarButton
                render={<Button variant="ghost" size="icon-sm" />}
                aria-label="Previous preview address"
                disabled={currentTab.position === 0}
                onClick={() => moveHistory(-1)}
              >
                <ArrowLeftIcon />
              </ToolbarButton>
              <ToolbarButton
                render={<Button variant="ghost" size="icon-sm" />}
                aria-label="Next preview address"
                disabled={currentTab.position === currentTab.history.length - 1}
                onClick={() => moveHistory(1)}
              >
                <ArrowRightIcon />
              </ToolbarButton>
              <div className="min-w-0 flex-1">
                <Input
                  size="sm"
                  aria-label="Preview address"
                  aria-invalid={!!addressError}
                  aria-describedby={
                    addressError ? "workspace-address-error" : undefined
                  }
                  value={addressDraft}
                  onValueChange={setAddressDraft}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") goToAddress();
                  }}
                  className="font-mono text-[12px]"
                />
              </div>
              <ToolbarButton
                render={
                  <Button size="sm" variant="outline" loading={navigating} />
                }
                onClick={goToAddress}
              >
                Go
              </ToolbarButton>
              <motion.span
                aria-hidden
                className="absolute inset-x-0 -bottom-px h-px origin-left bg-primary shadow-[0_0_12px_rgb(var(--og-rgb-primary)/0.8)]"
                initial={false}
                animate={
                  navigating
                    ? {
                        scaleX: 0.85,
                        opacity: 1,
                        transition: { duration: 0.5, ease },
                      }
                    : {
                        scaleX: 1,
                        opacity: 0,
                        transition: { duration: 0.45, ease },
                      }
                }
                style={{ scaleX: 0 }}
              />
            </Toolbar>
            <Reveal show={!!addressError}>
              <p
                id="workspace-address-error"
                role="alert"
                className="px-4 pt-3 text-xs text-destructive-foreground"
              >
                {addressError}
              </p>
            </Reveal>
            <div aria-busy={navigating} className="relative min-h-36 px-6 py-6">
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={`${currentTab.id}-${currentTab.position}`}
                  initial={{ opacity: 0, y: 8, filter: "blur(6px)" }}
                  animate={{
                    opacity: navigating ? 0.4 : 1,
                    y: 0,
                    filter: navigating ? "blur(2px)" : "blur(0px)",
                  }}
                  exit={{ opacity: 0, y: -8, filter: "blur(6px)" }}
                  transition={{ duration: 0.4, ease }}
                >
                  <p className={eyebrow}>{currentAddress.host}</p>
                  <p className="mt-3 text-xl font-light capitalize tracking-[-0.02em]">
                    {pageTitle}
                  </p>
                  <p className="mt-2 truncate font-mono text-[11px] text-muted-foreground">
                    Current preview location: {currentAddress.href}
                  </p>
                </motion.div>
              </AnimatePresence>
              <div className="mt-6 flex items-center gap-1.5" aria-hidden>
                {currentTab.history.map((entry, index) => (
                  <span
                    key={`${entry}-${index}`}
                    className="relative h-1 w-5 rounded-full bg-foreground/10"
                  >
                    {index === currentTab.position && (
                      <motion.span
                        layoutId={`history-${currentTab.id}`}
                        transition={spring}
                        className="absolute inset-0 rounded-full bg-primary shadow-[0_0_10px_rgb(var(--og-rgb-primary)/0.7)]"
                      />
                    )}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </Tabs>
        <div className="mt-5">
          <StatusLine>{notes.tabs}</StatusLine>
        </div>
      </Stage>

      <Stage
        index={2}
        kicker="Details"
        title="Details that edit where they sit"
        description="The title turns into a field in place, tags settle into the row as you type them, and a shortcut is recorded straight from the keys you press."
        sources={["Dice UI", "Coss"]}
      >
        <div className="divide-y divide-border/60">
          <div className="pb-7">
            <Editable
              value={title}
              onValueChange={setTitle}
              editing={titleEditing}
              onEditingChange={setTitleEditing}
              required
              onSubmit={(value) =>
                record("details", "Conversation title saved", value)
              }
              onCancel={() => record("details", "Title edit cancelled")}
            >
              <EditableLabel className={eyebrow}>
                Conversation title
              </EditableLabel>
              <div className="mt-3 flex items-center justify-between gap-4">
                <EditableArea className="min-w-0 flex-1">
                  <EditablePreview className="text-lg font-light tracking-[-0.015em]" />
                  <EditableInput
                    className="text-lg font-light tracking-[-0.015em]"
                    aria-invalid={!title.trim()}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" && !title.trim())
                        event.preventDefault();
                    }}
                    onBlur={(event) => {
                      if (!title.trim()) event.preventDefault();
                    }}
                  />
                </EditableArea>
                <EditableToolbar>
                  <AnimatePresence mode="popLayout" initial={false}>
                    <motion.div
                      key={titleEditing ? "editing" : "idle"}
                      className="flex items-center gap-1.5"
                      initial={{ opacity: 0, x: 8, filter: "blur(4px)" }}
                      animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                      exit={{ opacity: 0, x: -8, filter: "blur(4px)" }}
                      transition={{ duration: 0.3, ease }}
                    >
                      {titleEditing ? (
                        <>
                          <EditableCancel
                            render={<Button variant="ghost" size="sm" />}
                          >
                            Cancel
                          </EditableCancel>
                          <EditableSubmit
                            disabled={!title.trim()}
                            render={<Button size="sm" />}
                          >
                            Save
                          </EditableSubmit>
                        </>
                      ) : (
                        <EditableTrigger
                          render={<Button variant="ghost" size="sm" />}
                        >
                          <PencilIcon />
                          Edit
                        </EditableTrigger>
                      )}
                    </motion.div>
                  </AnimatePresence>
                </EditableToolbar>
              </div>
            </Editable>
          </div>

          <div className="py-7">
            <TagsInput
              value={tags}
              onValueChange={setTags}
              className="w-full gap-3"
            >
              <TagsInputLabel className={`${eyebrow} font-normal`}>
                Tags
              </TagsInputLabel>
              <TagsInputList className="min-h-9 rounded-lg border-border/70 bg-transparent px-2 py-1.5 transition-[border-color,box-shadow] duration-300 focus-within:border-primary/40 focus-within:shadow-[0_0_0_3px_rgb(var(--og-rgb-primary)/0.1)] focus-within:ring-0">
                {tags.map((tag) => (
                  <TagsInputItem
                    key={tag}
                    value={tag}
                    className="animate-[og-rise_420ms_var(--og-ease-spring)_both] rounded-full border-border/70 py-0.5 pl-2.5 text-[12px] transition-colors hover:border-primary/40"
                  >
                    {tag}
                  </TagsInputItem>
                ))}
                <TagsInputInput
                  placeholder="Add a tag…"
                  className="min-w-24 px-1 text-[12.5px]"
                />
              </TagsInputList>
            </TagsInput>
            <p className="mt-2.5 text-[11.5px] text-muted-foreground">
              Type a tag and press Enter. Backspace removes the last one.
            </p>
          </div>

          <div className="pt-7">
            <Field>
              <FieldLabel className={`${eyebrow} font-normal`}>
                Open command search
              </FieldLabel>
              <AnimatePresence mode="wait" initial={false}>
                {capturing ? (
                  <motion.div
                    key="capture"
                    className="mt-1 w-full space-y-3"
                    {...blurIn}
                  >
                    <Input
                      size="sm"
                      aria-label="Capture command search shortcut"
                      readOnly
                      autoFocus
                      value={shortcutDraft.join(" + ")}
                      aria-describedby="workspace-shortcut-help"
                      className="font-mono text-[12px]"
                      onKeyDown={(event) => {
                        if (event.key === "Escape") {
                          event.preventDefault();
                          setCapturing(false);
                          setShortcutError("");
                          return;
                        }
                        if (
                          ["Control", "Meta", "Alt", "Shift", "Tab"].includes(
                            event.key,
                          )
                        )
                          return;
                        event.preventDefault();
                        if (!(event.ctrlKey || event.altKey || event.metaKey)) {
                          setShortcutError("Include Control, Command, or Alt.");
                          return;
                        }
                        setShortcutDraft([
                          ...(event.ctrlKey ? ["Ctrl"] : []),
                          ...(event.metaKey ? ["⌘"] : []),
                          ...(event.altKey ? ["Alt"] : []),
                          ...(event.shiftKey ? ["Shift"] : []),
                          event.key === " " ? "Space" : event.key.toUpperCase(),
                        ]);
                        setShortcutError("");
                      }}
                    />
                    <FieldDescription id="workspace-shortcut-help">
                      Press a key combination. Escape cancels. This does not
                      register a device shortcut.
                    </FieldDescription>
                    <Reveal show={!!shortcutError}>
                      <p
                        role="alert"
                        className="text-xs text-destructive-foreground"
                      >
                        {shortcutError}
                      </p>
                    </Reveal>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        disabled={!!shortcutError}
                        onClick={() => {
                          setShortcut(shortcutDraft);
                          setCapturing(false);
                          record(
                            "details",
                            "Preview shortcut saved",
                            shortcutDraft.join(" + "),
                          );
                        }}
                      >
                        Save shortcut
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setCapturing(false);
                          setShortcutError("");
                        }}
                      >
                        Cancel
                      </Button>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    key="display"
                    className="mt-1 flex w-full items-center justify-between gap-3"
                    {...blurIn}
                  >
                    <KbdGroup>
                      {shortcut.map((key, index) => (
                        <motion.span
                          key={`${shortcut.join("+")}-${index}`}
                          className="inline-flex"
                          initial={{ opacity: 0, y: -6, filter: "blur(3px)" }}
                          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                          transition={{ ...spring, delay: index * 0.05 }}
                        >
                          <Kbd className="h-6 min-w-6 px-1.5 font-mono text-[11px] shadow-[inset_0_-1px_0_rgb(var(--og-rgb-text)/0.08)]">
                            {key}
                          </Kbd>
                        </motion.span>
                      ))}
                    </KbdGroup>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setShortcutDraft(shortcut);
                        setCapturing(true);
                      }}
                    >
                      Edit shortcut
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </Field>
          </div>
        </div>
        <div className="mt-6">
          <StatusLine>{notes.details}</StatusLine>
        </div>
      </Stage>

      <Stage
        index={3}
        kicker="Values"
        title="Rows that grow with what you add"
        description="Each new pair rises into the list. Names are checked as you type, and paste a block of KEY=value lines to add them all at once."
        sources={["Dice UI", "Coss"]}
      >
        <KeyValue
          value={environment}
          onValueChange={setEnvironment}
          allowDuplicateKeys={false}
          onKeyValidate={(key) =>
            key && !ENV_NAME.test(key)
              ? "Use uppercase letters, numbers, and underscores."
              : undefined
          }
          className="space-y-3"
        >
          <div className={`flex gap-2 pr-10 pl-0.5 ${eyebrow}`}>
            <span className="flex-1">Name</span>
            <span className="flex-1">Value</span>
          </div>
          <KeyValueList className="gap-2">
            <KeyValueItem
              render={
                <motion.div
                  layout
                  initial={{ opacity: 0, y: -8, filter: "blur(4px)" }}
                  animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                  transition={spring}
                />
              }
            >
              <div className="min-w-0 flex-1 space-y-1">
                <KeyValueKeyInput
                  aria-label="Environment key"
                  className="h-8 font-mono text-[12px] md:text-[12px]"
                />
                <KeyValueError
                  field="key"
                  className="animate-[og-rise_420ms_var(--og-ease-spring)_both] text-[11px]"
                />
              </div>
              <div className="min-w-0 flex-1">
                <KeyValueValueInput
                  aria-label="Environment value"
                  className="min-h-8 py-1.5 font-mono text-[12px] leading-[1.4] md:text-[12px]"
                />
              </div>
              <KeyValueRemove
                variant="ghost"
                size="icon-sm"
                aria-label="Remove environment value"
              >
                <XIcon />
              </KeyValueRemove>
            </KeyValueItem>
          </KeyValueList>
          <KeyValueAdd
            variant="ghost"
            size="sm"
            className="w-full justify-start text-muted-foreground"
          >
            <PlusIcon />
            Add value
          </KeyValueAdd>
        </KeyValue>
        <div className="mt-8 flex flex-wrap items-center gap-3">
          <Button
            size="sm"
            loading={savingValues}
            onClick={() => {
              if (environment.some((item) => !ENV_NAME.test(item.key))) {
                record(
                  "values",
                  "Check the environment names",
                  "Each name must start with an uppercase letter or underscore.",
                );
                return;
              }
              setSavingValues(true);
              later(() => {
                setSavedEnvironment(environment.map((item) => ({ ...item })));
                setSavingValues(false);
                record("values", `${environment.length} runtime values saved`);
              }, 600);
            }}
          >
            Save values
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => {
              setEnvironment(savedEnvironment.map((item) => ({ ...item })));
              record("values", "Unsaved runtime changes discarded");
            }}
          >
            Discard changes
          </Button>
          <StatusLine>{notes.values}</StatusLine>
        </div>
      </Stage>

      <Stage
        index={4}
        kicker="Order"
        title="A day you can rearrange by hand"
        description="Lift a block and it follows the pointer while the others make space. Completed blocks cross themselves out, hidden ones fold away and can be brought back."
        sources={["Dice UI", "Animate UI", "Coss"]}
      >
        <Sortable
          value={visibleBlocks}
          onValueChange={(items) => {
            setBlocks([...items, ...hiddenBlocks]);
            record("blocks", "Day blocks reordered");
          }}
          getItemValue={(block) => block.id}
        >
          <SortableContent className="divide-y divide-border/60 overflow-hidden rounded-xl border border-border">
            {visibleBlocks.map((block, index) => (
              <SortableItem
                key={block.id}
                value={block.id}
                render={<div className="min-w-0" />}
              >
                <div
                  data-leaving={leaving.includes(block.id) || undefined}
                  style={{ animationDelay: `${index * 60}ms` }}
                  className="grid animate-[og-rise_520ms_var(--og-ease-out)_both] grid-rows-[1fr] transition-[grid-template-rows,opacity,filter] duration-300 ease-[cubic-bezier(0.16,1,0.3,1)] data-leaving:grid-rows-[0fr] data-leaving:opacity-0 data-leaving:blur-[4px]"
                >
                  <div className="min-h-0 overflow-hidden">
                    <div className="group/row flex min-h-11 items-center gap-2 px-1.5 py-1 transition-colors hover:bg-foreground/[0.035] focus-within:bg-foreground/[0.035]">
                      <SortableItemHandle
                        render={<Button variant="ghost" size="icon-sm" />}
                        aria-label={`Move ${block.title}`}
                        className="text-muted-foreground opacity-50 transition-opacity group-hover/row:opacity-100"
                      >
                        <GripVerticalIcon />
                      </SortableItemHandle>
                      <Field className="min-w-0 flex-1 flex-row items-center gap-3">
                        <FieldLabel className="shrink-0 font-normal">
                          <Checkbox
                            checked={completed.includes(block.id)}
                            onCheckedChange={(checked) => {
                              setCompleted((previous) =>
                                checked
                                  ? [...new Set([...previous, block.id])]
                                  : previous.filter((id) => id !== block.id),
                              );
                              record(
                                "blocks",
                                checked
                                  ? `Completed ${block.title}`
                                  : `Reopened ${block.title}`,
                              );
                            }}
                          />
                          <DoneTitle done={completed.includes(block.id)}>
                            {block.title}
                          </DoneTitle>
                        </FieldLabel>
                        <FieldDescription className="min-w-0 flex-1 truncate text-[11.5px]">
                          {block.detail}
                        </FieldDescription>
                      </Field>
                      <Button
                        variant="ghost"
                        size="icon-sm"
                        aria-label={`Hide ${block.title}`}
                        className="opacity-0 transition-opacity group-hover/row:opacity-100 group-focus-within/row:opacity-100 focus-visible:opacity-100"
                        onClick={() => hideBlock(block)}
                      >
                        <EyeOffIcon />
                      </Button>
                    </div>
                  </div>
                </div>
              </SortableItem>
            ))}
          </SortableContent>
          <SortableOverlay>
            {({ value }) => {
              const block = blocks.find((item) => item.id === value);
              if (!block) return null;
              return (
                <div className="rounded-xl bg-popover/90 px-3 py-3 shadow-[0_0_0_1px_rgb(var(--og-rgb-primary)/0.35),0_18px_40px_-14px_rgb(0_0_0/0.7),0_0_40px_-16px_rgb(var(--og-rgb-primary)/0.6)] backdrop-blur-md">
                  <div className="flex items-start gap-3">
                    <span className="flex size-8 items-center justify-center text-primary">
                      <GripVerticalIcon className="size-4" />
                    </span>
                    <div className="min-w-0 flex-1 pt-1.5">
                      <DoneTitle done={completed.includes(block.id)}>
                        {block.title}
                      </DoneTitle>
                      <p className="mt-1 text-[11.5px] text-muted-foreground">
                        {block.detail}
                      </p>
                    </div>
                  </div>
                </div>
              );
            }}
          </SortableOverlay>
        </Sortable>
        <Reveal show={!visibleBlocks.length}>
          <div className="py-6 text-center">
            <p className="text-[13px]">All blocks hidden</p>
            <p className="mt-1 text-[11.5px] text-muted-foreground">
              Restore a block below to bring it back.
            </p>
          </div>
        </Reveal>
        <motion.div layout className="mt-4 flex flex-wrap items-center gap-2">
          <AnimatePresence mode="popLayout" initial={false}>
            {hiddenBlocks.map((block) => (
              <motion.div
                key={block.id}
                layout
                initial={{ opacity: 0, scale: 0.92, filter: "blur(4px)" }}
                animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                exit={{ opacity: 0, scale: 0.92, filter: "blur(4px)" }}
                transition={spring}
              >
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setHidden((previous) =>
                      previous.filter((id) => id !== block.id),
                    );
                    record("blocks", `Restored ${block.title}`);
                  }}
                >
                  <RotateCcwIcon />
                  Restore {block.title}
                </Button>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
        <div className="mt-4">
          <StatusLine>{notes.blocks}</StatusLine>
        </div>
      </Stage>

      <Stage
        index={5}
        kicker="Schedule"
        title="A time picked in two moves"
        description="Choose a day, roll the hours and minutes, and pick a rhythm. The saved schedule reads back as one sentence."
        sources={["Dice UI", "Coss"]}
      >
        <div className="grid gap-x-8 gap-y-8 sm:grid-cols-2">
          <Field>
            <FieldLabel>Start date</FieldLabel>
            <Input
              type="date"
              value={date}
              onValueChange={setDate}
              className="[color-scheme:dark]"
            />
          </Field>
          <TimePicker
            value={time}
            onValueChange={setTime}
            locale="en-GB"
            minuteStep={5}
            className="flex flex-col gap-2"
          >
            <TimePickerLabel className="leading-4">Start time</TimePickerLabel>
            <TimePickerInputGroup className="h-9 rounded-lg border-input sm:h-8 bg-transparent shadow-none dark:bg-input/32">
              <TimePickerInput segment="hour" aria-label="Start time hours" />
              <TimePickerSeparator />
              <TimePickerInput
                segment="minute"
                aria-label="Start time minutes"
              />
              <TimePickerTrigger aria-label="Choose start time" />
            </TimePickerInputGroup>
            <TimePickerContent>
              <TimePickerHour />
              <TimePickerMinute />
            </TimePickerContent>
          </TimePicker>
          <Field className="sm:col-span-2">
            <FieldLabel>Repeat</FieldLabel>
            <Select
              value={repeat}
              onValueChange={(value) => value && setRepeat(value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectPopup>
                {["Once", "Every day", "Weekdays", "Every week"].map(
                  (value) => (
                    <SelectItem key={value} value={value}>
                      {value}
                    </SelectItem>
                  ),
                )}
              </SelectPopup>
            </Select>
            <FieldDescription>
              Uses the current device time zone.
            </FieldDescription>
          </Field>
        </div>
        <div className={`mt-9 rounded-2xl px-5 py-4 ${hairline}`}>
          <p className={eyebrow}>Saved schedule</p>
          <div className="mt-2 text-[15px] font-light">
            <AnimatePresence mode="wait" initial={false}>
              <motion.p key={schedule || "none"} {...blurIn}>
                {schedule || (
                  <span className="text-muted-foreground">
                    Nothing scheduled yet
                  </span>
                )}
              </motion.p>
            </AnimatePresence>
          </div>
        </div>
        <div className="mt-6 flex flex-wrap items-center gap-3">
          <Button
            size="sm"
            disabled={!date || !time}
            loading={savingSchedule}
            onClick={() => {
              const day = new Date(`${date}T00:00`).toLocaleDateString(
                undefined,
                {
                  weekday: "short",
                  day: "numeric",
                  month: "short",
                },
              );
              const description = `${day} at ${time} · ${repeat}`;
              setSavingSchedule(true);
              later(() => {
                setSchedule(description);
                setSavingSchedule(false);
                record("schedule", "Preview schedule saved", description);
              }, 500);
            }}
          >
            Save schedule
          </Button>
          <Button
            size="sm"
            variant="ghost"
            disabled={!schedule}
            onClick={() => {
              setSchedule("");
              record("schedule", "Preview schedule removed");
            }}
          >
            Remove schedule
          </Button>
          <StatusLine>{notes.schedule}</StatusLine>
        </div>
      </Stage>

      <Stage
        index={6}
        kicker="Activity"
        title="A record that keeps up with you"
        description="Everything you do above lands here. The gauge eases toward the new total, counts roll rather than swap, and each event rises into the timeline."
        sources={["Dice UI", "React Bits", "Motion Primitives"]}
      >
        <div className="grid items-start gap-12 lg:grid-cols-[12rem_minmax(0,1fr)]">
          <div className="space-y-8">
            <Gauge
              value={doneCount}
              max={blocks.length}
              size={128}
              thickness={4}
              aria-label="Completed day blocks"
              className="mx-auto lg:mx-0"
            >
              <GaugeIndicator>
                <GaugeTrack className="text-foreground/8" />
                <GaugeRange className="duration-1000 ease-[cubic-bezier(0.16,1,0.3,1)] drop-shadow-[0_0_6px_rgb(var(--og-rgb-primary)/0.7)]" />
              </GaugeIndicator>
              <GaugeValueText className="flex-col gap-0.5 font-normal">
                <span className="flex items-baseline" aria-hidden>
                  <Counter
                    value={doneCount}
                    fontSize={28}
                    gap={0}
                    horizontalPadding={0}
                    fontWeight={300}
                    gradientFrom="transparent"
                    textColor="var(--foreground)"
                  />
                  <span className="ml-1 font-mono text-[11px] text-muted-foreground">
                    / {blocks.length}
                  </span>
                </span>
              </GaugeValueText>
            </Gauge>
            <dl className="divide-y divide-border/50 text-[12px]">
              {[
                { label: "Hidden", value: hidden.length },
                { label: "Tabs", value: workspaceTabs.length },
                { label: "Tags", value: tags.length },
                { label: "Saved values", value: savedEnvironment.length },
              ].map((item) => (
                <div
                  key={item.label}
                  className="flex items-center justify-between py-2"
                >
                  <dt className="text-muted-foreground">{item.label}</dt>
                  <dd className="font-mono text-[12px]">
                    <AnimatedNumber
                      value={item.value}
                      springOptions={{ bounce: 0, duration: 600 }}
                    />
                  </dd>
                </div>
              ))}
            </dl>
          </div>
          <Timeline activeIndex={activity.length}>
            <AnimatePresence initial={false} mode="popLayout">
              {activity.map((event, index) => (
                <TimelineItem
                  key={event.id}
                  render={
                    <motion.div
                      layout
                      initial={{ opacity: 0, y: 12, filter: "blur(6px)" }}
                      animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                      exit={{ opacity: 0, y: -12, filter: "blur(6px)" }}
                      transition={{ duration: 0.5, ease }}
                    />
                  }
                >
                  <TimelineDot />
                  {index < activity.length - 1 && <TimelineConnector />}
                  <TimelineContent>
                    <TimelineHeader>
                      <TimelineTitle className="text-[13px] font-normal">
                        {event.title}
                      </TimelineTitle>
                      <TimelineTime className="font-mono text-[10px]">
                        {event.time}
                      </TimelineTime>
                    </TimelineHeader>
                    {event.detail && (
                      <TimelineDescription className="truncate text-[11.5px]">
                        {event.detail}
                      </TimelineDescription>
                    )}
                  </TimelineContent>
                </TimelineItem>
              ))}
            </AnimatePresence>
          </Timeline>
        </div>
      </Stage>
    </div>
  );
}
