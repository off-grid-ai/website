import { useState } from "react";
import { Segmented } from "@offgrid/ui/operator/segmented";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { FileCode2Icon, FileTextIcon, TableIcon } from "lucide-react";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "@offgrid/ui/operator/chart";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@offgrid/ui/operator/coss/table";
import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@offgrid/ui/operator/resizable";
import AIArtifact from "@offgrid/ui/operator/ai-artifact";
import { AnimatedNumber } from "@offgrid/ui/operator/motion/animated-number";
import { Stage } from "./stage";

type Day = { day: string; focused: number; meetings: number; other: number };
const weeks: Record<"this" | "last", Day[]> = {
  this: [
    { day: "Mon", focused: 160, meetings: 70, other: 30 },
    { day: "Tue", focused: 220, meetings: 50, other: 40 },
    { day: "Wed", focused: 190, meetings: 80, other: 20 },
    { day: "Thu", focused: 260, meetings: 30, other: 35 },
    { day: "Fri", focused: 210, meetings: 60, other: 25 },
  ],
  last: [
    { day: "Mon", focused: 120, meetings: 95, other: 40 },
    { day: "Tue", focused: 175, meetings: 80, other: 30 },
    { day: "Wed", focused: 140, meetings: 110, other: 35 },
    { day: "Thu", focused: 205, meetings: 60, other: 45 },
    { day: "Fri", focused: 185, meetings: 70, other: 20 },
  ],
};
const config = {
  focused: { label: "Focus", color: "var(--primary)" },
  meetings: { label: "Meetings", color: "rgb(var(--og-rgb-primary) / 0.38)" },
  other: { label: "Other", color: "rgb(var(--og-rgb-text) / 0.18)" },
};
const ease = [0.16, 1, 0.3, 1] as const;
const sum = (rows: Day[], key: keyof Omit<Day, "day">) =>
  rows.reduce((total, row) => total + row[key], 0);

function ActivityChart({
  data,
  comparison = false,
  className = "h-60",
}: {
  data: Day[];
  comparison?: boolean;
  className?: string;
}) {
  const reduce = useReducedMotion();
  const motionProps = {
    isAnimationActive: !reduce,
    animationDuration: 700,
    animationEasing: "ease-out" as const,
  };
  return (
    <ChartContainer
      config={config}
      className={`aspect-auto w-full ${className}`}
      aria-label={
        comparison
          ? "Daily focus and meeting minutes"
          : "Weekly activity distribution in minutes"
      }
    >
      <BarChart
        accessibilityLayer
        data={data}
        barSize={comparison ? 10 : 22}
        barGap={3}
        margin={{ top: 8, right: 4, left: 0, bottom: 0 }}
      >
        <CartesianGrid vertical={false} strokeDasharray="2 6" />
        <XAxis
          dataKey="day"
          tickLine={false}
          axisLine={false}
          tickMargin={10}
        />
        <YAxis width={30} tickLine={false} axisLine={false} tickCount={4} />
        <ChartTooltip
          cursor={{ fill: "rgb(var(--og-rgb-text) / 0.04)", radius: 8 }}
          content={<ChartTooltipContent />}
        />
        <ChartLegend content={<ChartLegendContent />} />
        <Bar
          dataKey="focused"
          stackId={comparison ? undefined : "time"}
          fill="var(--color-focused)"
          radius={comparison ? [3, 3, 0, 0] : [0, 0, 3, 3]}
          {...motionProps}
        />
        <Bar
          dataKey="meetings"
          stackId={comparison ? undefined : "time"}
          fill="var(--color-meetings)"
          radius={comparison ? [3, 3, 0, 0] : 0}
          {...motionProps}
        />
        {!comparison && (
          <Bar
            dataKey="other"
            stackId="time"
            fill="var(--color-other)"
            radius={[3, 3, 0, 0]}
            {...motionProps}
          />
        )}
      </BarChart>
    </ChartContainer>
  );
}

function Metric({
  label,
  value,
  suffix,
  delta,
}: {
  label: string;
  value: number;
  suffix?: string;
  delta: number;
}) {
  return (
    <div className="min-w-0">
      <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
        {label}
      </p>
      <p className="mt-2 flex items-baseline gap-1 text-[28px] font-light leading-none tracking-[-0.02em]">
        <AnimatedNumber
          value={value}
          springOptions={{ stiffness: 140, damping: 22 }}
        />
        {suffix && (
          <span className="text-[13px] text-muted-foreground">{suffix}</span>
        )}
      </p>
      <AnimatePresence mode="wait" initial={false}>
        <motion.p
          key={delta}
          initial={{ opacity: 0, y: 4, filter: "blur(3px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          exit={{ opacity: 0, y: -4, filter: "blur(3px)" }}
          transition={{ duration: 0.3, ease }}
          className={`mt-2 font-mono text-[10.5px] ${delta >= 0 ? "text-primary" : "text-muted-foreground"}`}
        >
          {delta === 0
            ? "baseline"
            : `${delta > 0 ? "+" : "−"}${Math.abs(delta)}% vs other week`}
        </motion.p>
      </AnimatePresence>
    </div>
  );
}

const artifacts = [
  {
    id: "chart",
    title: "activity-report.tsx",
    icon: FileCode2Icon,
    note: "Stacked chart",
    code: `<ActivityChart\n  data={weekly}\n  series={["focused", "meetings", "other"]}\n/>`,
  },
  {
    id: "table",
    title: "focus-table.tsx",
    icon: TableIcon,
    note: "Daily minutes",
    code: `<Table rows={weekly} columns={["day", "focused", "meetings"]} />`,
  },
  {
    id: "summary",
    title: "weekly-summary.md",
    icon: FileTextIcon,
    note: "Written recap",
    code: `## This week\n\nFocus time rose on four of five days.\nThursday was the longest stretch.`,
  },
] as const;
type ArtifactId = (typeof artifacts)[number]["id"];

function ArtifactPreview({ id }: { id: ArtifactId }) {
  if (id === "chart")
    return <ActivityChart data={weeks.this} className="h-52" />;
  if (id === "table")
    return (
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Day</TableHead>
            <TableHead className="text-right">Focus</TableHead>
            <TableHead className="text-right">Meetings</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {weeks.this.map((row) => (
            <TableRow key={row.day}>
              <TableCell>{row.day}</TableCell>
              <TableCell className="text-right font-mono tabular-nums">
                {row.focused}
              </TableCell>
              <TableCell className="text-right font-mono tabular-nums">
                {row.meetings}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  return (
    <div className="space-y-2 px-1 py-2 text-[13px] leading-relaxed">
      <p className="text-[15px] font-normal">This week</p>
      <p className="text-muted-foreground">
        Focus time rose on four of five days. Thursday was the longest stretch,
        with 260 minutes and only half an hour of meetings.
      </p>
    </div>
  );
}

export function InspectionWorkshop() {
  const [week, setWeek] = useState<"this" | "last">("this");
  const [reading, setReading] = useState<"chart" | "table">("chart");
  const [artifact, setArtifact] = useState<ArtifactId>("chart");
  const [split, setSplit] = useState(34);

  const data = weeks[week];
  const other = weeks[week === "this" ? "last" : "this"];
  const focus = sum(data, "focused");
  const meetings = sum(data, "meetings");
  const total = focus + meetings + sum(data, "other");
  const share = Math.round((focus / total) * 100);
  const otherFocus = sum(other, "focused");
  const otherMeetings = sum(other, "meetings");
  const otherShare = Math.round(
    (otherFocus / (otherFocus + otherMeetings + sum(other, "other"))) * 100,
  );
  const change = (now: number, before: number) =>
    Math.round(((now - before) / before) * 100);
  const current = artifacts.find(({ id }) => id === artifact) ?? artifacts[0];

  return (
    <div className="min-w-0">
      <Stage
        index={1}
        kicker="Charts"
        title="Charts that grow into their numbers"
        description="Switch the week and every bar eases to its new height while the totals roll toward theirs. Hover a day for its breakdown, or move through days with the arrow keys."
        sources={["shadcn charts", "Recharts", "Motion Primitives"]}
      >
        <div className="space-y-10">
          <div className="flex flex-wrap items-start justify-between gap-6">
            <div className="grid flex-1 grid-cols-3 gap-6">
              <Metric
                label="Focus"
                value={focus}
                suffix="min"
                delta={change(focus, otherFocus)}
              />
              <Metric
                label="Meetings"
                value={meetings}
                suffix="min"
                delta={change(meetings, otherMeetings)}
              />
              <Metric
                label="Focus share"
                value={share}
                suffix="%"
                delta={share - otherShare}
              />
            </div>
            <Segmented
              label="Week"
              value={week}
              onValueChange={setWeek}
              options={[
                { id: "this", label: "This week" },
                { id: "last", label: "Last week" },
              ]}
            />
          </div>
          <ActivityChart data={data} />
          <p role="status" className="sr-only">
            {week === "this" ? "Showing this week." : "Showing last week."}
          </p>
        </div>
      </Stage>

      <Stage
        index={2}
        kicker="Readings"
        title="The same numbers, read two ways"
        description="Compare days side by side, or switch to the table behind the chart. The view dissolves into the other instead of swapping, and rows arrive one after another."
        sources={["shadcn charts", "Coss", "Motion Primitives"]}
      >
        <div className="space-y-8">
          <Segmented
            label="Reading"
            value={reading}
            onValueChange={setReading}
            options={[
              { id: "chart", label: "Chart" },
              { id: "table", label: "Data table" },
            ]}
          />
          <div className="min-h-64">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={reading}
                initial={{ opacity: 0, y: 8, filter: "blur(6px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -8, filter: "blur(6px)" }}
                transition={{ duration: 0.35, ease }}
              >
                {reading === "chart" ? (
                  <ActivityChart data={weeks.this} comparison />
                ) : (
                  <Table aria-label="Daily minutes this week">
                    <TableHeader>
                      <TableRow>
                        <TableHead>Day</TableHead>
                        <TableHead className="text-right">Focus</TableHead>
                        <TableHead className="text-right">Meetings</TableHead>
                        <TableHead className="text-right">Other</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {weeks.this.map((row, index) => (
                        <TableRow
                          key={row.day}
                          style={{ animationDelay: `${index * 35}ms` }}
                          className="motion-safe:animate-[og-rise_420ms_cubic-bezier(0.16,1,0.3,1)_both]"
                        >
                          <TableCell>{row.day}</TableCell>
                          <TableCell className="text-right font-mono tabular-nums text-primary">
                            {row.focused}
                          </TableCell>
                          <TableCell className="text-right font-mono tabular-nums">
                            {row.meetings}
                          </TableCell>
                          <TableCell className="text-right font-mono tabular-nums text-muted-foreground">
                            {row.other}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                    <TableFooter>
                      <TableRow>
                        <TableCell>Total</TableCell>
                        <TableCell className="text-right font-mono tabular-nums">
                          {sum(weeks.this, "focused")}
                        </TableCell>
                        <TableCell className="text-right font-mono tabular-nums">
                          {sum(weeks.this, "meetings")}
                        </TableCell>
                        <TableCell className="text-right font-mono tabular-nums">
                          {sum(weeks.this, "other")}
                        </TableCell>
                      </TableRow>
                    </TableFooter>
                  </Table>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
          <p role="status" className="sr-only">
            {reading === "chart"
              ? "Showing the chart."
              : "Showing the data table."}
          </p>
        </div>
      </Stage>

      <Stage
        index={3}
        kicker="Artifacts"
        title="Artifacts beside their source"
        description="Pick an artifact and it slides into the frame. Drag the divider, or focus it and use the arrow keys; the split follows your hand and the frame keeps its preview and code one swipe apart."
        sources={["SmoothUI", "react-resizable-panels"]}
        specimenClassName="p-6 sm:p-8"
      >
        <ResizablePanelGroup
          orientation="horizontal"
          className="min-h-80 rounded-2xl shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-text)/0.07)]"
          onLayoutChange={(layout) => {
            const first = Object.values(layout)[0];
            if (typeof first === "number") setSplit(Math.round(first));
          }}
        >
          <ResizablePanel defaultSize="34%" minSize="22%">
            <div className="flex h-full flex-col gap-1 p-3">
              <p className="px-2 pb-2 pt-1 font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                Artifacts
              </p>
              <div
                role="listbox"
                aria-label="Artifacts"
                className="flex flex-col gap-0.5"
              >
                {artifacts.map(({ id, title, icon: Icon, note }, index) => (
                  <motion.button
                    key={id}
                    type="button"
                    role="option"
                    aria-selected={artifact === id}
                    onClick={() => setArtifact(id)}
                    initial={{ opacity: 0, x: -6 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.06, duration: 0.45, ease }}
                    className="group relative flex min-w-0 items-center gap-3 rounded-lg px-2.5 py-2 text-left outline-none focus-visible:ring-2 focus-visible:ring-ring/60"
                  >
                    {artifact === id && (
                      <motion.span
                        layoutId="inspection-artifact-active"
                        transition={{
                          type: "spring",
                          bounce: 0.15,
                          duration: 0.5,
                        }}
                        className="absolute inset-0 rounded-lg bg-primary/10 shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-primary)/0.3)]"
                      />
                    )}
                    <span className="absolute inset-0 rounded-lg bg-foreground/0 transition-colors duration-300 group-hover:bg-foreground/[0.035]" />
                    <Icon
                      aria-hidden="true"
                      className={`relative size-4 shrink-0 transition-colors duration-300 ${artifact === id ? "text-primary" : "text-muted-foreground group-hover:text-foreground"}`}
                    />
                    <span className="relative min-w-0">
                      <span className="block truncate text-[12.5px] transition-transform duration-300 group-hover:translate-x-0.5">
                        {title}
                      </span>
                      <span className="block truncate text-[11px] text-muted-foreground">
                        {note}
                      </span>
                    </span>
                  </motion.button>
                ))}
              </div>
              <p className="mt-auto px-2 pt-6 font-mono text-[10px] tracking-[0.18em] text-muted-foreground">
                <AnimatedNumber
                  value={split}
                  springOptions={{ stiffness: 260, damping: 30 }}
                />
                <span className="text-muted-foreground/50"> / </span>
                <AnimatedNumber
                  value={100 - split}
                  springOptions={{ stiffness: 260, damping: 30 }}
                />
              </p>
            </div>
          </ResizablePanel>
          <ResizableHandle
            aria-label="Resize artifact workspace"
            className="group/handle w-px bg-border/50 transition-colors duration-300 data-[separator=active]:bg-primary data-[separator=focus]:bg-primary/70 data-[separator=hover]:bg-primary/50"
          >
            <span className="z-10 h-8 w-1 rounded-full bg-border transition-[background-color,height,box-shadow] duration-300 group-data-[separator=active]/handle:h-12 group-data-[separator=active]/handle:bg-primary group-data-[separator=active]/handle:shadow-[0_0_14px_rgb(var(--og-rgb-primary)/0.7)] group-data-[separator=hover]/handle:h-10 group-data-[separator=hover]/handle:bg-primary/70" />
          </ResizableHandle>
          <ResizablePanel defaultSize="66%" minSize="40%">
            <div className="h-full p-3">
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={current.id}
                  initial={{ opacity: 0, y: 10, filter: "blur(6px)" }}
                  animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                  exit={{ opacity: 0, y: -6, filter: "blur(6px)" }}
                  transition={{ duration: 0.32, ease }}
                >
                  <AIArtifact
                    title={current.title}
                    code={current.code}
                    preview={<ArtifactPreview id={current.id} />}
                    copyText={current.code}
                    className="border-border/60 bg-background/60"
                  />
                </motion.div>
              </AnimatePresence>
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
        <p role="status" className="sr-only">
          {`${current.title} open.`}
        </p>
      </Stage>
    </div>
  );
}
