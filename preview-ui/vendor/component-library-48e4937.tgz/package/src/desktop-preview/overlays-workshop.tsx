import {
  useEffect,
  useRef,
  useState,
} from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  ArrowRightIcon,
  CalendarIcon,
  CheckIcon,
  ChevronDownIcon,
  FileTextIcon,
  FolderIcon,
  LinkIcon,
  MoreHorizontalIcon,
  PinIcon,
  RotateCcwIcon,
  SearchIcon,
  SettingsIcon,
  ShieldCheckIcon,
  TrashIcon,
} from "lucide-react";
import { Button } from "@offgrid/ui/operator/coss/button";
import { Badge } from "@offgrid/ui/operator/coss/badge";
import {
  Field,
  FieldDescription,
  FieldError,
  FieldLabel,
} from "@offgrid/ui/operator/coss/field";
import { Input } from "@offgrid/ui/operator/coss/input";
import { Textarea } from "@offgrid/ui/operator/coss/textarea";
import { Kbd, KbdGroup } from "@offgrid/ui/operator/coss/kbd";
import { Switch } from "@offgrid/ui/operator/animate/switch";
import { Checkbox } from "@offgrid/ui/operator/animate/checkbox";
import {
  Menu,
  MenuTrigger,
  MenuPopup,
  MenuItem,
  MenuGroup,
  MenuGroupLabel,
  MenuCheckboxItem,
  MenuRadioGroup,
  MenuRadioItem,
  MenuSeparator,
  MenuSub,
  MenuSubTrigger,
  MenuSubPopup,
} from "@offgrid/ui/operator/coss/menu";
import {
  ContextMenu,
  ContextMenuTrigger,
  ContextMenuPopup,
  ContextMenuItem,
  ContextMenuSeparator,
} from "@offgrid/ui/operator/coss/context-menu";
import {
  Dialog,
  DialogPopup,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@offgrid/ui/operator/animate/dialog";
import {
  AlertDialog,
  AlertDialogPopup,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogClose,
} from "@offgrid/ui/operator/animate/alert-dialog";
import {
  Sheet,
  SheetTrigger,
  SheetContent as SheetPopup,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
  SheetClose,
} from "@offgrid/ui/operator/animate/sheet";
import {
  Popover,
  PopoverTrigger,
  PopoverPopup,
  PopoverTitle,
  PopoverDescription,
  PopoverClose,
} from "@offgrid/ui/operator/coss/popover";
import {
  Tooltip,
  TooltipProvider,
  TooltipTrigger,
  TooltipPopup,
} from "@offgrid/ui/operator/coss/tooltip";
import {
  Command,
  CommandDialog,
  CommandDialogPrimitive,
  CommandDialogPopup,
  CommandInput,
  CommandPanel,
  CommandList,
  CommandItem,
  CommandEmpty,
  CommandFooter,
} from "@offgrid/ui/operator/coss/command";
import { Calendar } from "@offgrid/ui/operator/coss/calendar";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectPopup,
  SelectItem,
} from "@offgrid/ui/operator/coss/select";
import { AnimatedNumber } from "@offgrid/ui/operator/motion/animated-number";
import { Stage } from "./stage";
import { AutoHeight } from "@offgrid/ui/operator/presence";

const ease = [0.16, 1, 0.3, 1] as const;
const spring = { type: "spring", stiffness: 380, damping: 32 } as const;
const folders = ["Project notes", "Research", "Downloads"];
const priorities = ["Low", "Normal", "High"] as const;

type Access = { folder: string; network: boolean; write: boolean };
type Task = Access & {
  id: string;
  name: string;
  pinned: boolean;
  priority: (typeof priorities)[number];
  archived: boolean;
};
const initialTasks: Task[] = [
  {
    id: "notes",
    name: "Review project notes",
    folder: "Project notes",
    network: false,
    write: false,
    pinned: true,
    priority: "Normal",
    archived: false,
  },
  {
    id: "research",
    name: "Summarise research",
    folder: "Research",
    network: true,
    write: false,
    pinned: false,
    priority: "High",
    archived: false,
  },
  {
    id: "downloads",
    name: "Tidy downloads",
    folder: "Downloads",
    network: false,
    write: true,
    pinned: false,
    priority: "Low",
    archived: false,
  },
];

const commandActions = [
  "Edit task permissions",
  "Open workspace settings",
  "Schedule a run",
  "Restore default settings",
];
const commandIcons: Record<string, typeof SearchIcon> = {
  [commandActions[0]]: ShieldCheckIcon,
  [commandActions[1]]: SettingsIcon,
  [commandActions[2]]: CalendarIcon,
  [commandActions[3]]: RotateCcwIcon,
};

const initialSettings = {
  downloads: true,
  notifications: true,
  history: false,
  askBeforeRun: true,
  localOnly: true,
  pauseOnBattery: false,
};
type SettingKey = keyof typeof initialSettings;
const settingsLabels: Record<SettingKey, [string, string]> = {
  downloads: ["Download updates", "Keep the local model files current."],
  notifications: [
    "Task notifications",
    "Show a notification when a task finishes.",
  ],
  history: ["Keep task history", "Retain previous results on this device."],
  askBeforeRun: [
    "Ask before running tools",
    "Review each tool request before it runs.",
  ],
  localOnly: ["Use local models", "Run requests on this device."],
  pauseOnBattery: [
    "Pause on battery",
    "Resume downloads when power is connected.",
  ],
};
const settingKeys = Object.keys(settingsLabels) as SettingKey[];
const workspaceFiles = ["README.md", "research.md", "release-notes.md"];

const formatDay = (date: Date) =>
  date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
const describeNetwork = (on: boolean) => (on ? "Allowed" : "Blocked");
const describeWrite = (on: boolean) => (on ? "Read and write" : "Read only");

/** A live status line: one stable region, the text inside it dissolves over. */
function Status({ children }: { children: string }) {
  return (
    <p
      role="status"
      className="relative min-h-5 text-[12px] text-muted-foreground"
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.span
          key={children}
          className="block"
          initial={{ opacity: 0, x: -6, filter: "blur(4px)" }}
          animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
          exit={{ opacity: 0, x: 6, filter: "blur(4px)" }}
          transition={{ duration: 0.32, ease }}
        >
          {children}
        </motion.span>
      </AnimatePresence>
    </p>
  );
}

/** A value that cross-fades when it changes instead of swapping. */
function Swap({ children }: { children: string }) {
  return (
    <AnimatePresence mode="popLayout" initial={false}>
      <motion.span
        key={children}
        className="inline-block"
        initial={{ opacity: 0, y: 6, filter: "blur(4px)" }}
        animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
        exit={{ opacity: 0, y: -6, filter: "blur(4px)" }}
        transition={{ duration: 0.3, ease }}
      >
        {children}
      </motion.span>
    </AnimatePresence>
  );
}


/** Preview composition: every surface is a vendored overlay on the alive layer. */
export function OverlaysWorkshop() {
  const [tasks, setTasks] = useState(initialTasks);
  const [menuNotice, setMenuNotice] = useState(
    "Right-click a task, or use its menu button.",
  );
  const [archiveId, setArchiveId] = useState<string | null>(null);

  const [activeId, setActiveId] = useState(initialTasks[0].id);
  const [draft, setDraft] = useState<Task>(initialTasks[0]);
  const [editing, setEditing] = useState(false);
  const [step, setStep] = useState<"edit" | "review">("edit");
  const [error, setError] = useState("");
  const [permissionNotice, setPermissionNotice] = useState(
    "No task permissions changed.",
  );

  const [commandOpen, setCommandOpen] = useState(false);
  const [commandNotice, setCommandNotice] = useState("No action run yet.");

  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settings, setSettings] = useState(initialSettings);
  const [settingsDraft, setSettingsDraft] = useState(initialSettings);
  const [model, setModel] = useState("Gemma 4");
  const [modelDraft, setModelDraft] = useState("Gemma 4");
  const [notes, setNotes] = useState(
    "Use the files in this workspace. Ask before changing a file.",
  );
  const [notesDraft, setNotesDraft] = useState(notes);
  const [settingsNotice, setSettingsNotice] = useState(
    "Workspace settings unchanged.",
  );

  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [date, setDate] = useState<Date | undefined>();
  const [scheduled, setScheduled] = useState<Date | undefined>();
  const [scheduleNotice, setScheduleNotice] = useState("No run scheduled.");

  const timers = useRef<Array<ReturnType<typeof setTimeout>>>([]);
  const later = (fn: () => void, ms: number) =>
    timers.current.push(setTimeout(fn, ms));
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  // ⌘K / Ctrl+K opens the command bar from anywhere in this chapter.
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() === "k" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        setCommandOpen((open) => !open);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const active = tasks.find(({ id }) => id === activeId) ?? tasks[0];
  const archiving = tasks.find(({ id }) => id === archiveId);
  const ordered = [...tasks].sort(
    (a, b) =>
      Number(a.archived) - Number(b.archived) ||
      Number(b.pinned) - Number(a.pinned),
  );
  const update = (id: string, patch: Partial<Task>) =>
    setTasks((all) =>
      all.map((task) => (task.id === id ? { ...task, ...patch } : task)),
    );

  const openEditor = (id: string = activeId) => {
    const task = tasks.find((candidate) => candidate.id === id) ?? tasks[0];
    setActiveId(task.id);
    setDraft(task);
    setError("");
    setStep("edit");
    setEditing(true);
  };
  const changeSettingsOpen = (open: boolean) => {
    if (open) {
      setSettingsDraft(settings);
      setModelDraft(model);
      setNotesDraft(notes);
    }
    setSettingsOpen(open);
  };
  const executeCommand = (action: string) => {
    setCommandOpen(false);
    setCommandNotice(`Ran “${action}”.`);
    // Let the command bar leave before the next surface arrives.
    later(() => {
      if (action === commandActions[0]) openEditor();
      else if (action === commandActions[1]) changeSettingsOpen(true);
      else if (action === commandActions[2]) {
        setDate(scheduled);
        setScheduleOpen(true);
      } else {
        setSettings(initialSettings);
        setModel("Gemma 4");
        setSettingsNotice("Default workspace settings restored.");
      }
    }, 420);
  };

  const dirty =
    settingKeys.filter((key) => settingsDraft[key] !== settings[key]).length +
    Number(modelDraft !== model) +
    Number(notesDraft !== notes);
  const enabledCount = settingKeys.filter((key) => settings[key]).length;
  const changes = [
    { label: "Name", from: active.name, to: draft.name.trim() },
    { label: "Folder", from: active.folder, to: draft.folder },
    {
      label: "Network",
      from: describeNetwork(active.network),
      to: describeNetwork(draft.network),
    },
    {
      label: "File changes",
      from: describeWrite(active.write),
      to: describeWrite(draft.write),
    },
  ];
  const changedCount = changes.filter(({ from, to }) => from !== to).length;

  return (
    <TooltipProvider>
      <div className="min-w-0">
        <Stage
          index={1}
          kicker="Menus"
          title="Menus that open where you asked"
          description="Each task has a menu on its button and on right-click. Items cascade in, the highlight leans toward the pointer, and a pinned task glides to the top of the list."
          sources={["Coss", "Off Grid alive"]}
        >
          <div className="space-y-6">
            <ul aria-label="Tasks" className="flex flex-col gap-1">
              {ordered.map((task) => (
                <motion.li
                  key={task.id}
                  layout
                  transition={spring}
                  animate={{ opacity: task.archived ? 0.5 : 1 }}
                >
                  <ContextMenu>
                    <ContextMenuTrigger
                      render={<div />}
                      aria-label={`${task.name} task`}
                      className="group relative flex items-center gap-4 rounded-xl px-4 py-3 transition-colors duration-300 hover:bg-foreground/[0.035] data-[popup-open]:bg-foreground/[0.05]"
                    >
                      <span className="relative flex size-7 shrink-0 items-center justify-center rounded-full shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-text)/0.08)]">
                        <AnimatePresence initial={false}>
                          {task.pinned ? (
                            <motion.span
                              key="pin"
                              className="absolute inset-0 flex items-center justify-center text-primary"
                              initial={{ opacity: 0, scale: 0.4, rotate: -40 }}
                              animate={{ opacity: 1, scale: 1, rotate: 0 }}
                              exit={{ opacity: 0, scale: 0.4, rotate: 40 }}
                              transition={spring}
                            >
                              <PinIcon
                                aria-hidden="true"
                                className="size-3.5"
                              />
                            </motion.span>
                          ) : (
                            <motion.span
                              key="dot"
                              className="absolute inset-0 m-auto size-1.5 rounded-full bg-muted-foreground/50"
                              initial={{ opacity: 0, scale: 0 }}
                              animate={{ opacity: 1, scale: 1 }}
                              exit={{ opacity: 0, scale: 0 }}
                              transition={spring}
                            />
                          )}
                        </AnimatePresence>
                      </span>
                      <span className="min-w-0 flex-1">
                        <span
                          className={`block truncate text-[13px] transition-[color,translate] duration-300 group-hover:translate-x-0.5 ${task.archived ? "text-muted-foreground line-through decoration-muted-foreground/40" : ""}`}
                        >
                          {task.name}
                        </span>
                        <span className="mt-0.5 block truncate text-[11.5px] text-muted-foreground">
                          {task.folder} ·{" "}
                          {describeWrite(task.write).toLowerCase()}
                        </span>
                      </span>
                      <span className="flex items-center gap-1.5">
                        <AnimatePresence mode="popLayout" initial={false}>
                          <motion.span
                            key={task.archived ? "archived" : task.priority}
                            layout
                            initial={{
                              opacity: 0,
                              scale: 0.85,
                              filter: "blur(3px)",
                            }}
                            animate={{
                              opacity: 1,
                              scale: 1,
                              filter: "blur(0px)",
                            }}
                            exit={{
                              opacity: 0,
                              scale: 0.85,
                              filter: "blur(3px)",
                            }}
                            transition={{ duration: 0.3, ease }}
                          >
                            <Badge
                              variant={
                                task.archived
                                  ? "outline"
                                  : task.priority === "High"
                                    ? "success"
                                    : "outline"
                              }
                              size="sm"
                              className="font-mono uppercase tracking-[0.12em]"
                            >
                              {task.archived ? "Archived" : task.priority}
                            </Badge>
                          </motion.span>
                        </AnimatePresence>
                      </span>
                      <AnimatePresence mode="popLayout" initial={false}>
                        {task.archived ? (
                          <motion.span
                            key="restore"
                            initial={{ opacity: 0, x: 6 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 6 }}
                            transition={{ duration: 0.3, ease }}
                          >
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => {
                                update(task.id, { archived: false });
                                setMenuNotice(`${task.name} restored.`);
                              }}
                            >
                              <RotateCcwIcon />
                              Restore
                            </Button>
                          </motion.span>
                        ) : (
                          <motion.span
                            key="menu"
                            initial={{ opacity: 0, x: 6 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 6 }}
                            transition={{ duration: 0.3, ease }}
                            className="opacity-60 transition-opacity duration-300 group-hover:opacity-100 has-[[data-popup-open]]:opacity-100"
                          >
                            <Menu>
                              <MenuTrigger
                                data-slot="button"
                                render={
                                  <Button
                                    variant="ghost"
                                    size="icon-sm"
                                    aria-label={`Actions for ${task.name}`}
                                  />
                                }
                              >
                                <MoreHorizontalIcon />
                              </MenuTrigger>
                              <MenuPopup align="end">
                                <MenuGroup>
                                  <MenuGroupLabel>{task.name}</MenuGroupLabel>
                                  <MenuItem onClick={() => openEditor(task.id)}>
                                    <ShieldCheckIcon />
                                    Edit permissions
                                  </MenuItem>
                                  <MenuItem disabled>
                                    <FolderIcon />
                                    Reveal on this device
                                  </MenuItem>
                                </MenuGroup>
                                <MenuSeparator />
                                <MenuCheckboxItem
                                  checked={task.pinned}
                                  onCheckedChange={(pinned) => {
                                    update(task.id, { pinned });
                                    setMenuNotice(
                                      `${task.name} ${pinned ? "pinned" : "unpinned"}.`,
                                    );
                                  }}
                                >
                                  Pin task
                                </MenuCheckboxItem>
                                <MenuSub>
                                  <MenuSubTrigger>Priority</MenuSubTrigger>
                                  <MenuSubPopup>
                                    <MenuRadioGroup
                                      value={task.priority}
                                      onValueChange={(
                                        priority: Task["priority"],
                                      ) => {
                                        update(task.id, { priority });
                                        setMenuNotice(
                                          `${task.name} set to ${priority.toLowerCase()} priority.`,
                                        );
                                      }}
                                    >
                                      {priorities.map((value) => (
                                        <MenuRadioItem
                                          key={value}
                                          value={value}
                                        >
                                          {value}
                                        </MenuRadioItem>
                                      ))}
                                    </MenuRadioGroup>
                                  </MenuSubPopup>
                                </MenuSub>
                                <MenuSeparator />
                                <MenuItem
                                  variant="destructive"
                                  onClick={() => setArchiveId(task.id)}
                                >
                                  <TrashIcon />
                                  Archive task
                                </MenuItem>
                              </MenuPopup>
                            </Menu>
                          </motion.span>
                        )}
                      </AnimatePresence>
                    </ContextMenuTrigger>
                    <ContextMenuPopup>
                      <ContextMenuItem
                        disabled={task.archived}
                        onClick={() => openEditor(task.id)}
                      >
                        Edit permissions
                      </ContextMenuItem>
                      <ContextMenuItem
                        onClick={() => {
                          update(task.id, { pinned: !task.pinned });
                          setMenuNotice(
                            `${task.name} ${task.pinned ? "unpinned" : "pinned"}.`,
                          );
                        }}
                      >
                        {task.pinned ? "Unpin task" : "Pin task"}
                      </ContextMenuItem>
                      <ContextMenuSeparator />
                      <ContextMenuItem
                        variant="destructive"
                        disabled={task.archived}
                        onClick={() => setArchiveId(task.id)}
                      >
                        Archive task
                      </ContextMenuItem>
                    </ContextMenuPopup>
                  </ContextMenu>
                </motion.li>
              ))}
            </ul>
            <div className="px-4">
              <Status>{menuNotice}</Status>
            </div>
          </div>

          <AlertDialog
            open={archiveId !== null}
            onOpenChange={(open) => !open && setArchiveId(null)}
          >
            <AlertDialogPopup className="sm:max-w-md">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-[17px] font-normal">
                  Archive this preview task?
                </AlertDialogTitle>
                <AlertDialogDescription className="text-[13px]">
                  {archiving?.name ?? "This task"} moves to the end of the list.
                  You can restore it from there.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogClose render={<Button size="sm" variant="ghost" />}>
                  Cancel
                </AlertDialogClose>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => {
                    if (archiving) {
                      update(archiving.id, { archived: true, pinned: false });
                      setMenuNotice(
                        `${archiving.name} archived. Restore it to undo.`,
                      );
                    }
                    setArchiveId(null);
                  }}
                >
                  Archive task
                </Button>
              </AlertDialogFooter>
            </AlertDialogPopup>
          </AlertDialog>
        </Stage>

        <Stage
          index={2}
          kicker="Dialogs"
          title="Dialogs that step instead of stack"
          description="Edit, review, apply. The dialog changes its content in place and resizes to fit, so a confirmation never piles a second window on top of the first."
          sources={["Animate UI", "Coss"]}
        >
          <div className="space-y-8">
            <div className="flex items-start justify-between gap-6">
              <div className="min-w-0">
                <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                  Task
                </p>
                <p className="mt-2 text-[17px] font-light">
                  <Swap>{active.name}</Swap>
                </p>
              </div>
              <Tooltip>
                <TooltipTrigger
                  data-slot="button"
                  render={
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      aria-label="About task permissions"
                    />
                  }
                >
                  <ShieldCheckIcon />
                </TooltipTrigger>
                <TooltipPopup>Access applies only to this task.</TooltipPopup>
              </Tooltip>
            </div>
            <dl className="divide-y divide-border/60">
              {[
                { term: "Folder", value: active.folder, on: true },
                {
                  term: "Network",
                  value: describeNetwork(active.network),
                  on: active.network,
                },
                {
                  term: "File changes",
                  value: describeWrite(active.write),
                  on: active.write,
                },
              ].map(({ term, value, on }) => (
                <div
                  key={term}
                  className="flex items-center justify-between gap-6 py-3.5 text-[13px]"
                >
                  <dt className="text-muted-foreground">{term}</dt>
                  <dd className="flex items-center gap-2.5">
                    <Swap>{value}</Swap>
                    <motion.span
                      aria-hidden="true"
                      className="size-1.5 rounded-full"
                      animate={{
                        backgroundColor: on
                          ? "rgb(52 211 153)"
                          : "rgb(255 255 255 / 0.2)",
                        boxShadow: on
                          ? "0 0 10px rgb(52 211 153 / 0.7)"
                          : "0 0 0px rgb(52 211 153 / 0)",
                      }}
                      transition={{ duration: 0.5, ease }}
                    />
                  </dd>
                </div>
              ))}
            </dl>
            <div className="flex flex-wrap items-center gap-4">
              <Button onClick={() => openEditor()} disabled={active.archived}>
                Edit permissions
              </Button>
              <Status>{permissionNotice}</Status>
            </div>
          </div>

          <Dialog open={editing} onOpenChange={setEditing}>
            <DialogPopup className="top-[14svh] translate-y-0 gap-5 rounded-2xl border-border/60 bg-background/90 p-6 backdrop-blur-xl sm:max-w-md">
              <DialogHeader>
                <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                  <span className="text-primary">
                    {step === "edit" ? "01" : "02"}
                  </span>
                  <span className="mx-2 text-muted-foreground/40">/</span>02
                </p>
                <DialogTitle className="text-[17px] font-normal leading-tight">
                  {step === "edit"
                    ? "Edit task permissions"
                    : "Apply these permissions?"}
                </DialogTitle>
                <DialogDescription className="text-[12.5px]">
                  {step === "edit"
                    ? "Review access before this task runs."
                    : changedCount === 0
                      ? "Nothing has changed yet."
                      : `${changedCount} ${changedCount === 1 ? "change" : "changes"} for ${draft.name.trim()}.`}
                </DialogDescription>
              </DialogHeader>
              <AutoHeight>
                <AnimatePresence mode="wait" initial={false}>
                  {step === "edit" ? (
                    <motion.div
                      key="edit"
                      initial={{ opacity: 0, x: -16, filter: "blur(4px)" }}
                      animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                      exit={{ opacity: 0, x: -16, filter: "blur(4px)" }}
                      transition={{ duration: 0.28, ease }}
                      className="space-y-5 pb-1"
                    >
                      <Field invalid={!!error}>
                        <FieldLabel>Task name</FieldLabel>
                        <Input
                          value={draft.name}
                          onChange={(event) => {
                            const name = event.target.value;
                            setDraft((previous) => ({ ...previous, name }));
                            setError("");
                          }}
                          aria-invalid={!!error || undefined}
                        />
                        <FieldError match={!!error}>{error}</FieldError>
                      </Field>
                      <Field>
                        <FieldLabel>Allowed folder</FieldLabel>
                        <Select
                          value={draft.folder}
                          onValueChange={(folder) =>
                            folder &&
                            setDraft((previous) => ({ ...previous, folder }))
                          }
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectPopup>
                            {folders.map((folder) => (
                              <SelectItem key={folder} value={folder}>
                                {folder}
                              </SelectItem>
                            ))}
                          </SelectPopup>
                        </Select>
                        <FieldDescription>
                          The task can read files in this folder.
                        </FieldDescription>
                      </Field>
                      <div className="space-y-4">
                        {(
                          [
                            [
                              "network",
                              "Allow network requests",
                              "Permit requests outside this device.",
                            ],
                            [
                              "write",
                              "Allow file changes",
                              "Permit edits in the selected folder.",
                            ],
                          ] as const
                        ).map(([key, label, hint]) => (
                          <label
                            key={key}
                            className="flex cursor-pointer items-start gap-3 text-[13px]"
                          >
                            <Checkbox
                              className="mt-0.5"
                              checked={draft[key]}
                              onCheckedChange={(checked) =>
                                setDraft((previous) => ({
                                  ...previous,
                                  [key]: checked === true,
                                }))
                              }
                            />
                            <span>
                              <span className="block">{label}</span>
                              <span className="mt-0.5 block text-[11.5px] text-muted-foreground">
                                {hint}
                              </span>
                            </span>
                          </label>
                        ))}
                      </div>
                    </motion.div>
                  ) : (
                    <motion.ul
                      key="review"
                      aria-label="Permission changes"
                      initial={{ opacity: 0, x: 16, filter: "blur(4px)" }}
                      animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                      exit={{ opacity: 0, x: 16, filter: "blur(4px)" }}
                      transition={{ duration: 0.28, ease }}
                      className="divide-y divide-border/60 pb-1"
                    >
                      {changes.map(({ label, from, to }, index) => {
                        const changed = from !== to;
                        return (
                          <motion.li
                            key={label}
                            initial={{ opacity: 0, y: 6 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{
                              delay: 0.08 + index * 0.05,
                              duration: 0.35,
                              ease,
                            }}
                            className="flex items-center justify-between gap-4 py-3 text-[13px]"
                          >
                            <span className="text-muted-foreground">
                              {label}
                            </span>
                            <span className="flex min-w-0 items-center gap-2">
                              {changed && (
                                <>
                                  <span className="truncate text-muted-foreground line-through decoration-muted-foreground/40">
                                    {from}
                                  </span>
                                  <ArrowRightIcon
                                    aria-hidden="true"
                                    className="size-3 shrink-0 text-muted-foreground"
                                  />
                                </>
                              )}
                              <span
                                className={`truncate ${changed ? "text-primary" : ""}`}
                              >
                                {to}
                              </span>
                            </span>
                          </motion.li>
                        );
                      })}
                    </motion.ul>
                  )}
                </AnimatePresence>
              </AutoHeight>
              <DialogFooter>
                {step === "edit" ? (
                  <>
                    <DialogClose render={<Button size="sm" variant="ghost" />}>
                      Cancel
                    </DialogClose>
                    <Button
                      size="sm"
                      onClick={() => {
                        if (!draft.name.trim()) setError("Enter a task name.");
                        else setStep("review");
                      }}
                    >
                      Review changes
                    </Button>
                  </>
                ) : (
                  <>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => setStep("edit")}
                    >
                      Back to editing
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => {
                        const name = draft.name.trim();
                        update(active.id, {
                          name,
                          folder: draft.folder,
                          network: draft.network,
                          write: draft.write,
                        });
                        setEditing(false);
                        setPermissionNotice(`Permissions saved for ${name}.`);
                      }}
                    >
                      <CheckIcon />
                      Apply permissions
                    </Button>
                  </>
                )}
              </DialogFooter>
            </DialogPopup>
          </Dialog>
        </Stage>

        <Stage
          index={3}
          kicker="Command"
          title="One search for every action"
          description="Press ⌘K or click the field. The bar arrives as glass, results filter as you type, and the chosen action opens right where it lives."
          sources={["Coss", "Off Grid alive"]}
          specimenClassName="items-center"
        >
          <div className="flex w-full max-w-md flex-col gap-5">
            <CommandDialog open={commandOpen} onOpenChange={setCommandOpen}>
              <Button
                variant="outline"
                size="lg"
                onClick={() => setCommandOpen(true)}
                className="w-full justify-start font-normal text-muted-foreground"
                aria-label="Find an action"
              >
                <SearchIcon />
                Find an action…
                <KbdGroup className="ms-auto">
                  <Kbd>⌘</Kbd>
                  <Kbd>K</Kbd>
                </KbdGroup>
              </Button>
              <CommandDialogPopup className="border-border/60">
                <CommandDialogPrimitive.Title className="sr-only">
                  Workspace commands
                </CommandDialogPrimitive.Title>
                <Command items={commandActions}>
                  <CommandInput
                    aria-label="Search workspace actions"
                    placeholder="Search actions…"
                  />
                  <CommandPanel>
                    <CommandEmpty>No matching actions.</CommandEmpty>
                    <CommandList>
                      {(action: string) => {
                        const Icon = commandIcons[action] ?? SearchIcon;
                        return (
                          <CommandItem
                            key={action}
                            value={action}
                            className="gap-2.5"
                            onClick={() => executeCommand(action)}
                          >
                            <Icon
                              aria-hidden="true"
                              className="size-4 text-muted-foreground"
                            />
                            {action}
                          </CommandItem>
                        );
                      }}
                    </CommandList>
                  </CommandPanel>
                </Command>
                <CommandFooter>
                  <span className="flex items-center gap-2">
                    <KbdGroup>
                      <Kbd>↑</Kbd>
                      <Kbd>↓</Kbd>
                    </KbdGroup>
                    to move
                    <Kbd className="ms-2">↵</Kbd>
                    to select
                  </span>
                  <span className="flex items-center gap-2">
                    <Kbd>Esc</Kbd>
                    to close
                  </span>
                </CommandFooter>
              </CommandDialogPopup>
            </CommandDialog>
            <div className="px-1">
              <Status>{commandNotice}</Status>
            </div>
          </div>
        </Stage>

        <Stage
          index={4}
          kicker="Side panel"
          title="Settings that slide in from the edge"
          description="The page recedes, the panel arrives on a spring, and it counts your unsaved changes before you commit to them."
          sources={["Animate UI", "Coss"]}
        >
          <div className="space-y-8">
            <dl className="grid grid-cols-3 gap-6">
              {[
                { term: "Default model", value: model },
                {
                  term: "Execution",
                  value: settings.localOnly ? "Local models" : "All models",
                },
              ].map(({ term, value }) => (
                <div key={term} className="min-w-0">
                  <dt className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                    {term}
                  </dt>
                  <dd className="mt-2 truncate text-[15px] font-light">
                    <Swap>{value}</Swap>
                  </dd>
                </div>
              ))}
              <div className="min-w-0">
                <dt className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                  Preferences on
                </dt>
                <dd className="mt-2 text-[15px] font-light">
                  <AnimatedNumber value={enabledCount} />
                  <span className="text-muted-foreground">
                    {" "}
                    of {settingKeys.length}
                  </span>
                </dd>
              </div>
            </dl>
            <div className="flex flex-wrap items-center gap-4">
              <Sheet open={settingsOpen} onOpenChange={changeSettingsOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline">
                    <SettingsIcon />
                    Workspace settings
                  </Button>
                </SheetTrigger>
                <SheetPopup className="w-[400px] gap-0 border-border/60 bg-background/85 backdrop-blur-xl">
                  <SheetHeader className="px-6 pb-2 pt-6">
                    <SheetTitle className="text-[17px] font-normal">
                      Workspace settings
                    </SheetTitle>
                    <SheetDescription className="text-[12.5px]">
                      Save changes or cancel to keep the current settings.
                    </SheetDescription>
                  </SheetHeader>
                  <div className="flex-1 space-y-6 overflow-y-auto px-6 py-4">
                    <Field>
                      <FieldLabel>Default model</FieldLabel>
                      <Select
                        value={modelDraft}
                        onValueChange={(value) => value && setModelDraft(value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectPopup>
                          {["Gemma 4", "Qwen 3", "Llama 3.2"].map((value) => (
                            <SelectItem key={value} value={value}>
                              {value}
                            </SelectItem>
                          ))}
                        </SelectPopup>
                      </Select>
                      <FieldDescription>
                        Used when a new task starts.
                      </FieldDescription>
                    </Field>
                    <div className="divide-y divide-border/60">
                      {settingKeys.map((key, index) => (
                        <motion.label
                          key={key}
                          initial={{ opacity: 0, x: 12 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{
                            delay: 0.12 + index * 0.035,
                            duration: 0.45,
                            ease,
                          }}
                          className="group flex cursor-pointer items-center justify-between gap-6 py-3.5"
                        >
                          <span className="min-w-0">
                            <span className="block text-[13px] transition-colors group-hover:text-foreground">
                              {settingsLabels[key][0]}
                            </span>
                            <span className="mt-0.5 block text-[11.5px] text-muted-foreground">
                              {settingsLabels[key][1]}
                            </span>
                          </span>
                          <Switch
                            checked={settingsDraft[key]}
                            onCheckedChange={(checked) =>
                              setSettingsDraft((previous) => ({
                                ...previous,
                                [key]: checked,
                              }))
                            }
                          />
                        </motion.label>
                      ))}
                    </div>
                    <Field>
                      <FieldLabel>Task instructions</FieldLabel>
                      <Textarea
                        value={notesDraft}
                        onChange={(event) => setNotesDraft(event.target.value)}
                        rows={3}
                      />
                      <FieldDescription>
                        Applied to new tasks in this workspace.
                      </FieldDescription>
                    </Field>
                  </div>
                  <SheetFooter className="flex-row items-center gap-2 border-t border-border/60 px-6 py-4">
                    <span className="mr-auto font-mono text-[10.5px] text-muted-foreground">
                      <AnimatePresence mode="wait" initial={false}>
                        <motion.span
                          key={dirty === 0 ? "clean" : "dirty"}
                          className="inline-flex items-center gap-1"
                          initial={{ opacity: 0, y: 4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -4 }}
                          transition={{ duration: 0.25, ease }}
                        >
                          {dirty === 0 ? (
                            "No changes"
                          ) : (
                            <>
                              <span className="text-primary">
                                <AnimatedNumber value={dirty} />
                              </span>
                              unsaved
                            </>
                          )}
                        </motion.span>
                      </AnimatePresence>
                    </span>
                    <SheetClose asChild>
                      <Button size="sm" variant="ghost">
                        Cancel
                      </Button>
                    </SheetClose>
                    <Button
                      size="sm"
                      onClick={() => {
                        setSettings(settingsDraft);
                        setModel(modelDraft);
                        setNotes(notesDraft);
                        setSettingsOpen(false);
                        setSettingsNotice(
                          `Workspace settings saved. Default model: ${modelDraft}.`,
                        );
                      }}
                    >
                      Save settings
                    </Button>
                  </SheetFooter>
                </SheetPopup>
              </Sheet>
              <Status>{settingsNotice}</Status>
            </div>
          </div>
        </Stage>

        <Stage
          index={5}
          kicker="Popovers"
          title="Small surfaces for small questions"
          description="Popovers and tooltips grow out of their trigger and leave the way they came. The chevron turns as the popup opens, and the choice you make lands back on the button."
          sources={["Coss", "Off Grid alive"]}
          specimenClassName="items-center"
        >
          <div className="flex flex-col items-center gap-8">
            <div className="flex flex-wrap items-center justify-center gap-3">
              <Popover
                open={scheduleOpen}
                onOpenChange={(open) => {
                  if (open) setDate(scheduled);
                  setScheduleOpen(open);
                }}
              >
                <PopoverTrigger
                  data-slot="button"
                  render={
                    <Button
                      variant="outline"
                      className="group/schedule min-w-40"
                    />
                  }
                >
                  <CalendarIcon />
                  <Swap>
                    {scheduled ? formatDay(scheduled) : "Schedule run"}
                  </Swap>
                  <ChevronDownIcon className="ms-auto transition-transform duration-500 ease-[cubic-bezier(0.16,1,0.3,1)] group-data-[popup-open]/schedule:rotate-180" />
                </PopoverTrigger>
                <PopoverPopup>
                  <div className="space-y-3">
                    <div>
                      <PopoverTitle className="text-[14px] font-normal">
                        Schedule a run
                      </PopoverTitle>
                      <PopoverDescription className="text-[12px]">
                        Choose a date for this preview task.
                      </PopoverDescription>
                    </div>
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={setDate}
                      defaultMonth={scheduled ?? new Date()}
                    />
                    <div className="flex justify-end gap-2">
                      <PopoverClose
                        render={<Button size="sm" variant="ghost" />}
                      >
                        Cancel
                      </PopoverClose>
                      <Button
                        size="sm"
                        disabled={!date}
                        onClick={() => {
                          setScheduled(date);
                          setScheduleOpen(false);
                          if (date)
                            setScheduleNotice(
                              `Preview run scheduled for ${formatDay(date)}.`,
                            );
                        }}
                      >
                        Set date
                      </Button>
                    </div>
                  </div>
                </PopoverPopup>
              </Popover>
              <Popover>
                <PopoverTrigger
                  data-slot="button"
                  render={<Button variant="ghost" />}
                >
                  <FolderIcon />
                  Workspace details
                </PopoverTrigger>
                <PopoverPopup className="w-64">
                  <div className="space-y-3">
                    <div>
                      <PopoverTitle className="text-[14px] font-normal">
                        Project notes
                      </PopoverTitle>
                      <PopoverDescription className="text-[12px]">
                        Three local files are available to this preview task.
                      </PopoverDescription>
                    </div>
                    <ul className="space-y-0.5">
                      {workspaceFiles.map((file, index) => (
                        <motion.li
                          key={file}
                          initial={{ opacity: 0, y: -4, filter: "blur(3px)" }}
                          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                          transition={{
                            delay: 0.06 + index * 0.04,
                            duration: 0.4,
                            ease,
                          }}
                          className="flex items-center gap-2 rounded-md px-1.5 py-1 text-[12.5px] transition-colors hover:bg-foreground/[0.04]"
                        >
                          <FileTextIcon
                            aria-hidden="true"
                            className="size-3.5 text-muted-foreground"
                          />
                          {file}
                        </motion.li>
                      ))}
                    </ul>
                  </div>
                </PopoverPopup>
              </Popover>
              <span className="mx-1 h-5 w-px bg-border" />
              {[
                {
                  label: "Copy workspace link",
                  icon: LinkIcon,
                  tip: "Copy a link to this workspace.",
                },
                {
                  label: "Pin workspace",
                  icon: PinIcon,
                  tip: "Keep it at the top of the sidebar.",
                },
              ].map(({ label, icon: Icon, tip }) => (
                <Tooltip key={label}>
                  <TooltipTrigger
                    data-slot="button"
                    render={
                      <Button variant="ghost" size="icon" aria-label={label} />
                    }
                  >
                    <Icon />
                  </TooltipTrigger>
                  <TooltipPopup>{tip}</TooltipPopup>
                </Tooltip>
              ))}
            </div>
            <Status>{scheduleNotice}</Status>
          </div>
        </Stage>
      </div>
    </TooltipProvider>
  );
}
