import { useEffect, useRef, useState } from "react";
import { Segmented } from "@offgrid/ui/operator/segmented";
import { AnimatePresence, motion } from "motion/react";
import {
  CheckIcon,
  DownloadIcon,
  FileTextIcon,
  Grid2X2Icon,
  HardDriveIcon,
  ListIcon,
  MoreHorizontalIcon,
  PauseIcon,
  RefreshCwIcon,
  SearchIcon,
  TriangleAlertIcon,
  XIcon,
} from "lucide-react";
import { Button } from "@offgrid/ui/operator/coss/button";
import { Badge } from "@offgrid/ui/operator/coss/badge";
import { Card } from "@offgrid/ui/operator/coss/card";
import {
  InputGroup,
  InputGroupAddon,
  InputGroupInput,
} from "@offgrid/ui/operator/coss/input-group";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectPopup,
  SelectItem,
} from "@offgrid/ui/operator/coss/select";
import { Checkbox } from "@offgrid/ui/operator/animate/checkbox";
import {
  Menu,
  MenuTrigger,
  MenuPopup,
  MenuItem,
  MenuSeparator,
} from "@offgrid/ui/operator/coss/menu";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@offgrid/ui/operator/coss/pagination";
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from "@offgrid/ui/operator/coss/empty";
import {
  Progress,
  ProgressTrack,
  ProgressIndicator,
} from "@offgrid/ui/operator/coss/progress";
import { Skeleton } from "@offgrid/ui/operator/coss/skeleton";
import { Spinner } from "@offgrid/ui/operator/coss/spinner";
import {
  Sheet,
  SheetContent as SheetPopup,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
  SheetClose,
} from "@offgrid/ui/operator/animate/sheet";
import { AnimatedNumber } from "@offgrid/ui/operator/motion/animated-number";
import { ListGroup, ListRow } from "@offgrid/ui/operator/list-row";
import { Stage } from "./stage";

type Model = {
  id: string;
  name: string;
  family: string;
  size: number;
  context: string;
};

const sampleModels: Model[] = [
  {
    id: "gemma",
    name: "Gemma · sample",
    family: "General",
    size: 2.4,
    context: "32k",
  },
  {
    id: "qwen",
    name: "Qwen · sample",
    family: "Code",
    size: 4.8,
    context: "64k",
  },
  {
    id: "llama",
    name: "Llama · sample",
    family: "General",
    size: 3.2,
    context: "32k",
  },
  {
    id: "phi",
    name: "Phi · sample",
    family: "Compact",
    size: 1.8,
    context: "16k",
  },
  {
    id: "mistral",
    name: "Mistral · sample",
    family: "General",
    size: 5.1,
    context: "32k",
  },
  {
    id: "coder",
    name: "Coder · sample",
    family: "Code",
    size: 6.2,
    context: "64k",
  },
];
const byId = (id: string) => sampleModels.find((model) => model.id === id)!;
const PAGE_SIZE = 3;

const libraryStates = [
  { id: "ready", label: "Ready" },
  { id: "loading", label: "Loading" },
  { id: "refreshing", label: "Refreshing" },
  { id: "failed", label: "Failed" },
  { id: "empty", label: "Empty" },
  { id: "nomatch", label: "No match" },
];

type Phase =
  | "Queued"
  | "Connecting"
  | "Downloading"
  | "Interrupted"
  | "Retrying"
  | "Cancelled"
  | "Downloaded"
  | "Installing"
  | "Installed";
const milestones = [
  "Queued",
  "Downloading",
  "Installing",
  "Installed",
] as const;
const milestoneOf = (phase: Phase) =>
  phase === "Queued" || phase === "Cancelled"
    ? 0
    : phase === "Downloaded" || phase === "Installing"
      ? 2
      : phase === "Installed"
        ? 3
        : 1;
const phaseCopy: Record<Phase, string> = {
  Queued: "Waiting to start.",
  Connecting: "Connecting. The server has not sent a total size yet.",
  Downloading: "Receiving the sample file.",
  Interrupted: "Connection interrupted. Downloaded data is kept.",
  Retrying: "Reconnecting. Previous progress is kept.",
  Cancelled: "Transfer cancelled. You can queue it again.",
  Downloaded: "File received. Ready to install.",
  Installing: "Installing. The transfer is already complete.",
  Installed: "Ready to use. The library is updated.",
};

type Log = { id: number; time: string; message: string; result: string };
const resultTone = (result: string) =>
  result === "Installed" || result === "Complete"
    ? "success"
    : result === "Interrupted" || result === "Cancelled"
      ? "warning"
      : result === "Failed"
        ? "error"
        : "outline";

const ease = [0.16, 1, 0.3, 1] as const;
const spring = { type: "spring", stiffness: 380, damping: 32 } as const;
const rise = {
  initial: { opacity: 0, y: 8, filter: "blur(4px)" },
  animate: { opacity: 1, y: 0, filter: "blur(0px)" },
  exit: { opacity: 0, y: -6, filter: "blur(4px)" },
};
const eyebrow =
  "font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground";

function Availability({ installed }: { installed: boolean }) {
  return (
    <Badge variant={installed ? "success" : "outline"} size="sm">
      {installed ? "Installed" : "Available"}
    </Badge>
  );
}

function ModelGlyph({ className = "size-8" }: { className?: string }) {
  return (
    <span
      aria-hidden="true"
      className={`grid shrink-0 place-items-center rounded-lg bg-primary/10 text-primary shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-primary)/0.22)] ${className}`}
    >
      <HardDriveIcon className="size-3.5" />
    </span>
  );
}

/** Compact term/value list for the details sheet. */
function Specs({ items }: { items: Array<[string, React.ReactNode]> }) {
  return (
    <dl className="grid grid-cols-[auto_1fr] gap-x-6 gap-y-2.5 text-[12.5px]">
      {items.map(([term, value]) => (
        <div key={term} className="contents">
          <dt className={eyebrow + " self-center"}>{term}</dt>
          <dd className="tabular-nums">{value}</dd>
        </div>
      ))}
    </dl>
  );
}

function StateEmpty({
  icon,
  title,
  description,
  action,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  action: React.ReactNode;
}) {
  return (
    <Empty className="py-6">
      <EmptyHeader>
        <EmptyMedia variant="icon">{icon}</EmptyMedia>
        <EmptyTitle className="text-[15px] font-normal">{title}</EmptyTitle>
        <EmptyDescription className="text-[12px]">
          {description}
        </EmptyDescription>
      </EmptyHeader>
      <EmptyContent>{action}</EmptyContent>
    </Empty>
  );
}

/** Thin rows used by the states stage: one surface, hairlines, facts inline. */
function LibraryRows({ models, dim }: { models: Model[]; dim?: boolean }) {
  return (
    <motion.div
      animate={{ opacity: dim ? 0.55 : 1 }}
      transition={{ duration: 0.4, ease }}
    >
      <ListGroup label="Model library">
        {models.map((model, index) => (
          <motion.div
            key={model.id}
            data-id={model.id}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.05, duration: 0.45, ease }}
          >
            <ListRow
              leading={<ModelGlyph className="size-6" />}
              title={model.name}
              description={`${model.family} · ${model.context} context`}
              meta={`${model.size.toFixed(1)} GB`}
            />
          </motion.div>
        ))}
      </ListGroup>
    </motion.div>
  );
}

/** Sample data and explicit state controls; no production files or services are used. */
export function CollectionsWorkshop() {
  // Catalogue
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [sort, setSort] = useState<string | null>("name");
  const [view, setView] = useState("list");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<string[]>([]);
  const [activeId, setActiveId] = useState(sampleModels[0].id);
  const [installed, setInstalled] = useState(["gemma", "llama"]);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [notice, setNotice] = useState("");
  // States
  const [libraryState, setLibraryState] = useState("ready");
  const [retrying, setRetrying] = useState(false);
  const [stateNotice, setStateNotice] = useState("");
  // Transfer
  const [transferId, setTransferId] = useState("qwen");
  const [phase, setPhase] = useState<Phase>("Queued");
  const [percent, setPercent] = useState(0);
  // Activity
  const [logQuery, setLogQuery] = useState("");
  const [logs, setLogs] = useState<Log[]>([
    {
      id: 2,
      time: "Sample",
      message: "Qwen · sample queued.",
      result: "Waiting",
    },
    {
      id: 1,
      time: "Sample",
      message: "Local library opened.",
      result: "Complete",
    },
  ]);

  const timers = useRef<Array<ReturnType<typeof setTimeout>>>([]);
  const later = (fn: () => void, ms: number) =>
    timers.current.push(setTimeout(fn, ms));
  const clearTimers = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };
  useEffect(() => () => timers.current.forEach(clearTimeout), []);

  const isInstalled = (id: string) => installed.includes(id);
  const active = byId(activeId);
  const transfer = byId(transferId);
  const results = sampleModels
    .filter(
      (model) =>
        model.name.toLowerCase().includes(query.trim().toLowerCase()) &&
        (filter === "all" ||
          (filter === "installed") === installed.includes(model.id)),
    )
    .sort((a, b) =>
      sort === "size" ? a.size - b.size : a.name.localeCompare(b.name),
    );
  const pages = Math.max(1, Math.ceil(results.length / PAGE_SIZE));
  const currentPage = Math.min(page, pages);
  const visible = results.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE,
  );
  const selectedOnPage = visible.filter((model) =>
    selected.includes(model.id),
  ).length;
  const filteredLogs = logs.filter((log) =>
    log.message.toLowerCase().includes(logQuery.trim().toLowerCase()),
  );

  const record = (message: string, result = "Complete") =>
    setLogs((previous) => [
      {
        id: previous.length + 1,
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: false,
        }),
        message,
        result,
      },
      ...previous,
    ]);
  const choose = (id: string, checked: boolean) =>
    setSelected((previous) =>
      checked
        ? [...new Set([...previous, id])]
        : previous.filter((item) => item !== id),
    );
  const resetFilters = () => {
    setQuery("");
    setFilter("all");
    setPage(1);
  };

  // ── Transfer lifecycle ────────────────────────────────────────────────
  const go = (next: Phase) => {
    setPhase(next);
    record(`${transfer.name}: ${next.toLowerCase()}.`, next);
  };
  const queue = (id: string) => {
    clearTimers();
    setTransferId(id);
    setPhase("Queued");
    setPercent(0);
    setNotice(`${byId(id).name} queued in Downloads.`);
    record(`${byId(id).name} queued.`, "Waiting");
  };
  const start = () => {
    go("Connecting");
    later(() => setPhase("Downloading"), 1200);
  };
  const resume = () => {
    go("Retrying");
    later(() => setPhase("Downloading"), 1100);
  };
  const install = () => {
    go("Installing");
    later(() => {
      setPhase("Installed");
      setInstalled((previous) => [...new Set([...previous, transferId])]);
      record(`${transfer.name} installed.`, "Installed");
    }, 1500);
  };
  const cancel = () => {
    clearTimers();
    go("Cancelled");
  };
  // Chunks arrive while downloading; the bar eases between them.
  useEffect(() => {
    if (phase !== "Downloading") return;
    const timer = setTimeout(() => {
      const next = Math.min(100, percent + 5 + Math.round(Math.random() * 5));
      setPercent(next);
      if (next === 100) {
        setPhase("Downloaded");
        record(`${transfer.name}: downloaded.`, "Downloaded");
      }
    }, 800);
    return () => clearTimeout(timer);
    // record and transfer are stable for a given phase/percent pair.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, percent]);

  const indeterminate = phase === "Connecting" || phase === "Retrying";
  const totalMb = Math.round(transfer.size * 1024);
  const receivedMb = Math.round((totalMb * percent) / 100);
  const reached = milestoneOf(phase);

  // ── Library states ────────────────────────────────────────────────────
  const stateTimers = useRef<Array<ReturnType<typeof setTimeout>>>([]);
  const stateLater = (fn: () => void, ms: number) =>
    stateTimers.current.push(setTimeout(fn, ms));
  const clearStateTimers = () => {
    stateTimers.current.forEach(clearTimeout);
    stateTimers.current = [];
  };
  useEffect(() => () => stateTimers.current.forEach(clearTimeout), []);
  const showState = (next: string) => {
    clearStateTimers();
    setLibraryState(next);
    setRetrying(false);
    setStateNotice("");
    if (next === "loading")
      stateLater(() => {
        setLibraryState("ready");
        setStateNotice("Library loaded.");
      }, 2200);
    if (next === "refreshing")
      stateLater(() => {
        setLibraryState("ready");
        setStateNotice("Library refreshed. Nothing changed.");
        record("Library refresh completed.");
      }, 1800);
  };

  return (
    <div className="min-w-0">
      <Stage
        index={1}
        kicker="Catalogue"
        title="A library that rearranges itself"
        description="Search, filter and sort, and the rows slide to their new places instead of jumping. One thin row per model: name, state and size inline, actions in the trailing menu."
        sources={["Coss", "Animate UI", "Motion Primitives"]}
      >
        <div className="space-y-6">
          <div className="flex flex-wrap items-center gap-3">
            <InputGroup className="min-w-48 flex-1">
              <InputGroupAddon>
                <SearchIcon aria-hidden="true" />
              </InputGroupAddon>
              <InputGroupInput
                type="search"
                aria-label="Search models"
                value={query}
                onValueChange={(value) => {
                  setQuery(value);
                  setPage(1);
                }}
                placeholder="Find a model…"
              />
            </InputGroup>
            <Select
              items={[
                { value: "name", label: "Name" },
                { value: "size", label: "Smallest first" },
              ]}
              value={sort}
              onValueChange={(value) => {
                setSort(value);
                setPage(1);
              }}
            >
              <SelectTrigger aria-label="Sort by" className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectPopup>
                <SelectItem value="name">Name</SelectItem>
                <SelectItem value="size">Smallest first</SelectItem>
              </SelectPopup>
            </Select>
            <Segmented
              label="Layout"
              value={view}
              onValueChange={setView}
              options={[
                { id: "list", label: "List view", icon: <ListIcon /> },
                { id: "grid", label: "Grid view", icon: <Grid2X2Icon /> },
              ]}
            />
          </div>

          <div className="flex min-h-8 flex-wrap items-center justify-between gap-3">
            <Segmented
              label="Availability"
              value={filter}
              onValueChange={(value) => {
                setFilter(value);
                setPage(1);
              }}
              options={[
                { id: "all", label: "All" },
                { id: "installed", label: "Installed" },
                { id: "available", label: "Available" },
              ]}
            />
            <AnimatePresence initial={false}>
              {selected.length > 0 && (
                <motion.div
                  key="selection"
                  initial={{ opacity: 0, x: 8, filter: "blur(4px)" }}
                  animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                  exit={{ opacity: 0, x: 8, filter: "blur(4px)" }}
                  transition={{ duration: 0.3, ease }}
                  className="flex items-center gap-3 text-[12px] text-muted-foreground"
                >
                  <span>
                    <AnimatedNumber
                      value={selected.length}
                      className="text-foreground"
                      springOptions={{ stiffness: 260, damping: 26 }}
                    />{" "}
                    selected
                  </span>
                  <Button
                    size="xs"
                    variant="ghost"
                    onClick={() => {
                      setSelected([]);
                      setNotice("Selection cleared.");
                      record("Selection cleared.");
                    }}
                  >
                    Clear selection
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <AnimatePresence mode="wait" initial={false}>
            {results.length === 0 ? (
              <motion.div
                key="empty"
                {...rise}
                transition={{ duration: 0.35, ease }}
              >
                <StateEmpty
                  icon={<SearchIcon />}
                  title="No matching models"
                  description="Change the search or clear the filters."
                  action={
                    <Button size="sm" variant="outline" onClick={resetFilters}>
                      Clear filters
                    </Button>
                  }
                />
              </motion.div>
            ) : view === "grid" ? (
              <motion.div
                key="grid"
                {...rise}
                transition={{ duration: 0.35, ease }}
                className="grid gap-3 sm:grid-cols-3"
              >
                <AnimatePresence mode="popLayout" initial={false}>
                  {visible.map((model) => (
                    <motion.div
                      key={model.id}
                      layout
                      initial={{ opacity: 0, scale: 0.96, filter: "blur(4px)" }}
                      animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                      exit={{ opacity: 0, scale: 0.96, filter: "blur(4px)" }}
                      transition={spring}
                      whileHover={{ y: -2 }}
                      className="relative"
                    >
                      <Card className="relative gap-0 p-4">
                        <div className="flex items-center justify-between">
                          <ModelGlyph />
                          <Checkbox
                            aria-label={`Select ${model.name}`}
                            checked={selected.includes(model.id)}
                            onCheckedChange={(checked) =>
                              choose(model.id, checked)
                            }
                            className="relative z-10"
                          />
                        </div>
                        <button
                          type="button"
                          aria-label={`Inspect ${model.name}`}
                          aria-pressed={activeId === model.id}
                          onClick={() => setActiveId(model.id)}
                          className="mt-4 rounded-sm text-left text-[13px] outline-none after:absolute after:inset-0 after:rounded-[inherit] focus-visible:ring-2 focus-visible:ring-ring/60"
                        >
                          {model.name}
                        </button>
                        <p className="mt-1 text-[11.5px] text-muted-foreground">
                          {model.family} · {model.context} context
                        </p>
                        <div className="mt-4 flex items-center justify-between">
                          <span className="font-mono text-[11px] text-muted-foreground">
                            {model.size.toFixed(1)} GB
                          </span>
                          <Availability installed={isInstalled(model.id)} />
                        </div>
                      </Card>
                      {activeId === model.id && (
                        <motion.span
                          layoutId="collections-active-ring"
                          aria-hidden="true"
                          transition={spring}
                          className="pointer-events-none absolute inset-0 rounded-2xl shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-primary)/0.55),0_0_28px_-10px_rgb(var(--og-rgb-primary)/0.8)]"
                        />
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </motion.div>
            ) : (
              <motion.div
                key="list"
                {...rise}
                transition={{ duration: 0.35, ease }}
              >
                <div className="mb-1.5 flex h-7 items-center gap-3 px-3.5">
                  <Checkbox
                    aria-label="Select models on this page"
                    checked={
                      !!visible.length && selectedOnPage === visible.length
                    }
                    indeterminate={
                      selectedOnPage > 0 && selectedOnPage < visible.length
                    }
                    onCheckedChange={(checked) =>
                      setSelected((previous) =>
                        checked
                          ? [
                              ...new Set([
                                ...previous,
                                ...visible.map((m) => m.id),
                              ]),
                            ]
                          : previous.filter(
                              (id) => !visible.some((m) => m.id === id),
                            ),
                      )
                    }
                  />
                  <span className={eyebrow}>
                    {results.length} models · page {currentPage} of {pages}
                  </span>
                </div>
                <ListGroup label="Models" density="compact">
                  <AnimatePresence mode="popLayout" initial={false}>
                    {visible.map((model) => (
                      <motion.div
                        key={model.id}
                        layout
                        initial={{ opacity: 0, x: -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 8 }}
                        transition={spring}
                      >
                        <ListRow
                          selected={activeId === model.id}
                          leading={
                            <span className="flex items-center gap-2.5">
                              <Checkbox
                                aria-label={`Select ${model.name}`}
                                checked={selected.includes(model.id)}
                                onCheckedChange={(checked) =>
                                  choose(model.id, checked)
                                }
                              />
                              <ModelGlyph className="size-6" />
                            </span>
                          }
                          title={
                            <button
                              type="button"
                              aria-label={`Inspect ${model.name}`}
                              aria-pressed={activeId === model.id}
                              onClick={() => setActiveId(model.id)}
                              className="rounded-sm text-left outline-none transition-colors hover:text-primary focus-visible:ring-2 focus-visible:ring-ring/60 aria-pressed:text-primary"
                            >
                              {model.name}
                            </button>
                          }
                          badges={
                            <Availability installed={isInstalled(model.id)} />
                          }
                          description={`${model.family} · ${model.context} context`}
                          meta={`${model.size.toFixed(1)} GB`}
                          trailing={
                            <Menu>
                              <MenuTrigger
                                render={
                                  <Button
                                    variant="ghost"
                                    size="icon-sm"
                                    aria-label={`Actions for ${model.name}`}
                                  />
                                }
                              >
                                <MoreHorizontalIcon />
                              </MenuTrigger>
                              <MenuPopup align="end">
                                <MenuItem
                                  onClick={() => {
                                    setActiveId(model.id);
                                    setDetailsOpen(true);
                                  }}
                                >
                                  View details
                                </MenuItem>
                                <MenuItem
                                  disabled={isInstalled(model.id)}
                                  onClick={() => queue(model.id)}
                                >
                                  Download
                                </MenuItem>
                                <MenuSeparator />
                                <MenuItem
                                  variant="destructive"
                                  disabled={!isInstalled(model.id)}
                                  onClick={() => {
                                    setInstalled((previous) =>
                                      previous.filter((id) => id !== model.id),
                                    );
                                    setNotice(
                                      `${model.name} removed from this preview.`,
                                    );
                                    record(
                                      `${model.name} removed from this preview.`,
                                    );
                                  }}
                                >
                                  Remove sample installation
                                </MenuItem>
                              </MenuPopup>
                            </Menu>
                          }
                        />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </ListGroup>
              </motion.div>
            )}
          </AnimatePresence>

          {results.length > 0 && (
            <Pagination aria-label="Model library pages">
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    render={
                      <Button
                        size="sm"
                        variant="ghost"
                        disabled={currentPage === 1}
                      />
                    }
                    onClick={() => setPage(currentPage - 1)}
                  />
                </PaginationItem>
                {Array.from({ length: pages }, (_, index) => index + 1).map(
                  (number) => (
                    <PaginationItem key={number}>
                      <PaginationLink
                        isActive={number === currentPage}
                        render={
                          <Button
                            variant={
                              number === currentPage ? "outline" : "ghost"
                            }
                            size="icon-sm"
                          />
                        }
                        onClick={() => setPage(number)}
                      >
                        {number}
                      </PaginationLink>
                    </PaginationItem>
                  ),
                )}
                <PaginationItem>
                  <PaginationNext
                    render={
                      <Button
                        size="sm"
                        variant="ghost"
                        disabled={currentPage === pages}
                      />
                    }
                    onClick={() => setPage(currentPage + 1)}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}

          <div className="border-t border-border/60 pt-6">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={active.id}
                {...rise}
                transition={{ duration: 0.3, ease }}
                className="flex flex-wrap items-center justify-between gap-6"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <ModelGlyph className="size-9" />
                  <div className="min-w-0">
                    <p className={eyebrow}>Inspecting</p>
                    <p className="mt-1 truncate text-[14px]">{active.name}</p>
                  </div>
                </div>
                <div className="flex gap-6 text-[12px]">
                  {[
                    ["Family", active.family],
                    ["Download", `${active.size.toFixed(1)} GB`],
                    ["Context", active.context],
                  ].map(([term, value]) => (
                    <div key={term}>
                      <p className={eyebrow}>{term}</p>
                      <p className="mt-1 tabular-nums">{value}</p>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setDetailsOpen(true)}
                  >
                    Details
                  </Button>
                  <Button
                    size="sm"
                    variant={isInstalled(active.id) ? "outline" : "default"}
                    disabled={isInstalled(active.id)}
                    onClick={() => queue(active.id)}
                  >
                    {isInstalled(active.id) ? <CheckIcon /> : <DownloadIcon />}
                    {isInstalled(active.id) ? "Installed" : "Download"}
                  </Button>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
          <p
            role="status"
            className="min-h-4 text-[12px] text-muted-foreground"
          >
            {notice}
          </p>
        </div>
      </Stage>

      <Stage
        index={2}
        kicker="States"
        title="Never a blank library"
        description="Loading draws the shape of what is coming, a refresh keeps the rows you were reading, and every dead end offers a way back. Each state crossfades into the next."
        sources={["Coss", "Motion Primitives", "Off Grid alive"]}
      >
        <div className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <Segmented
              label="Library state"
              value={libraryState}
              onValueChange={showState}
              options={libraryStates}
            />
            <Button
              size="sm"
              variant="ghost"
              loading={libraryState === "refreshing"}
              disabled={libraryState !== "ready"}
              onClick={() => showState("refreshing")}
            >
              <RefreshCwIcon />
              Refresh
            </Button>
          </div>
          <div className="relative min-h-[18rem]">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div
                key={libraryState === "refreshing" ? "ready" : libraryState}
                {...rise}
                transition={{ duration: 0.35, ease }}
              >
                {libraryState === "loading" ? (
                  <div
                    aria-busy="true"
                    aria-label="Loading model library"
                    className="divide-y divide-border/60 overflow-hidden rounded-xl border border-border"
                  >
                    {[0, 1, 2, 3].map((row) => (
                      <div
                        key={row}
                        className="flex min-h-11 items-center gap-3 px-3 py-1.5"
                      >
                        <Skeleton className="size-6 rounded-lg" />
                        <div className="flex-1 space-y-1.5">
                          <Skeleton
                            className="h-3"
                            style={{ width: `${46 - row * 6}%` }}
                          />
                          <Skeleton className="h-2.5 w-1/4" />
                        </div>
                        <Skeleton className="h-2.5 w-10" />
                      </div>
                    ))}
                  </div>
                ) : libraryState === "failed" ? (
                  <StateEmpty
                    icon={<TriangleAlertIcon />}
                    title="Could not load models"
                    description="The sample library did not respond. Nothing was lost."
                    action={
                      <Button
                        size="sm"
                        loading={retrying}
                        onClick={() => {
                          setRetrying(true);
                          stateLater(() => {
                            setRetrying(false);
                            setLibraryState("ready");
                            setStateNotice("Library loaded after retry.");
                            record("Library load retried.");
                          }, 1100);
                        }}
                      >
                        Retry
                      </Button>
                    }
                  />
                ) : libraryState === "empty" ? (
                  <StateEmpty
                    icon={<HardDriveIcon />}
                    title="No models in this library"
                    description="Choose a sample model to start a download."
                    action={
                      <Button size="sm" onClick={() => showState("ready")}>
                        Browse sample models
                      </Button>
                    }
                  />
                ) : libraryState === "nomatch" ? (
                  <StateEmpty
                    icon={<SearchIcon />}
                    title="Nothing matches “vision”"
                    description="Try another name, or clear the search."
                    action={
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => showState("ready")}
                      >
                        Clear search
                      </Button>
                    }
                  />
                ) : (
                  <div aria-busy={libraryState === "refreshing" || undefined}>
                    <div className="mb-2 h-0.5 overflow-hidden rounded-full">
                      <AnimatePresence>
                        {libraryState === "refreshing" && (
                          <motion.div
                            key="bar"
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                          >
                            <Progress
                              value={null}
                              aria-label="Refreshing library"
                            >
                              <ProgressTrack className="h-0.5">
                                <ProgressIndicator />
                              </ProgressTrack>
                            </Progress>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                    <LibraryRows
                      models={sampleModels.slice(0, 4)}
                      dim={libraryState === "refreshing"}
                    />
                  </div>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
          <p
            role="status"
            className="min-h-4 text-[12px] text-muted-foreground"
          >
            {libraryState === "refreshing"
              ? "Refreshing. Current rows stay available."
              : libraryState === "loading"
                ? "Loading the model library…"
                : stateNotice}
          </p>
        </div>
      </Stage>

      <Stage
        index={3}
        kicker="Downloads"
        title="Progress that belongs to the transfer"
        description="The bar eases between real chunks rather than inventing speed. When the size is unknown it says so, interruptions keep what arrived, and the install lands in the library above."
        sources={["Coss", "Motion Primitives", "Off Grid alive"]}
      >
        <div className="space-y-8">
          <div className="flex items-start justify-between gap-4">
            <div className="flex min-w-0 items-center gap-3">
              <ModelGlyph className="size-10" />
              <div className="min-w-0">
                <p className="truncate text-[15px]">{transfer.name}</p>
                <p className="mt-0.5 font-mono text-[11px] text-muted-foreground">
                  {transfer.id}-sample.gguf
                </p>
              </div>
            </div>
            <AnimatePresence mode="popLayout" initial={false}>
              <motion.span
                key={phase}
                initial={{ opacity: 0, y: 6, filter: "blur(4px)" }}
                animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -6, filter: "blur(4px)" }}
                transition={{ duration: 0.3, ease }}
              >
                <Badge
                  variant={
                    phase === "Installed"
                      ? "success"
                      : phase === "Interrupted" || phase === "Cancelled"
                        ? "warning"
                        : "outline"
                  }
                >
                  {phase}
                </Badge>
              </motion.span>
            </AnimatePresence>
          </div>

          <div className="space-y-3">
            <div className="flex items-end justify-between gap-4">
              <p className="text-[12px] text-muted-foreground">
                {indeterminate ? (
                  "Total size unknown · no estimate shown"
                ) : (
                  <>
                    <AnimatedNumber
                      value={receivedMb}
                      className="text-foreground"
                      springOptions={{ stiffness: 90, damping: 20 }}
                    />{" "}
                    of {totalMb.toLocaleString()} MB
                  </>
                )}
              </p>
              <span className="font-mono text-[22px] font-light leading-none tabular-nums">
                {indeterminate ? (
                  "—"
                ) : (
                  <>
                    <AnimatedNumber
                      value={percent}
                      springOptions={{ stiffness: 90, damping: 20 }}
                    />
                    <span className="text-[13px] text-muted-foreground">%</span>
                  </>
                )}
              </span>
            </div>
            <Progress
              value={indeterminate ? null : percent}
              aria-label={`${transfer.name} download progress`}
            >
              <ProgressTrack className="h-1">
                <ProgressIndicator
                  className={
                    phase === "Interrupted" || phase === "Cancelled"
                      ? "bg-primary/40 shadow-none"
                      : undefined
                  }
                />
              </ProgressTrack>
            </Progress>
          </div>

          <ol
            aria-label="Transfer milestones"
            className="grid grid-cols-4 gap-2"
          >
            {milestones.map((label, index) => (
              <li key={label} className="space-y-2">
                <div className="relative h-px bg-border">
                  <motion.div
                    initial={false}
                    animate={{ scaleX: index <= reached ? 1 : 0 }}
                    transition={{ duration: 0.6, ease, delay: index * 0.06 }}
                    className="absolute inset-0 origin-left bg-primary shadow-[0_0_10px_rgb(var(--og-rgb-primary)/0.7)]"
                  />
                </div>
                <p
                  aria-current={index === reached ? "step" : undefined}
                  className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground/60 transition-colors duration-500 aria-[current=step]:text-foreground"
                >
                  {label}
                </p>
              </li>
            ))}
          </ol>

          <div className="flex min-h-9 flex-wrap items-center gap-2">
            <AnimatePresence mode="popLayout" initial={false}>
              {(
                [
                  phase === "Queued" && {
                    key: "start",
                    node: (
                      <Button size="sm" onClick={start}>
                        <DownloadIcon />
                        Start transfer
                      </Button>
                    ),
                  },
                  phase === "Downloading" && {
                    key: "interrupt",
                    node: (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => go("Interrupted")}
                      >
                        <PauseIcon />
                        Interrupt
                      </Button>
                    ),
                  },
                  phase === "Interrupted" && {
                    key: "resume",
                    node: (
                      <Button size="sm" onClick={resume}>
                        <RefreshCwIcon />
                        Resume
                      </Button>
                    ),
                  },
                  (phase === "Downloaded" || phase === "Installing") && {
                    key: "install",
                    node: (
                      <Button
                        size="sm"
                        loading={phase === "Installing"}
                        onClick={install}
                      >
                        Install
                      </Button>
                    ),
                  },
                  phase === "Installed" && {
                    key: "view",
                    node: (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          resetFilters();
                          setActiveId(transferId);
                          setNotice(
                            `${transfer.name} is ready in the library.`,
                          );
                        }}
                      >
                        <CheckIcon />
                        Inspect in library
                      </Button>
                    ),
                  },
                  phase === "Cancelled" && {
                    key: "again",
                    node: (
                      <Button size="sm" onClick={() => queue(transferId)}>
                        Queue again
                      </Button>
                    ),
                  },
                  [
                    "Connecting",
                    "Downloading",
                    "Interrupted",
                    "Retrying",
                    "Queued",
                  ].includes(phase) && {
                    key: "cancel",
                    node: (
                      <Button size="sm" variant="ghost" onClick={cancel}>
                        <XIcon />
                        Cancel
                      </Button>
                    ),
                  },
                ].filter(Boolean) as Array<{
                  key: string;
                  node: React.ReactNode;
                }>
              ).map(({ key, node }) => (
                <motion.div
                  key={key}
                  layout
                  initial={{ opacity: 0, scale: 0.94, filter: "blur(4px)" }}
                  animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                  exit={{ opacity: 0, scale: 0.94, filter: "blur(4px)" }}
                  transition={spring}
                >
                  {node}
                </motion.div>
              ))}
            </AnimatePresence>
            {(phase === "Connecting" || phase === "Retrying") && (
              <Spinner className="ml-1 size-4 text-muted-foreground" />
            )}
          </div>

          <p role="status" className="text-[12px] text-muted-foreground">
            {phaseCopy[phase]}
          </p>
        </div>
      </Stage>

      <Stage
        index={4}
        kicker="Activity"
        title="Every action leaves a trace"
        description="Each download, install and refresh above writes a line here. New entries slide in at the top and the rest make room."
        sources={["Coss", "Motion"]}
      >
        <div className="space-y-5">
          <InputGroup>
            <InputGroupAddon>
              <SearchIcon aria-hidden="true" />
            </InputGroupAddon>
            <InputGroupInput
              type="search"
              aria-label="Filter activity"
              value={logQuery}
              onValueChange={setLogQuery}
              placeholder="Search this preview's actions…"
            />
          </InputGroup>
          <div className="min-h-40">
            <AnimatePresence mode="wait" initial={false}>
              {filteredLogs.length ? (
                <motion.ul
                  key="logs"
                  aria-label="Activity"
                  {...rise}
                  transition={{ duration: 0.3, ease }}
                  className="divide-y divide-border/60 overflow-hidden rounded-xl border border-border"
                >
                  <AnimatePresence initial={false}>
                    {filteredLogs.slice(0, 7).map((log) => (
                      <motion.li
                        key={log.id}
                        layout
                        initial={{ opacity: 0, y: -10, filter: "blur(4px)" }}
                        animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                        exit={{ opacity: 0, filter: "blur(4px)" }}
                        transition={spring}
                        className="flex min-h-10 items-center gap-4 px-3"
                      >
                        <span className="w-16 shrink-0 font-mono text-[10.5px] text-muted-foreground">
                          {log.time}
                        </span>
                        <span className="min-w-0 flex-1 truncate text-[12.5px]">
                          {log.message}
                        </span>
                        <Badge size="sm" variant={resultTone(log.result)}>
                          {log.result}
                        </Badge>
                      </motion.li>
                    ))}
                  </AnimatePresence>
                </motion.ul>
              ) : (
                <motion.div
                  key="none"
                  {...rise}
                  transition={{ duration: 0.3, ease }}
                >
                  <StateEmpty
                    icon={<FileTextIcon />}
                    title="No matching activity"
                    description="Clear the search to see previous actions."
                    action={
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setLogQuery("")}
                      >
                        Clear search
                      </Button>
                    }
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </Stage>

      <Sheet open={detailsOpen} onOpenChange={setDetailsOpen}>
        <SheetPopup>
          <SheetHeader>
            <SheetTitle className="font-normal">{active.name}</SheetTitle>
            <SheetDescription>Sample model details</SheetDescription>
          </SheetHeader>
          <div className="space-y-6 px-4">
            <Availability installed={isInstalled(active.id)} />
            <Specs
              items={[
                ["Family", active.family],
                ["Size", `${active.size.toFixed(1)} GB`],
                ["Context", active.context],
                ["File", `${active.id}-sample.gguf`],
              ]}
            />
            <p className="border-t border-border/60 pt-5 text-[12px] leading-relaxed text-muted-foreground">
              This preview uses illustrative specifications. It does not fetch a
              model catalogue or access files on your device.
            </p>
          </div>
          <SheetFooter className="flex-row justify-end gap-2">
            <SheetClose asChild>
              <Button size="sm" variant="ghost">
                Close
              </Button>
            </SheetClose>
            <Button
              size="sm"
              variant={isInstalled(active.id) ? "outline" : "default"}
              disabled={isInstalled(active.id)}
              onClick={() => {
                queue(active.id);
                setDetailsOpen(false);
              }}
            >
              Queue download
            </Button>
          </SheetFooter>
        </SheetPopup>
      </Sheet>
    </div>
  );
}
