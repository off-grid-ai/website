import * as React from "react";
import { Segmented } from "@offgrid/ui/operator/segmented";
import { AnimatePresence, motion } from "motion/react";
import { Check, Sparkles, X } from "lucide-react";
import { Prec } from "@codemirror/state";
import {
  QueuedComposer,
  type QueuedMessage,
  type QueueEdit,
} from "@offgrid/ui/operator/workflows/queue";
import {
  SecretValue,
  type SecretReadState,
} from "@offgrid/ui/operator/workflows/secret-value";
import { Button } from "@offgrid/ui/operator/coss/button";
import {
  Field,
  FieldLabel,
  FieldDescription,
} from "@offgrid/ui/operator/coss/field";
import {
  Autocomplete,
  AutocompleteInput,
  AutocompletePopup,
  AutocompleteList,
  AutocompleteItem,
  AutocompleteEmpty,
} from "@offgrid/ui/operator/coss/autocomplete";
import { CodeEditor, EditorView } from "@offgrid/ui/operator/media/code-editor";
import {
  inlineCompletion,
  acceptInlineCompletion,
  rejectInlineCompletion,
} from "@offgrid/ui/operator/media/inline-completion";
import { Stage } from "./stage";
import { LiveStatus } from "@offgrid/ui/operator/presence";

const SAMPLE_SECRET = "demo-key-not-a-real-credential";
const LIFETIME = 30;
const SUGGESTION = "Summarize these notes and list the next steps.";
const MULTILINE_SUGGESTION =
  "Plan the release.\nCheck Android and iOS beta links.\nRecord the test results.";
const ease = [0.16, 1, 0.3, 1] as const;
const rise = {
  initial: { opacity: 0, y: 6, filter: "blur(4px)" },
  animate: { opacity: 1, y: 0, filter: "blur(0px)" },
  exit: { opacity: 0, y: -6, filter: "blur(4px)" },
  transition: { duration: 0.35, ease },
};

/**
 * Chapter-scoped dressing for the sourced queue: rows arrive instead of
 * appearing, and their actions stay quiet until the row is in hand.
 */
// The queue row reveal and frame/PDF surfaces now ship in the library stylesheet.
const COMPLETION_CSS = `
.og-queue [aria-label="Message queue"] .max-h-40 { max-height: 14rem; }
.og-ghost .cm-placeholder { color: var(--muted-foreground); opacity: 0.7; }
`;

/** A message field, not a code slab: sans text, no gutter, emerald caret. */
const messageTheme = Prec.highest(
  EditorView.theme(
    {
      "&": {
        backgroundColor: "transparent",
        color: "var(--foreground)",
        fontSize: "13px",
      },
      "&.cm-focused": { outline: "none" },
      ".cm-scroller": { fontFamily: "var(--og-font-sans)", lineHeight: "1.7" },
      ".cm-content": { padding: "10px 12px", caretColor: "var(--primary)" },
      ".cm-cursor": { borderLeftColor: "var(--primary)" },
      ".cm-selectionBackground, &.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground":
        { backgroundColor: "rgb(var(--og-rgb-primary) / 0.2)" },
    },
    { dark: true },
  ),
);


export function CompletionWorkshop() {
  // Queue
  const [items, setItems] = React.useState<QueuedMessage[]>([
    { id: "notes", text: "Summarize the project notes.", state: "queued" },
    {
      id: "actions",
      text: "List the decisions that need review.",
      state: "queued",
    },
  ]);
  const [edit, setEdit] = React.useState<QueueEdit | null>(null);
  const [draft, setDraft] = React.useState("");
  const [suggestion, setSuggestion] = React.useState<string | undefined>(
    SUGGESTION,
  );
  const nextId = React.useRef(0);
  const [notice, setNotice] = React.useState(
    "Preview only. Messages stay in this page.",
  );
  // Inline completion
  const [ghostDraft, setGhostDraft] = React.useState("");
  const [ghostAvailable, setGhostAvailable] = React.useState(false);
  const [ghostNotice, setGhostNotice] = React.useState(
    "Type Plan to see the local sample suggestion.",
  );
  const ghostEditor = React.useRef<EditorView | null>(null);
  const ghostExtensions = React.useMemo(
    () => [
      messageTheme,
      EditorView.lineWrapping,
      EditorView.contentAttributes.of({
        "aria-label": "Message with multiline completion",
        "aria-describedby": "multiline-completion-help",
      }),
      inlineCompletion({
        delay: 200,
        fetchFn: async (state) => {
          const text = state.doc.toString();
          return text &&
            state.selection.main.head === text.length &&
            MULTILINE_SUGGESTION.startsWith(text)
            ? MULTILINE_SUGGESTION.slice(text.length)
            : "";
        },
        events: {
          shouldShowSuggestion: (_view, suggestion) => {
            setGhostAvailable(Boolean(suggestion));
            if (suggestion)
              setGhostNotice(
                "Suggestion ready. Tab accepts; Escape dismisses.",
              );
            return true;
          },
          onSuggestionAccepted: () => {
            setGhostAvailable(false);
            setGhostNotice("Multiline suggestion accepted into the draft.");
          },
          onSuggestionRejected: () => {
            setGhostAvailable(false);
            setGhostNotice("Suggestion dismissed. Your draft is unchanged.");
          },
        },
      }),
    ],
    [],
  );
  // Secrets
  const [secret, setSecret] = React.useState<SecretReadState>({
    status: "ready",
    value: SAMPLE_SECRET,
    remainingSeconds: LIFETIME,
    lifetimeSeconds: LIFETIME,
  });
  const [revealed, setRevealed] = React.useState(false);
  const [copyState, setCopyState] = React.useState<
    "idle" | "copying" | "copied" | "error"
  >("idle");

  const timers = React.useRef<Array<ReturnType<typeof setTimeout>>>([]);
  const later = (fn: () => void, ms: number) =>
    timers.current.push(setTimeout(fn, ms));
  React.useEffect(() => () => timers.current.forEach(clearTimeout), []);

  // A read value counts down in real time and expires on its own.
  const ticking = secret.status === "ready";
  React.useEffect(() => {
    if (!ticking) return;
    const timer = setInterval(() => {
      setSecret((current) => {
        if (current.status !== "ready") return current;
        // Reading again resets the reveal, so expiry never re-shows the value.
        if (current.remainingSeconds <= 1) return { status: "expired" };
        return { ...current, remainingSeconds: current.remainingSeconds - 1 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [ticking]);

  const sending = items.find((item) => item.state === "sending");
  const updateItem = (id: string, update: Partial<QueuedMessage>) =>
    setItems((previous) =>
      previous.map((item) => (item.id === id ? { ...item, ...update } : item)),
    );
  const changeSecret = (status: SecretReadState["status"]) => {
    setRevealed(false);
    setCopyState("idle");
    setSecret(
      status === "ready"
        ? {
            status,
            value: SAMPLE_SECRET,
            remainingSeconds: LIFETIME,
            lifetimeSeconds: LIFETIME,
          }
        : status === "error"
          ? {
              status,
              message: "Sample secret store is locked. Unlock it, then retry.",
            }
          : { status },
    );
  };
  const readSecret = () => {
    changeSecret("loading");
    later(() => changeSecret("ready"), 1100);
  };

  return (
    <div className="min-w-0">
      <style>{COMPLETION_CSS}</style>
      <Stage
        index={1}
        kicker="Queue"
        title="Messages that wait their turn"
        description="Line up the next questions while one is still answering. Reorder, edit or cancel them; actions stay quiet until a row is in hand."
        sources={["AI Elements", "Coss"]}
      >
        <section aria-label="Queued composer" className="og-queue space-y-5">
          <QueuedComposer
            items={items}
            edit={edit}
            value={draft}
            onValueChange={setDraft}
            suggestion={suggestion}
            onAcceptSuggestion={(value) => {
              setDraft(value);
              setSuggestion(undefined);
            }}
            onDismissSuggestion={() => setSuggestion(undefined)}
            onQueue={(text) => {
              setItems((previous) => [
                ...previous,
                { id: `added-${++nextId.current}`, text, state: "queued" },
              ]);
              setDraft("");
              setSuggestion(undefined);
              setNotice("Message added to the local queue.");
            }}
            onEdit={(id) => {
              const item = items.find((entry) => entry.id === id);
              if (item) setEdit({ id, text: item.text });
            }}
            onEditChange={(text) =>
              setEdit((previous) =>
                previous ? { ...previous, text, error: undefined } : null,
              )
            }
            onSaveEdit={() => {
              if (edit?.text.trim()) {
                updateItem(edit.id, {
                  text: edit.text.trim(),
                  state: "queued",
                  error: undefined,
                });
                setEdit(null);
                setNotice("Queued message updated.");
              }
            }}
            onCancelEdit={() => setEdit(null)}
            onMove={(id, direction) => {
              setItems((previous) => {
                const index = previous.findIndex((item) => item.id === id);
                const target = index + direction;
                if (index < 0 || target < 0 || target >= previous.length)
                  return previous;
                const next = [...previous];
                [next[index], next[target]] = [next[target], next[index]];
                return next;
              });
              setNotice("Queue order updated.");
            }}
            onSendNow={(id) => {
              updateItem(id, { state: "sending" });
              setNotice("Sending. Choose how the sample ends.");
            }}
            onCancel={(id) => {
              updateItem(id, { state: "cancelled", error: undefined });
              setNotice("Message cancelled in the preview.");
            }}
            onRetry={(id) => {
              updateItem(id, { state: "queued", error: undefined });
              setNotice("Message returned to the queue.");
            }}
            onRemove={(id) => {
              setItems((previous) => previous.filter((item) => item.id !== id));
              setNotice("Message removed from the queue.");
            }}
          />
          <div className="flex min-h-8 flex-wrap items-center justify-between gap-3">
            <LiveStatus travel="across" as="span" className="block text-[11.5px]">{notice}</LiveStatus>
            <AnimatePresence mode="popLayout" initial={false}>
              {sending ? (
                <motion.div
                  key="outcomes"
                  {...rise}
                  role="group"
                  aria-label="Preview outcomes"
                  className="flex items-center gap-1"
                >
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      updateItem(sending.id, { state: "sent" });
                      setNotice("Sample message marked sent.");
                    }}
                  >
                    <Check />
                    Mark sent
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      updateItem(sending.id, {
                        state: "failed",
                        error:
                          "Sample connection closed before the message was sent.",
                      });
                      setNotice("Sample send failure selected.");
                    }}
                  >
                    <X />
                    Mark failed
                  </Button>
                </motion.div>
              ) : !suggestion ? (
                <motion.div key="suggest" {...rise}>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setSuggestion(SUGGESTION)}
                  >
                    <Sparkles />
                    Show suggestion
                  </Button>
                </motion.div>
              ) : null}
            </AnimatePresence>
          </div>
        </section>
      </Stage>

      <Stage
        index={2}
        kicker="Completion"
        title="Suggestions that wait at the caret"
        description="Ghost lines appear after a short pause and never move what you typed. Tab takes all of them, Escape lets them go."
        sources={["CodeMirror", "codemirror-ai", "Coss"]}
      >
        <section aria-label="Multiline completion" className="space-y-4">
          <h3 className="font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
            Complete a message
          </h3>
          <div
            data-slot="textarea-control"
            className="og-ghost rounded-lg border border-input bg-background dark:bg-input/32"
          >
            <CodeEditor
              value={ghostDraft}
              minHeight="104px"
              placeholder="Type Plan…"
              theme="dark"
              extensions={ghostExtensions}
              indentWithTab={false}
              basicSetup={{
                lineNumbers: false,
                foldGutter: false,
                highlightActiveLine: false,
                highlightActiveLineGutter: false,
                autocompletion: false,
              }}
              onCreateEditor={(view) => {
                ghostEditor.current = view;
              }}
              onChange={(value) => {
                setGhostDraft(value);
                setGhostAvailable(false);
              }}
            />
          </div>
          <p
            id="multiline-completion-help"
            className="text-[11.5px] leading-relaxed text-muted-foreground"
          >
            Tab accepts all suggested lines. Escape dismisses them. This sample
            uses local text and does not call a model.
          </p>
          <div className="flex min-h-8 flex-wrap items-center justify-between gap-3">
            <LiveStatus travel="across" as="span" className="block text-[11.5px]">{ghostNotice}</LiveStatus>
            <div className="flex items-center gap-1">
              <AnimatePresence mode="popLayout" initial={false}>
                {ghostAvailable && (
                  <motion.div
                    key="choices"
                    {...rise}
                    className="flex items-center gap-1"
                  >
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => {
                        const view = ghostEditor.current;
                        if (view) {
                          view.focus();
                          rejectInlineCompletion(view);
                        }
                      }}
                    >
                      Dismiss suggestion
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => {
                        const view = ghostEditor.current;
                        if (view) {
                          view.focus();
                          acceptInlineCompletion(view);
                        }
                      }}
                    >
                      Accept suggestion
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
              <Button
                size="sm"
                variant="outline"
                disabled={!ghostDraft.trim()}
                onClick={() => {
                  setDraft(ghostDraft);
                  setGhostNotice("Draft copied to the queued composer.");
                }}
              >
                Use completed draft
              </Button>
            </div>
          </div>
        </section>
      </Stage>

      <Stage
        index={3}
        kicker="Commands"
        title="Commands that finish themselves"
        description="Type a prefix and the rest appears in the field as you move through the list. Enter keeps it; the result lands in your next message."
        sources={["Coss", "Base UI"]}
      >
        <CommandCompletion
          onUse={(value) => {
            setDraft(value);
            setNotice("Command placed in your next message.");
          }}
        />
      </Stage>

      <Stage
        index={4}
        kicker="Secrets"
        title="Secrets that show only on request"
        description="A key stays masked and out of the page until you ask. Once read it counts down in real time, then locks itself and has to be read again."
        sources={["Coss", "Motion Primitives"]}
      >
        <section aria-label="Secret access" className="space-y-8">
          <div className="min-h-[124px]">
            <AnimatePresence mode="wait" initial={false}>
              <motion.div key={secret.status} {...rise}>
                <SecretValue
                  label="Preview API key"
                  state={secret}
                  revealed={revealed}
                  onRevealedChange={setRevealed}
                  copyState={copyState}
                  onRetry={readSecret}
                  onCopy={() => {
                    if (
                      secret.status !== "ready" ||
                      secret.remainingSeconds <= 0
                    )
                      return;
                    setCopyState("copying");
                    if (!navigator.clipboard?.writeText) {
                      setCopyState("error");
                      return;
                    }
                    void navigator.clipboard.writeText(secret.value).then(
                      () => setCopyState("copied"),
                      () => setCopyState("error"),
                    );
                  }}
                />
              </motion.div>
            </AnimatePresence>
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border/50 pt-6">
            <div className="space-y-3">
              <span className="block font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground">
                Sample state
              </span>
              <Segmented
                label="Secret state specimen"
                value={secret.status}
                options={[
                  { id: "ready", label: "Ready" },
                  { id: "loading", label: "Reading" },
                  { id: "error", label: "Read error" },
                  { id: "expired", label: "Expired" },
                ]}
                onValueChange={(id) =>
                  changeSecret(id as SecretReadState["status"])
                }
              />
            </div>
            <Button
              size="sm"
              variant="ghost"
              disabled={
                secret.status !== "ready" || secret.remainingSeconds <= 10
              }
              onClick={() =>
                setSecret((current) =>
                  current.status === "ready"
                    ? { ...current, remainingSeconds: 10 }
                    : current,
                )
              }
            >
              Skip to 10 seconds left
            </Button>
          </div>
          <p className="text-[11.5px] leading-relaxed text-muted-foreground">
            This is a sample key. Copy writes the sample to your clipboard.
          </p>
        </section>
      </Stage>
    </div>
  );
}

/** The same source composition used by the workshop and its focused test. */
export function CommandCompletion({
  onUse,
}: {
  onUse: (value: string) => void;
}) {
  const [command, setCommand] = React.useState("");
  return (
    <Field className="gap-3">
      <FieldLabel>Complete a command</FieldLabel>
      <div className="flex w-full items-center gap-2">
        <Autocomplete
          items={[
            "/summarize project notes",
            "/summarize recent decisions",
            "/search local files",
            "/schedule tomorrow",
          ]}
          mode="both"
          value={command}
          onValueChange={setCommand}
        >
          <AutocompleteInput
            placeholder="Type /sum"
            showClear
            className="flex-1 font-mono text-[12.5px]"
          />
          <AutocompletePopup>
            <AutocompleteEmpty>No matching command.</AutocompleteEmpty>
            <AutocompleteList>
              {(item: string) => (
                <AutocompleteItem
                  key={item}
                  value={item}
                  className="font-mono text-[12.5px]"
                >
                  {item}
                </AutocompleteItem>
              )}
            </AutocompleteList>
          </AutocompletePopup>
        </Autocomplete>
        <Button
          variant="outline"
          disabled={!command.trim()}
          onClick={() => {
            onUse(command);
            setCommand("");
          }}
        >
          Use in next message
        </Button>
      </div>
      <FieldDescription>
        Type a prefix. Use Down Arrow to preview the completion in the input and
        Enter to accept it. Escape closes the list.
      </FieldDescription>
    </Field>
  );
}
