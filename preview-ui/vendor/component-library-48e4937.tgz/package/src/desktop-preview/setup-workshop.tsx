import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  ChevronDown,
  FolderOpen,
  Mic,
  MonitorUp,
  Plug,
} from "lucide-react";
import { Button } from "@offgrid/ui/operator/coss/button";
import { Checkbox } from "@offgrid/ui/operator/animate/checkbox";
import { Badge } from "@offgrid/ui/operator/coss/badge";
import {
  Field,
  FieldLabel,
  FieldDescription,
} from "@offgrid/ui/operator/coss/field";
import { Input } from "@offgrid/ui/operator/coss/input";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectPopup,
  SelectItem,
} from "@offgrid/ui/operator/coss/select";
import { Progress } from "@offgrid/ui/operator/coss/progress";
import {
  Collapsible,
  CollapsibleTrigger,
  CollapsiblePanel,
} from "@offgrid/ui/operator/coss/collapsible";
import AnimatedStepper from "@offgrid/ui/operator/animated-stepper";
import { TextEffect } from "@offgrid/ui/operator/text-effect";
import { AnimatedNumber } from "@offgrid/ui/operator/motion/animated-number";
import { TextMorph } from "@offgrid/ui/operator/motion/text-morph";
import { Stage } from "./stage";
import { LiveStatus as Live, SettingRow, StatePill } from "@offgrid/ui/operator/presence";

type Permission = "denied" | "checking" | "restart" | "granted";
type Connection = "idle" | "testing" | "ready" | "empty" | "failed";
type Tone = "off" | "busy" | "warn" | "on";

const plans = [
  { id: "chat", label: "Chat model", size: 2.4 },
  { id: "vision", label: "Vision model", size: 1.2 },
];
const ease = [0.16, 1, 0.3, 1] as const;
/** One selectable model row in the download plan. */
const modelRow =
  "flex cursor-pointer items-center gap-3 py-3.5 text-[13px] transition-colors has-[:disabled]:cursor-not-allowed";
const eyebrow =
  "font-mono text-[10px] uppercase tracking-[0.22em] text-muted-foreground";
const reveal = {
  initial: { opacity: 0, height: 0, filter: "blur(4px)" },
  animate: { opacity: 1, height: "auto", filter: "blur(0px)" },
  exit: { opacity: 0, height: 0, filter: "blur(4px)" },
  transition: { duration: 0.4, ease },
};


const TONE_DOT: Record<Tone, string> = {
  off: "bg-muted-foreground/50",
  busy: "bg-muted-foreground animate-pulse",
  warn: "bg-amber-400 shadow-[0_0_8px_rgb(251_191_36/0.7)]",
  on: "bg-primary shadow-[0_0_8px_rgb(var(--og-rgb-primary)/0.9)]",
};



const ONBOARDING = [
  {
    label: "Welcome",
    description: "Local by default",
    title: "Keep your work on your device.",
    body: "Models, files and history stay on this computer unless you connect a server.",
  },
  {
    label: "Models",
    description: "Choose a setup plan",
    title: "Choose the tools you need.",
    body: "Start with a chat model. Vision and speech can be added at any time.",
  },
  {
    label: "Ready",
    description: "Open your workspace",
    title: "Start with your own workspace.",
    body: "Your workspace opens with sample notes you can delete whenever you like.",
  },
];

/** Local host-state examples. The source controls own their input and motion behavior. */
export function SetupWorkshop() {
  const [onboardingStep, setOnboardingStep] = useState(0);
  const [onboardingDone, setOnboardingDone] = useState(false);
  const [permission, setPermission] = useState<Permission>("denied");
  const [address, setAddress] = useState("http://localhost:11434/v1");
  const [key, setKey] = useState("");
  const [hasKey, setHasKey] = useState(true);
  const [response, setResponse] = useState<string | null>("ready");
  const [connection, setConnection] = useState<Connection>("idle");
  const [model, setModel] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [selected, setSelected] = useState(["chat"]);
  const [downloadState, setDownload] = useState<
    "idle" | "preparing" | "running" | "cancelled" | "complete"
  >("idle");
  const [progress, setProgress] = useState(0);
  const download =
    downloadState === "running" && progress === 100
      ? "complete"
      : downloadState;
  const [folder, setFolder] = useState("/Users/you/Off Grid/models");
  const [pendingFolder, setPendingFolder] = useState(false);
  const permissionTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const connectionTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prepareTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(
    () => () => {
      if (permissionTimer.current) clearTimeout(permissionTimer.current);
      if (connectionTimer.current) clearTimeout(connectionTimer.current);
      if (prepareTimer.current) clearTimeout(prepareTimer.current);
    },
    [],
  );
  useEffect(() => {
    if (download !== "running") return;
    const timer = setInterval(
      () => setProgress((value) => Math.min(value + 10, 100)),
      350,
    );
    return () => clearInterval(timer);
  }, [download]);
  const busy = download === "preparing" || download === "running";
  const total = plans
    .filter((plan) => selected.includes(plan.id))
    .reduce((sum, plan) => sum + plan.size, 0);
  /** A direct choice wins over a check that is still in flight. */
  const settlePermission = (next: Permission) => {
    if (permissionTimer.current) clearTimeout(permissionTimer.current);
    setPermission(next);
  };
  const resetConnection = () => {
    if (connectionTimer.current) clearTimeout(connectionTimer.current);
    setConnection("idle");
    setModel(null);
    setSaved(false);
  };
  const step = ONBOARDING[onboardingStep];

  return (
    <div className="min-w-0">
      <Stage
        index={1}
        kicker="First run"
        title="Three calm steps to a workspace"
        description="The rail fills as you move, finished steps draw their check, and each headline resolves out of blur. Skip is always one press away."
        sources={["SmoothUI", "Motion Primitives", "Coss"]}
      >
        <section aria-label="Onboarding" className="space-y-10">
          <div className="[&_[role=tab]]:size-8 [&_[role=tab]]:border [&_[role=tab]]:text-[12px] [&_[role=tab]]:font-normal [&_[role=tab][aria-selected=true]]:bg-primary/15 [&_[role=tab][aria-selected=true]]:text-primary [&_[role=tab][aria-selected=true]]:shadow-[0_0_18px_-4px_rgb(var(--og-rgb-primary)/0.8)] [&_[role=tab]_svg]:size-4 [&_[role=tablist]_p]:text-[12.5px] [&_[role=tablist]_p]:font-normal [&_[role=tablist]_p+p]:text-[11px]">
            <AnimatedStepper
              currentStep={onboardingDone ? ONBOARDING.length : onboardingStep}
              onStepChange={setOnboardingStep}
              steps={ONBOARDING.map(({ label, description }) => ({
                label,
                description,
              }))}
            />
          </div>
          <div className="min-h-20 space-y-2">
            <TextEffect
              key={onboardingDone ? "done" : onboardingStep}
              as="h3"
              per="word"
              preset="blur"
              className="text-[22px] font-light tracking-[-0.02em]"
            >
              {onboardingDone ? "Your local workspace is ready." : step.title}
            </TextEffect>
            <AnimatePresence mode="wait" initial={false}>
              <motion.p
                key={onboardingDone ? "done" : onboardingStep}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0, transition: { delay: 0.15 } }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.3, ease }}
                className="max-w-md text-[12.5px] leading-relaxed text-muted-foreground"
              >
                {onboardingDone
                  ? "You can revisit these choices in Settings."
                  : step.body}
              </motion.p>
            </AnimatePresence>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            {!onboardingDone && (
              <Button
                className="min-w-36"
                aria-label={
                  onboardingStep < 2 ? "Continue setup" : "Finish setup"
                }
                onClick={() =>
                  onboardingStep < 2
                    ? setOnboardingStep((value) => value + 1)
                    : setOnboardingDone(true)
                }
              >
                <TextMorph as="span">
                  {onboardingStep < 2 ? "Continue setup" : "Finish setup"}
                </TextMorph>
              </Button>
            )}
            {onboardingDone ? (
              <Button
                variant="outline"
                onClick={() => {
                  setOnboardingDone(false);
                  setOnboardingStep(0);
                }}
              >
                Start over
              </Button>
            ) : (
              <>
                <Button
                  variant="outline"
                  disabled={onboardingStep === 0}
                  onClick={() => setOnboardingStep((value) => value - 1)}
                >
                  Previous step
                </Button>
                <Button
                  variant="ghost"
                  className="ml-auto text-muted-foreground"
                  onClick={() => {
                    setOnboardingStep(2);
                    setOnboardingDone(true);
                  }}
                >
                  Skip setup
                </Button>
              </>
            )}
          </div>
        </section>
      </Stage>

      <Stage
        index={2}
        kicker="Consent"
        title="Permissions that explain themselves"
        description="Each permission says where it stands and what happens next. Checking breathes, a needed relaunch is named plainly, and a moved folder waits for your go-ahead."
        sources={["Coss", "Motion Primitives"]}
      >
        <section aria-labelledby="permission-heading">
          <h3 id="permission-heading" className={eyebrow}>
            Device permissions
          </h3>
          <div className="mt-2 divide-y divide-border/50">
            <SettingRow
              icon={<MonitorUp aria-hidden="true" />}
              title="Screen recording"
              description="Lets the assistant read the window you share."
            >
              <StatePill
                tone={
                  permission === "granted"
                    ? "on"
                    : permission === "restart"
                      ? "warn"
                      : permission === "checking"
                        ? "busy"
                        : "off"
                }
                label={
                  permission === "checking"
                    ? "Checking"
                    : permission === "restart"
                      ? "Relaunch needed"
                      : permission === "granted"
                        ? "Allowed"
                        : "Not allowed"
                }
              />
            </SettingRow>
            <SettingRow
              icon={<Mic aria-hidden="true" />}
              title="Microphone"
              description="Used only while you hold the voice key."
            >
              <StatePill tone="on" label="Allowed" />
            </SettingRow>
            <SettingRow
              icon={<FolderOpen aria-hidden="true" />}
              title="Models directory"
              description={folder}
            >
              <Button
                size="sm"
                variant="outline"
                disabled={pendingFolder}
                onClick={() => {
                  setFolder("/Volumes/External/Off Grid/models");
                  setPendingFolder(true);
                }}
              >
                Preview folder change
              </Button>
            </SettingRow>
          </div>
          <AnimatePresence initial={false}>
            {pendingFolder && (
              <motion.div {...reveal} className="overflow-hidden">
                <div className="mb-5 flex flex-wrap items-center justify-between gap-4 rounded-xl px-4 py-3 shadow-[inset_0_0_0_1px_rgb(251_191_36/0.25)]">
                  <p className="max-w-md text-[12px] leading-relaxed text-muted-foreground">
                    New directory saved. Existing files stay in the previous
                    directory until you move them. Relaunch to use the new
                    location.
                  </p>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setPendingFolder(false)}
                  >
                    Apply directory restart
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          <div className="flex flex-wrap items-center gap-3 border-t border-border/50 pt-6">
            <Button
              aria-label="Check permissions"
              variant="outline"
              loading={permission === "checking"}
              onClick={() => {
                const next =
                  permission === "granted"
                    ? "granted"
                    : permission === "restart"
                      ? "restart"
                      : "denied";
                setPermission("checking");
                permissionTimer.current = setTimeout(
                  () => setPermission(next),
                  700,
                );
              }}
            >
              Check permissions
            </Button>
            <AnimatePresence mode="popLayout" initial={false}>
              {permission === "denied" && (
                <motion.span key="allow" {...fadeScale}>
                  <Button onClick={() => settlePermission("restart")}>
                    Allow in preview
                  </Button>
                </motion.span>
              )}
              {permission === "restart" && (
                <motion.span key="relaunch" {...fadeScale}>
                  <Button onClick={() => settlePermission("granted")}>
                    Relaunch preview
                  </Button>
                </motion.span>
              )}
              {permission === "granted" && (
                <motion.span key="reset" {...fadeScale}>
                  <Button
                    variant="ghost"
                    onClick={() => settlePermission("denied")}
                  >
                    Reset permission
                  </Button>
                </motion.span>
              )}
            </AnimatePresence>
            <div className="basis-full pt-1">
              <Live>
                {permission === "restart"
                  ? "Permission is saved. Relaunch to apply it."
                  : permission === "granted"
                    ? "Screen recording is ready."
                    : permission === "checking"
                      ? "Checking device access…"
                      : "Allow screen recording in system settings."}
              </Live>
            </div>
          </div>
        </section>
      </Stage>

      <Stage
        index={3}
        kicker="Connect"
        title="Find a server, then pick a model"
        description="Testing runs inside the button. Discovered models roll into view, and changing the address quietly clears what no longer applies. Sample responses only; nothing is sent."
        sources={["Coss", "Off Grid alive"]}
      >
        <section
          aria-labelledby="connection-heading"
          className="grid gap-x-8 gap-y-8 sm:grid-cols-2"
        >
          <h3 id="connection-heading" className={`${eyebrow} sm:col-span-2`}>
            Server discovery
          </h3>
          <Field className="sm:col-span-2">
            <FieldLabel>Discovery address</FieldLabel>
            <Input
              value={address}
              onChange={(event) => {
                setAddress(event.target.value);
                resetConnection();
              }}
            />
          </Field>
          <Field>
            <FieldLabel>Replacement API key</FieldLabel>
            <Input
              type="password"
              value={key}
              placeholder={
                hasKey ? "Saved key · enter a replacement" : "Optional API key"
              }
              onChange={(event) => {
                setKey(event.target.value);
                setSaved(false);
              }}
            />
            <FieldDescription>
              {hasKey
                ? "The saved key stays private. Leave blank to keep it."
                : "No key is saved."}
            </FieldDescription>
          </Field>
          <Field>
            <FieldLabel>Sample server response</FieldLabel>
            <Select
              value={response}
              onValueChange={(value) => {
                setResponse(value);
                resetConnection();
              }}
              items={[
                { value: "ready", label: "Models available" },
                { value: "empty", label: "No models found" },
                { value: "failed", label: "Connection refused" },
              ]}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectPopup>
                <SelectItem value="ready">Models available</SelectItem>
                <SelectItem value="empty">No models found</SelectItem>
                <SelectItem value="failed">Connection refused</SelectItem>
              </SelectPopup>
            </Select>
            <FieldDescription>
              Simulates what the server answers.
            </FieldDescription>
          </Field>
          <div className="flex flex-wrap items-center gap-4 sm:col-span-2">
            <Button
              aria-label="Test connection"
              variant="outline"
              loading={connection === "testing"}
              disabled={!address.trim()}
              onClick={() => {
                setConnection("testing");
                setModel(null);
                setSaved(false);
                connectionTimer.current = setTimeout(
                  () => setConnection(response as Connection),
                  700,
                );
              }}
            >
              <Plug aria-hidden="true" />
              Test connection
            </Button>
            <span className="flex min-w-0 items-center gap-2">
              <span
                aria-hidden="true"
                className={`size-1.5 shrink-0 rounded-full transition-[background-color,box-shadow] duration-500 ${
                  TONE_DOT[
                    connection === "ready"
                      ? "on"
                      : connection === "testing"
                        ? "busy"
                        : connection === "empty" || connection === "failed"
                          ? "warn"
                          : "off"
                  ]
                }`}
              />
              <Live>
                {connection === "testing"
                  ? "Testing connection and finding models…"
                  : connection === "ready"
                    ? "Connected. Two models found."
                    : connection === "empty"
                      ? "Connected. No models found. Install a model on this server, then test again."
                      : connection === "failed"
                        ? "Connection refused. Check the address and retry."
                        : "Not tested."}
              </Live>
            </span>
          </div>
          <AnimatePresence initial={false}>
            {connection === "ready" && (
              <motion.div {...reveal} className="overflow-hidden sm:col-span-2">
                <Field className="pb-1">
                  <FieldLabel>Discovered model</FieldLabel>
                  <Select
                    value={model}
                    onValueChange={(value) => {
                      setModel(value);
                      setSaved(false);
                    }}
                    items={[
                      { value: "gemma", label: "Gemma · text and vision" },
                      { value: "qwen", label: "Qwen · text" },
                    ]}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a model" />
                    </SelectTrigger>
                    <SelectPopup>
                      <SelectItem value="gemma">
                        Gemma · text and vision
                      </SelectItem>
                      <SelectItem value="qwen">Qwen · text</SelectItem>
                    </SelectPopup>
                  </Select>
                </Field>
              </motion.div>
            )}
          </AnimatePresence>
          <div className="flex flex-wrap items-center gap-4 border-t border-border/50 pt-6 sm:col-span-2">
            <Button
              disabled={connection !== "ready" || !model || saved}
              onClick={() => {
                if (key) {
                  setHasKey(true);
                  setKey("");
                }
                setSaved(true);
              }}
            >
              Save connection
            </Button>
            <AnimatePresence initial={false}>
              {saved && (
                <motion.p
                  role="status"
                  initial={{ opacity: 0, x: -6, filter: "blur(4px)" }}
                  animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                  exit={{ opacity: 0, x: -6, filter: "blur(4px)" }}
                  transition={{ duration: 0.35, ease }}
                  className="text-[12px] text-muted-foreground"
                >
                  Connection saved to this preview.
                </motion.p>
              )}
            </AnimatePresence>
          </div>
        </section>
      </Stage>

      <Stage
        index={4}
        kicker="Models"
        title="Downloads you can plan, pause and trust"
        description="Choose what to fetch and the total follows. Progress eases rather than jumps, cancelling keeps your plan, and installed assets are never touched."
        sources={["Coss", "Animate UI", "Motion Primitives"]}
      >
        <section aria-labelledby="setup-heading" className="space-y-6">
          <h3 id="setup-heading" className={eyebrow}>
            Model setup
          </h3>
          <div
            aria-busy={busy || undefined}
            className="divide-y divide-border/50"
          >
            <label className={modelRow}>
              <Checkbox size="sm" checked disabled />
              Speech model
              <Badge variant="outline" className="font-normal">
                Installed
              </Badge>
            </label>
            {plans.map((plan) => (
              <label key={plan.id} className={modelRow}>
                <Checkbox
                  size="sm"
                  checked={selected.includes(plan.id)}
                  disabled={busy}
                  onCheckedChange={(checked) =>
                    setSelected((current) =>
                      checked
                        ? [...current, plan.id]
                        : current.filter((id) => id !== plan.id),
                    )
                  }
                />
                {plan.label}
                <span className="ml-auto font-mono text-[11px] tabular-nums text-muted-foreground">
                  {plan.size.toFixed(1)} GB
                </span>
              </label>
            ))}
            <label className={`${modelRow} opacity-50`}>
              <Checkbox size="sm" disabled />
              Video runtime
              <Badge variant="outline" className="font-normal">
                Unavailable
              </Badge>
            </label>
          </div>
          <Collapsible>
            <CollapsibleTrigger
              render={
                <Button
                  size="sm"
                  variant="ghost"
                  className="-ml-2 text-muted-foreground"
                />
              }
            >
              Included files
              <ChevronDown aria-hidden="true" />
            </CollapsibleTrigger>
            <CollapsiblePanel>
              <ul className="space-y-1.5 py-2 text-[12px] text-muted-foreground">
                <li>Tokenizer · included</li>
                <li>Model configuration · included</li>
                <li>Speech assets · installed</li>
              </ul>
            </CollapsiblePanel>
          </Collapsible>
          <div className="space-y-4 border-t border-border/50 pt-6">
            <AnimatePresence mode="popLayout" initial={false}>
              <motion.p
                key={`${selected.length}-${total}`}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -4 }}
                transition={{ duration: 0.25, ease }}
                className="text-[13px]"
              >
                {selected.length}{" "}
                {selected.length === 1 ? "download" : "downloads"} ·{" "}
                {total.toFixed(1)} GB
              </motion.p>
            </AnimatePresence>
            <AnimatePresence initial={false}>
              {(busy || download === "complete") && (
                <motion.div {...reveal} className="overflow-hidden">
                  <div className="flex items-center gap-4 py-1">
                    <Progress
                      aria-label="Model setup progress"
                      value={download === "preparing" ? null : progress}
                      className="flex-1"
                    />
                    <span className="w-10 text-right font-mono text-[11px] tabular-nums text-muted-foreground">
                      <AnimatedNumber value={progress} />%
                    </span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            <Live>
              {download === "preparing"
                ? "Preparing required files…"
                : download === "running"
                  ? "Downloading selected models…"
                  : download === "complete"
                    ? "Selected models are ready."
                    : download === "cancelled"
                      ? "Download cancelled. Your plan is unchanged."
                      : "Ready to download."}
            </Live>
            <div className="flex flex-wrap gap-3">
              <Button
                disabled={!selected.length || busy}
                loading={download === "preparing"}
                aria-label={
                  download === "cancelled" ? "Retry setup" : "Start setup"
                }
                onClick={() => {
                  setProgress(0);
                  setDownload("preparing");
                  prepareTimer.current = setTimeout(
                    () => setDownload("running"),
                    600,
                  );
                }}
              >
                {download === "cancelled" ? "Retry setup" : "Start setup"}
              </Button>
              <AnimatePresence mode="popLayout" initial={false}>
                {busy && (
                  <motion.span key="cancel" {...fadeScale}>
                    <Button
                      variant="ghost"
                      onClick={() => {
                        if (prepareTimer.current)
                          clearTimeout(prepareTimer.current);
                        setDownload("cancelled");
                      }}
                    >
                      Cancel setup
                    </Button>
                  </motion.span>
                )}
              </AnimatePresence>
            </div>
          </div>
        </section>
      </Stage>
    </div>
  );
}

const fadeScale = {
  initial: { opacity: 0, scale: 0.96, filter: "blur(3px)" },
  animate: { opacity: 1, scale: 1, filter: "blur(0px)" },
  exit: { opacity: 0, scale: 0.96, filter: "blur(3px)" },
  transition: { duration: 0.28, ease },
};
