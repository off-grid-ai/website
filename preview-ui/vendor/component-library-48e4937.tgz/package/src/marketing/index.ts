/**
 * The catalogue has not yet passed the production curation gate for marketing use.
 * This explicit surface stays empty so preview components cannot be imported by accident.
 */
export {};
