import { useState, useMemo } from 'react';
import { Search, Filter, Box, Layers, Zap } from 'lucide-react';
import { components } from '../data/components';
import { ComponentGrid } from '../components/ComponentGrid';
import { TextGenerateEffect } from '../components/aceternity/TextGenerateEffect';
import { motion } from 'framer-motion';

export const ComponentLibrary = () => {
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedCategory, setSelectedCategory] = useState<string>('All');
    const [selectedLibrary, setSelectedLibrary] = useState<string>('All');

    const categories = useMemo(() => {
        const cats = new Set(components.map(c => c.category || 'Uncategorized'));
        return ['All', ...Array.from(cats)].sort();
    }, []);

    const libraries = useMemo(() => {
        const libs = new Set(components.map(c => c.library));
        return ['All', ...Array.from(libs)].sort();
    }, []);

    const filteredComponents = useMemo(() => {
        return components.filter(component => {
            const matchesSearch = component.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                component.description.toLowerCase().includes(searchQuery.toLowerCase());
            const matchesCategory = selectedCategory === 'All' || component.category === selectedCategory;
            const matchesLibrary = selectedLibrary === 'All' || component.library === selectedLibrary;

            return matchesSearch && matchesCategory && matchesLibrary;
        });
    }, [searchQuery, selectedCategory, selectedLibrary]);

    return (
        <div className="min-h-screen bg-surface-secondary text-text-primary overflow-x-hidden selection:bg-green-400/30 selection:text-green-900">

            {/* Ambient Background Animations */}
            <div className="fixed inset-0 pointer-events-none overflow-hidden">
                <div className="absolute top-[-20%] right-[-10%] w-[50vw] h-[50vw] bg-green-400/5 rounded-full blur-[120px] animate-[pulse_8s_infinite]" />
                <div className="absolute bottom-[-20%] left-[-10%] w-[50vw] h-[50vw] bg-teal-400/5 rounded-full blur-[120px] animate-[float_10s_infinite_reverse]" />
            </div>

            <div className="relative z-10 max-w-7xl mx-auto px-6 py-24 md:py-32">

                {/* Header */}
                <header className="mb-24 flex flex-col items-center text-center">
                    <motion.div
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="inline-flex items-center gap-2 mb-8 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-sm text-sm font-medium text-neutral-600"
                    >
                        <Box className="w-4 h-4 text-green-600" />
                        <span>The Ultimate Collection</span>
                    </motion.div>

                    <h1 className="text-6xl md:text-8xl mb-8 tracking-tight text-neutral-900 font-serif">
                        <TextGenerateEffect words="Scroll is the story." />
                    </h1>

                    <motion.p
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.8 }}
                        className="text-xl md:text-2xl text-neutral-500 max-w-2xl mx-auto leading-relaxed font-sans"
                    >
                        A curated index of <span className="text-neutral-900 font-medium">{components.length}+</span> premium components from the best libraries in the React ecosystem.
                    </motion.p>
                </header>

                {/* Controls */}
                <div className="sticky top-6 z-50 mb-12">
                    <div className="p-4 rounded-[20px] bg-white/80 backdrop-blur-xl border border-white/40 shadow-[0_8px_32px_rgba(0,0,0,0.04)] ring-1 ring-black/5">
                        <div className="flex flex-col md:flex-row gap-4">
                            {/* Search */}
                            <div className="relative flex-1 group">
                                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400 group-focus-within:text-green-600 transition-colors" />
                                <input
                                    type="text"
                                    placeholder="Search components..."
                                    value={searchQuery}
                                    onChange={(e) => setSearchQuery(e.target.value)}
                                    className="w-full pl-11 pr-4 py-3 rounded-[12px] bg-surface-tertiary border-transparent text-neutral-900 placeholder-neutral-500 focus:outline-none focus:bg-white focus:ring-2 focus:ring-green-500/20 transition-all font-sans"
                                />
                            </div>

                            {/* Filters */}
                            <div className="flex gap-4 overflow-x-auto pb-2 md:pb-0 scrollbar-hide">
                                <div className="relative min-w-[200px] group">
                                    <Layers className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 group-hover:text-green-600 transition-colors" />
                                    <select
                                        value={selectedCategory}
                                        onChange={(e) => setSelectedCategory(e.target.value)}
                                        className="w-full pl-11 pr-10 py-3 rounded-[12px] bg-surface-tertiary border-transparent text-neutral-900 appearance-none cursor-pointer hover:bg-white focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-500/20 transition-all font-sans"
                                    >
                                        <option value="All">All Categories</option>
                                        {categories.filter(c => c !== 'All').map(category => (
                                            <option key={category} value={category}>{category}</option>
                                        ))}
                                    </select>
                                    <Filter className="absolute right-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400 pointer-events-none" />
                                </div>

                                <div className="relative min-w-[200px] group">
                                    <Zap className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400 group-hover:text-green-600 transition-colors" />
                                    <select
                                        value={selectedLibrary}
                                        onChange={(e) => setSelectedLibrary(e.target.value)}
                                        className="w-full pl-11 pr-10 py-3 rounded-[12px] bg-surface-tertiary border-transparent text-neutral-900 appearance-none cursor-pointer hover:bg-white focus:bg-white focus:outline-none focus:ring-2 focus:ring-green-500/20 transition-all font-sans"
                                    >
                                        <option value="All">All Libraries</option>
                                        {libraries.filter(l => l !== 'All').map(lib => (
                                            <option key={lib} value={lib}>{lib}</option>
                                        ))}
                                    </select>
                                    <Filter className="absolute right-4 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-neutral-400 pointer-events-none" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Content */}
                <div className="min-h-[80vh]">
                    <ComponentGrid components={filteredComponents} />
                </div>

            </div>
        </div>
    );
};
