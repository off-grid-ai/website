// Which tab a key press in a tab list moves to: the WAI-ARIA tabs pattern. Pure.
//
// Left and Right step through the tabs and wrap at either end. Home and End jump to the first
// and last tab. Any other key leaves the selection alone, so Tab still leaves the list.
//
// Drop-in for the Off Grid browser extension's `src/sidepanel/tab-keys.ts`.

export function nextTabIndex(
  key: string,
  current: number,
  count: number,
): number | null {
  if (count <= 0) {
    return null;
  }
  switch (key) {
    case "ArrowRight":
      return (current + 1) % count;
    case "ArrowLeft":
      return (current - 1 + count) % count;
    case "Home":
      return 0;
    case "End":
      return count - 1;
    default:
      return null;
  }
}
