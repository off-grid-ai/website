// A section that is open while its work is live and folds away once it settles, as the
// desktop shows thinking and tool rows. The user can open or close it either way.
//
// Drop-in for the Off Grid browser extension's `src/sidepanel/LiveDisclosure.tsx`. Premium
// layer: the caret turns on a spring and the body rises in.

import { useEffect, useState, type ReactNode } from "react";
import { CaretDown } from "@phosphor-icons/react";

export function LiveDisclosure(props: {
  readonly live: boolean;
  /** The trigger's content: an icon, the label, a live indicator. */
  readonly summary: ReactNode;
  readonly children: ReactNode;
  readonly testId?: string;
}) {
  const [open, setOpen] = useState(props.live);
  useEffect(() => {
    setOpen(props.live);
  }, [props.live]);
  return (
    <div className="w-full">
      <button
        type="button"
        aria-expanded={open}
        data-testid={props.testId}
        onClick={() => setOpen((v) => !v)}
        className="group inline-flex items-center gap-1.5 rounded-sm text-[11px] text-text-muted transition-colors hover:text-text-secondary"
      >
        {props.summary}
        <CaretDown
          size={12}
          className={`transition-[rotate,translate] duration-[460ms] ease-[var(--og-ease-spring,cubic-bezier(0.34,1.56,0.64,1))] group-hover:translate-y-px ${
            open ? "rotate-180" : ""
          }`}
          aria-hidden="true"
        />
      </button>
      {open && <div className="og-rise mt-1">{props.children}</div>}
    </div>
  );
}
