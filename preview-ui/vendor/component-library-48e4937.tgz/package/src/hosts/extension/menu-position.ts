// Where the extension Menu sits once it is portalled out of the panel: fixed offsets against
// the element it used to be absolutely positioned in. Pure, so it is tested without a layout.

import type { CSSProperties } from "react";

/** Where the menu opens against its anchor. */
export type MenuPlacement = "above" | "below" | "up" | "belowEnd" | "upEnd";

/** The anchor's box in viewport coordinates (a DOMRect fits). */
export interface MenuAnchorRect {
  readonly top: number;
  readonly left: number;
  readonly right: number;
  readonly bottom: number;
}

const GAP = 4;
/** `above` sits in from the composer's left edge, as `left-3` did. */
const ABOVE_INSET = 12;

/**
 * Fixed-position offsets for the menu against its anchor, for each placement: the same spots
 * the old `bottom-full left-3 mb-1` style classes gave inside the anchor.
 */
export function menuPosition(
  placement: MenuPlacement,
  anchor: MenuAnchorRect,
  viewport: { readonly width: number; readonly height: number },
): CSSProperties {
  const opensUp =
    placement === "above" || placement === "up" || placement === "upEnd";
  const vertical = opensUp
    ? { bottom: viewport.height - anchor.top + GAP }
    : { top: anchor.bottom + GAP };
  if (placement === "belowEnd" || placement === "upEnd") {
    return { ...vertical, right: viewport.width - anchor.right };
  }
  return {
    ...vertical,
    left: anchor.left + (placement === "above" ? ABOVE_INSET : 0),
  };
}
