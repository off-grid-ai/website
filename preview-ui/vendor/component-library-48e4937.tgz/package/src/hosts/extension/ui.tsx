// Small shared controls for the panel's secondary screens (Models, Settings, Vault).
//
// Drop-in for the Off Grid browser extension's `src/sidepanel/ui.tsx`: same exports, props,
// roles and labels. The one difference at the seam: `Screen` takes the panel's navigation as
// `nav`, because PanelNav reads extension state; the extension's ui.tsx shim passes it.
//
// Premium layer, inside the panel's density rules: screens push in from the right, the header
// rests on a hairline that fades at the edges, switches travel on a spring and stretch under
// the finger, selects glow on focus, and the spinner is a quiet two-tone ring.

import type { CSSProperties, ReactNode } from "react";
import { ArrowLeft, CaretDown } from "@phosphor-icons/react";
import { EASE } from "./motion.js";

export { PillTabs, TabPanel } from "./PillTabs.js";

export function Screen(props: {
  readonly title: string;
  readonly onBack: () => void;
  readonly children: ReactNode;
  readonly actions?: ReactNode;
  /** The host's panel navigation, after `actions` (the extension passes its PanelNav). */
  readonly nav?: ReactNode;
  /** Blur what shows through the screen's glass (the living field, the chat). Default on. */
  readonly blur?: boolean;
}) {
  // The screen is glass, not a wall: its veil is a pseudo-element at 0.82 of the background,
  // so the living field reads through at rest. The veil, not the section, carries the
  // backdrop blur, so the section never becomes the containing block of a fixed descendant.
  // The skin's push animation slides the section and holds the veil opaque until it lands.
  return (
    <section
      aria-label={props.title}
      data-slot="extension-screen"
      className={`og-screen-in absolute inset-0 z-10 flex flex-col before:pointer-events-none before:absolute before:inset-0 before:-z-10 before:bg-background/82 before:content-[''] ${
        props.blur === false ? "" : "before:backdrop-blur-lg"
      }`}
    >
      <header className="relative flex items-center gap-2 border-b border-border px-2 py-2 after:pointer-events-none after:absolute after:inset-x-0 after:-bottom-px after:h-px after:bg-linear-to-r after:from-border/40 after:via-border-light after:to-border/40">
        <button
          type="button"
          onClick={props.onBack}
          className="group flex items-center gap-1.5 rounded-md px-1.5 py-1 text-[12px] text-text-muted hover:text-primary"
        >
          <ArrowLeft
            size={14}
            className="transition-[translate] duration-[420ms] ease-[var(--og-ease-spring,cubic-bezier(0.34,1.56,0.64,1))] group-hover:-translate-x-0.5"
          />{" "}
          Back
        </button>
        <h1 className="flex-1 truncate text-h3 text-text">{props.title}</h1>
        {props.actions}
        {props.nav}
      </header>
      <div className="flex-1 overflow-y-auto overscroll-contain">
        {props.children}
      </div>
    </section>
  );
}

export function SectionLabel({ children }: { readonly children: ReactNode }) {
  return (
    <h2 className="px-1 pb-1.5 pt-3 text-label uppercase tracking-wider text-text-muted">
      {children}
    </h2>
  );
}

export function Row(props: {
  readonly label: string;
  readonly hint?: string;
  /** Trailing control: one icon action, a switch, a select. */
  readonly children?: ReactNode;
  /** Small facts (size, time, count) inline after the label. */
  readonly meta?: ReactNode;
  /** Badges inline after the label. */
  readonly badges?: ReactNode;
  /**
   * `default` is 44px with the hint under the label. `compact` is 36px with
   * the hint inline after the label as muted text.
   */
  readonly density?: "default" | "compact";
}) {
  const compact = props.density === "compact";
  const hint = props.hint && (
    <div
      data-slot="row-hint"
      className={`text-meta text-text-muted ${compact ? "min-w-0 flex-1 truncate" : "truncate"}`}
    >
      {props.hint}
    </div>
  );
  return (
    <div
      data-slot="extension-row"
      data-density={compact ? "compact" : "default"}
      className={`flex items-center justify-between gap-3 border-b border-border ${
        compact ? "min-h-9 py-1" : "min-h-11 py-1.5"
      }`}
    >
      <div
        className={`min-w-0 flex-1 ${compact ? "flex items-center gap-2" : ""}`}
      >
        <div
          className={`flex min-w-0 items-center gap-2 ${compact ? "shrink" : ""}`}
        >
          <span className="min-w-0 truncate text-h3 text-text-secondary">
            {props.label}
          </span>
          {props.badges && (
            <span
              data-slot="row-badges"
              className="flex shrink-0 items-center gap-1"
            >
              {props.badges}
            </span>
          )}
          {props.meta && (
            <span
              data-slot="row-meta"
              className="shrink-0 font-mono text-meta tabular-nums text-text-muted"
            >
              {props.meta}
            </span>
          )}
        </div>
        {hint}
      </div>
      {props.children !== undefined && props.children !== null && (
        <div className="flex shrink-0 items-center gap-1">{props.children}</div>
      )}
    </div>
  );
}

const THUMB_SPRING =
  "transition-[translate,width,background-color,box-shadow] duration-[460ms] ease-[var(--og-ease-spring,cubic-bezier(0.34,1.56,0.64,1))]";

export function Toggle(props: {
  readonly label: string;
  readonly checked: boolean;
  readonly onChange: (value: boolean) => void;
  readonly disabled?: boolean;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-label={props.label}
      aria-checked={props.checked}
      disabled={props.disabled}
      onClick={() => props.onChange(!props.checked)}
      className={`group relative h-5 w-9 rounded-full border disabled:opacity-40 ${
        props.checked
          ? "border-primary bg-primary/20"
          : "border-border-light bg-surface-light enabled:hover:border-text-disabled"
      }`}
    >
      <span
        className={`absolute left-0.5 top-0.5 h-3.5 w-3.5 rounded-full ${THUMB_SPRING} group-active:w-[18px] ${
          props.checked
            ? "translate-x-4 bg-primary shadow-[0_0_10px_rgb(var(--og-rgb-primary)/0.55)] group-active:translate-x-3"
            : "translate-x-0 bg-text-muted"
        }`}
      />
    </button>
  );
}

export function Slider(props: {
  readonly label: string;
  readonly value: number;
  readonly min: number;
  readonly max: number;
  readonly step: number;
  readonly onChange: (value: number) => void;
  readonly hint?: string;
}) {
  return (
    <div className="border-b border-border py-2.5">
      <div className="mb-1.5 flex items-baseline justify-between">
        <span className="text-h3 text-text-secondary">{props.label}</span>
        <span className="text-meta tabular-nums text-text-muted">
          {props.value}
          {props.hint ? ` · ${props.hint}` : ""}
        </span>
      </div>
      <input
        type="range"
        aria-label={props.label}
        min={props.min}
        max={props.max}
        step={props.step}
        value={props.value}
        onChange={(e) => props.onChange(Number(e.target.value))}
        className="w-full cursor-pointer accent-primary"
      />
    </div>
  );
}

// Inline for the same reason as IconButton: theme.css limits `select` transitions to colours,
// outside any layer, so the focus glow would snap rather than ease.
const FIELD_MOTION: CSSProperties = {
  transition: `color 200ms ${EASE}, background-color 200ms ${EASE}, border-color 240ms ${EASE}, box-shadow 420ms ${EASE}`,
};

export function Select<T extends string | number>(props: {
  readonly label: string;
  readonly value: T;
  readonly options: readonly {
    readonly value: T;
    readonly label: string;
    readonly disabled?: boolean;
    readonly reason?: string;
  }[];
  readonly onChange: (value: T) => void;
}) {
  return (
    <span className="relative inline-flex max-w-[180px]">
      <select
        aria-label={props.label}
        disabled={
          props.options.length === 0 || props.options.every((o) => o.disabled)
        }
        title={props.options.find((o) => o.value === props.value)?.reason}
        value={String(props.value)}
        onChange={(e) => {
          const picked = props.options.find(
            (o) => String(o.value) === e.target.value,
          );
          if (picked) {
            props.onChange(picked.value);
          }
        }}
        style={FIELD_MOTION}
        className="peer min-w-0 w-full cursor-pointer appearance-none rounded-md border border-border-light bg-background pl-2 pr-7 py-1 text-meta text-text-secondary enabled:hover:border-text-disabled focus:border-primary focus:shadow-[0_0_0_3px_rgb(var(--og-rgb-primary)/0.1),0_0_20px_-8px_rgb(var(--og-rgb-primary)/0.5)] focus:outline-none disabled:cursor-default disabled:opacity-60"
      >
        {props.options.map((o) => (
          <option
            key={String(o.value)}
            value={String(o.value)}
            disabled={o.disabled}
            title={o.reason}
          >
            {o.reason ? `${o.label} · ${o.reason}` : o.label}
          </option>
        ))}
      </select>
      <CaretDown
        aria-hidden
        className="pointer-events-none absolute right-2 top-1/2 h-3 w-3 -translate-y-1/2 text-text-secondary transition-colors duration-200 peer-focus:text-primary"
      />
    </span>
  );
}

export function Spinner() {
  return (
    <span
      aria-hidden
      className="inline-block h-3 w-3 animate-spin rounded-full border border-text-muted/30 border-t-text-secondary [animation-duration:0.8s]"
    />
  );
}
