// The panel's one dropdown menu: the composer's "+" menu and each message's "..." menu.
// A full-screen invisible button behind it closes it on any outside click.
//
// The menu and that button render in a layer portalled to document.body. A `position: fixed`
// layer inside the panel is fixed to the nearest ancestor with a filter, transform or
// backdrop-filter instead of the viewport, so an entrance animation or a glass screen above
// the composer shrank the click-to-close area to that ancestor. From body the layer always
// covers the viewport; the menu is placed against its anchor (its old containing block),
// measured before paint.
//
// Drop-in for the Off Grid browser extension's `src/sidepanel/Menu.tsx`: same exports, props,
// roles and behaviour. Premium layer: the menu opens from the corner it is anchored to
// (alive-semantic.css draws the entrance for `[role=menu]`), its items arrive in a short
// stagger, and it floats on a soft shadow instead of sitting flat.

import {
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
import { createPortal } from "react-dom";
import { menuPosition, type MenuPlacement } from "./menu-position.js";

export interface MenuItem {
  readonly label: string;
  readonly icon: ReactNode;
  readonly onSelect: () => void;
  readonly checked?: boolean;
  /** Shown under the label; with `unavailable`, says what to install or change. */
  readonly hint?: string;
  /** Offered but not usable yet: selecting it runs onSelect (e.g. open Models) instead. */
  readonly unavailable?: boolean;
  readonly disabled?: boolean;
}

const PLACEMENT = {
  /** Above the composer, from its left edge. */
  above: "min-w-[200px] origin-bottom-left",
  /** Under a message's "..." button, from its left edge. */
  below: "min-w-[160px] origin-top-left",
  /** Over it, when there is no room below (the last message). */
  up: "min-w-[160px] origin-bottom-left",
  /** From its right edge, for the user's own right-aligned messages. */
  belowEnd: "min-w-[160px] origin-top-right",
  upEnd: "min-w-[160px] origin-bottom-right",
} as const satisfies Record<MenuPlacement, string>;

export type { MenuPlacement } from "./menu-position.js";

interface Layer {
  readonly position: CSSProperties;
  readonly alive: boolean;
}

/** Measures the element the menu used to be absolutely positioned in. */
function measure(marker: HTMLElement, placement: MenuPlacement): Layer {
  const anchor =
    (marker.offsetParent as HTMLElement | null) ??
    marker.parentElement ??
    marker;
  const root = marker.ownerDocument.documentElement;
  return {
    position: menuPosition(placement, anchor.getBoundingClientRect(), {
      width: root.clientWidth || window.innerWidth,
      height: root.clientHeight || window.innerHeight,
    }),
    alive: marker.closest("[data-og-alive]") !== null,
  };
}

// Items sit in <li> wrappers, which alive-semantic's direct-child item rule does not reach,
// so the stagger is applied here with its keyframe (a no-op where that stylesheet is absent).
const ITEM_IN =
  "animate-[og-alive-semantic-item_420ms_cubic-bezier(0.16,1,0.3,1)_backwards]";

export function Menu(props: {
  readonly items: readonly MenuItem[];
  readonly onClose: () => void;
  readonly placement: MenuPlacement;
  readonly label?: string;
}) {
  const marker = useRef<HTMLSpanElement>(null);
  const [layer, setLayer] = useState<Layer | null>(null);
  const { placement } = props;

  useLayoutEffect(() => {
    const element = marker.current;
    if (!element) {
      return;
    }
    const place = () => setLayer(measure(element, placement));
    place();
    window.addEventListener("resize", place);
    return () => window.removeEventListener("resize", place);
  }, [placement]);

  return (
    <>
      <span ref={marker} aria-hidden="true" className="absolute size-0" />
      {layer &&
        createPortal(
          <div
            data-slot="extension-menu-layer"
            data-og-alive={layer.alive ? "" : undefined}
            className="fixed inset-0 z-50"
          >
            <button
              type="button"
              aria-label="Close menu"
              tabIndex={-1}
              className="absolute inset-0 cursor-default"
              onClick={props.onClose}
            />
            <MenuList {...props} position={layer.position} />
          </div>,
          document.body,
        )}
    </>
  );
}

function MenuList(props: {
  readonly items: readonly MenuItem[];
  readonly onClose: () => void;
  readonly placement: MenuPlacement;
  readonly label?: string;
  readonly position: CSSProperties;
}) {
  return (
    <ul
      role="menu"
      aria-label={props.label}
      style={props.position}
      className={`fixed rounded-md border border-border-light bg-surface p-1 shadow-[0_18px_40px_-18px_rgb(0_0_0/0.75),0_0_0_1px_rgb(var(--og-rgb-text)/0.02)] ${PLACEMENT[props.placement]}`}
    >
      {props.items.map((item, index) => (
        <li
          key={item.label}
          className={ITEM_IN}
          style={{ animationDelay: `${Math.min(index, 5) * 25}ms` }}
        >
          <button
            type="button"
            role={
              item.checked === undefined || item.unavailable
                ? "menuitem"
                : "menuitemcheckbox"
            }
            aria-checked={item.unavailable ? undefined : item.checked}
            disabled={item.disabled}
            onClick={() => {
              item.onSelect();
              props.onClose();
            }}
            className="group flex w-full items-center gap-2.5 rounded-md px-2.5 py-2 text-left text-h3 text-text-secondary hover:bg-surface-light hover:text-text focus-visible:bg-surface-light disabled:opacity-40"
          >
            <span
              className={`transition-colors duration-200 ${
                item.unavailable
                  ? "text-text-disabled"
                  : "text-text-muted group-hover:text-text-secondary"
              }`}
            >
              {item.icon}
            </span>
            <span className="flex flex-1 flex-col">
              <span className={item.unavailable ? "text-text-muted" : ""}>
                {item.label}
              </span>
              {item.hint && (
                <span className="text-meta text-text-muted">{item.hint}</span>
              )}
            </span>
            {item.checked && (
              <span className="text-primary [text-shadow:0_0_12px_rgb(var(--og-rgb-primary)/0.55)]">
                On
              </span>
            )}
          </button>
        </li>
      ))}
    </ul>
  );
}
