// A notice with an optional action, sliding in above the composer. Replaces bare status text:
// when something needs the user, the fix is a button right there, not an instruction.
//
// Drop-in for the Off Grid browser extension's `src/sidepanel/Banner.tsx`: same exports, types
// and props. Premium layer: the notice rises in (`og-rise`), short notices settle with one
// flash (the alive conductor marks `role=status`), and the one action glows as the primary.

import type { ReactNode } from "react";
import { Info, X } from "@phosphor-icons/react";

/** What a producer reports: text, or a failure the user can fix by granting site access. */
export type NoticeInput =
  | string
  | {
      readonly text: string;
      readonly needsAccess: true;
      readonly retry: () => void;
    }
  | null;

export type NoticeSink = (notice: NoticeInput) => void;

export interface Notice {
  readonly text: string;
  readonly tone?: "info" | "action";
  /** A one-click fix, e.g. granting site access, which then retries what failed. */
  readonly action?: { readonly label: string; readonly run: () => void };
}

export function Banner(props: {
  notice: Notice;
  onDismiss?: () => void;
  icon?: ReactNode;
  plain?: boolean;
}) {
  const { notice } = props;
  return (
    <div
      role="status"
      className={
        props.plain
          ? "mx-2.5 mb-1.5 flex items-center gap-2 px-3 py-2"
          : `og-rise mx-2.5 mb-1.5 flex items-start gap-2 rounded-md border px-3 py-2 ${
              notice.action
                ? "border-primary/40 bg-primary/[0.06] shadow-[0_0_24px_-12px_rgb(var(--og-rgb-primary)/0.6)]"
                : "border-border-light bg-surface"
            }`
      }
    >
      {!props.plain && (
        <span
          className={`mt-0.5 ${notice.action ? "text-primary" : "text-text-muted"}`}
        >
          {props.icon ?? <Info size={14} />}
        </span>
      )}
      <div className="flex min-w-0 flex-1 flex-col gap-2">
        <p className="text-meta leading-relaxed text-text-secondary">
          {notice.text}
        </p>
        {notice.action && (
          <button
            type="button"
            onClick={notice.action.run}
            className="og-press w-fit rounded-md bg-primary px-3 py-1.5 text-[12px] font-medium text-background shadow-[0_0_18px_-6px_rgb(var(--og-rgb-primary)/0.8)] hover:bg-primary-light"
          >
            {notice.action.label}
          </button>
        )}
      </div>
      {props.onDismiss && (
        <button
          type="button"
          aria-label="Dismiss"
          onClick={props.onDismiss}
          className="og-press rounded-full p-0.5 text-text-muted hover:bg-surface-light hover:text-text-secondary"
        >
          <X size={12} />
        </button>
      )}
    </div>
  );
}
