// The one icon-only button. Every icon control in the panel uses it, so hit area, focus ring
// and the accessible name are decided once.
//
// Drop-in for the Off Grid browser extension's `src/sidepanel/IconButton.tsx`. Premium layer:
// the press gives and springs back, keyboard focus glows, the active state carries a faint
// accent hairline, and the icon leans in on hover.

import type { CSSProperties, ReactNode } from "react";
import { EASE, SPRING } from "./motion.js";

export interface IconButtonProps {
  /** Accessible name and tooltip. Required: an icon alone is not a label. */
  readonly label: string;
  readonly onClick: () => void;
  readonly children: ReactNode;
  readonly disabled?: boolean;
  readonly active?: boolean;
  readonly variant?: "ghost" | "solid";
}

// Inline, because the extension's theme.css sets `transition-property` on every button
// outside any layer, which a utility class cannot beat. Its reduced-motion rule is
// `!important`, so it still wins over this.
const MOTION: CSSProperties = {
  transition: `color 200ms ${EASE}, background-color 200ms ${EASE}, opacity 200ms ${EASE}, box-shadow 320ms ${EASE}, scale 380ms ${SPRING}`,
};

export function IconButton(props: IconButtonProps) {
  const tone =
    props.variant === "solid"
      ? "bg-text text-background hover:bg-text-secondary hover:shadow-[0_0_18px_-6px_rgb(var(--og-rgb-text)/0.55)] disabled:bg-surface-hover disabled:text-text-disabled disabled:shadow-none"
      : props.active
        ? "text-primary bg-surface-light shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-primary)/0.18)]"
        : "text-text-muted hover:bg-surface-light hover:text-text disabled:text-text-disabled disabled:hover:bg-transparent";
  return (
    <button
      type="button"
      aria-label={props.label}
      title={props.label}
      aria-pressed={props.active}
      onClick={props.onClick}
      disabled={props.disabled}
      style={MOTION}
      className={`grid h-8 w-8 shrink-0 place-items-center rounded-full focus-visible:outline focus-visible:outline-1 focus-visible:outline-primary focus-visible:shadow-[0_0_0_3px_rgb(var(--og-rgb-primary)/0.14),0_0_16px_-4px_rgb(var(--og-rgb-primary)/0.6)] active:scale-[0.92] disabled:active:scale-100 [&>svg]:transition-[scale] [&>svg]:duration-[420ms] [&>svg]:ease-[var(--og-ease-spring,cubic-bezier(0.34,1.56,0.64,1))] enabled:hover:[&>svg]:scale-[1.08] ${tone}`}
    >
      {props.children}
    </button>
  );
}
