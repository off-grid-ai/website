// Tab pills and the panel they control, wired as the WAI-ARIA tabs pattern.
//
// Drop-in for the Off Grid browser extension's `src/sidepanel/PillTabs.tsx`: same exports,
// props, roles and keyboard handling. Only the selected tab sits in the Tab order (roving
// tabindex). Left and Right move between tabs and wrap, Home and End jump to the ends, and the
// tab that receives focus is selected at once (automatic activation). Each tab names the panel
// it controls, and the panel is labelled by the selected tab.
//
// Premium layer: one highlight glides between the tabs on a spring (like the library's
// Segmented control, but CSS-only so the panel bundle gains no motion runtime), and the panel's
// content rises in again when the tab changes.

import {
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type CSSProperties,
  type KeyboardEvent,
  type ReactNode,
  type RefObject,
} from "react";
import { EASE, SPRING, replayRise } from "./motion.js";
import { nextTabIndex } from "./tab-keys.js";

const tabId = (idBase: string, id: string) => `${idBase}-tab-${id}`;
const tabPanelId = (idBase: string) => `${idBase}-panel`;

// Server rendering has no layout to measure; the effect only runs in a browser.
const useIsomorphicLayoutEffect =
  typeof window === "undefined" ? useEffect : useLayoutEffect;

interface Pill {
  readonly left: number;
  readonly width: number;
}

/** Tracks the selected tab's box so the highlight can glide to it. */
function usePill(
  list: RefObject<HTMLDivElement | null>,
  tabs: RefObject<(HTMLButtonElement | null)[]>,
  current: number,
  layoutKey: string,
) {
  const [pill, setPill] = useState<Pill | null>(null);
  // The first placement snaps; only later moves glide.
  const [glide, setGlide] = useState(false);

  useIsomorphicLayoutEffect(() => {
    const measure = () => {
      const tab = current < 0 ? null : tabs.current[current];
      if (!tab || tab.offsetWidth === 0) {
        setPill(null);
        return;
      }
      setPill((prev) =>
        prev && prev.left === tab.offsetLeft && prev.width === tab.offsetWidth
          ? prev
          : { left: tab.offsetLeft, width: tab.offsetWidth },
      );
    };
    measure();
    const node = list.current;
    if (!node || typeof ResizeObserver === "undefined") {
      return undefined;
    }
    const observer = new ResizeObserver(measure);
    observer.observe(node);
    return () => observer.disconnect();
  }, [current, layoutKey, list, tabs]);

  useEffect(() => {
    if (!pill || glide || typeof requestAnimationFrame === "undefined") {
      return undefined;
    }
    const frame = requestAnimationFrame(() => setGlide(true));
    return () => cancelAnimationFrame(frame);
  }, [pill, glide]);

  return { pill, glide };
}

export function PillTabs<T extends string>(props: {
  readonly label: string;
  /** Unique on the page; ties the tabs to their TabPanel. `useId()` at the call site. */
  readonly idBase: string;
  readonly tabs: readonly { readonly id: T; readonly label: string }[];
  readonly value: T;
  readonly onChange: (id: T) => void;
}) {
  const list = useRef<HTMLDivElement | null>(null);
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  const current = props.tabs.findIndex((tab) => tab.id === props.value);
  const layoutKey = props.tabs.map((tab) => tab.label).join("\u0000");
  const { pill, glide } = usePill(list, refs, current, layoutKey);

  const onKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    const next = nextTabIndex(
      event.key,
      Math.max(current, 0),
      props.tabs.length,
    );
    const tab = next === null ? undefined : props.tabs[next];
    if (next === null || !tab) {
      return;
    }
    event.preventDefault();
    refs.current[next]?.focus();
    props.onChange(tab.id);
  };

  const pillStyle: CSSProperties | undefined = pill
    ? {
        width: pill.width,
        translate: `${pill.left}px 0`,
        transition: glide
          ? `translate 520ms ${SPRING}, width 520ms ${SPRING}, opacity 200ms ${EASE}`
          : "none",
      }
    : undefined;

  return (
    <div
      ref={list}
      role="tablist"
      aria-label={props.label}
      onKeyDown={onKeyDown}
      className="relative flex gap-0.5 overflow-x-auto rounded-full border border-border-light p-0.5"
    >
      <span
        aria-hidden="true"
        data-og-pill=""
        style={pillStyle}
        className={`pointer-events-none absolute bottom-0.5 left-0 top-0.5 rounded-full bg-surface-hover shadow-[inset_0_0_0_1px_rgb(var(--og-rgb-primary)/0.22),0_0_18px_-8px_rgb(var(--og-rgb-primary)/0.7)] ${
          pill ? "opacity-100" : "opacity-0"
        }`}
      />
      {props.tabs.map((tab, index) => {
        const selected = tab.id === props.value;
        return (
          <button
            key={tab.id}
            ref={(el) => {
              refs.current[index] = el;
            }}
            id={tabId(props.idBase, tab.id)}
            type="button"
            role="tab"
            aria-selected={selected}
            aria-controls={tabPanelId(props.idBase)}
            tabIndex={selected || (current < 0 && index === 0) ? 0 : -1}
            onClick={() => props.onChange(tab.id)}
            className={`relative shrink-0 rounded-full px-2.5 py-1 text-[12px] focus-visible:-outline-offset-2 ${
              selected
                ? `text-primary ${pill ? "" : "bg-surface-hover"}`
                : "text-text-muted hover:text-text-secondary"
            }`}
          >
            {tab.label}
          </button>
        );
      })}
    </div>
  );
}

/** The content a PillTabs list switches. One panel whose content follows the selected tab. */
export function TabPanel(props: {
  readonly idBase: string;
  readonly value: string;
  readonly className?: string;
  readonly children: ReactNode;
}) {
  const panel = useRef<HTMLDivElement | null>(null);
  const shown = useRef(props.value);

  // alive-semantic.css animates the panel when it mounts; this replays that rise when the
  // same panel switches content, without remounting (and resetting) what is inside.
  useEffect(() => {
    if (shown.current === props.value) {
      return;
    }
    shown.current = props.value;
    replayRise(panel.current);
  }, [props.value]);

  return (
    <div
      ref={panel}
      role="tabpanel"
      id={tabPanelId(props.idBase)}
      aria-labelledby={tabId(props.idBase, props.value)}
      className={props.className}
    >
      {props.children}
    </div>
  );
}
