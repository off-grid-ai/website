// Motion helpers shared by the extension side-panel components.
//
// The panel's stylesheets carry most of the motion: `alive-semantic.css` (under the panel's
// `[data-og-alive]` root) and the extension's own `ui/motion.css` (`og-rise`, `og-push`, ...).
// These helpers cover the two things CSS cannot do alone: replaying an entrance when content
// changes in place, and timing curves inline where the extension's unlayered `button`
// transition rule would otherwise win over a utility class.

/** Spring with a small overshoot (alive.css `--og-ease-spring`), with a plain fallback. */
export const SPRING =
  "var(--og-ease-spring, cubic-bezier(0.34, 1.56, 0.64, 1))";
/** Expo-out, the extension's `--og-ease`. */
export const EASE = "var(--og-ease, cubic-bezier(0.16, 1, 0.3, 1))";

export function prefersReducedMotion(): boolean {
  return (
    typeof window !== "undefined" &&
    typeof window.matchMedia === "function" &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
}

/** Replays a short rise on an element whose content just changed in place. */
export function replayRise(element: HTMLElement | null): void {
  if (
    !element ||
    typeof element.animate !== "function" ||
    prefersReducedMotion()
  ) {
    return;
  }
  element.animate(
    [
      { opacity: 0, translate: "0 5px", filter: "blur(3px)" },
      { opacity: 1, translate: "none", filter: "none" },
    ],
    { duration: 420, easing: "cubic-bezier(0.16, 1, 0.3, 1)" },
  );
}
