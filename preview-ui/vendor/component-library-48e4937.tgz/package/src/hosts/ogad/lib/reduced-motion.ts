import { useEffect, useState } from "react";

const QUERY = "(prefers-reduced-motion: reduce)";

function matches(): boolean {
  return (
    typeof window !== "undefined" &&
    typeof window.matchMedia === "function" &&
    Boolean(window.matchMedia(QUERY)?.matches)
  );
}

/**
 * Live `prefers-reduced-motion` read for the OGAD drop-ins. motion's
 * `useReducedMotion` caches the first answer for the whole page; this one reads
 * the media query on mount and follows changes, so a user toggling the OS
 * setting (or a test that swaps `matchMedia`) is honoured immediately.
 */
export function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(matches);
  useEffect(() => {
    if (typeof window.matchMedia !== "function") return undefined;
    const query = window.matchMedia(QUERY);
    if (!query) return undefined;
    const update = (): void => setReduced(Boolean(query.matches));
    update();
    query.addEventListener?.("change", update);
    return () => query.removeEventListener?.("change", update);
  }, []);
  return reduced;
}
