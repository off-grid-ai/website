import { useCallback, useState } from "react";

/**
 * Mirrors a Radix root's open state (controlled `open` or uncontrolled
 * `defaultOpen`) so the OGAD drop-ins can keep their content mounted through
 * a motion exit. The Radix root still owns the state; this only reads it.
 */
export function useOpenState({
  open,
  defaultOpen,
  onOpenChange,
}: {
  open?: boolean;
  defaultOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
}): readonly [boolean, (open: boolean) => void] {
  const [inner, setInner] = useState(defaultOpen ?? false);
  const controlled = open !== undefined;
  const set = useCallback(
    (next: boolean) => {
      if (!controlled) setInner(next);
      onOpenChange?.(next);
    },
    [controlled, onOpenChange],
  );
  return [controlled ? open : inner, set] as const;
}
