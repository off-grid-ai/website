"use client";

// Drop-in for OGAD `src/renderer/src/components/ui/animated-modal.tsx`
// (Aceternity). Same exports (ModalProvider, useModal, Modal, ModalTrigger,
// ModalBody, ModalContent, ModalFooter, useOutsideClick), props and
// behaviour: portal to body, scroll lock, focus capture/restore, Escape
// closes only the top-most modal of a stack, outside click closes.
// Visual: the theatrical 3D flip (scale 0.5, rotateX 40) becomes a short
// lift-and-settle spring; the scrim reads from host tokens (the old
// `bg-opacity-50` was a no-op under Tailwind v4, leaving it opaque); hairline
// border, quieter footer, compact close button.
import { AnimatePresence, motion } from "motion/react";
import React, {
  type ReactNode,
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { createPortal } from "react-dom";

import { cn } from "../../../sourced/coss/lib/utils.js";

interface ModalContextType {
  open: boolean;
  setOpen: (open: boolean) => void;
}

const ModalContext = createContext<ModalContextType | undefined>(undefined);
const openModalStack: symbol[] = [];

const settleSpring = {
  type: "spring",
  stiffness: 380,
  damping: 30,
  mass: 0.9,
} as const;

export const ModalProvider = ({
  children,
}: {
  children: ReactNode;
}): React.JSX.Element => {
  const [open, setOpen] = useState(false);

  return (
    <ModalContext.Provider value={{ open, setOpen }}>
      {children}
    </ModalContext.Provider>
  );
};

export const useModal = (): ModalContextType => {
  const context = useContext(ModalContext);
  if (!context) {
    throw new Error("useModal must be used within a ModalProvider");
  }
  return context;
};

export function Modal({
  children,
}: {
  children: ReactNode;
}): React.JSX.Element {
  return <ModalProvider>{children}</ModalProvider>;
}

export const ModalTrigger = ({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}): React.JSX.Element => {
  const { setOpen } = useModal();
  return (
    <button
      data-slot="modal-trigger"
      className={cn(
        "relative overflow-hidden rounded-md px-4 py-2 text-center text-foreground",
        className,
      )}
      onClick={() => setOpen(true)}
    >
      {children}
    </button>
  );
};

export const ModalBody = ({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}): React.ReactPortal => {
  const { open, setOpen } = useModal();
  const modalRef = useRef<HTMLDivElement>(null);
  const modalId = useRef(Symbol("animated-modal"));
  const previousFocus = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!open) return undefined;

    const id = modalId.current;
    const previousOverflow = document.body.style.overflow;
    previousFocus.current =
      document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;
    document.body.style.overflow = "hidden";
    openModalStack.push(id);

    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key !== "Escape" || openModalStack.at(-1) !== id) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      setOpen(false);
    };
    document.addEventListener("keydown", onKeyDown);
    modalRef.current?.focus();

    return () => {
      document.removeEventListener("keydown", onKeyDown);
      const index = openModalStack.lastIndexOf(id);
      if (index >= 0) openModalStack.splice(index, 1);
      document.body.style.overflow = previousOverflow;
      previousFocus.current?.focus();
    };
  }, [open, setOpen]);

  useOutsideClick(modalRef, () => setOpen(false));

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          data-slot="modal-backdrop"
          initial={{
            opacity: 0,
          }}
          animate={{
            opacity: 1,
            backdropFilter: "blur(10px)",
          }}
          exit={{
            opacity: 0,
            backdropFilter: "blur(0px)",
          }}
          transition={{ duration: 0.24, ease: [0.16, 1, 0.3, 1] }}
          className="fixed inset-0 z-50 flex h-full w-full items-center justify-center [perspective:1200px] [transform-style:preserve-3d]"
        >
          <Overlay />

          <motion.div
            ref={modalRef}
            role="dialog"
            aria-modal="true"
            tabIndex={-1}
            data-slot="modal-body"
            className={cn(
              "relative z-50 flex max-h-[90%] min-h-[50%] flex-1 flex-col overflow-hidden border border-border/70 bg-background shadow-[0_30px_80px_-20px_rgb(0_0_0/0.6)] outline-none md:max-w-[40%] md:rounded-xl",
              className,
            )}
            initial={{
              opacity: 0,
              scale: 0.96,
              rotateX: 6,
              y: 14,
              filter: "blur(6px)",
            }}
            animate={{
              opacity: 1,
              scale: 1,
              rotateX: 0,
              y: 0,
              filter: "blur(0px)",
            }}
            exit={{
              opacity: 0,
              scale: 0.97,
              rotateX: 3,
              filter: "blur(4px)",
              transition: { duration: 0.16, ease: [0.4, 0, 1, 1] },
            }}
            transition={settleSpring}
          >
            <CloseIcon />
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
};

export const ModalContent = ({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}): React.JSX.Element => {
  return (
    <div
      data-slot="modal-content"
      className={cn("flex flex-1 flex-col p-6 md:p-8", className)}
    >
      {children}
    </div>
  );
};

export const ModalFooter = ({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}): React.JSX.Element => {
  return (
    <div
      data-slot="modal-footer"
      className={cn(
        "flex justify-end gap-2 border-t border-border/60 bg-muted/30 px-4 py-3",
        className,
      )}
    >
      {children}
    </div>
  );
};

const Overlay = ({ className }: { className?: string }): React.JSX.Element => {
  return (
    <motion.div
      initial={{
        opacity: 0,
      }}
      animate={{
        opacity: 1,
        backdropFilter: "blur(10px)",
      }}
      exit={{
        opacity: 0,
        backdropFilter: "blur(0px)",
      }}
      className={cn(
        "fixed inset-0 z-50 h-full w-full bg-background/55",
        className,
      )}
    ></motion.div>
  );
};

const CloseIcon = (): React.JSX.Element => {
  const { setOpen } = useModal();
  return (
    <button
      onClick={() => setOpen(false)}
      className="group absolute top-3 right-3 z-10 inline-flex size-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent/70 hover:text-foreground"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="24"
        height="24"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="h-3.5 w-3.5 transition duration-200 group-hover:rotate-90"
      >
        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
        <path d="M18 6l-12 12" />
        <path d="M6 6l12 12" />
      </svg>
    </button>
  );
};

// Detects clicks outside of a component.
export const useOutsideClick = (
  ref: React.RefObject<HTMLDivElement | null>,
  callback: (event: MouseEvent | TouchEvent) => void,
): void => {
  useEffect(() => {
    const listener = (event: MouseEvent | TouchEvent): void => {
      // Do nothing if the click lands on the target element or its children.
      if (
        !ref.current ||
        !(event.target instanceof Node) ||
        ref.current.contains(event.target)
      ) {
        return;
      }
      callback(event);
    };

    document.addEventListener("mousedown", listener);
    document.addEventListener("touchstart", listener);

    return () => {
      document.removeEventListener("mousedown", listener);
      document.removeEventListener("touchstart", listener);
    };
  }, [ref, callback]);
};
