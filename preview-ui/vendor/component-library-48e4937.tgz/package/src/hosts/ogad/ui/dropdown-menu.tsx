"use client";

// Drop-in for OGAD `src/renderer/src/components/ui/dropdown-menu.tsx`.
// Same 15 exports, props (`inset`, item `variant`), defaults (sideOffset 4)
// and data-slot/data-variant/data-inset attributes. z-index stays at the
// top of the stack so menus clear Electron overlays as before.
// Visual: translucent glass panel with a hairline border, compact rows.
//
// Motion: the `./operator/coss/menu` popup reveal (coss `PopupReveal`: fade,
// rise 20px, top-down mask unroll, 0.35s easeInOut), ported onto the Radix
// primitives this file has always used. coss menu is Base UI (`render` not
// `asChild`, `onClick` not `onSelect`, data-open not data-state, different
// positioner CSS vars), so swapping it in would break OGAD's call sites.
// `DropdownMenu`/`DropdownMenuSub` mirror the Radix open state and the
// content stays mounted through an `AnimatePresence` exit (200ms ease-in).
// coss also animates `height`; that is left out because Radix's popper
// measures the content to place it, so the mask carries the unroll instead.
// The mask is dropped once the reveal ends so the panel shadow shows. Items
// keep the `alive.css` cascade; the content opts out of its CSS keyframes so
// they never stack on the reveal. Reduced motion is an instant fade.
import * as React from "react";
import {
  AnimatePresence,
  motion,
  type HTMLMotionProps,
  type Transition,
} from "motion/react";
import {
  Check as CheckIcon,
  CaretRight as ChevronRightIcon,
  Circle as CircleIcon,
} from "@phosphor-icons/react";
import { DropdownMenu as DropdownMenuPrimitive } from "radix-ui";

import { cn } from "../../../sourced/coss/lib/utils.js";
import { useOpenState } from "../lib/open-state.js";
import { usePrefersReducedMotion } from "../lib/reduced-motion.js";

const popupSurface =
  "rounded-lg border border-border/60 bg-popover/95 p-1 text-popover-foreground shadow-[0_18px_50px_-12px_rgb(0_0_0/0.55)] backdrop-blur-xl backdrop-saturate-150";

const itemRow =
  "relative flex cursor-default items-center gap-2 rounded-[4px] text-[13px] leading-5 outline-hidden select-none focus:bg-accent/70 focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-45 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-3.5";

// Open state of the nearest drop-in root/sub; null under raw Radix roots,
// where content falls back to Radix's own presence (no motion).
const MenuOpenContext = React.createContext<boolean | null>(null);
const SubOpenContext = React.createContext<boolean | null>(null);

const revealMask =
  "linear-gradient(black var(--mask-stop), transparent var(--mask-stop))";
const revealTransition: Transition = { duration: 0.35, ease: "easeInOut" };

type RevealProps = Pick<
  HTMLMotionProps<"div">,
  "initial" | "animate" | "exit" | "transition"
> & { style: React.CSSProperties };

// coss `PopupReveal` minus `height` (see the header note).
function popupReveal(reduced: boolean): RevealProps {
  const shown = {
    opacity: 1,
    y: 0,
    "--mask-stop": "100%",
    transitionEnd: { maskImage: "none", WebkitMaskImage: "none" },
  };
  return {
    initial: reduced ? false : { opacity: 0, y: 20, "--mask-stop": "0%" },
    animate: shown,
    exit: reduced
      ? { opacity: 0, transition: { duration: 0 } }
      : {
          opacity: 0,
          y: 20,
          "--mask-stop": "0%",
          maskImage: revealMask,
          WebkitMaskImage: revealMask,
          transition: {
            duration: 0.2,
            ease: "easeIn",
            maskImage: { duration: 0 },
            WebkitMaskImage: { duration: 0 },
          },
        },
    transition: reduced ? { duration: 0 } : revealTransition,
    style: {
      maskImage: reduced ? "none" : revealMask,
      WebkitMaskImage: reduced ? "none" : revealMask,
      // motion owns this element; `alive.css` keys keyframes off data-state.
      animation: "none",
    },
  } as unknown as RevealProps;
}

function MotionPopup({
  open,
  portal,
  style,
  children,
  className,
  Content,
  ...contentProps
}: {
  open: boolean;
  portal: boolean;
  Content:
    | typeof DropdownMenuPrimitive.Content
    | typeof DropdownMenuPrimitive.SubContent;
} & React.ComponentProps<
  typeof DropdownMenuPrimitive.Content
>): React.JSX.Element {
  const reduced = usePrefersReducedMotion();
  const { style: motionStyle, ...reveal } = popupReveal(reduced);
  const Primitive = Content as typeof DropdownMenuPrimitive.Content;
  const popup = (
    <Primitive forceMount asChild {...contentProps}>
      <motion.div
        className={className}
        style={{ ...style, ...motionStyle }}
        {...reveal}
      >
        {children}
      </motion.div>
    </Primitive>
  );
  return (
    <AnimatePresence>
      {open &&
        (portal ? (
          <DropdownMenuPrimitive.Portal forceMount>
            {popup}
          </DropdownMenuPrimitive.Portal>
        ) : (
          popup
        ))}
    </AnimatePresence>
  );
}

function DropdownMenu({
  open,
  defaultOpen,
  onOpenChange,
  ...props
}: React.ComponentProps<typeof DropdownMenuPrimitive.Root>): React.JSX.Element {
  const [isOpen, setIsOpen] = useOpenState({ open, defaultOpen, onOpenChange });
  return (
    <MenuOpenContext.Provider value={isOpen}>
      <DropdownMenuPrimitive.Root
        data-slot="dropdown-menu"
        open={isOpen}
        onOpenChange={setIsOpen}
        {...props}
      />
    </MenuOpenContext.Provider>
  );
}

function DropdownMenuPortal({
  ...props
}: React.ComponentProps<
  typeof DropdownMenuPrimitive.Portal
>): React.JSX.Element {
  return (
    <DropdownMenuPrimitive.Portal data-slot="dropdown-menu-portal" {...props} />
  );
}

function DropdownMenuTrigger({
  ...props
}: React.ComponentProps<
  typeof DropdownMenuPrimitive.Trigger
>): React.JSX.Element {
  return (
    <DropdownMenuPrimitive.Trigger
      data-slot="dropdown-menu-trigger"
      {...props}
    />
  );
}

function DropdownMenuContent({
  className,
  sideOffset = 4,
  ...props
}: React.ComponentProps<
  typeof DropdownMenuPrimitive.Content
>): React.JSX.Element {
  const isOpen = React.useContext(MenuOpenContext);
  const classes = cn(
    "z-[2147483647] max-h-(--radix-dropdown-menu-content-available-height) min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-x-hidden overflow-y-auto",
    popupSurface,
    className,
  );
  if (isOpen === null || props.forceMount || props.asChild) {
    return (
      <DropdownMenuPrimitive.Portal>
        <DropdownMenuPrimitive.Content
          data-slot="dropdown-menu-content"
          sideOffset={sideOffset}
          className={classes}
          {...props}
        />
      </DropdownMenuPrimitive.Portal>
    );
  }
  return (
    <MotionPopup
      open={isOpen}
      portal
      Content={DropdownMenuPrimitive.Content}
      data-slot="dropdown-menu-content"
      sideOffset={sideOffset}
      className={classes}
      {...props}
    />
  );
}

function DropdownMenuGroup({
  ...props
}: React.ComponentProps<
  typeof DropdownMenuPrimitive.Group
>): React.JSX.Element {
  return (
    <DropdownMenuPrimitive.Group data-slot="dropdown-menu-group" {...props} />
  );
}

function DropdownMenuItem({
  className,
  inset,
  variant = "default",
  ...props
}: React.ComponentProps<typeof DropdownMenuPrimitive.Item> & {
  inset?: boolean;
  variant?: "default" | "destructive";
}): React.JSX.Element {
  return (
    <DropdownMenuPrimitive.Item
      data-slot="dropdown-menu-item"
      data-inset={inset}
      data-variant={variant}
      className={cn(
        itemRow,
        "px-2 py-1 data-[inset]:pl-7 data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/12 data-[variant=destructive]:focus:text-destructive [&_svg:not([class*='text-'])]:text-muted-foreground data-[variant=destructive]:*:[svg]:text-destructive!",
        className,
      )}
      {...props}
    />
  );
}

function DropdownMenuCheckboxItem({
  className,
  children,
  checked,
  ...props
}: React.ComponentProps<
  typeof DropdownMenuPrimitive.CheckboxItem
>): React.JSX.Element {
  return (
    <DropdownMenuPrimitive.CheckboxItem
      data-slot="dropdown-menu-checkbox-item"
      className={cn(itemRow, "py-1 pr-2 pl-7", className)}
      checked={checked}
      {...props}
    >
      <span className="pointer-events-none absolute left-2 flex size-3.5 items-center justify-center text-primary">
        <DropdownMenuPrimitive.ItemIndicator>
          <CheckIcon className="size-3.5" weight="bold" />
        </DropdownMenuPrimitive.ItemIndicator>
      </span>
      {children}
    </DropdownMenuPrimitive.CheckboxItem>
  );
}

function DropdownMenuRadioGroup({
  ...props
}: React.ComponentProps<
  typeof DropdownMenuPrimitive.RadioGroup
>): React.JSX.Element {
  return (
    <DropdownMenuPrimitive.RadioGroup
      data-slot="dropdown-menu-radio-group"
      {...props}
    />
  );
}

function DropdownMenuRadioItem({
  className,
  children,
  ...props
}: React.ComponentProps<
  typeof DropdownMenuPrimitive.RadioItem
>): React.JSX.Element {
  return (
    <DropdownMenuPrimitive.RadioItem
      data-slot="dropdown-menu-radio-item"
      className={cn(itemRow, "py-1 pr-2 pl-7", className)}
      {...props}
    >
      <span className="pointer-events-none absolute left-2 flex size-3.5 items-center justify-center text-primary">
        <DropdownMenuPrimitive.ItemIndicator>
          <CircleIcon className="size-1.5 fill-current" weight="fill" />
        </DropdownMenuPrimitive.ItemIndicator>
      </span>
      {children}
    </DropdownMenuPrimitive.RadioItem>
  );
}

function DropdownMenuLabel({
  className,
  inset,
  ...props
}: React.ComponentProps<typeof DropdownMenuPrimitive.Label> & {
  inset?: boolean;
}): React.JSX.Element {
  return (
    <DropdownMenuPrimitive.Label
      data-slot="dropdown-menu-label"
      data-inset={inset}
      className={cn(
        "px-2 pt-1.5 pb-1 text-xs font-medium text-muted-foreground data-[inset]:pl-7",
        className,
      )}
      {...props}
    />
  );
}

function DropdownMenuSeparator({
  className,
  ...props
}: React.ComponentProps<
  typeof DropdownMenuPrimitive.Separator
>): React.JSX.Element {
  return (
    <DropdownMenuPrimitive.Separator
      data-slot="dropdown-menu-separator"
      className={cn("-mx-1 my-1 h-px bg-border/60", className)}
      {...props}
    />
  );
}

function DropdownMenuShortcut({
  className,
  ...props
}: React.ComponentProps<"span">): React.JSX.Element {
  return (
    <span
      data-slot="dropdown-menu-shortcut"
      className={cn(
        "ml-auto pl-3 text-[11px] tracking-widest text-muted-foreground/80",
        className,
      )}
      {...props}
    />
  );
}

function DropdownMenuSub({
  open,
  defaultOpen,
  onOpenChange,
  ...props
}: React.ComponentProps<typeof DropdownMenuPrimitive.Sub>): React.JSX.Element {
  const [isOpen, setIsOpen] = useOpenState({ open, defaultOpen, onOpenChange });
  return (
    <SubOpenContext.Provider value={isOpen}>
      <DropdownMenuPrimitive.Sub
        data-slot="dropdown-menu-sub"
        open={isOpen}
        onOpenChange={setIsOpen}
        {...props}
      />
    </SubOpenContext.Provider>
  );
}

function DropdownMenuSubTrigger({
  className,
  inset,
  children,
  ...props
}: React.ComponentProps<typeof DropdownMenuPrimitive.SubTrigger> & {
  inset?: boolean;
}): React.JSX.Element {
  return (
    <DropdownMenuPrimitive.SubTrigger
      data-slot="dropdown-menu-sub-trigger"
      data-inset={inset}
      className={cn(
        itemRow,
        "px-2 py-1 data-[inset]:pl-7 data-[state=open]:bg-accent/70 data-[state=open]:text-accent-foreground [&_svg:not([class*='text-'])]:text-muted-foreground",
        className,
      )}
      {...props}
    >
      {children}
      <ChevronRightIcon className="ml-auto size-3.5" />
    </DropdownMenuPrimitive.SubTrigger>
  );
}

function DropdownMenuSubContent({
  className,
  ...props
}: React.ComponentProps<
  typeof DropdownMenuPrimitive.SubContent
>): React.JSX.Element {
  const isOpen = React.useContext(SubOpenContext);
  const classes = cn(
    "z-[2147483647] min-w-[8rem] origin-(--radix-dropdown-menu-content-transform-origin) overflow-hidden",
    popupSurface,
    className,
  );
  if (isOpen === null || props.forceMount || props.asChild) {
    return (
      <DropdownMenuPrimitive.SubContent
        data-slot="dropdown-menu-sub-content"
        className={classes}
        {...props}
      />
    );
  }
  return (
    <MotionPopup
      open={isOpen}
      portal={false}
      Content={DropdownMenuPrimitive.SubContent}
      data-slot="dropdown-menu-sub-content"
      className={classes}
      {...props}
    />
  );
}

export {
  DropdownMenu,
  DropdownMenuPortal,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuLabel,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuSubContent,
};
