// Drop-in for OGAD `src/renderer/src/components/ui/starfield-backdrop.tsx`.
// Same export, props and markup. The stars and the shooting star are drawn
// by OGAD's own `.og-starfield` / `.og-shooting-star` rules in main.css
// (theme-aware, reduced-motion aware), so this module keeps those class
// hooks unchanged and only adds a data-slot.
import type * as React from "react";

import { cn } from "../../../sourced/coss/lib/utils.js";

/** Starry-night layer over the terminal grid, in both themes. */
export function StarfieldBackdrop({
  className,
}: {
  className?: string;
}): React.ReactElement {
  return (
    <div
      aria-hidden
      data-slot="starfield-backdrop"
      className={cn(
        "pointer-events-none absolute inset-0 overflow-hidden",
        className,
      )}
    >
      <div className="og-starfield absolute inset-0" />
      <span className="og-shooting-star" />
    </div>
  );
}
