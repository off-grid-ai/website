"use client";

// Drop-in for OGAD `src/renderer/src/components/ui/dialog.tsx`.
// Same 10 exports, props (`showCloseButton` on content and footer), ref
// forwarding and data-slots.
//
// Native-surface occlusion: OGAD's DialogContent keeps Electron's native child
// views below every open dialog by calling its app-level
// `acquireNativeSurfaceOcclusion()` while the content is mounted. A library
// cannot import app code, so the host registers its implementation once with
// `registerDialogOcclusion()` (OGAD's `ui/dialog.tsx` shim does this at module
// load). The acquire/release timing is identical to OGAD's: acquire when the
// content node attaches, release when it detaches or the component unmounts.
// Without a registration, dialogs work exactly the same minus occlusion.
//
// Visual: glass-free solid surface (dialogs carry text), hairline border,
// tighter padding, a compact icon close button, scrim from host tokens.
//
// Motion: the `./operator/animate/dialog` (animate-ui) motion, ported onto the
// Radix primitives this file has always used. The animate-ui component is
// built on Base UI (`render` instead of `asChild`, different focus/dismiss
// props and data attributes), so swapping it in would break OGAD's call
// sites. Instead `Dialog` mirrors the Radix open state, and `DialogContent`
// keeps its portal mounted through an `AnimatePresence` exit: the popup flips
// in on animate-ui's spring (perspective rotateX -20deg, scale 0.8, blur 4px)
// over a fading, unblurring scrim. Exit is a 200ms ease-in of the same pose so
// a close never feels sluggish. Reduced motion collapses both to an instant
// fade. The motion elements opt out of `alive.css`'s CSS keyframes so the two
// never stack. Occlusion is held until the exit finishes (node detach).
import * as React from "react";
import { X as XIcon } from "@phosphor-icons/react";
import { AnimatePresence, motion, type Transition } from "motion/react";
import { Dialog as DialogPrimitive } from "radix-ui";

import {
  useNodePresence,
  type AcquireOcclusion,
} from "../../../sourced/animateui/adapters/node-presence.js";
import { cn } from "../../../sourced/coss/lib/utils.js";
import { useOpenState } from "../lib/open-state.js";
import { usePrefersReducedMotion } from "../lib/reduced-motion.js";
import { Button } from "./button.js";

let acquireOcclusion: AcquireOcclusion | null = null;

/**
 * Registers the host's occlusion hook. Every mounted DialogContent calls it
 * once and invokes the returned release when it closes. Returns an
 * unregister function (used by tests).
 */
function registerDialogOcclusion(acquire: AcquireOcclusion): () => void {
  acquireOcclusion = acquire;
  return () => {
    if (acquireOcclusion === acquire) acquireOcclusion = null;
  };
}

// Open state of the nearest drop-in `Dialog`; null under a raw Radix root,
// where DialogContent falls back to Radix's own presence (no motion).
const DialogOpenContext = React.createContext<boolean | null>(null);

function Dialog({
  open,
  defaultOpen,
  onOpenChange,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Root>): React.JSX.Element {
  const [isOpen, setIsOpen] = useOpenState({ open, defaultOpen, onOpenChange });
  return (
    <DialogOpenContext.Provider value={isOpen}>
      <DialogPrimitive.Root
        data-slot="dialog"
        open={isOpen}
        onOpenChange={setIsOpen}
        {...props}
      />
    </DialogOpenContext.Provider>
  );
}

function DialogTrigger({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Trigger>): React.JSX.Element {
  return <DialogPrimitive.Trigger data-slot="dialog-trigger" {...props} />;
}

function DialogPortal({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Portal>): React.JSX.Element {
  return <DialogPrimitive.Portal data-slot="dialog-portal" {...props} />;
}

function DialogClose({
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Close>): React.JSX.Element {
  return <DialogPrimitive.Close data-slot="dialog-close" {...props} />;
}

function DialogOverlay({
  className,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Overlay>): React.JSX.Element {
  return (
    <DialogPrimitive.Overlay
      data-slot="dialog-overlay"
      className={cn(
        "pointer-events-auto fixed inset-0 z-50 bg-background/55",
        className,
      )}
      {...props}
    />
  );
}

// motion owns these elements; `alive.css` keys keyframes off Radix's
// data-state, which would otherwise run on top of the spring.
const noCssKeyframes: React.CSSProperties = { animation: "none" };

const exitTransition: Transition = { duration: 0.2, ease: "easeIn" };

// animate-ui `DialogBackdrop` (primitives/base/dialog).
function dialogBackdropMotion(reduced: boolean) {
  return {
    initial: reduced ? false : { opacity: 0, filter: "blur(4px)" },
    animate: { opacity: 1, filter: "blur(0px)" },
    exit: reduced
      ? { opacity: 0, transition: { duration: 0 } }
      : { opacity: 0, filter: "blur(4px)", transition: exitTransition },
    transition: reduced
      ? { duration: 0 }
      : ({ duration: 0.2, ease: "easeInOut" } as Transition),
  } as const;
}

// animate-ui `DialogPopup` with its default `from="top"` flip.
const popupHidden = {
  opacity: 0,
  filter: "blur(4px)",
  transform: "perspective(500px) rotateX(-20deg) scale(0.8)",
};

function dialogPopupMotion(reduced: boolean) {
  return {
    initial: reduced ? false : popupHidden,
    animate: {
      opacity: 1,
      filter: "blur(0px)",
      transform: "perspective(500px) rotateX(0deg) scale(1)",
    },
    exit: reduced
      ? { opacity: 0, transition: { duration: 0 } }
      : { ...popupHidden, transition: exitTransition },
    transition: reduced
      ? { duration: 0 }
      : ({ type: "spring", stiffness: 150, damping: 25 } as Transition),
  } as const;
}

function DialogContent({
  className,
  children,
  showCloseButton = true,
  ref,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Content> & {
  showCloseButton?: boolean;
}): React.JSX.Element {
  const contentRef = useNodePresence<HTMLDivElement>({
    ref,
    acquire: acquireOcclusion,
  });

  const isOpen = React.useContext(DialogOpenContext);
  const reduced = usePrefersReducedMotion();
  const contentClass = cn(
    "fixed top-[50%] left-[50%] z-50 grid w-full max-w-[calc(100%-2rem)] translate-x-[-50%] translate-y-[-50%] gap-3 rounded-xl border border-border/70 bg-background p-5 text-foreground shadow-[0_30px_80px_-20px_rgb(0_0_0/0.6)] outline-none sm:max-w-lg",
    className,
  );
  const closeButton = showCloseButton && (
    <DialogPrimitive.Close
      data-slot="dialog-close"
      className="absolute top-3 right-3 inline-flex size-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent/70 hover:text-foreground focus-visible:ring-2 focus-visible:ring-ring/45 focus-visible:outline-hidden disabled:pointer-events-none [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-3.5"
    >
      <XIcon />
      <span className="sr-only">Close</span>
    </DialogPrimitive.Close>
  );

  if (isOpen === null || props.asChild || props.forceMount) {
    return (
      <DialogPortal data-slot="dialog-portal">
        <DialogPrimitive.Close asChild>
          <DialogOverlay />
        </DialogPrimitive.Close>
        <DialogPrimitive.Content
          ref={contentRef}
          data-slot="dialog-content"
          className={contentClass}
          {...props}
        >
          {children}
          {closeButton}
        </DialogPrimitive.Content>
      </DialogPortal>
    );
  }

  const { style, ...contentProps } = props;
  return (
    <AnimatePresence>
      {isOpen && (
        <DialogPrimitive.Portal forceMount data-slot="dialog-portal">
          <DialogPrimitive.Close asChild>
            <DialogPrimitive.Overlay forceMount asChild>
              <motion.div
                data-slot="dialog-overlay"
                className="pointer-events-auto fixed inset-0 z-50 bg-background/55"
                style={noCssKeyframes}
                {...dialogBackdropMotion(reduced)}
              />
            </DialogPrimitive.Overlay>
          </DialogPrimitive.Close>
          <DialogPrimitive.Content
            forceMount
            asChild
            ref={contentRef}
            {...contentProps}
          >
            <motion.div
              data-slot="dialog-content"
              className={contentClass}
              style={{ ...style, ...noCssKeyframes }}
              {...dialogPopupMotion(reduced)}
            >
              {children}
              {closeButton}
            </motion.div>
          </DialogPrimitive.Content>
        </DialogPrimitive.Portal>
      )}
    </AnimatePresence>
  );
}

function DialogHeader({
  className,
  ...props
}: React.ComponentProps<"div">): React.JSX.Element {
  return (
    <div
      data-slot="dialog-header"
      className={cn(
        "flex flex-col gap-1.5 text-center sm:text-left",
        className,
      )}
      {...props}
    />
  );
}

function DialogFooter({
  className,
  showCloseButton = false,
  children,
  ...props
}: React.ComponentProps<"div"> & {
  showCloseButton?: boolean;
}): React.JSX.Element {
  return (
    <div
      data-slot="dialog-footer"
      className={cn(
        "flex flex-col-reverse gap-2 pt-1 sm:flex-row sm:justify-end",
        className,
      )}
      {...props}
    >
      {children}
      {showCloseButton && (
        <DialogPrimitive.Close asChild>
          <Button variant="outline">Close</Button>
        </DialogPrimitive.Close>
      )}
    </div>
  );
}

function DialogTitle({
  className,
  ...props
}: React.ComponentProps<typeof DialogPrimitive.Title>): React.JSX.Element {
  return (
    <DialogPrimitive.Title
      data-slot="dialog-title"
      className={cn(
        "text-base leading-tight font-medium tracking-tight",
        className,
      )}
      {...props}
    />
  );
}

function DialogDescription({
  className,
  ...props
}: React.ComponentProps<
  typeof DialogPrimitive.Description
>): React.JSX.Element {
  return (
    <DialogPrimitive.Description
      data-slot="dialog-description"
      className={cn(
        "text-[13px] leading-relaxed text-muted-foreground",
        className,
      )}
      {...props}
    />
  );
}

export {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogOverlay,
  DialogPortal,
  DialogTitle,
  DialogTrigger,
  registerDialogOcclusion,
};
