// Drop-in for OGAD `src/renderer/src/components/ui/progressive-blur.tsx`.
// Same export, props and defaults, same layer stack (first, middle, last
// blur bands with the same masks), so scroll edges look identical. It is a
// pure optical effect: the only change is a `data-slot` and the mask maths
// written once instead of three times.
import type * as React from "react";

import { cn } from "../../../sourced/coss/lib/utils.js";

export interface ProgressiveBlurProps {
  className?: string;
  height?: string;
  position?: "top" | "bottom" | "both";
  blurLevels?: number[];
  children?: React.ReactNode;
}

const BOTH_MASK =
  "linear-gradient(rgba(0,0,0,0) 0%, rgba(0,0,0,1) 5%, rgba(0,0,0,1) 95%, rgba(0,0,0,0) 100%)";

function bandMask(
  position: ProgressiveBlurProps["position"],
  stops: string,
): string {
  if (position === "bottom") return `linear-gradient(to bottom, ${stops})`;
  if (position === "top") return `linear-gradient(to top, ${stops})`;
  return BOTH_MASK;
}

function blurLayer(
  zIndex: number,
  blur: number | undefined,
  mask: string,
): React.CSSProperties {
  return {
    zIndex,
    backdropFilter: `blur(${blur}px)`,
    WebkitBackdropFilter: `blur(${blur}px)`,
    maskImage: mask,
    WebkitMaskImage: mask,
  };
}

export function ProgressiveBlur({
  className,
  height = "30%",
  position = "bottom",
  blurLevels = [0.5, 1, 2, 4, 8, 16, 32, 64],
}: ProgressiveBlurProps): React.JSX.Element {
  // One element per level minus the first and last bands.
  const divElements = Array(blurLevels.length - 2).fill(null);

  return (
    <div
      data-slot="progressive-blur"
      className={cn(
        "gradient-blur pointer-events-none absolute inset-x-0 z-10",
        className,
        position === "top"
          ? "top-0"
          : position === "bottom"
            ? "bottom-0"
            : "inset-y-0",
      )}
      style={{
        height: position === "both" ? "100%" : height,
      }}
    >
      <div
        className="absolute inset-0"
        style={blurLayer(
          1,
          blurLevels[0],
          bandMask(
            position,
            "rgba(0,0,0,0) 0%, rgba(0,0,0,1) 12.5%, rgba(0,0,0,1) 25%, rgba(0,0,0,0) 37.5%",
          ),
        )}
      />

      {divElements.map((_, index) => {
        const blurIndex = index + 1;
        const startPercent = blurIndex * 12.5;
        const midPercent = (blurIndex + 1) * 12.5;
        const endPercent = (blurIndex + 2) * 12.5;
        const mask = bandMask(
          position,
          `rgba(0,0,0,0) ${startPercent}%, rgba(0,0,0,1) ${midPercent}%, rgba(0,0,0,1) ${endPercent}%, rgba(0,0,0,0) ${endPercent + 12.5}%`,
        );

        return (
          <div
            key={`blur-${index}`}
            className="absolute inset-0"
            style={blurLayer(index + 2, blurLevels[blurIndex], mask)}
          />
        );
      })}

      <div
        className="absolute inset-0"
        style={blurLayer(
          blurLevels.length,
          blurLevels[blurLevels.length - 1],
          bandMask(position, "rgba(0,0,0,0) 87.5%, rgba(0,0,0,1) 100%"),
        )}
      />
    </div>
  );
}
