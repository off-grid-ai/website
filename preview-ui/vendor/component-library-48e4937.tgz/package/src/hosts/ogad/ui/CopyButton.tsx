// Drop-in for OGAD `src/renderer/src/components/ui/CopyButton.tsx`.
// Same export, props (`text`, `label` default "Copy"), clipboard call and
// 1.5s "Copied" confirmation. The label and "Copied" are the accessible name.
// Visual: icons over labels. A square ghost icon button with a tooltip; the
// glyph crossfades copy -> check instead of the text morphing.
import { Check, Copy } from "@phosphor-icons/react";
import { AnimatePresence, motion } from "motion/react";
import React, { useState } from "react";

import { usePrefersReducedMotion } from "../lib/reduced-motion.js";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "./tooltip.js";

/** Small copy-to-clipboard icon button with a brief "Copied" confirmation. */
export function CopyButton({
  text,
  label = "Copy",
}: {
  text: string;
  label?: string;
}): React.ReactElement {
  const [done, setDone] = useState(false);
  const reduceMotion = usePrefersReducedMotion();
  const name = done ? "Copied" : label;
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            data-slot="copy-button"
            data-state={done ? "copied" : "idle"}
            aria-label={name}
            onClick={() =>
              navigator.clipboard.writeText(text).then(() => {
                setDone(true);
                setTimeout(() => setDone(false), 1500);
              })
            }
            className="grid size-7 shrink-0 place-items-center rounded-md text-muted-foreground transition-colors duration-150 hover:bg-accent/50 hover:text-foreground data-[state=copied]:text-foreground"
          >
            <AnimatePresence initial={false}>
              <motion.span
                key={done ? "check" : "copy"}
                data-glyph={done ? "check" : "copy"}
                className="inline-flex [grid-area:1/1]"
                initial={
                  reduceMotion
                    ? { opacity: 0 }
                    : { scale: 0.4, opacity: 0, rotate: -30 }
                }
                animate={{ scale: 1, opacity: 1, rotate: 0 }}
                exit={
                  reduceMotion
                    ? { opacity: 0, transition: { duration: 0 } }
                    : { scale: 0.4, opacity: 0, rotate: 30 }
                }
                transition={{ type: "spring", stiffness: 520, damping: 26 }}
              >
                {done ? (
                  <Check
                    aria-hidden="true"
                    className="size-3.5 text-primary"
                    weight="bold"
                  />
                ) : (
                  <Copy aria-hidden="true" className="size-3.5" />
                )}
              </motion.span>
            </AnimatePresence>
          </button>
        </TooltipTrigger>
        <TooltipContent>{name}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
