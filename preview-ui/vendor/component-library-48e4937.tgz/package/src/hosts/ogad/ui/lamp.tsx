"use client";

// Drop-in for OGAD `src/renderer/src/components/ui/lamp.tsx` (Aceternity).
// Same exports: default `LampDemo` and named `LampContainer` with the same
// props and layer geometry (OGAD's onboarding lays its content against it).
// Visual: the stock cyan light becomes the emerald primary token (Off Grid is
// single-accent), masks read the background token so the lamp sits on either
// theme, the light settles with an ease-out instead of ease-in-out, and the
// glow is a touch softer.
import { motion } from "motion/react";
import type * as React from "react";

import { cn } from "../../../sourced/coss/lib/utils.js";

// Reveal on scroll-in where IntersectionObserver exists (Electron, browsers);
// otherwise (jsdom, very old engines) reveal on mount instead of throwing.
const canObserve = typeof IntersectionObserver !== "undefined";
function inView<T>(target: T): { whileInView: T } | { animate: T } {
  return canObserve ? { whileInView: target } : { animate: target };
}

const reveal = {
  delay: 0.3,
  duration: 0.9,
  ease: [0.16, 1, 0.3, 1],
} as const;

export default function LampDemo(): React.JSX.Element {
  return (
    <LampContainer>
      <motion.h1
        initial={{ opacity: 0.5, y: 100 }}
        {...inView({ opacity: 1, y: 0 })}
        transition={reveal}
        className="mt-8 bg-gradient-to-br from-foreground to-muted-foreground bg-clip-text py-4 text-center text-4xl font-medium tracking-tight text-transparent md:text-7xl"
      >
        Build lamps <br /> the right way
      </motion.h1>
    </LampContainer>
  );
}

export const LampContainer = ({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}): React.JSX.Element => {
  return (
    <div
      data-slot="lamp"
      className={cn(
        "relative z-0 flex min-h-screen w-full flex-col items-center justify-center overflow-hidden rounded-md bg-background",
        className,
      )}
    >
      <div className="relative isolate z-0 flex w-full flex-1 scale-y-125 items-center justify-center">
        <motion.div
          initial={{ opacity: 0.5, width: "15rem" }}
          {...inView({ opacity: 1, width: "30rem" })}
          transition={reveal}
          style={{
            backgroundImage: `conic-gradient(var(--conic-position), var(--tw-gradient-stops))`,
          }}
          className="bg-gradient-conic absolute inset-auto right-1/2 h-56 w-[30rem] overflow-visible from-primary/80 via-transparent to-transparent text-foreground [--conic-position:from_70deg_at_center_top]"
        >
          <div className="absolute bottom-0 left-0 z-20 h-40 w-[100%] bg-background [mask-image:linear-gradient(to_top,white,transparent)]" />
          <div className="absolute bottom-0 left-0 z-20 h-[100%] w-40 bg-background [mask-image:linear-gradient(to_right,white,transparent)]" />
        </motion.div>
        <motion.div
          initial={{ opacity: 0.5, width: "15rem" }}
          {...inView({ opacity: 1, width: "30rem" })}
          transition={reveal}
          style={{
            backgroundImage: `conic-gradient(var(--conic-position), var(--tw-gradient-stops))`,
          }}
          className="bg-gradient-conic absolute inset-auto left-1/2 h-56 w-[30rem] from-transparent via-transparent to-primary/80 text-foreground [--conic-position:from_290deg_at_center_top]"
        >
          <div className="absolute right-0 bottom-0 z-20 h-[100%] w-40 bg-background [mask-image:linear-gradient(to_left,white,transparent)]" />
          <div className="absolute right-0 bottom-0 z-20 h-40 w-[100%] bg-background [mask-image:linear-gradient(to_top,white,transparent)]" />
        </motion.div>
        <div className="absolute top-1/2 h-48 w-full translate-y-12 scale-x-150 bg-background blur-2xl"></div>
        <div className="absolute top-1/2 z-50 h-48 w-full bg-transparent opacity-10 backdrop-blur-md"></div>
        <div className="absolute inset-auto z-50 h-36 w-[28rem] -translate-y-1/2 rounded-full bg-primary opacity-40 blur-3xl"></div>
        <motion.div
          initial={{ width: "8rem" }}
          {...inView({ width: "16rem" })}
          transition={reveal}
          className="absolute inset-auto z-30 h-36 w-64 -translate-y-[6rem] rounded-full bg-primary/80 blur-2xl"
        ></motion.div>
        <motion.div
          initial={{ width: "15rem" }}
          {...inView({ width: "30rem" })}
          transition={reveal}
          className="absolute inset-auto z-50 h-px w-[30rem] -translate-y-[7rem] bg-primary shadow-[0_0_12px_1px_var(--color-primary)]"
        ></motion.div>

        <div className="absolute inset-auto z-40 h-44 w-full -translate-y-[12.5rem] bg-background"></div>
      </div>

      <div className="relative z-50 flex -translate-y-80 flex-col items-center px-5">
        {children}
      </div>
    </div>
  );
};
