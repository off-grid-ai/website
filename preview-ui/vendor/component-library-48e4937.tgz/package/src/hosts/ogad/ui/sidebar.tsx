"use client";

// Drop-in for OGAD `src/renderer/src/components/ui/sidebar.tsx` (Aceternity).
// Same exports (useSidebar, SidebarProvider, Sidebar, SidebarBody,
// DesktopSidebar, MobileSidebar, SidebarLink), props, data-state
// (expanded/collapsed) and data-motion (full/reduced). Desktop-first: the
// rail is always present; MobileSidebar renders nothing, as in OGAD.
// Width still animates 60px <-> 220px; the curve is now a soft spring
// (instant under reduced motion). Rail padding is unchanged so OGAD's 60px
// icon column stays aligned. Visual: token surface with a hairline edge,
// quieter link labels that ease in instead of popping.
import { motion } from "motion/react";
import React, { createContext, useContext, useState } from "react";

import { cn } from "../../../sourced/coss/lib/utils.js";
import { usePrefersReducedMotion } from "../lib/reduced-motion.js";

interface Links {
  label: string;
  href: string;
  icon: React.JSX.Element | React.ReactNode;
}

interface SidebarContextProps {
  open: boolean;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  animate: boolean;
}

const SidebarContext = createContext<SidebarContextProps | undefined>(
  undefined,
);

export const useSidebar = (): SidebarContextProps => {
  const context = useContext(SidebarContext);
  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider");
  }
  return context;
};

export const SidebarProvider = ({
  children,
  open: openProp,
  setOpen: setOpenProp,
  animate = true,
}: {
  children: React.ReactNode;
  open?: boolean;
  setOpen?: React.Dispatch<React.SetStateAction<boolean>>;
  animate?: boolean;
}): React.JSX.Element => {
  const [openState, setOpenState] = useState(false);

  const open = openProp !== undefined ? openProp : openState;
  const setOpen = setOpenProp !== undefined ? setOpenProp : setOpenState;

  return (
    <SidebarContext.Provider value={{ open, setOpen, animate: animate }}>
      {children}
    </SidebarContext.Provider>
  );
};

export const Sidebar = ({
  children,
  open,
  setOpen,
  animate,
}: {
  children: React.ReactNode;
  open?: boolean;
  setOpen?: React.Dispatch<React.SetStateAction<boolean>>;
  animate?: boolean;
}): React.JSX.Element => {
  return (
    <SidebarProvider open={open} setOpen={setOpen} animate={animate}>
      {children}
    </SidebarProvider>
  );
};

export const SidebarBody = (
  props: React.ComponentProps<typeof motion.div>,
): React.JSX.Element => {
  return (
    <>
      <DesktopSidebar {...props} />
      <MobileSidebar {...(props as React.ComponentProps<"div">)} />
    </>
  );
};

const widthSpring = {
  type: "spring",
  stiffness: 420,
  damping: 40,
  mass: 0.9,
} as const;

export const DesktopSidebar = ({
  className,
  children,
  ...props
}: React.ComponentProps<typeof motion.div>): React.JSX.Element => {
  const { open, animate } = useSidebar();
  const reduceMotion = usePrefersReducedMotion();
  return (
    <>
      <motion.div
        className={cn(
          // Desktop-first app: the sidebar is ALWAYS present (no responsive hide).
          "flex h-full shrink-0 flex-col border-r border-border/60 bg-card px-4 py-4",
          className,
        )}
        // App owns hover and keyboard-focus intent; this primitive owns only the
        // width transition between the rail and expanded navigation.
        animate={{
          width: animate ? (open ? "220px" : "60px") : "220px",
        }}
        transition={reduceMotion ? { duration: 0 } : widthSpring}
        data-slot="sidebar"
        data-state={open ? "expanded" : "collapsed"}
        data-motion={reduceMotion ? "reduced" : "full"}
        {...props}
      >
        {children}
      </motion.div>
    </>
  );
};

// Desktop-first app: no separate mobile nav.
export const MobileSidebar = (_props: React.ComponentProps<"div">): null =>
  null;

export const SidebarLink = ({
  link,
  className,
  ...props
}: {
  link: Links;
  className?: string;
}): React.JSX.Element => {
  const { open, animate } = useSidebar();
  return (
    <a
      href={link.href}
      data-slot="sidebar-link"
      className={cn(
        "group/sidebar flex items-center justify-start gap-2 rounded-md py-1.5 text-muted-foreground transition-colors hover:text-foreground",
        className,
      )}
      {...props}
    >
      {link.icon}

      <motion.span
        animate={{
          display: animate ? (open ? "inline-block" : "none") : "inline-block",
          opacity: animate ? (open ? 1 : 0) : 1,
        }}
        transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
        className="inline-block !m-0 !p-0 text-[13px] whitespace-pre transition duration-150 group-hover/sidebar:translate-x-0.5"
      >
        {link.label}
      </motion.span>
    </a>
  );
};
