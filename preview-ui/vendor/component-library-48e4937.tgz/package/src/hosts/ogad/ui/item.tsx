"use client";

// Drop-in for OGAD `src/renderer/src/components/ui/item.tsx`.
// Same 10 forwardRef exports, `variant`/`size` props and displayNames.
// Adds `data-slot` names (and `data-og-surface` on Item so it catches the
// alive layer's pointer light on its border); no other behaviour changes.
// Visual: token-backed hairline borders instead of fixed neutral fills,
// slightly leaner padding, quieter media wells.
import * as React from "react";

import { cn } from "../../../sourced/coss/lib/utils.js";

type ItemVariant = "default" | "outline" | "muted";
type ItemSize = "default" | "sm";

const itemVariants: Record<ItemVariant, string> = {
  default:
    "border border-border/60 bg-card/45 hover:border-border hover:bg-card/75",
  outline:
    "border border-border/60 bg-transparent hover:border-border hover:bg-card/35",
  muted:
    "border border-border/40 bg-muted/25 hover:border-border/70 hover:bg-muted/45",
};

const itemSizes: Record<ItemSize, string> = {
  default: "p-3.5",
  sm: "p-2.5",
};

export const Item = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & {
    variant?: ItemVariant;
    size?: ItemSize;
  }
>(({ className, variant = "default", size = "default", ...props }, ref) => (
  <div
    ref={ref}
    data-slot="item"
    data-variant={variant}
    data-size={size}
    data-og-surface=""
    className={cn(
      "relative flex w-full items-center gap-3.5 rounded-xl transition-[background-color,border-color] duration-200",
      itemVariants[variant],
      itemSizes[size],
      className,
    )}
    {...props}
  />
));
Item.displayName = "Item";

export const ItemGroup = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    data-slot="item-group"
    className={cn("flex flex-col gap-2.5", className)}
    {...props}
  />
));
ItemGroup.displayName = "ItemGroup";

export const ItemSeparator = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    data-slot="item-separator"
    className={cn("h-px w-full bg-border/60", className)}
    {...props}
  />
));
ItemSeparator.displayName = "ItemSeparator";

export const ItemMedia = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & {
    variant?: "default" | "icon" | "image";
  }
>(({ className, variant = "default", ...props }, ref) => (
  <div
    ref={ref}
    data-slot="item-media"
    data-variant={variant}
    className={cn(
      "flex shrink-0 items-center justify-center",
      variant === "image" && "h-10 w-10 overflow-hidden rounded-lg",
      variant === "icon" &&
        "h-8 w-8 rounded-lg border border-border/60 bg-muted/50 text-foreground/80 [&_svg:not([class*='size-'])]:size-4",
      variant === "default" &&
        "h-10 w-10 rounded-lg bg-muted/70 text-foreground/80",
      className,
    )}
    {...props}
  />
));
ItemMedia.displayName = "ItemMedia";

export const ItemContent = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    data-slot="item-content"
    className={cn("flex min-w-0 flex-1 flex-col gap-0.5", className)}
    {...props}
  />
));
ItemContent.displayName = "ItemContent";

export const ItemTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <p
    ref={ref}
    data-slot="item-title"
    className={cn(
      "truncate text-[13px] font-medium text-foreground",
      className,
    )}
    {...props}
  />
));
ItemTitle.displayName = "ItemTitle";

export const ItemDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <p
    ref={ref}
    data-slot="item-description"
    className={cn("truncate text-xs text-muted-foreground", className)}
    {...props}
  />
));
ItemDescription.displayName = "ItemDescription";

export const ItemActions = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    data-slot="item-actions"
    className={cn("flex items-center gap-1.5", className)}
    {...props}
  />
));
ItemActions.displayName = "ItemActions";

export const ItemHeader = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    data-slot="item-header"
    className={cn("w-full", className)}
    {...props}
  />
));
ItemHeader.displayName = "ItemHeader";

export const ItemFooter = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    data-slot="item-footer"
    className={cn("w-full", className)}
    {...props}
  />
));
ItemFooter.displayName = "ItemFooter";
