// Drop-in for OGAD `src/renderer/src/components/ui/grid-backdrop.tsx`.
// Same export, props and aria-hidden, pointer-events-none layer.
// Visual: the same 44px hairline grid at ~6% neutral, now feathered toward
// the edges with a soft radial mask so it recedes behind content instead of
// tiling hard to the window frame.
import type * as React from "react";

import { cn } from "../../../sourced/coss/lib/utils.js";

const FEATHER =
  "radial-gradient(ellipse 120% 100% at 50% 40%, #000 45%, rgba(0,0,0,0.35) 80%, transparent 100%)";

/** Flat, theme-aware terminal grid: the Off Grid AI backdrop. */
export function GridBackdrop({
  className,
}: {
  className?: string;
}): React.ReactElement {
  return (
    <div
      aria-hidden
      data-slot="grid-backdrop"
      className={cn("pointer-events-none absolute inset-0", className)}
      style={{
        backgroundImage:
          "linear-gradient(to right, rgba(128,128,128,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(128,128,128,0.06) 1px, transparent 1px)",
        backgroundSize: "44px 44px",
        maskImage: FEATHER,
        WebkitMaskImage: FEATHER,
      }}
    />
  );
}
