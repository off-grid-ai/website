"use client";

// Drop-in for OGAD `src/renderer/src/components/ui/orbiting-circles.tsx`
// (Magic UI). Same export, props and defaults. Items are spaced by `--angle`
// only and animate with OGAD's global `offgrid-orbit-circles` keyframes (in
// main.css), exactly as before; `delay` is accepted and ignored for the same
// reason (a per-index delay collapses the ring).
// Visual: the orbit path is a dashed hairline in the host border token
// instead of a 10% white stroke, so it reads in both themes.
import React from "react";

import { cn } from "../../../sourced/coss/lib/utils.js";

export interface OrbitingCirclesProps extends React.HTMLAttributes<HTMLDivElement> {
  className?: string;
  children?: React.ReactNode;
  reverse?: boolean;
  duration?: number;
  delay?: number;
  radius?: number;
  path?: boolean;
  iconSize?: number;
  speed?: number;
}

export function OrbitingCircles({
  className,
  children,
  reverse = false,
  duration = 20,
  delay = 10,
  radius = 160,
  path = true,
  iconSize = 30,
  speed = 1,
  ...props
}: OrbitingCirclesProps): React.JSX.Element {
  const calculatedDuration = duration / speed;
  const childCount = React.Children.count(children);

  return (
    <>
      {path && (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          version="1.1"
          data-slot="orbit-path"
          className="pointer-events-none absolute inset-0 size-full"
        >
          <circle
            className="stroke-border stroke-1 [stroke-dasharray:2_4]"
            cx="50%"
            cy="50%"
            r={radius}
            fill="none"
          />
        </svg>
      )}
      {React.Children.map(children, (child, index) => {
        const angle = (360 / childCount) * index;
        // Distribute by --angle only; keep the delay at 0 (see header).
        void delay;

        return (
          <div
            style={{
              position: "absolute",
              width: iconSize,
              height: iconSize,
              animation: `offgrid-orbit-circles ${calculatedDuration}s linear infinite ${reverse ? "reverse" : "normal"}`,
              animationDelay: "0s",
              transform: `rotate(${angle}deg) translateY(-${radius}px) rotate(-${angle}deg)`,
              ["--radius" as string]: `${radius}px`,
              ["--angle" as string]: `${angle}deg`,
            }}
            className={cn(
              "flex transform-gpu items-center justify-center",
              className,
            )}
            {...props}
          >
            {child}
          </div>
        );
      })}
    </>
  );
}
