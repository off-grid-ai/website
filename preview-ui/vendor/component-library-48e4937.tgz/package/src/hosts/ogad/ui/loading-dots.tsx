// Drop-in for OGAD `src/renderer/src/components/ui/loading-dots.tsx`.
// Same export, props (`size` small|medium, `className`), aria-hidden and the
// `offgrid-loading-dot` class whose wave keyframes live in OGAD's main.css
// (tests and styles select on it). Dots now read the primary token directly
// (OGAD maps green-500 onto it anyway) with a faint glow.
import type { ReactElement } from "react";

interface LoadingDotsProps {
  readonly size?: "small" | "medium";
  readonly className?: string;
}

/** One three-dot busy state for every Desktop surface. */
export function LoadingDots({
  size = "medium",
  className = "",
}: LoadingDotsProps): ReactElement {
  const dot = size === "small" ? "h-1 w-1" : "h-1.5 w-1.5";
  const tone =
    "offgrid-loading-dot rounded-full bg-primary shadow-[0_0_6px_rgb(var(--og-rgb-primary,52_211_153)/0.45)]";
  return (
    <span
      data-slot="loading-dots"
      className={`inline-flex items-center gap-1 px-1 ${className}`}
      aria-hidden="true"
    >
      <span className={`${dot} ${tone}`} />
      <span className={`${dot} ${tone}`} />
      <span className={`${dot} ${tone}`} />
    </span>
  );
}
