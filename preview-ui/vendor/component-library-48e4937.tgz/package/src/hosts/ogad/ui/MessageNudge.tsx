// Drop-in for OGAD `src/renderer/src/components/ui/MessageNudge.tsx`.
// Same export, props (`children`, optional `onDismiss`), role="status" and
// the "Dismiss" accessible name.
// Visual: the amber advisory keeps its meaning but sits as a quiet hairline
// row; the dismiss glyph is an icon with a small hit area. role="status"
// also lets the alive layer settle it when the text changes.
import { WarningCircle, X } from "@phosphor-icons/react";
import type * as React from "react";

export function MessageNudge({
  children,
  onDismiss,
}: {
  children: React.ReactNode;
  onDismiss?: () => void;
}): React.JSX.Element {
  return (
    <div
      role="status"
      data-slot="message-nudge"
      className="mt-2 flex items-start gap-1.5 border-t border-amber-500/15 pt-2 text-[11px] leading-relaxed text-amber-500"
    >
      <WarningCircle className="mt-[3px] h-3 w-3 shrink-0" weight="fill" />
      <span className="flex-1">{children}</span>
      {onDismiss && (
        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss"
          className="-my-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded-[3px] text-amber-500/70 transition-colors hover:bg-amber-500/10 hover:text-amber-400"
        >
          <X className="size-3" weight="bold" />
        </button>
      )}
    </div>
  );
}
