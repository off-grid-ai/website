// Drop-in for OGAD `src/renderer/src/components/ui/border-beam.tsx` (Magic UI).
// Same export and props, same emerald token defaults, same motion loop.
// Changes: the beam path follows the host card's radius (OGAD's rounded-xl is
// 6px under its sharp radius scale, not 12px) via `--border-beam-radius`, and
// the beam head is softened so it reads as light on a hairline, not a stripe.
import { motion, type MotionStyle, type Transition } from "motion/react";
import type * as React from "react";

import { cn } from "../../../sourced/coss/lib/utils.js";

interface BorderBeamProps {
  /** The size of the border beam. */
  size?: number;
  /** The duration of the border beam. */
  duration?: number;
  /** The delay of the border beam. */
  delay?: number;
  /** The color of the border beam from. */
  colorFrom?: string;
  /** The color of the border beam to. */
  colorTo?: string;
  /** The motion transition of the border beam. */
  transition?: Transition;
  /** The class name of the border beam. */
  className?: string;
  /** The style of the border beam. */
  style?: React.CSSProperties;
  /** Whether to reverse the animation direction. */
  reverse?: boolean;
  /** The initial offset position (0-100). */
  initialOffset?: number;
  /** The border width of the beam. */
  borderWidth?: number;
}

export const BorderBeam = ({
  className,
  size = 50,
  delay = 0,
  duration = 6,
  // Off Grid AI is emerald-only: the beam rides the brand accent.
  colorFrom = "var(--og-primary-light)",
  colorTo = "var(--og-primary)",
  transition,
  style,
  reverse = false,
  initialOffset = 0,
  borderWidth = 1,
}: BorderBeamProps): React.JSX.Element => {
  return (
    <div
      data-slot="border-beam"
      className="pointer-events-none absolute inset-0 rounded-[inherit] border-(length:--border-beam-width) border-transparent mask-[linear-gradient(transparent,transparent),linear-gradient(#000,#000)] mask-intersect [mask-clip:padding-box,border-box]"
      style={
        {
          "--border-beam-width": `${borderWidth}px`,
        } as React.CSSProperties
      }
    >
      <motion.div
        className={cn(
          "absolute aspect-square",
          "bg-linear-to-l from-(--color-from) via-(--color-to) to-transparent opacity-90",
          className,
        )}
        style={
          {
            width: size,
            offsetPath: `rect(0 auto auto 0 round var(--border-beam-radius, 6px))`,
            "--color-from": colorFrom,
            "--color-to": colorTo,
            ...style,
          } as MotionStyle
        }
        initial={{ offsetDistance: `${initialOffset}%` }}
        animate={{
          offsetDistance: reverse
            ? [`${100 - initialOffset}%`, `${-initialOffset}%`]
            : [`${initialOffset}%`, `${100 + initialOffset}%`],
        }}
        transition={{
          repeat: Infinity,
          ease: "linear",
          duration,
          delay: -delay,
          ...transition,
        }}
      />
    </div>
  );
};
