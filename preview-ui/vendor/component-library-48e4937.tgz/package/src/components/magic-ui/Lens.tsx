import { motion } from "framer-motion";
import { useState } from "react";

export const Lens = () => {
    const [hover, setHover] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div
                className="relative group cursor-none"
                onMouseEnter={() => setHover(true)}
                onMouseLeave={() => setHover(false)}
            >
                <span className="text-2xl font-bold">Hover Me</span>
                {hover && (
                    <motion.div
                        layoutId="lens"
                        className="absolute -inset-8 w-32 h-32 rounded-full border-2 border-black dark:border-white pointer-events-none"
                        style={{ backdropFilter: "hue-rotate(90deg)" }}
                    />
                )}
            </div>
        </div>
    );
};
