import { motion } from "framer-motion";

export const MagicScrollProgress = () => {
    return (
        <div className="w-full h-full bg-white dark:bg-neutral-900 relative">
            <motion.div
                className="absolute top-0 left-0 right-0 h-1 bg-blue-500 origin-left"
                initial={{ scaleX: 0 }}
                animate={{ scaleX: 1 }}
                transition={{ duration: 2, repeat: Infinity }}
            />
            <div className="h-full overflow-hidden p-4 text-neutral-400 text-sm">
                <p className="mb-4">Scroll content...</p>
                <p className="mb-4">Scroll content...</p>
                <p className="mb-4">Scroll content...</p>
                <p className="mb-4">Scroll content...</p>
            </div>
        </div>
    );
};
