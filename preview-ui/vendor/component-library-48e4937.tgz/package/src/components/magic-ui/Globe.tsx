export const Globe = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden relative">
            <div className="w-40 h-40 rounded-full border border-neutral-800 bg-black relative flex items-center justify-center">
                <div className="w-full h-full rounded-full border border-blue-500/10 absolute animate-pulse" />
                <div className="w-[110%] h-[30%] border border-blue-500/20 rounded-[50%] absolute rotate-45" />
                <div className="w-[110%] h-[30%] border border-blue-500/20 rounded-[50%] absolute -rotate-45" />
                <span className="text-xs text-neutral-500">Globe</span>
            </div>
        </div>
    );
};
