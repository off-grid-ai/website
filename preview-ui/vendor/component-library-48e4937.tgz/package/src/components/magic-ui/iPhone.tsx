export const iPhone = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900">
            <div className="w-32 h-64 bg-black rounded-[2.5rem] border-4 border-neutral-800 shadow-xl overflow-hidden relative">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-5 bg-black rounded-b-xl z-20" />
                <div className="w-full h-full bg-white dark:bg-neutral-900 flex items-center justify-center">
                    <span className="text-4xl text-neutral-200 dark:text-neutral-800"></span>
                </div>
            </div>
        </div>
    );
};
