import { motion } from "framer-motion";

export const AnimatedCircularProgress = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative w-20 h-20">
                <svg className="w-full h-full transform -rotate-90">
                    <circle
                        cx="40"
                        cy="40"
                        r="36"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        className="text-neutral-200 dark:text-neutral-800"
                    />
                    <motion.circle
                        cx="40"
                        cy="40"
                        r="36"
                        stroke="currentColor"
                        strokeWidth="8"
                        fill="transparent"
                        className="text-blue-500"
                        initial={{ strokeDasharray: "0 100" }}
                        animate={{ strokeDasharray: "150 100" }}
                        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                    />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center font-bold text-sm">
                    65%
                </div>
            </div>
        </div>
    );
};
