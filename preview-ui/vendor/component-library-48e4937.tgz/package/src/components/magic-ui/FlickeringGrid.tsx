import { useEffect, useState } from "react";

export const FlickeringGrid = () => {
    const [opacity, setOpacity] = useState(0.5);

    useEffect(() => {
        const interval = setInterval(() => {
            setOpacity(Math.random() * 0.5 + 0.2);
        }, 100);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full bg-black relative overflow-hidden">
            <div className="absolute inset-0 grid grid-cols-12 gap-px bg-neutral-900 opacity-20">
                {[...Array(144)].map((_, i) => (
                    <div
                        key={i}
                        className="bg-blue-500 transition-opacity duration-100"
                        style={{ opacity: Math.random() > 0.8 ? opacity : 0 }}
                    />
                ))}
            </div>
        </div>
    );
};
