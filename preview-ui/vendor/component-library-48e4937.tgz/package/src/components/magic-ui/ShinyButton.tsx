export const ShinyButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <button className="relative rounded-lg bg-gradient-to-b from-neutral-700 to-neutral-800 px-8 py-3 text-sm font-medium text-white shadow-[0px_0px_10px_2px_rgba(255,255,255,0.1)] transition-all hover:scale-105 hover:shadow-[0px_0px_20px_4px_rgba(255,255,255,0.2)]">
                <span className="absolute inset-0 rounded-lg bg-gradient-to-b from-white/20 to-transparent opacity-0 transition-opacity hover:opacity-100" />
                Shiny
            </button>
        </div>
    );
};
