export const AuroraText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <h1 className="text-4xl font-bold text-center">
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 animate-pulse">
                    Aurora
                </span>
            </h1>
        </div>
    );
};
