import { motion } from "framer-motion";

export const BlurFade = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 gap-2">
            {[0, 1, 2].map((i) => (
                <motion.div
                    key={i}
                    initial={{ opacity: 0, filter: "blur(10px)" }}
                    animate={{ opacity: 1, filter: "blur(0px)" }}
                    transition={{ delay: i * 0.2, duration: 0.5 }}
                    className="w-16 h-16 bg-neutral-200 dark:bg-neutral-800 rounded-lg"
                />
            ))}
        </div>
    );
};
