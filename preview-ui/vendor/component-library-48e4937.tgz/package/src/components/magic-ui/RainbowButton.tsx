export const RainbowButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <button className="group relative px-6 py-2 font-bold text-white transition-transform active:scale-95">
                <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-red-500 via-yellow-500 to-blue-500 opacity-75 blur-lg transition duration-1000 group-hover:opacity-100 group-hover:duration-200 animate-tilt" />
                <div className="relative rounded-lg bg-black px-6 py-2 ring-1 ring-white/10">
                    Rainbow
                </div>
            </button>
        </div>
    );
};
