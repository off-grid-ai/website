export const ProgressiveBlur = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black relative">
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent z-10" />
            <div className="text-6xl font-black text-white tracking-tighter mix-blend-overlay opacity-50">
                BLUR
            </div>
            <div className="absolute bottom-0 w-full h-16 backdrop-blur-[2px]" />
            <div className="absolute bottom-0 w-full h-12 backdrop-blur-[4px]" />
            <div className="absolute bottom-0 w-full h-8 backdrop-blur-[8px]" />
            <div className="absolute bottom-0 w-full h-4 backdrop-blur-[16px]" />
        </div>
    );
};
