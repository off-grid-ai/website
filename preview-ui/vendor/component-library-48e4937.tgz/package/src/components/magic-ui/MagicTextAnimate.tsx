import { motion } from "framer-motion";

export const MagicTextAnimate = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex overflow-hidden text-2xl font-bold">
                {["A", "n", "i", "m", "a", "t", "e"].map((letter, i) => (
                    <motion.span
                        key={i}
                        initial={{ y: "100%" }}
                        animate={{ y: 0 }}
                        transition={{ delay: i * 0.1, duration: 0.5, ease: "circOut" }}
                    >
                        {letter}
                    </motion.span>
                ))}
            </div>
        </div>
    );
};
