export const SparklesText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <div className="relative">
                <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 to-yellow-500">
                    Sparkles
                </h1>
                <div className="absolute -top-2 -right-4 text-yellow-300 animate-pulse">✨</div>
                <div className="absolute -bottom-2 -left-4 text-yellow-300 animate-pulse delay-75">✨</div>
            </div>
        </div>
    );
};
