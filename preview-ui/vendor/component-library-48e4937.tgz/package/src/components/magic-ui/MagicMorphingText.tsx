import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

export const MagicMorphingText = () => {
    const words = ["Magic", "UI", "Rocks"];
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % words.length);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <AnimatePresence mode="wait">
                <motion.div
                    key={index}
                    initial={{ opacity: 0, filter: "blur(10px)" }}
                    animate={{ opacity: 1, filter: "blur(0px)" }}
                    exit={{ opacity: 0, filter: "blur(10px)" }}
                    className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-br from-purple-500 to-cyan-500"
                >
                    {words[index]}
                </motion.div>
            </AnimatePresence>
        </div>
    );
};
