export const VideoText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <div className="relative">
                <h1 className="text-5xl font-black uppercase tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-600">
                    VIDEO
                </h1>
                <div className="absolute inset-0 bg-white/10 mix-blend-overlay animate-pulse" />
            </div>
        </div>
    );
};
