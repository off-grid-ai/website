export const NeonGradientCard = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <div className="relative w-40 h-24 rounded-xl flex items-center justify-center bg-neutral-900 group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-600 to-purple-600 rounded-xl blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt" />
                <div className="relative w-full h-full bg-black rounded-xl flex items-center justify-center">
                    <span className="text-white font-bold">Neon</span>
                </div>
            </div>
        </div>
    );
};
