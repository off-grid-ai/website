import { motion } from "framer-motion";

export const ScrollBasedVelocity = () => {
    return (
        <div className="w-full h-full flex flex-col justify-center bg-white dark:bg-neutral-900 overflow-hidden">
            <motion.div
                className="whitespace-nowrap text-4xl font-black uppercase text-neutral-900 dark:text-neutral-100"
                animate={{ x: ["0%", "-100%"] }}
                transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
            >
                Velocity Scroll - Velocity Scroll - Velocity Scroll -
            </motion.div>
            <motion.div
                className="whitespace-nowrap text-4xl font-black uppercase text-neutral-900 dark:text-neutral-100 opacity-50"
                animate={{ x: ["-100%", "0%"] }}
                transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
            >
                - Velocity Scroll - Velocity Scroll - Velocity Scroll
            </motion.div>
        </div>
    );
};
