export const RetroGrid = () => {
    return (
        <div className="w-full h-full items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden relative flex flex-col">
            <h2 className="text-4xl font-bold z-10 mt-10">RETRO</h2>
            <div className="absolute inset-0 [perspective:200px]">
                <div className="absolute inset-0 [transform:rotateX(35deg)]">
                    <div className="animate-grid w-[200%] h-[200%] -ml-[50%] -mt-[50%] bg-[linear-gradient(to_right,gray_1px,transparent_1px),linear-gradient(to_bottom,gray_1px,transparent_1px)] bg-[size:40px_40px] opacity-20" />
                </div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-white dark:from-neutral-900 to-transparent z-0" />
        </div>
    );
};
