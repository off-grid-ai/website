import { motion } from "framer-motion";

export const SmoothCursor = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 cursor-none">
            <motion.div
                className="w-6 h-6 rounded-full border-2 border-black dark:border-white"
                initial={{ x: 0, y: 0 }}
                animate={{
                    x: [0, 60, -60, 0],
                    y: [0, 40, -40, 0]
                }}
                transition={{ duration: 3, repeat: Infinity, ease: "anticipate" }}
            />
            <motion.div
                className="w-2 h-2 bg-black dark:bg-white rounded-full absolute"
                initial={{ x: 0, y: 0 }}
                animate={{
                    x: [0, 60, -60, 0],
                    y: [0, 40, -40, 0]
                }}
                transition={{ duration: 3, repeat: Infinity, ease: "anticipate", delay: 0.1 }}
            />
        </div>
    );
};
