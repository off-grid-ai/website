import { motion } from "framer-motion";

export const AnimatedList = () => {
    const items = ["Item 1", "Item 2", "Item 3"];

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="w-48 flex flex-col gap-2">
                {items.map((item, i) => (
                    <motion.div
                        key={item}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.2 }}
                        className="p-3 bg-neutral-100 dark:bg-neutral-800 rounded-lg shadow-sm"
                    >
                        <div className="h-2 w-20 bg-neutral-200 dark:bg-neutral-700 rounded" />
                    </motion.div>
                ))}
            </div>
        </div>
    );
};
