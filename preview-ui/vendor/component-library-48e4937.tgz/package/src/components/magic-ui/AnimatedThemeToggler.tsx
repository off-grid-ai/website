import { motion } from "framer-motion";
import { useState } from "react";
import { Sun, Moon } from "lucide-react";

export const AnimatedThemeToggler = () => {
    const [isDark, setIsDark] = useState(false);

    return (
        <div className={`w-full h-full flex items-center justify-center ${isDark ? 'bg-neutral-900' : 'bg-neutral-100'} transition-colors duration-500`}>
            <button
                onClick={() => setIsDark(!isDark)}
                className="relative p-2 rounded-full bg-white dark:bg-neutral-800 shadow-md"
            >
                <motion.div
                    initial={false}
                    animate={{ rotate: isDark ? 180 : 0 }}
                    transition={{ type: "spring", stiffness: 200, damping: 10 }}
                >
                    {isDark ? <Moon className="text-white w-6 h-6" /> : <Sun className="text-orange-500 w-6 h-6" />}
                </motion.div>
            </button>
        </div>
    );
};
