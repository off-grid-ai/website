import { motion } from "framer-motion";

export const OrbitingCircles = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden">
            <div className="relative w-40 h-40">
                <div className="absolute inset-0 rounded-full border border-neutral-200 dark:border-neutral-800" />
                <div className="absolute inset-[25%] rounded-full border border-neutral-200 dark:border-neutral-800" />

                <motion.div
                    className="absolute w-full h-full"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                >
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-blue-500" />
                </motion.div>

                <motion.div
                    className="absolute inset-[25%]"
                    animate={{ rotate: -360 }}
                    transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
                >
                    <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-red-500" />
                </motion.div>
            </div>
        </div>
    );
};
