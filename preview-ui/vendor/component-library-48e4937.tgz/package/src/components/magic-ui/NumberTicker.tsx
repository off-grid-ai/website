import { useState, useEffect } from "react";

export const NumberTicker = () => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setCount(prev => (prev < 100 ? prev + 1 : 0));
        }, 50);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="text-5xl font-mono font-bold tabular-nums tracking-tighter">
                {count}
            </div>
        </div>
    );
};
