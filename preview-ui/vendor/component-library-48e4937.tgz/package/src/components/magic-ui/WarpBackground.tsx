export const WarpBackground = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden relative">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-neutral-800 via-black to-black animate-pulse opacity-50" />
            <div className="grid grid-cols-2 gap-4 opacity-30 transform scale-150 rotate-12">
                <div className="w-20 h-20 border border-neutral-700 rounded-lg" />
                <div className="w-20 h-20 border border-neutral-700 rounded-lg" />
                <div className="w-20 h-20 border border-neutral-700 rounded-lg" />
                <div className="w-20 h-20 border border-neutral-700 rounded-lg" />
            </div>
            <div className="absolute z-10 font-bold text-white tracking-widest text-lg">WARP</div>
        </div>
    );
};
