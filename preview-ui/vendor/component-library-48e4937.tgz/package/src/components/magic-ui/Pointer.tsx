import { motion } from "framer-motion";

export const Pointer = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 cursor-none">
            <motion.div
                className="w-4 h-4 bg-black dark:bg-white rounded-full pointer-events-none z-50 mix-blend-difference"
                initial={{ x: 0, y: 0 }}
                animate={{
                    x: [0, 50, -50, 0],
                    y: [0, 50, -50, 0]
                }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            />
            <span className="text-sm font-medium text-neutral-500">Auto Pointer</span>
        </div>
    );
};
