import { useState } from "react";

export const InteractiveGridPattern = () => {
    const [hovered, setHovered] = useState<number | null>(null);

    return (
        <div className="w-full h-full bg-white dark:bg-neutral-900 grid grid-cols-8 grid-rows-6">
            {[...Array(48)].map((_, i) => (
                <div
                    key={i}
                    onMouseEnter={() => setHovered(i)}
                    onMouseLeave={() => setHovered(null)}
                    className="border border-neutral-100 dark:border-neutral-800 transition-colors duration-300"
                    style={{
                        backgroundColor: hovered === i ? 'rgba(59, 130, 246, 0.2)' : 'transparent'
                    }}
                />
            ))}
        </div>
    );
};
