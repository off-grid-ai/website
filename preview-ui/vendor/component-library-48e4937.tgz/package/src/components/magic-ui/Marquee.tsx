import { motion } from "framer-motion";

export const Marquee = () => {
    return (
        <div className="w-full h-full flex items-center bg-white dark:bg-neutral-900 overflow-hidden">
            <motion.div
                className="flex gap-4 whitespace-nowrap"
                animate={{ x: ["0%", "-100%"] }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            >
                {[...Array(10)].map((_, i) => (
                    <div key={i} className="px-4 py-2 bg-neutral-100 dark:bg-neutral-800 rounded-lg">
                        Item {i + 1}
                    </div>
                ))}
            </motion.div>
        </div>
    );
};
