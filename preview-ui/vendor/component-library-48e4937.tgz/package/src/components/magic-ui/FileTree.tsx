export const FileTree = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-4">
            <div className="w-full text-sm font-mono text-neutral-600 dark:text-neutral-400">
                <div className="flex items-center gap-1">📁 <span className="text-neutral-900 dark:text-neutral-200">components</span></div>
                <div className="pl-4 flex items-center gap-1 border-l border-neutral-200 dark:border-neutral-800 ml-1.5">📁 ui</div>
                <div className="pl-8 flex items-center gap-1 border-l border-neutral-200 dark:border-neutral-800 ml-1.5 text-blue-500">📄 button.tsx</div>
                <div className="pl-8 flex items-center gap-1 border-l border-neutral-200 dark:border-neutral-800 ml-1.5">📄 card.tsx</div>
            </div>
        </div>
    );
};
