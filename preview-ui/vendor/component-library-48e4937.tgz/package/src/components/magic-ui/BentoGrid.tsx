export const BentoGrid = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-4">
            <div className="grid grid-cols-3 gap-2 w-full max-w-[200px] h-32">
                <div className="col-span-2 bg-neutral-100 dark:bg-neutral-800 rounded-md" />
                <div className="col-span-1 bg-neutral-100 dark:bg-neutral-800 rounded-md" />
                <div className="col-span-1 bg-neutral-100 dark:bg-neutral-800 rounded-md" />
                <div className="col-span-2 bg-neutral-100 dark:bg-neutral-800 rounded-md" />
            </div>
        </div>
    );
};
