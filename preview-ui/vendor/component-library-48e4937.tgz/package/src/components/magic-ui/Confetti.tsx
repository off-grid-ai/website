import { motion } from "framer-motion";

export const Confetti = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden relative">
            <button className="px-4 py-2 bg-blue-500 text-white rounded-full font-bold z-10">
                Celebrate
            </button>
            {[...Array(20)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute w-2 h-2 rounded-full"
                    style={{
                        backgroundColor: ['#ff0000', '#00ff00', '#0000ff', '#ffff00'][i % 4],
                        top: '50%',
                        left: '50%'
                    }}
                    animate={{
                        x: (Math.random() - 0.5) * 200,
                        y: (Math.random() - 0.5) * 200,
                        opacity: [1, 0]
                    }}
                    transition={{ duration: 1, repeat: Infinity, repeatDelay: 1 }}
                />
            ))}
        </div>
    );
};
