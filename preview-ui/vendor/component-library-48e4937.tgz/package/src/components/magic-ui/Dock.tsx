import { motion } from "framer-motion";

export const Dock = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex items-end gap-2 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-2xl border border-neutral-200 dark:border-neutral-700">
                {[1, 2, 3, 4].map((i) => (
                    <motion.div
                        key={i}
                        whileHover={{ scale: 1.5, y: -10 }}
                        className="w-10 h-10 bg-white dark:bg-neutral-600 rounded-xl shadow-sm border border-black/5"
                    />
                ))}
            </div>
        </div>
    );
};
