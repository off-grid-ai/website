export const LightRays = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden relative">
            <div className="absolute inset-0 bg-gradient-to-t from-black to-neutral-900" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[200px] h-[200px] bg-white/5 blur-3xl rounded-full" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full shadow-[0_0_40px_20px_rgba(255,255,255,0.2)] animate-pulse" />
            <div className="w-full h-full flex items-center justify-center relative z-10 font-bold text-white tracking-widest text-xl opacity-80">
                RAYS
            </div>
        </div>
    );
};
