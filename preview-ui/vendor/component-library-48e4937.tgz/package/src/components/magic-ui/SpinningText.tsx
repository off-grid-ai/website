import { motion } from "framer-motion";

export const SpinningText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.div
                className="relative w-32 h-32 flex items-center justify-center"
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            >
                <svg viewBox="0 0 100 100" className="w-full h-full">
                    <path
                        id="circlePath"
                        d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"
                        fill="transparent"
                    />
                    <text className="fill-current text-xs font-mono uppercase">
                        <textPath href="#circlePath">
                            • Spinning Text • Spinning Text •
                        </textPath>
                    </text>
                </svg>
                <div className="absolute inset-0 flex items-center justify-center text-4xl">
                    🌀
                </div>
            </motion.div>
        </div>
    );
};
