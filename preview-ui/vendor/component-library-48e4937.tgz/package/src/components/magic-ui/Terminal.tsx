export const Terminal = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-4">
            <div className="w-full h-full bg-black rounded-lg shadow-xl overflow-hidden font-mono text-xs p-3">
                <div className="flex gap-1.5 mb-2">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500" />
                </div>
                <div className="text-green-400">$ npm install magic-ui</div>
                <div className="text-neutral-400">Installing dependencies...</div>
                <div className="text-green-400">$ start dev</div>
                <div className="text-white animate-pulse">_</div>
            </div>
        </div>
    );
};
