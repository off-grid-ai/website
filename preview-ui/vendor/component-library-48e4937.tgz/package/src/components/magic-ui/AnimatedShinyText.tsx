export const AnimatedShinyText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <p className="animate-shiny-text bg-gradient-to-r from-neutral-600 via-neutral-100 to-neutral-600 bg-[length:200%_auto] bg-clip-text text-transparent font-medium text-xl">
                Shiny Text
            </p>
        </div>
    );
};
