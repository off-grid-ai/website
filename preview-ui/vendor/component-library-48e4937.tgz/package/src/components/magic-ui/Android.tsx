export const Android = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="w-32 h-64 bg-black rounded-[2rem] border-4 border-neutral-800 relative shadow-xl">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-8 rounded-b-xl bg-black z-10" />
                <div className="w-full h-full bg-neutral-900 rounded-[1.7rem] overflow-hidden flex items-center justify-center text-neutral-500">
                    Android
                </div>
            </div>
        </div>
    );
};
