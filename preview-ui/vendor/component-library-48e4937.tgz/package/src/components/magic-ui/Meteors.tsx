export const Meteors = () => {
    return (
        <div className="w-full h-full bg-neutral-900 relative overflow-hidden flex items-center justify-center">
            <h2 className="text-white z-10 font-bold relative">Meteors</h2>
            {[...Array(5)].map((_, i) => (
                <span
                    key={i}
                    className="absolute top-1/2 left-1/2 h-0.5 w-[50px] bg-gradient-to-r from-slate-500 to-transparent animate-meteor"
                    style={{
                        top: Math.random() * 100 + '%',
                        left: Math.random() * 100 + '%',
                        animationDelay: Math.random() * 2 + 's',
                        transform: 'rotate(215deg)'
                    }}
                />
            ))}
        </div>
    );
};
