export const CodeComparison = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-950 p-4">
            <div className="flex w-full border border-neutral-800 rounded-lg overflow-hidden text-xs font-mono">
                <div className="flex-1 p-2 bg-neutral-900 text-neutral-400 border-r border-neutral-800 opacity-50">
                    <div className="text-red-400">- old()</div>
                </div>
                <div className="flex-1 p-2 bg-neutral-900 text-neutral-200">
                    <div className="text-green-400">+ new()</div>
                </div>
            </div>
        </div>
    );
};
