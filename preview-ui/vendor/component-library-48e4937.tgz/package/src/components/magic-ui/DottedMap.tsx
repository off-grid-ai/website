export const DottedMap = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-950">
            <svg viewBox="0 0 100 60" className="w-3/4 opacity-50">
                {[...Array(50)].map((_, i) => (
                    <circle
                        key={i}
                        cx={Math.random() * 100}
                        cy={Math.random() * 60}
                        r="0.5"
                        fill="white"
                    />
                ))}
                <circle cx="50" cy="30" r="1" fill="#3b82f6" className="animate-ping" />
                <circle cx="50" cy="30" r="1" fill="#3b82f6" />
            </svg>
        </div>
    );
};
