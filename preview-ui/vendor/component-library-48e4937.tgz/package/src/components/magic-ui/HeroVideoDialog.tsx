import { Play } from "lucide-react";

export const HeroVideoDialog = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative w-48 h-28 bg-black rounded-lg shadow-xl overflow-hidden group cursor-pointer">
                <div className="absolute inset-0 bg-neutral-800 flex items-center justify-center">
                    <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm group-hover:scale-110 transition-transform">
                        <Play className="w-4 h-4 text-white fill-current" />
                    </div>
                </div>
            </div>
        </div>
    );
};
