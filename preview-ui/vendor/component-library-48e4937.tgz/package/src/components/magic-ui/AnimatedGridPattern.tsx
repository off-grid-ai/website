import { motion } from "framer-motion";

export const AnimatedGridPattern = () => {
    return (
        <div className="w-full h-full bg-white dark:bg-neutral-900 overflow-hidden relative">
            <div className="absolute inset-0 opacity-20">
                {[...Array(20)].map((_, i) => (
                    <div key={i} className="flex">
                        {[...Array(20)].map((_, j) => (
                            <motion.div
                                key={j}
                                className="w-8 h-8 border border-neutral-200 dark:border-neutral-800"
                                initial={{ opacity: 0.5 }}
                                animate={{ opacity: [0.5, 1, 0.5] }}
                                transition={{ duration: 2, delay: (i + j) * 0.1, repeat: Infinity }}
                            />
                        ))}
                    </div>
                ))}
            </div>
        </div>
    );
};
