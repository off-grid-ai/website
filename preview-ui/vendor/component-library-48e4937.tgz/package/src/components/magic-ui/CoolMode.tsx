import { motion } from "framer-motion";

export const CoolMode = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.button
                whileTap={{ scale: 0.9 }}
                className="relative px-6 py-2 bg-black text-white dark:bg-white dark:text-black rounded-full font-medium"
            >
                Cool Mode
                <motion.div
                    className="absolute -top-4 -right-4 text-2xl"
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: [0, 1, 0], scale: [0.5, 1.5, 0.5], y: -20 }}
                    transition={{ duration: 1, repeat: Infinity, repeatDelay: 2 }}
                >
                    ❄️
                </motion.div>
            </motion.button>
        </div>
    );
};
