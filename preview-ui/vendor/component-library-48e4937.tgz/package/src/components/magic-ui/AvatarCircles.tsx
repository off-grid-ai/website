export const AvatarCircles = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex -space-x-4 rtl:space-x-reverse">
                {[1, 2, 3].map((i) => (
                    <div key={i} className="w-10 h-10 rounded-full border-2 border-white dark:border-neutral-900 bg-neutral-200 dark:bg-neutral-700 flex items-center justify-center text-xs font-semibold">
                        U{i}
                    </div>
                ))}
                <a className="flex h-10 w-10 items-center justify-center rounded-full border-2 border-white bg-black hover:bg-neutral-800 dark:border-neutral-900 dark:bg-white dark:hover:bg-neutral-200 text-white dark:text-black text-xs font-medium" href="">
                    +99
                </a>
            </div>
        </div>
    );
};
