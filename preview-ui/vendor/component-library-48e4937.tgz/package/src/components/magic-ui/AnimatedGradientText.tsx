

export const AnimatedGradientText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <div className="group relative mx-auto flex max-w-fit flex-row items-center justify-center rounded-2xl bg-white/10 px-4 py-1.5 text-sm font-medium shadow-[inset_0_-8px_10px_#ffffff1f] backdrop-blur-sm transition-shadow duration-500 ease-out hover:shadow-[inset_0_-5px_10px_#ffffff3f] dark:bg-black/10">
                <span className="inline-flex animate-text-gradient bg-gradient-to-r from-[#b2a8fd] via-[#8678f9] to-[#c7d2fe] bg-[200%_auto] bg-clip-text text-transparent">
                    Introducing Magic UI
                </span>
            </div>
        </div>
    );
};
