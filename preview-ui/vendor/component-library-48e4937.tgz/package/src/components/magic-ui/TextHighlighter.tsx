export const TextHighlighter = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-4 font-serif text-xl">
            <p className="leading-relaxed text-center">
                Make it{" "}
                <span className="relative inline-block px-1">
                    <span className="absolute inset-0 bg-yellow-200 dark:bg-yellow-900/50 -rotate-2 scale-105 rounded-sm" />
                    <span className="relative z-10 font-bold">pop</span>
                </span>
                {" "}with highlights.
            </p>
        </div>
    );
};
