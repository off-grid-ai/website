export const TweetCard = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-4">
            <div className="bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800 rounded-xl p-4 shadow-sm w-full max-w-[240px]">
                <div className="flex gap-2 items-center mb-2">
                    <div className="w-8 h-8 rounded-full bg-blue-500" />
                    <div className="text-xs">
                        <div className="font-bold">Magic UI</div>
                        <div className="text-neutral-500">@magicui</div>
                    </div>
                </div>
                <p className="text-xs mb-3">
                    Building the best UI library for React & Tailwind CSS. 🪄
                </p>
                <div className="text-[10px] text-neutral-400">10:00 AM · Jan 1, 2024</div>
            </div>
        </div>
    );
};
