export const DotPattern = () => {
    return (
        <div className="w-full h-full bg-white dark:bg-neutral-900 relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] dark:bg-[radial-gradient(#333_1px,transparent_1px)]" />
            <div className="relative flex items-center justify-center h-full">
                <div className="bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 px-4 py-2 rounded-lg shadow-sm">
                    Dots
                </div>
            </div>
        </div>
    );
};
