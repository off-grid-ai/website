export const ComicText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-yellow-400">
            <h1 className="text-4xl font-black text-black tracking-tighter drop-shadow-[4px_4px_0px_rgba(0,0,0,1)] -rotate-3">
                POW!
            </h1>
        </div>
    );
};
