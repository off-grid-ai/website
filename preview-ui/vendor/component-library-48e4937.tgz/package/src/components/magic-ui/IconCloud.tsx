export const IconCloud = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden">
            <div className="relative w-32 h-32">
                {[...Array(12)].map((_, i) => (
                    <div
                        key={i}
                        className="absolute w-6 h-6 bg-neutral-100 dark:bg-neutral-800 rounded-full flex items-center justify-center shadow-sm"
                        style={{
                            top: `${50 + 35 * Math.sin(i * Math.PI / 6)}%`,
                            left: `${50 + 35 * Math.cos(i * Math.PI / 6)}%`,
                            transform: 'translate(-50%, -50%)'
                        }}
                    >
                        <div className="w-3 h-3 bg-neutral-400 rounded-full opacity-50" />
                    </div>
                ))}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                    <span className="text-xs">React</span>
                </div>
            </div>
        </div>
    );
};
