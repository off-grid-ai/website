import { motion } from "framer-motion";

export const AnimatedBeam = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 relative overflow-hidden">
            <div className="flex justify-between w-48 items-center">
                <div className="w-10 h-10 bg-neutral-200 dark:bg-neutral-800 rounded-lg shadow-sm z-10" />
                <div className="w-10 h-10 bg-neutral-200 dark:bg-neutral-800 rounded-lg shadow-sm z-10" />
            </div>
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
                <path
                    d="M 100 128 L 220 128"
                    fill="none"
                    stroke="rgba(156, 163, 175, 0.3)"
                    strokeWidth="2"
                />
                <motion.path
                    d="M 100 128 L 220 128"
                    fill="none"
                    stroke="url(#gradient-beam)"
                    strokeWidth="2"
                    strokeLinecap="round"
                    initial={{ pathLength: 0, opacity: 0 }}
                    animate={{ pathLength: 1, opacity: 1 }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                />
                <defs>
                    <linearGradient id="gradient-beam" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#3b82f6" stopOpacity="0" />
                        <stop offset="50%" stopColor="#3b82f6" />
                        <stop offset="100%" stopColor="#3b82f6" stopOpacity="0" />
                    </linearGradient>
                </defs>
            </svg>
        </div>
    );
};
