export const PixelImage = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-8">
            <div className="grid grid-cols-10 gap-0.5 w-32 h-32">
                {[...Array(100)].map((_, i) => (
                    <div
                        key={i}
                        className="bg-neutral-200 dark:bg-neutral-800 hover:bg-black dark:hover:bg-white transition-colors duration-0"
                    />
                ))}
            </div>
        </div>
    );
};
