export const MagicCard = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black p-4">
            <div className="group relative flex h-full w-full flex-col items-center justify-center overflow-hidden rounded-xl border border-neutral-800 bg-neutral-900 text-neutral-200">
                <div className="pointer-events-none absolute -inset-px opacity-0 transition duration-300 group-hover:opacity-100"
                    style={{ background: "radial-gradient(600px circle at 50% 50%, rgba(255,255,255,0.1), transparent 40%)" }}
                />
                <span className="z-10 text-lg font-medium">Magic Card</span>
            </div>
        </div>
    );
};
