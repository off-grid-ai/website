import { useState, useEffect } from "react";

export const HyperText = () => {
    const [text, setText] = useState("Hyper");
    const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    useEffect(() => {
        let iterations = 0;
        const interval = setInterval(() => {
            setText(prev =>
                prev.split("")
                    .map((_, index) => {
                        if (index < iterations) return "Hyper"[index];
                        return letters[Math.floor(Math.random() * 26)];
                    })
                    .join("")
            );
            if (iterations >= 5) clearInterval(interval);
            iterations += 1 / 3;
        }, 50);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <h1 className="text-3xl font-bold font-mono">{text}</h1>
        </div>
    );
};
