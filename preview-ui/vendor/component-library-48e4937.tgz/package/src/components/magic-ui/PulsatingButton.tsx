export const PulsatingButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative">
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-20 h-20 bg-blue-500/30 rounded-full animate-pulse" />
                <button className="relative z-10 px-6 py-2 bg-blue-500 text-white rounded-full font-medium shadow-lg hover:bg-blue-600 transition-colors">
                    Pulse
                </button>
            </div>
        </div>
    );
};
