export const LineShadowText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <h1 className="text-4xl font-black uppercase italic tracking-tighter"
                style={{
                    textShadow: "2px 2px 0px rgba(0,0,0,0.2)",
                    WebkitTextStroke: "1px black"
                }}>
                <span className="text-transparent">Shadow</span>
            </h1>
        </div>
    );
};
