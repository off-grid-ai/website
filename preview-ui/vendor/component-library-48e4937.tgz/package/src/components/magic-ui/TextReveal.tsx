export const TextReveal = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <h1 className="text-3xl font-bold text-neutral-800 dark:text-neutral-600">
                Reveal{" "}
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-white/20 animate-text-reveal">
                    Magic
                </span>
            </h1>
        </div>
    );
};
