import { useState, useEffect } from "react";

export const TypingAnimation = () => {
    const text = "Typing...";
    const [displayed, setDisplayed] = useState("");

    useEffect(() => {
        let i = 0;
        const interval = setInterval(() => {
            setDisplayed(text.slice(0, i + 1));
            i++;
            if (i > text.length) i = 0;
        }, 200);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <h1 className="text-2xl font-mono border-r-2 border-black dark:border-white animate-pulse pr-1">
                {displayed}
            </h1>
        </div>
    );
};
