export const StripedPattern = () => {
    return (
        <div className="w-full h-full bg-white dark:bg-neutral-900 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10"
                style={{
                    backgroundImage: "linear-gradient(45deg, #000 25%, transparent 25%, transparent 50%, #000 50%, #000 75%, transparent 75%, transparent)",
                    backgroundSize: "20px 20px"
                }}
            />
            <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-white dark:bg-neutral-800 px-4 py-2 rounded shadow border border-neutral-200 dark:border-neutral-700">
                    Stripes
                </div>
            </div>
        </div>
    );
};
