export const Safari = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900 p-4">
            <div className="w-full h-full bg-white dark:bg-neutral-800 rounded-lg shadow-xl overflow-hidden flex flex-col border border-neutral-200 dark:border-neutral-700">
                <div className="h-8 bg-neutral-100 dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 flex items-center px-2 gap-1.5">
                    <div className="w-3 h-3 rounded-full bg-red-500" />
                    <div className="w-3 h-3 rounded-full bg-yellow-500" />
                    <div className="w-3 h-3 rounded-full bg-green-500" />
                    <div className="flex-1 flex justify-center">
                        <div className="w-32 h-5 bg-neutral-200 dark:bg-neutral-700 rounded text-[10px] flex items-center justify-center text-neutral-500">
                            magicui.design
                        </div>
                    </div>
                </div>
                <div className="flex-1 flex items-center justify-center p-4 text-center text-sm text-neutral-400">
                    Browser Content
                </div>
            </div>
        </div>
    );
};
