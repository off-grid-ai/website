export const Ripple = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 relative overflow-hidden">
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full flex items-center justify-center opacity-30">
                {[...Array(5)].map((_, i) => (
                    <div
                        key={i}
                        className="absolute rounded-full border border-blue-500/50"
                        style={{
                            width: `${(i + 1) * 20}%`,
                            height: `${(i + 1) * 20}%`,
                        }}
                    />
                ))}
            </div>
            <div className="z-10 text-2xl font-bold text-neutral-900 dark:text-white">Ripple</div>
        </div>
    );
};
