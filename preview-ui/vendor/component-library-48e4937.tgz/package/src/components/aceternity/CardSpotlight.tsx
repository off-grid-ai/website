import { useRef, useState } from "react";

export const CardSpotlight = () => {
    const divRef = useRef<HTMLDivElement>(null);
    const [isFocused] = useState(false);
    const [position, setPosition] = useState({ x: 0, y: 0 });
    const [opacity, setOpacity] = useState(0);

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!divRef.current || isFocused) return;

        const div = divRef.current;
        const rect = div.getBoundingClientRect();

        setPosition({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    };



    const handleMouseEnter = () => {
        setOpacity(1);
    };

    const handleMouseLeave = () => {
        setOpacity(0);
    };

    return (
        <div
            ref={divRef}
            onMouseMove={handleMouseMove}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            className="group relative flex h-full w-full items-center justify-center overflow-hidden rounded-xl border border-slate-800 bg-slate-900 bg-[rgb(15,23,42)]"
        >
            <div
                className="pointer-events-none absolute -inset-px opacity-0 transition duration-300"
                style={{
                    opacity,
                    background: `radial-gradient(100px circle at ${position.x}px ${position.y}px, rgba(255,255,255,0.1), transparent 100%)`,
                }}
            />
            <h3 className="z-10 text-white font-bold opacity-80">Spotlight</h3>
        </div>
    );
};
