import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

const words = ["Dream", "Build", "Ship", "Scale"];

export const ContainerTextFlip = () => {
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % words.length);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <div className="text-xl font-bold text-white flex gap-2">
                <span>We</span>
                <div className="relative h-8 w-20 overflow-hidden bg-neutral-800 rounded px-2 flex items-center justify-center">
                    <AnimatePresence mode="wait">
                        <motion.span
                            key={index}
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            exit={{ y: -20, opacity: 0 }}
                            className="absolute text-emerald-400"
                        >
                            {words[index]}
                        </motion.span>
                    </AnimatePresence>
                </div>
            </div>
        </div>
    );
};
