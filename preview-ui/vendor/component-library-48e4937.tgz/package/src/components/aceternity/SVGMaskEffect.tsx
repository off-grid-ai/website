import { motion } from "framer-motion";
import { useState } from "react";

export const SVGMaskEffect = () => {
    const [isHovered, setIsHovered] = useState(false);

    return (
        <div
            className="h-full w-full flex items-center justify-center bg-neutral-900 overflow-hidden relative cursor-pointer"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
        >
            <div className="text-4xl font-bold text-white opacity-20 absolute z-0">
                MASK
            </div>

            <motion.div
                className="absolute inset-0 bg-white mix-blend-overlay z-10 flex items-center justify-center"
                animate={{
                    maskSize: isHovered ? "100% 100%" : "0% 0%",
                    WebkitMaskSize: isHovered ? "400px" : "150px"
                } as any}
                style={{
                    maskImage: "url(https://raw.githubusercontent.com/aceternity/ui/main/public/mask.svg)",
                    maskPosition: "center",
                    maskRepeat: "no-repeat",
                    WebkitMaskImage: "radial-gradient(circle, black 50%, transparent 100%)", // Fallback for preview
                }}
            >
                <div className="text-4xl font-bold text-red-500">
                    MASK
                </div>
            </motion.div>
        </div>
    );
};
