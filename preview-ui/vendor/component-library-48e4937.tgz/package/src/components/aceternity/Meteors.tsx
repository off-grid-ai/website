import { motion } from "framer-motion";

export const Meteors = () => {
    return (
        <div className="h-full w-full bg-slate-900 relative flex items-center justify-center overflow-hidden">

            {[...Array(5)].map((_, i) => (
                <motion.span
                    key={i}
                    className="absolute w-0.5 h-0.5 bg-white rounded-full shadow-[0_0_0_1px_#ffffff10]"
                    style={{
                        top: Math.random() * 100 + "%",
                        left: Math.random() * 100 + "%",
                        rotate: "215deg"
                    }}
                    animate={{
                        top: ["0%", "100%"],
                        left: [Math.random() * 100 + "%", Math.random() * 100 - 50 + "%"],
                        opacity: [1, 0]
                    }}
                    transition={{
                        duration: Math.random() * 2 + 1,
                        repeat: Infinity,
                        ease: "linear",
                        delay: Math.random() * 2
                    }}
                >
                    <span className="absolute top-1/2 left-1/2 -translate-y-1/2 w-[50px] h-[1px] bg-gradient-to-r from-slate-500 to-transparent" />
                </motion.span>
            ))}

            <div className="relative z-10 bg-slate-800/50 backdrop-blur-md p-4 rounded-xl border border-slate-700">
                <h3 className="text-slate-100 font-bold">Meteors</h3>
            </div>
        </div>
    );
};
