import { motion } from "framer-motion";

export const BackgroundLines = () => {
    return (
        <div className="relative w-full h-full bg-neutral-950 flex items-center justify-center overflow-hidden">

            {/* Lines */}
            <div className="absolute inset-0 flex items-center justify-center opacity-30">
                {[...Array(10)].map((_, i) => (
                    <motion.div
                        key={i}
                        className="absolute w-full h-[1px] bg-gradient-to-r from-transparent via-neutral-500 to-transparent"
                        style={{ top: `${i * 10}%` }}
                        animate={{
                            x: [-100, 100],
                            opacity: [0, 1, 0]
                        }}
                        transition={{
                            duration: 3 + Math.random() * 2,
                            repeat: Infinity,
                            ease: "linear",
                            delay: Math.random() * 2
                        }}
                    />
                ))}
                {[...Array(10)].map((_, i) => (
                    <motion.div
                        key={`v-${i}`}
                        className="absolute h-full w-[1px] bg-gradient-to-b from-transparent via-neutral-500 to-transparent"
                        style={{ left: `${i * 10}%` }}
                        animate={{
                            y: [-100, 100],
                            opacity: [0, 1, 0]
                        }}
                        transition={{
                            duration: 3 + Math.random() * 2,
                            repeat: Infinity,
                            ease: "linear",
                            delay: Math.random() * 2
                        }}
                    />
                ))}
            </div>

            <div className="relative z-10 bg-neutral-950/80 p-3 rounded-lg border border-neutral-800 backdrop-blur-sm">
                <span className="text-white text-xs font-mono">System Online</span>
            </div>
        </div>
    );
};
