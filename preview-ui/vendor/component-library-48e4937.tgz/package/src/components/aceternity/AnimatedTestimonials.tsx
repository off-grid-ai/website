import { motion, AnimatePresence } from 'framer-motion';
import { useState, useEffect } from 'react';

const testimonials = [
    { quote: "Amazing!", name: "Sarah" },
    { quote: "Love it.", name: "Mike" },
    { quote: "Superb.", name: "Alex" },
];

export const AnimatedTestimonials = () => {
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            setIndex((prev) => (prev + 1) % testimonials.length);
        }, 2000);
        return () => clearInterval(timer);
    }, []);

    return (
        <div className="relative w-full max-w-[180px] h-24 flex items-center justify-center">
            <AnimatePresence mode="wait">
                <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10, rotate: -2 }}
                    animate={{ opacity: 1, y: 0, rotate: 0 }}
                    exit={{ opacity: 0, y: -10, rotate: 2 }}
                    transition={{ duration: 0.3 }}
                    className="absolute inset-0 bg-white border border-neutral-100 shadow-lg rounded-xl p-3 flex flex-col items-center justify-center text-center"
                >
                    <p className="text-neutral-600 text-xs font-medium italic mb-1">"{testimonials[index].quote}"</p>
                    <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-green-400 to-teal-500 mb-1" />
                    <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">{testimonials[index].name}</span>
                </motion.div>
            </AnimatePresence>
            <div className="absolute -bottom-2 -right-2 w-full h-full bg-neutral-100 rounded-xl -z-10 rotate-2 opacity-50" />
        </div>
    );
};
