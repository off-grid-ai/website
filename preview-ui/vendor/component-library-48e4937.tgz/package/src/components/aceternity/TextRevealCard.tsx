import { motion } from "framer-motion";
import { useState } from "react";

export const TextRevealCard = () => {
    const [, setIsHovered] = useState(false);

    return (
        <div
            className="w-full h-full bg-[#1d1c20] flex items-center justify-center overflow-hidden cursor-pointer group"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
        >
            <div className="relative">
                <p className="text-neutral-500 text-xl font-bold group-hover:opacity-0 transition-opacity duration-500">
                    Hover to Reveal
                </p>
                <motion.p
                    className="text-[#2eb9cc] text-xl font-bold absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-0"

                >
                    Aceternity UI
                </motion.p>
                <motion.div
                    className="absolute inset-0 bg-[#1d1c20] mix-blend-color group-hover:hidden"
                />
            </div>
        </div>
    );
};
