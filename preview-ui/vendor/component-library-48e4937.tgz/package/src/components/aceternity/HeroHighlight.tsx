

export const HeroHighlight = () => {
    return (
        <div className="h-full w-full bg-white dark:bg-black flex items-center justify-center">
            <div className="text-xl px-4 md:text-2xl font-bold text-neutral-700 dark:text-white max-w-4xl leading-relaxed lg:leading-snug text-center mx-auto">
                With{" "}
                <span className="relative inline-block pb-1 px-1 rounded-lg bg-gradient-to-r from-indigo-300 to-purple-300 dark:from-indigo-500 dark:to-purple-500">
                    <span className="relative text-white z-10">aceternity</span>
                </span>
            </div>
        </div>
    );
};
