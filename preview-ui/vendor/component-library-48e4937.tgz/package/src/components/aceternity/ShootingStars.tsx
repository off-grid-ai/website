import { motion } from "framer-motion";

export const ShootingStars = () => {
    return (
        <div className="w-full h-full bg-slate-900 flex items-center justify-center relative overflow-hidden">

            {[...Array(6)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute h-[1px] bg-gradient-to-r from-transparent via-blue-100 to-transparent"
                    style={{
                        width: Math.random() * 100 + 50 + "px",
                        top: Math.random() * 100 + "%",
                        left: Math.random() * 50 + "%",
                        rotate: "-45deg"
                    }}
                    animate={{
                        x: [0, 200],
                        y: [0, 200],
                        opacity: [1, 0]
                    }}
                    transition={{
                        duration: Math.random() * 1 + 0.5,
                        repeat: Infinity,
                        delay: Math.random() * 2,
                        ease: "easeIn"
                    }}
                />
            ))}

            <div className="flex flex-col items-center z-10">
                <span className="text-white font-bold text-xl tracking-tight">STARS</span>
            </div>
        </div>
    );
};
