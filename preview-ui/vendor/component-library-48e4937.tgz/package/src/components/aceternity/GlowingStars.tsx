import { motion } from "framer-motion";

export const GlowingStars = () => {
    return (
        <div className="w-full h-full bg-black flex items-center justify-center p-4 overflow-hidden relative">
            <div className="absolute inset-0 bg-neutral-900/50" />

            {[...Array(10)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute w-1 h-1 bg-white rounded-full shadow-[0_0_10px_rgba(255,255,255,0.8)]"
                    style={{
                        top: `${Math.random() * 100}%`,
                        left: `${Math.random() * 100}%`,
                    }}
                    animate={{
                        opacity: [0, 1, 0],
                        scale: [0, 1.5, 0]
                    }}
                    transition={{
                        duration: 2 + Math.random() * 3,
                        repeat: Infinity,
                        delay: Math.random() * 2
                    }}
                />
            ))}

            <div className="relative z-10 text-center">
                <h3 className="text-white font-bold text-lg">Glowing Stars</h3>
                <p className="text-neutral-400 text-xs">Background Effect</p>
            </div>
        </div>
    );
};
