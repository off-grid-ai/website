import { motion } from "framer-motion";
import { useState, useEffect } from "react";

const chars = "!@#$%^&*()_+-=[]{}|;:,.<>?";

export const EncryptedText = () => {
    const [text, setText] = useState("ENCRYPTED");
    const target = "ENCRYPTED";

    useEffect(() => {
        const interval = setInterval(() => {
            setText(target.split("").map((char) => {
                if (Math.random() > 0.9) return char;
                return chars[Math.floor(Math.random() * chars.length)];
            }).join(""));
        }, 100);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-black font-mono">
            <motion.div
                className="text-green-500 font-bold text-xl tracking-widest relative"
            >
                {text}
                <div className="absolute -bottom-2 w-full h-[2px] bg-green-500/50 blur-[2px]" />
            </motion.div>
        </div>
    );
};
