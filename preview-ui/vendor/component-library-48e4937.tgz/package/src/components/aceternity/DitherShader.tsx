import { motion } from "framer-motion";

export const DitherShader = () => {
    return (
        <div className="relative w-full h-full bg-neutral-900 flex items-center justify-center overflow-hidden">
            {/* Simplified Dither Effect using CSS radial gradients and blend modes */}
            <div
                className="absolute inset-0 z-0 opacity-50"
                style={{
                    backgroundImage: "radial-gradient(circle at center, white 1px, transparent 1px)",
                    backgroundSize: "4px 4px",
                }}
            />
            <motion.div
                className="relative z-10 w-24 h-24 bg-gradient-to-tr from-pink-500 to-yellow-500 rounded-full blur-xl"
                animate={{
                    scale: [1, 1.2, 1],
                    rotate: [0, 90, 0]
                }}
                transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                }}
            />
            <h3 className="relative z-20 text-white font-bold text-xl mix-blend-difference">Dither</h3>
        </div>
    );
};
