import { motion } from "framer-motion";

export const HeroParallax = () => {
    return (
        <div className="h-full w-full bg-neutral-900 overflow-hidden perspective-1000 flex flex-col items-center justify-center">
            <div className="flex gap-4 opacity-50 transform rotate-x-12 rotate-z-20 -transtale-y-20 scale-110">
                {/* Row 1 */}
                <div className="flex flex-col gap-4">
                    {[1, 2, 3].map(i => (
                        <motion.div
                            key={i}
                            className="w-24 h-16 bg-white rounded-lg opacity-80"
                            animate={{ y: [0, -100] }}
                            transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
                        />
                    ))}
                </div>

                {/* Row 2 (Reverse) */}
                <div className="flex flex-col gap-4 mt-8">
                    {[1, 2, 3].map(i => (
                        <motion.div
                            key={i}
                            className="w-24 h-16 bg-white rounded-lg opacity-80"
                            animate={{ y: [-100, 0] }}
                            transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
                        />
                    ))}
                </div>

                {/* Row 3 */}
                <div className="flex flex-col gap-4">
                    {[1, 2, 3].map(i => (
                        <motion.div
                            key={i}
                            className="w-24 h-16 bg-white rounded-lg opacity-80"
                            animate={{ y: [0, -100] }}
                            transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
                        />
                    ))}
                </div>
            </div>

            <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-transparent to-neutral-900" />
            <h3 className="absolute bottom-4 text-white font-bold text-sm z-10">Parallax</h3>
        </div>
    );
};
