import { motion } from "framer-motion";

// Renaming internal export to avoid conflict if any, but file name matches
export const Carousel = () => {
    const images = [
        "https://images.unsplash.com/photo-1554080353-a576cf803bda?ixlib=rb-4.0.3&auto=format&fit=crop&w=3387&q=80",
        "https://images.unsplash.com/photo-1505144808419-1957a94ca61e?ixlib=rb-4.0.3&auto=format&fit=crop&w=3070&q=80",
        "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?ixlib=rb-4.0.3&auto=format&fit=crop&w=3540&q=80",
    ];

    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900 rounded-xl overflow-hidden">
            <div className="relative w-full overflow-hidden flex">
                <motion.div
                    className="flex"
                    animate={{
                        x: ["0%", "-100%"]
                    }}
                    transition={{
                        duration: 10,
                        ease: "linear",
                        repeat: Infinity
                    }}
                >
                    {[...images, ...images].map((src, i) => (
                        <div key={i} className="min-w-[120px] h-[80px] m-2 rounded-lg overflow-hidden border border-neutral-200">
                            <img src={src} className="w-full h-full object-cover" alt="carousel item" />
                        </div>
                    ))}
                </motion.div>
            </div>
        </div>
    );
};
