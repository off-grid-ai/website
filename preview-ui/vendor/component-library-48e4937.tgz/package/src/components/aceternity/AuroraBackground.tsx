import { motion } from "framer-motion";

export const AuroraBackground = () => {
    return (
        <div className="relative w-full h-full overflow-hidden bg-zinc-50 dark:bg-zinc-900">
            <motion.div
                className="absolute -inset-[10px] opacity-50"
                style={{
                    backgroundImage: `
                        repeating-linear-gradient(100deg, #60a5fa 10%, #e879f9 15%, #60a5fa 20%, #818cf8 25%, #60a5fa 30%)
                    `,
                    filter: "blur(10px)",
                }}
                animate={{
                    backgroundPosition: ["0% 50%", "100% 50%"],
                }}
                transition={{
                    duration: 10,
                    ease: "linear",
                    repeat: Infinity,
                }}
            />
            <div className="absolute inset-0 bg-zinc-50/90 dark:bg-zinc-900/90 backdrop-blur-sm" />
            <div className="relative z-10 w-full h-full flex items-center justify-center">
                <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-neutral-900 to-neutral-700 dark:from-neutral-200 dark:to-neutral-500">
                    Aurora
                </h1>
            </div>
        </div>
    );
};
