export const GridAndDotBackgrounds = () => {
    return (
        <div className="w-full h-full flex flex-row">
            {/* Grid Half */}
            <div className="w-1/2 h-full bg-white dark:bg-black relative flex items-center justify-center border-r border-neutral-200 dark:border-neutral-800">
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:14px_24px]" />
                <span className="relative z-10 text-[10px] font-bold text-neutral-500">Grid</span>
            </div>

            {/* Dot Half */}
            <div className="w-1/2 h-full bg-white dark:bg-black relative flex items-center justify-center">
                <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] dark:bg-[radial-gradient(#333_1px,transparent_1px)]" />
                <span className="relative z-10 text-[10px] font-bold text-neutral-500">Dot</span>
            </div>
        </div>
    );
};
