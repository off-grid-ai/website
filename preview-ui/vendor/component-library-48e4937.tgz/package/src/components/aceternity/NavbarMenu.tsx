import { motion } from "framer-motion";

export const NavbarMenu = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-start pt-8 bg-neutral-50 dark:bg-black relative">
            <motion.div
                className="rounded-full bg-white dark:bg-black border border-black/[0.2] dark:border-white/[0.2] shadow-input flex justify-center space-x-4 px-4 py-2"
            >
                <span className="text-sm dark:text-neutral-300">Home</span>
                <span className="text-sm dark:text-neutral-300">Services</span>
                <span className="text-sm dark:text-neutral-300">About</span>
            </motion.div>

            {/* Simulating hover menu */}
            <motion.div
                className="mt-4 bg-white dark:bg-black border border-black/[0.2] dark:border-white/[0.2] rounded-xl p-4 shadow-xl"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.5 }}
            >
                <div className="w-32 h-20 bg-neutral-100 dark:bg-neutral-800 rounded-lg flex items-center justify-center text-xs text-neutral-500">
                    Menu Content
                </div>
            </motion.div>
        </div>
    );
};
