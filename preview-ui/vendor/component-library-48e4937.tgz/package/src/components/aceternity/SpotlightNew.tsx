import { motion } from "framer-motion";

export const SpotlightNew = () => {
    return (
        <div className="h-full w-full rounded-md flex md:items-center md:justify-center bg-black/[0.96] antialiased bg-grid-white/[0.02] relative overflow-hidden">

            {/* Spotlight New Implementation */}
            <motion.div
                className="absolute h-full w-full top-0 left-0 z-[1] opacity-0"
                animate={{ opacity: 1 }}
                transition={{ duration: 1 }}
            >
                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-sky-500/20 to-transparent blur-3xl transform -translate-y-1/2" />
                <div className="absolute bottom-0 right-0 w-full h-full bg-gradient-to-l from-transparent via-purple-500/20 to-transparent blur-3xl transform translate-y-1/2" />
            </motion.div>

            <div className="p-4 max-w-7xl mx-auto relative z-10 w-full pt-10 md:pt-0">
                <h1 className="text-xl md:text-3xl font-bold text-center bg-clip-text text-transparent bg-gradient-to-b from-neutral-50 to-neutral-400 bg-opacity-50">
                    New Spotlight
                </h1>
            </div>
        </div>
    );
};
