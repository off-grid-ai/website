import { motion } from "framer-motion";

export const DraggableCard = () => {
    return (
        <div className="relative w-full h-full bg-white dark:bg-neutral-900 flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 grid grid-cols-6 grid-rows-4 gap-1 opacity-10 pointer-events-none">
                {[...Array(24)].map((_, i) => (
                    <div key={i} className="border border-neutral-500 rounded-sm" />
                ))}
            </div>

            <motion.div
                drag
                dragConstraints={{ left: -50, right: 50, top: -50, bottom: 50 }}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                className="w-32 h-24 bg-gradient-to-br from-indigo-500 to-violet-500 rounded-xl shadow-2xl flex flex-col items-center justify-center cursor-grab active:cursor-grabbing z-10"
            >
                <span className="text-white font-bold text-sm">Drag Me</span>
                <div className="w-8 h-1 bg-white/30 rounded-full mt-2" />
            </motion.div>
        </div>
    );
};
