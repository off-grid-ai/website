import { motion } from "framer-motion";
import { useState } from "react";

export const ThreeDCardEffect = () => {
    const [x, setX] = useState(0);
    const [y, setY] = useState(0);

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        const rect = e.currentTarget.getBoundingClientRect();
        const width = rect.width;
        const height = rect.height;
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;
        const xPct = mouseX / width - 0.5;
        const yPct = mouseY / height - 0.5;
        setX(xPct);
        setY(yPct);
    };

    const handleMouseLeave = () => {
        setX(0);
        setY(0);
    };

    return (
        <motion.div
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            className="relative w-32 h-24 bg-neutral-900 rounded-xl group/card border border-white/10 shadow-xl"
            style={{
                borderRadius: "12px",
                transformStyle: "preserve-3d",
            }}
            animate={{
                rotateX: -y * 20,
                rotateY: x * 20,
            }}
            transition={{
                type: "spring",
                stiffness: 300,
                damping: 20,
            }}
        >
            <div
                className="absolute inset-0 flex items-center justify-center"
                style={{ transform: "translateZ(50px)" }}
            >
                <div className="w-8 h-8 bg-green-500 rounded-full shadow-[0_0_20px_rgba(34,197,94,0.5)]" />
            </div>
            <div
                className="absolute inset-4 rounded-lg border border-white/20"
                style={{ transform: "translateZ(20px)" }}
            />
        </motion.div>
    );
};
