import { motion } from "framer-motion";

export const BackgroundBeamsCollision = () => {
    return (
        <div className="relative w-full h-full bg-neutral-950 flex flex-col items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-neutral-950/20" />

            {/* Beam 1 - Horizontal */}
            <motion.div
                className="absolute h-[2px] w-[200px] bg-gradient-to-r from-transparent via-purple-500 to-transparent top-1/2 left-0"
                animate={{
                    x: [-200, 400],
                    opacity: [0, 1, 0]
                }}
                transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "linear"
                }}
            />

            {/* Beam 2 - Vertical */}
            <motion.div
                className="absolute w-[2px] h-[200px] bg-gradient-to-b from-transparent via-blue-500 to-transparent left-1/2 top-0"
                animate={{
                    y: [-200, 400],
                    opacity: [0, 1, 0]
                }}
                transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "linear",
                    delay: 1
                }}
            />

            {/* Central Explosion/Collision Loop */}
            <motion.div
                className="absolute z-10 w-24 h-24 bg-gradient-to-r from-purple-500/20 to-blue-500/20 blur-xl rounded-full"
                animate={{
                    scale: [0.8, 1.5, 0.8],
                    opacity: [0.3, 0.8, 0.3],
                }}
                transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                }}
            />

            <motion.div
                className="relative z-20 flex flex-col items-center"
            >
                <div className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-500 to-cyan-500 filter drop-shadow-2xl">
                    Explosion
                </div>
            </motion.div>
        </div>
    );
};
