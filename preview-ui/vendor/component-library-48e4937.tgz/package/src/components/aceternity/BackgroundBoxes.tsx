import { motion } from "framer-motion";

export const BackgroundBoxes = () => {
    return (
        <div className="relative w-full h-full bg-slate-950 overflow-hidden flex items-center justify-center rounded-xl p-4">
            <div className="absolute inset-0 w-full h-full bg-slate-900 z-20 [mask-image:radial-gradient(transparent,white)] pointer-events-none" />

            <div className="absolute inset-0 grid grid-cols-6 grid-rows-3 gap-1 opacity-50">
                {[...Array(18)].map((_, i) => (
                    <motion.div
                        key={i}
                        whileHover={{ backgroundColor: "#3b82f6", opacity: 1, transition: { duration: 0 } }}
                        animate={{ transition: { duration: 2 } }}
                        className="bg-slate-800/10 border border-slate-700/30 rounded-sm relative z-10"
                    >
                        {i % 2 === 0 && (
                            <svg viewBox="0 0 24 24" fill="none" className="absolute top-1 left-1 w-3 h-3 text-slate-700 stroke-current opacity-20">
                                <path d="M12 6v12m6-6H6" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                        )}
                    </motion.div>
                ))}
            </div>

            <h3 className="relative z-30 text-white font-bold text-xl pointer-events-none">Boxes</h3>
        </div>
    );
};
