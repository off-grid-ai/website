import { motion } from "framer-motion";

const cards = [
    { title: "Productivity", src: "https://images.unsplash.com/photo-1512756290469-ec264b7fbf87?q=80&w=2553&auto=format&fit=crop" },
    { title: "Design", src: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?q=80&w=2671&auto=format&fit=crop" },
    { title: "Code", src: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?q=80&w=2670&auto=format&fit=crop" },
    { title: "AI", src: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?q=80&w=2565&auto=format&fit=crop" },
];

export const AppleCardsCarousel = () => {
    return (
        <div className="relative w-full h-full flex items-center overflow-hidden pl-4 mask-linear">
            <motion.div
                className="flex gap-4"
                drag="x"
                dragConstraints={{ right: 0, left: -200 }}
            >
                {cards.map((card, idx) => (
                    <div key={idx} className="relative w-32 h-40 rounded-[20px] bg-gray-100 dark:bg-neutral-900 overflow-hidden flex-shrink-0 border border-neutral-200">
                        <img
                            src={card.src}
                            alt={card.title}
                            className="absolute inset-0 w-full h-full object-cover opacity-80 hover:opacity-100 transition-opacity"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                        <span className="absolute bottom-4 left-4 text-white text-xs font-bold">{card.title}</span>
                    </div>
                ))}
            </motion.div>
        </div>
    );
};
