import { motion } from "framer-motion";
import { useState } from "react";

export const FocusCards = () => {
    const [hovered, setHovered] = useState<number | null>(null);

    return (
        <div className="w-full h-full flex items-center justify-center gap-2 px-2">
            {[0, 1, 2].map((i) => (
                <motion.div
                    key={i}
                    onMouseEnter={() => setHovered(i)}
                    onMouseLeave={() => setHovered(null)}
                    className="h-32 flex-1 rounded-xl bg-neutral-200 dark:bg-neutral-800 overflow-hidden relative cursor-pointer"
                    animate={{
                        filter: hovered !== null && hovered !== i ? "blur(4px) grayscale(100%)" : "blur(0px) grayscale(0%)",
                        scale: hovered === i ? 1.05 : 1,
                    }}
                >
                    <img
                        src={`https://picsum.photos/seed/${i + 50}/200/300`}
                        className="w-full h-full object-cover"
                        alt="focus card"
                    />
                    <div className="absolute inset-0 bg-black/20" />
                    <div className="absolute bottom-2 left-2 text-white font-bold text-xs">Card {i + 1}</div>
                </motion.div>
            ))}
        </div>
    );
};
