import { motion } from "framer-motion";

export const GoogleGeminiEffect = () => {
    return (
        <div className="w-full h-full bg-black flex flex-col items-center justify-center overflow-hidden">
            {/* Simplified line drawing effect */}
            <div className="relative w-full h-40">
                <motion.svg
                    viewBox="0 0 100 100"
                    className="w-full h-full opacity-50"
                    fill="none"
                    strokeWidth="0.5"
                >
                    <motion.path
                        d="M0 50 Q 50 100 100 50"
                        stroke="url(#gradient1)"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: 1 }}
                        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
                    />
                    <motion.path
                        d="M0 50 Q 50 0 100 50"
                        stroke="url(#gradient2)"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: 1 }}
                        transition={{ duration: 2, repeat: Infinity, repeatType: "reverse", ease: "easeInOut", delay: 0.5 }}
                    />
                    <defs>
                        <linearGradient id="gradient1" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="#3b82f6" />
                            <stop offset="100%" stopColor="#a855f7" />
                        </linearGradient>
                        <linearGradient id="gradient2" x1="0%" y1="0%" x2="100%" y2="0%">
                            <stop offset="0%" stopColor="#f97316" />
                            <stop offset="100%" stopColor="#ec4899" />
                        </linearGradient>
                    </defs>
                </motion.svg>
            </div>

            <span className="text-white text-xs font-mono mt-2 opacity-80">Gemini Effect</span>
        </div>
    );
};
