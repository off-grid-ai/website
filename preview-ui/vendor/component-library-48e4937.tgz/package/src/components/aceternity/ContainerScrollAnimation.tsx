import { motion } from "framer-motion";

export const ContainerScrollAnimation = () => {
    return (
        <div className="relative w-full h-full flex flex-col items-center justify-center overflow-hidden bg-neutral-100 dark:bg-neutral-950 p-4">
            <div className="perspective-1000">
                <motion.div
                    className="w-32 h-20 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-xl shadow-2xl p-2 overflow-hidden flex flex-col gap-2"
                    animate={{
                        rotateX: [0, 20, 0],
                        scale: [1, 0.9, 1],
                        y: [0, -10, 0]
                    }}
                    transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                >
                    <div className="w-full h-2 bg-neutral-200 dark:bg-neutral-800 rounded-full" />
                    <div className="w-3/4 h-2 bg-neutral-200 dark:bg-neutral-800 rounded-full" />
                    <div className="w-1/2 h-2 bg-neutral-200 dark:bg-neutral-800 rounded-full" />
                    <div className="mt-auto w-full h-8 bg-neutral-100 dark:bg-neutral-800 rounded-md" />
                </motion.div>
            </div>
        </div>
    );
};
