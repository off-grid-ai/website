import { useRef } from "react";
import { motion, useMotionTemplate, useMotionValue } from "framer-motion";

export const PointerHighlight = () => {
    const ref = useRef<HTMLDivElement>(null);
    const mouseX = useMotionValue(0);
    const mouseY = useMotionValue(0);

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!ref.current) return;
        const rect = ref.current.getBoundingClientRect();
        mouseX.set(e.clientX - rect.left);
        mouseY.set(e.clientY - rect.top);
    };

    return (
        <div
            ref={ref}
            onMouseMove={handleMouseMove}
            className="w-full h-full bg-neutral-950 flex items-center justify-center group relative overflow-hidden"
        >
            <motion.div
                className="pointer-events-none absolute -inset-px rounded-xl opacity-0 group-hover:opacity-100 transition duration-300"
                style={{
                    background: useMotionTemplate`radial-gradient(150px circle at ${mouseX}px ${mouseY}px, rgba(14, 165, 233, 0.15), transparent 80%)`,
                }}
            />
            <div className="relative border border-white/10 bg-neutral-900/50 p-4 rounded-xl backdrop-blur-sm">
                <h3 className="text-white font-bold text-sm">Hover Me</h3>
                <p className="text-neutral-400 text-[10px]">Spotlight effect</p>
            </div>
        </div>
    );
};
