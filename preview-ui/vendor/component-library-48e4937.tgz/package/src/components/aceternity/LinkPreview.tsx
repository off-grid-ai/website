import { motion } from "framer-motion";

export const LinkPreview = () => {
    return (
        <div className="w-full h-full flex items-center justify-center gap-4 bg-white dark:bg-neutral-900">
            <div className="relative group cursor-pointer">
                <span className="text-neutral-500 dark:text-neutral-400 font-bold underline decoration-dotted">Hover Link</span>

                {/* Tooltip Link Preview */}
                <motion.div
                    className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-32 h-20 bg-black rounded-xl overflow-hidden shadow-xl border border-white/10 opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity duration-300 z-20"
                    initial={{ y: 10, scale: 0.9 }}
                    whileHover={{ y: 0, scale: 1 }}
                >
                    <div className="w-full h-2/3 bg-neutral-800" />
                    <div className="w-full h-1/3 bg-neutral-900 p-2 flex items-center">
                        <div className="w-4 h-4 bg-white/20 rounded-sm" />
                        <div className="ml-2 w-16 h-2 bg-white/20 rounded-sm" />
                    </div>
                </motion.div>
            </div>
        </div>
    );
};
