import { motion } from "framer-motion";

export const TextHoverEffect = () => {
    return (
        <div className="h-full bg-neutral-900 flex items-center justify-center">
            <svg
                viewBox="0 0 300 100" // Adjusted viewBox
                className="w-full h-full select-none"
            >
                <text
                    x="50%"
                    y="50%"
                    textAnchor="middle"
                    dominantBaseline="middle"
                    strokeWidth="1" // Increased stroke width for visibility
                    className="font-[helvetica] font-bold fill-transparent stroke-neutral-500 opacity-30 text-6xl" // Reduced font size
                >
                    A
                </text>
                <motion.text
                    x="50%"
                    y="50%"
                    textAnchor="middle"
                    dominantBaseline="middle"
                    strokeWidth="1"
                    className="font-[helvetica] font-bold fill-transparent stroke-red-500 text-6xl"
                    initial={{ strokeDashoffset: 1000, strokeDasharray: 1000 }}
                    animate={{
                        strokeDashoffset: 0,
                        strokeDasharray: 1000,
                    }}
                    transition={{
                        duration: 4,
                        ease: "easeInOut",
                        repeat: Infinity,
                        repeatType: "reverse"
                    }}
                >
                    A
                </motion.text>
            </svg>
        </div>
    );
};
