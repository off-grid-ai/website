

export const SignupForm = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-black p-4">
            <div className="max-w-md w-full mx-auto rounded-none md:rounded-2xl p-4 md:p-6 shadow-input bg-white dark:bg-black border border-neutral-200 dark:border-neutral-800">
                <h2 className="font-bold text-lg text-neutral-800 dark:text-neutral-200 text-center mb-4">
                    Welcome
                </h2>
                <form className="space-y-2" onSubmit={(e) => e.preventDefault()}>
                    <div className="flex flex-col space-y-1">
                        <div className="h-2 w-12 bg-neutral-200 dark:bg-neutral-700 rounded" />
                        <div className="h-8 w-full bg-neutral-100 dark:bg-neutral-800 rounded px-2 border-none" />
                    </div>
                    <div className="flex flex-col space-y-1">
                        <div className="h-2 w-16 bg-neutral-200 dark:bg-neutral-700 rounded" />
                        <div className="h-8 w-full bg-neutral-100 dark:bg-neutral-800 rounded px-2 border-none" />
                    </div>
                    <button className="bg-gradient-to-br from-black to-neutral-600 w-full text-white rounded-md h-8 font-medium text-xs mt-2">
                        Sign up
                    </button>
                </form>
            </div>
        </div>
    );
};
