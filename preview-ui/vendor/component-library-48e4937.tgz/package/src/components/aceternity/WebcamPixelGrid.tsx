import { motion } from "framer-motion";

export const WebcamPixelGrid = () => {
    return (
        <div className="w-full h-full bg-neutral-900 grid grid-cols-12 grid-rows-8 gap-[2px] p-2 overflow-hidden">
            {/* Simulating pixel grid noise since we can't access webcam in preview */}
            {[...Array(96)].map((_, i) => (
                <motion.div
                    key={i}
                    className="bg-neutral-800 rounded-[1px]"
                    animate={{
                        backgroundColor: ["#262626", "#404040", "#262626"]
                    }}
                    transition={{
                        duration: 0.5 + Math.random(),
                        repeat: Infinity,
                        delay: Math.random() * 2
                    }}
                />
            ))}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className="bg-black/80 text-white px-3 py-1 text-xs rounded-full">Webcam Feed</span>
            </div>
        </div>
    );
};
