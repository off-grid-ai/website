import { motion } from "framer-motion";

export const Timeline = () => {
    return (
        <div className="w-full h-full bg-white dark:bg-neutral-950 flex p-4 overflow-hidden relative">
            <div className="w-8 flex flex-col items-center">
                <div className="w-[1px] h-full bg-neutral-200 dark:bg-neutral-700 relative">
                    <motion.div
                        className="absolute top-0 w-full bg-gradient-to-b from-purple-500 via-blue-500 to-transparent w-[2px] -left-[0.5px]"
                        animate={{ height: ["0%", "100%"] }}
                        transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                    />
                </div>
            </div>
            <div className="flex-1 space-y-8 pl-4 pt-4">
                {[1, 2].map((i) => (
                    <div key={i} className="space-y-2">
                        <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-full bg-neutral-800 dark:bg-neutral-200" />
                            <h4 className="font-bold text-sm">Step {i}</h4>
                        </div>
                        <p className="text-xs text-neutral-500">Timeline content description.</p>
                    </div>
                ))}
            </div>
        </div>
    );
};
