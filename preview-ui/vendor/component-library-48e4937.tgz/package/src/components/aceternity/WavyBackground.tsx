import { motion } from "framer-motion";

export const WavyBackground = () => {
    return (
        <div className="w-full h-full bg-black flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 flex flex-col gap-4 items-center justify-center opacity-30">
                {[...Array(5)].map((_, i) => (
                    <motion.div
                        key={i}
                        className="w-[200%] h-12 border-t border-b border-pink-500"
                        style={{
                            borderRadius: "50%",
                        }}
                        animate={{
                            x: [-100, 0]
                        }}
                        transition={{
                            duration: 5 + i,
                            repeat: Infinity,
                            ease: "linear",
                            repeatType: "mirror"
                        }}
                    />
                ))}
            </div>
            <p className="z-10 text-white font-bold text-xl mix-blend-difference">Wavy</p>
        </div>
    );
};
