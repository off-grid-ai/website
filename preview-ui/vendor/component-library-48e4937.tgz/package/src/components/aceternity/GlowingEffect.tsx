

export const GlowingEffect = () => {
    return (
        <div className="w-full h-full bg-black flex items-center justify-center p-8">
            <div className="relative group">
                {/* Glow Background */}
                <div className="absolute -inset-1 bg-gradient-to-r from-red-600 to-violet-600 rounded-lg blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>

                {/* Content */}
                <div className="relative px-7 py-4 bg-black rounded-lg leading-none flex items-center divide-x divide-gray-600">
                    <span className="flex items-center space-x-2">
                        <span className="pr-2 text-gray-100">Glow</span>
                    </span>
                    <span className="pl-2 text-indigo-400 group-hover:text-gray-100 transition duration-200">Effect</span>
                </div>
            </div>
        </div>
    );
};
