import { motion } from "framer-motion";

export const WobbleCard = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-8">
            <motion.div
                className="w-full h-40 bg-pink-900 rounded-2xl p-6 relative overflow-hidden"
                whileHover={{
                    scale: 1.05,
                    rotateX: 5,
                    rotateY: 5,
                }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
            >
                <div className="relative z-10">
                    <h2 className="text-white font-bold text-lg">Wobble Card</h2>
                    <div className="w-12 h-1 bg-white/50 rounded-full mt-2" />
                </div>

                {/* Noise pattern simulated */}
                <div className="absolute inset-0 bg-gradient-to-br from-pink-800 to-indigo-900 opacity-80" />
                <motion.div
                    className="absolute -right-10 -bottom-10 w-32 h-32 bg-white/10 rounded-full blur-2xl"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 4, repeat: Infinity }}
                />
            </motion.div>
        </div>
    );
};
