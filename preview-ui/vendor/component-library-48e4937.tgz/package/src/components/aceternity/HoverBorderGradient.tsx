import { useState } from "react";
import { motion } from "framer-motion";

export const HoverBorderGradient = () => {
    const [hovered, setHovered] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <div
                className="relative flex justify-center items-center text-white bg-black/40 backdrop-blur-md rounded-full px-4 py-2 cursor-pointer overflow-hidden"
                onMouseEnter={() => setHovered(true)}
                onMouseLeave={() => setHovered(false)}
            >
                {hovered && (
                    <motion.div
                        className="absolute inset-0 z-0"
                        initial={{ rotate: 0 }}
                        animate={{ rotate: 360 }}
                        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        style={{
                            background: "conic-gradient(from 0deg, transparent 0 340deg, white 360deg)",
                            scale: 2
                        }}
                    />
                )}
                <div className="absolute inset-[1px] bg-black rounded-full z-0" />
                <span className="relative z-10 text-xs font-medium">Hover Me</span>
            </div>
        </div>
    );
};
