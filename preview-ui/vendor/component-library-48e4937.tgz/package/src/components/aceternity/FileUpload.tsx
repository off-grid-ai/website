import { motion } from "framer-motion";
import { Upload } from "lucide-react";

export const FileUpload = () => {
    return (
        <div className="w-full h-full flex items-center justify-center p-4">
            <div className="w-full h-full border-2 border-dashed border-neutral-300 dark:border-neutral-700 rounded-xl flex flex-col items-center justify-center bg-neutral-50 dark:bg-neutral-900 group hover:border-neutral-400 dark:hover:border-neutral-500 transition-colors">
                <motion.div
                    className="p-3 bg-white dark:bg-neutral-800 rounded-full shadow-sm mb-2"
                    whileHover={{ y: -5 }}
                >
                    <Upload className="w-5 h-5 text-neutral-500" />
                </motion.div>
                <div className="text-center">
                    <p className="text-sm font-bold text-neutral-600 dark:text-neutral-300">Upload File</p>
                    <p className="text-[10px] text-neutral-400">Drag & drop or Click</p>
                </div>
            </div>
        </div>
    );
};
