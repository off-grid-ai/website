import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

const placeholders = ["What is the weather?", "How to build a SaaS?", "Write a poem"];

export const PlaceholdersVanishInput = () => {
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % placeholders.length);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative w-48 h-10 bg-neutral-100 dark:bg-neutral-800 rounded-full flex items-center px-4 overflow-hidden shadow-sm">
                <AnimatePresence mode="wait">
                    <motion.span
                        key={placeholders[index]}
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -20, opacity: 0 }}
                        transition={{ duration: 0.3 }}
                        className="absolute text-sm text-neutral-500 truncate w-full pr-8"
                    >
                        {placeholders[index]}
                    </motion.span>
                </AnimatePresence>
                <div className="absolute right-2 w-6 h-6 bg-black dark:bg-white rounded-full flex items-center justify-center">
                    <div className="w-2 h-0.5 bg-white dark:bg-black" />
                </div>
            </div>
        </div>
    );
};
