import { motion } from "framer-motion";

export const FloatingNavbar = () => {
    return (
        <div className="w-full h-full flex flex-col relative bg-neutral-50 dark:bg-neutral-950 overflow-hidden">

            {/* Content Scroll Simulation */}
            <motion.div
                className="w-full p-4 space-y-4 opacity-50"
                animate={{ y: [-20, -100] }}
                transition={{ duration: 5, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
            >
                <div className="w-full h-32 bg-neutral-200 rounded-xl" />
                <div className="w-full h-32 bg-neutral-200 rounded-xl" />
                <div className="w-full h-32 bg-neutral-200 rounded-xl" />
            </motion.div>

            {/* Navbar */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 w-[80%]">
                <motion.div
                    className="flex items-center justify-between px-4 py-2 bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-full shadow-lg"
                    initial={{ y: -50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.5 }}
                >
                    <div className="w-4 h-4 bg-black rounded-full" />
                    <div className="flex gap-2 text-[10px] items-center text-neutral-500">
                        <span>Home</span>
                        <span>About</span>
                        <span className="bg-black text-white px-2 py-0.5 rounded-full">Login</span>
                    </div>
                </motion.div>
            </div>
        </div>
    );
};
