import { motion } from "framer-motion";

export const MacbookScroll = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-end bg-neutral-100 dark:bg-neutral-900 pb-4">
            {/* Screen */}
            <div className="w-48 h-32 bg-black rounded-t-xl border-4 border-neutral-300 dark:border-neutral-700 relative overflow-hidden flex items-center justify-center">
                <div className="w-8 h-8 rounded-full bg-white/10" />
                <motion.div
                    className="absolute inset-x-0 h-full bg-gradient-to-t from-blue-500/20 to-transparent"
                    animate={{ y: [0, 50, 0] }}
                    transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                />
            </div>
            {/* Base */}
            <div className="w-60 h-2 bg-neutral-300 dark:bg-neutral-700 rounded-b-xl" />
            <div className="w-8 h-1 bg-neutral-400 dark:bg-neutral-600 rounded-b-md" />
        </div>
    );
};
