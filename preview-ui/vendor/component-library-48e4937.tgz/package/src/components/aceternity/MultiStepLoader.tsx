import { motion } from "framer-motion";
import { useState, useEffect } from "react";

const steps = ["Checking", "Verifying", "Connecting", "Complete"];

export const MultiStepLoader = () => {
    const [currentStep, setCurrentStep] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentStep((prev) => (prev + 1) % (steps.length + 1));
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-900 text-white font-mono text-sm">
            <div className="space-y-2">
                {steps.map((step, i) => (
                    <motion.div
                        key={step}
                        className="flex items-center gap-2"
                        initial={{ opacity: 0.3 }}
                        animate={{ opacity: i < currentStep ? 0.3 : i === currentStep ? 1 : 0.1 }}
                    >
                        <div className={`w-2 h-2 rounded-full ${i <= currentStep ? "bg-green-500" : "bg-neutral-700"}`} />
                        <span>{step}</span>
                    </motion.div>
                ))}
            </div>
        </div>
    );
};
