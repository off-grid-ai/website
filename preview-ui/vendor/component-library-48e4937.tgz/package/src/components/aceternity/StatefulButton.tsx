import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { Loader2, Check } from "lucide-react";

export const StatefulButton = () => {
    const [status, setStatus] = useState<"idle" | "loading" | "success">("idle");

    const handleClick = () => {
        if (status !== "idle") return;
        setStatus("loading");
        setTimeout(() => {
            setStatus("success");
            setTimeout(() => setStatus("idle"), 2000);
        }, 1500);
    };

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-black">
            <button
                onClick={handleClick}
                className="relative bg-black dark:bg-white text-white dark:text-black px-8 py-2 rounded-full font-medium transition-all active:scale-95 w-32 h-10 flex items-center justify-center overflow-hidden"
            >
                <AnimatePresence mode="wait">
                    {status === "idle" && (
                        <motion.span
                            key="idle"
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            exit={{ y: -20, opacity: 0 }}
                        >
                            Submit
                        </motion.span>
                    )}
                    {status === "loading" && (
                        <motion.span
                            key="loading"
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            exit={{ y: -20, opacity: 0 }}
                        >
                            <Loader2 className="w-5 h-5 animate-spin" />
                        </motion.span>
                    )}
                    {status === "success" && (
                        <motion.span
                            key="success"
                            initial={{ y: 20, opacity: 0 }}
                            animate={{ y: 0, opacity: 1 }}
                            exit={{ y: -20, opacity: 0 }}
                        >
                            <Check className="w-5 h-5" />
                        </motion.span>
                    )}
                </AnimatePresence>
            </button>
        </div>
    );
};
