import { motion } from "framer-motion";

export const DottedGlowBackground = () => {
    return (
        <div className="relative w-full h-full bg-black flex items-center justify-center overflow-hidden">
            <div
                className="absolute inset-0 opacity-20"
                style={{
                    backgroundImage: "radial-gradient(#333 1px, transparent 1px)",
                    backgroundSize: "16px 16px"
                }}
            />

            <motion.div
                className="absolute w-64 h-64 bg-purple-500/30 rounded-full blur-[80px]"
                animate={{
                    x: [-50, 50, -50],
                    y: [-20, 20, -20],
                }}
                transition={{
                    duration: 5,
                    repeat: Infinity,
                    ease: "easeInOut"
                }}
            />

            <div className="relative z-10 bg-black/50 border border-white/10 p-4 rounded-xl backdrop-blur-md">
                <span className="text-white font-mono text-sm">Glow</span>
            </div>
        </div>
    );
};
