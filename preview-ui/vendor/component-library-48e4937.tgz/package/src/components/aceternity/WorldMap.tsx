import { motion } from "framer-motion";

export const WorldMap = () => {
    return (
        <div className="w-full h-full bg-black flex items-center justify-center overflow-hidden relative">
            {/* Abstract Map Dots */}
            <div className="absolute inset-0 flex items-center justify-center opacity-20">
                <div className="grid grid-cols-12 gap-4">
                    {[...Array(48)].map((_, i) => (
                        <div key={i} className="w-1 h-1 bg-white rounded-full" />
                    ))}
                </div>
            </div>

            {/* Connection Lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none">
                <motion.path
                    d="M 50 150 Q 150 50 250 150"
                    fill="none"
                    stroke="url(#lineGradient)"
                    strokeWidth="2"
                    strokeDasharray="10 10"
                    initial={{ strokeDashoffset: 100 }}
                    animate={{ strokeDashoffset: 0 }}
                    transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
                />
                <defs>
                    <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#3b82f6" />
                        <stop offset="100%" stopColor="#a855f7" />
                    </linearGradient>
                </defs>
            </svg>

            <div className="relative z-10 bg-neutral-900/80 px-3 py-1 rounded-full border border-neutral-800">
                <span className="text-white text-xs font-mono">Global Connection</span>
            </div>
        </div>
    );
};
