import { motion } from "framer-motion";

export const TooltipCard = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-sky-50 dark:bg-neutral-900 overflow-hidden">
            <div className="relative group p-4 border border-sky-100 bg-white shadow-xl rounded-xl">
                <div className="font-bold text-sky-500">Hover for Info</div>

                {/* Tooltip Content */}
                <motion.div
                    className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 w-48 bg-black text-white p-3 rounded-lg text-xs opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-20"
                    initial={{ y: 10, scale: 0.9 }}
                    whileHover={{ y: 0, scale: 1 }}
                >
                    <p>This is a detailed tooltip that appears on hover with animation.</p>
                    <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-black rotate-45" />
                </motion.div>
            </div>
        </div>
    );
};
