import { motion } from 'framer-motion';

export const ThreeDPin = () => {
    return (
        <div className="flex items-center justify-center p-4">
            <motion.div
                className="relative"
                initial={{ rotateX: 0 }}
                animate={{ rotateX: [0, 20, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
            >
                {/* Pin Head */}
                <motion.div
                    className="w-16 h-12 bg-neutral-900 rounded-xl border border-white/10 flex items-center justify-center shadow-[0_8px_16px_rgba(0,0,0,0.4)] relative z-10"
                    whileHover={{ scale: 1.1, rotateX: 10 }}
                >
                    <span className="text-xs font-bold text-green-400">Pin</span>
                </motion.div>

                {/* Pin Leg */}
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 w-[2px] h-16 bg-gradient-to-b from-green-500 to-transparent blur-[0.5px]" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 translate-y-16 w-[4px] h-[4px] rounded-full bg-green-500 blur-[2px]" />

                {/* Base Ripple */}
                <motion.div
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 translate-y-16 w-12 h-12 border border-green-500/30 rounded-full"
                    style={{ rotateX: 65 }}
                    animate={{ scale: [1, 2], opacity: [1, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                />
            </motion.div>
        </div>
    );
};
