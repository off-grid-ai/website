import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

const items = ["Rotate", "Layout", "Flip"];

export const LayoutTextFlip = () => {
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % items.length);
        }, 1500);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-900 overflow-hidden">
            <div className="text-3xl font-bold text-white relative h-10 w-32 flex items-center justify-center">
                <AnimatePresence mode="popLayout">
                    <motion.div
                        key={items[index]}
                        initial={{ rotateX: -90, opacity: 0 }}
                        animate={{ rotateX: 0, opacity: 1 }}
                        exit={{ rotateX: 90, opacity: 0 }}
                        transition={{ duration: 0.5 }}
                        className="absolute inset-0 flex items-center justify-center"
                    >
                        {items[index]}
                    </motion.div>
                </AnimatePresence>
            </div>
        </div>
    );
};
