import { motion } from "framer-motion";

export const ParallaxScroll = () => {
    return (
        <div className="w-full h-full bg-neutral-100 dark:bg-neutral-900 flex overflow-hidden p-2 gap-2">
            <div className="w-1/3 flex flex-col gap-2">
                {[1, 2, 3].map(i => (
                    <motion.div
                        key={i}
                        className="w-full aspect-[2/3] bg-neutral-300 dark:bg-neutral-700 rounded-lg"
                        animate={{ y: [0, -50] }}
                        transition={{ duration: 4, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
                    />
                ))}
            </div>
            <div className="w-1/3 flex flex-col gap-2 pt-8">
                {[1, 2, 3].map(i => (
                    <motion.div
                        key={i}
                        className="w-full aspect-[2/3] bg-neutral-400 dark:bg-neutral-600 rounded-lg"
                        animate={{ y: [0, -80] }}
                        transition={{ duration: 5, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
                    />
                ))}
            </div>
            <div className="w-1/3 flex flex-col gap-2">
                {[1, 2, 3].map(i => (
                    <motion.div
                        key={i}
                        className="w-full aspect-[2/3] bg-neutral-300 dark:bg-neutral-700 rounded-lg"
                        animate={{ y: [0, -50] }}
                        transition={{ duration: 4, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
                    />
                ))}
            </div>
        </div>
    );
};
