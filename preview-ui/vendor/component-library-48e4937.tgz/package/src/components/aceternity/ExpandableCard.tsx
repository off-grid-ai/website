import { motion } from "framer-motion";
import { useState } from "react";
import { X } from "lucide-react";

export const ExpandableCard = () => {
    const [expanded, setExpanded] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center">
            <motion.div
                layout
                onClick={() => setExpanded(!expanded)}
                className="bg-neutral-100 dark:bg-neutral-800 rounded-xl cursor-pointer shadow-lg overflow-hidden"
                style={{
                    width: expanded ? 240 : 100,
                    height: expanded ? 160 : 100,
                }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
                <motion.div layout className="p-4 flex flex-col h-full">
                    <div className="flex justify-between items-start">
                        <motion.div layout className="w-8 h-8 rounded-full bg-green-500 mb-2" />
                        {expanded && (
                            <motion.button
                                initial={{ opacity: 0 }}
                                animate={{ opacity: 1 }}
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setExpanded(false);
                                }}
                            >
                                <X className="w-4 h-4 text-neutral-500" />
                            </motion.button>
                        )}
                    </div>
                    <motion.h3 layout className="font-bold text-neutral-800 dark:text-neutral-200">
                        {expanded ? "Expanded Card Title" : "Click Me"}
                    </motion.h3>
                    {expanded && (
                        <motion.p
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="text-xs text-neutral-500 mt-2"
                        >
                            This is the expanded content showing more details about this items.
                        </motion.p>
                    )}
                </motion.div>
            </motion.div>
        </div>
    );
};
