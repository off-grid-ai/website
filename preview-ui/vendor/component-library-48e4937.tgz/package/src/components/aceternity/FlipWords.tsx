import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

const words = ["Better", "Faster", "Stronger", "Smarter"];

export const FlipWords = () => {
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % words.length);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-950">
            <div className="text-2xl font-bold dark:text-white">
                Build
                <AnimatePresence mode="wait">
                    <motion.span
                        key={index}
                        initial={{ opacity: 0, y: 10, filter: "blur(8px)" }}
                        animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                        exit={{ opacity: 0, y: -10, filter: "blur(8px)" }}
                        transition={{ duration: 0.4 }}
                        className="inline-block ml-2 text-blue-500"
                    >
                        {words[index]}
                    </motion.span>
                </AnimatePresence>
            </div>
        </div>
    );
};
