

export const StickyBanner = () => {
    return (
        <div className="w-full h-full bg-neutral-100 dark:bg-neutral-900 overflow-hidden relative">
            <div className="absolute top-0 inset-x-0 bg-yellow-400 text-black text-xs font-bold py-1 text-center shadow-md z-10">
                Special Offer: 50% Off!
            </div>
            <div className="pt-8 px-4 space-y-2 overflow-y-auto h-full scrollbar-hide">
                {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-20 bg-white dark:bg-neutral-800 rounded-lg shadow-sm" />
                ))}
            </div>
        </div>
    );
};
