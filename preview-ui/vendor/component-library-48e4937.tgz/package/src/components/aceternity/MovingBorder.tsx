import { motion } from "framer-motion";

export const MovingBorder = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <div className="relative p-[1px] overflow-hidden rounded-lg">
                <motion.div
                    className="absolute inset-0"
                    style={{
                        background: "conic-gradient(from 90deg at 50% 50%, #E2CBFF 0%, #393BB2 50%, #E2CBFF 100%)",
                    }}
                    animate={{ rotate: 360 }}
                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                />
                <div className="relative bg-slate-900 text-white rounded-lg p-4 px-6 z-10 w-full h-full flex items-center justify-center">
                    Button
                </div>
            </div>
        </div>
    );
};
