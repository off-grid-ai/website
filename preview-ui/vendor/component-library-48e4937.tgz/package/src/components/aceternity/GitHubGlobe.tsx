import { motion } from "framer-motion";

export const GitHubGlobe = () => {
    return (
        <div className="w-full h-full bg-black flex items-center justify-center overflow-hidden relative">
            {/* Simplified Globe via rotating dots */}
            <motion.div
                className="relative w-32 h-32 rounded-full border border-white/10"
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            >
                {[...Array(8)].map((_, i) => (
                    <div
                        key={i}
                        className="absolute w-1 h-1 bg-white rounded-full"
                        style={{
                            top: `${Math.random() * 100}%`,
                            left: `${Math.random() * 100}%`,
                            opacity: Math.random()
                        }}
                    />
                ))}

                {/* Arcs */}
                <div className="absolute inset-0 rounded-full border-t border-r border-blue-500/50 rotate-45" />
                <div className="absolute inset-2 rounded-full border-b border-l border-purple-500/50 -rotate-12" />
            </motion.div>

            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />

            <div className="absolute bottom-4 left-0 w-full text-center">
                <span className="text-white font-mono text-xs opacity-70">Globe</span>
            </div>
        </div>
    );
};
