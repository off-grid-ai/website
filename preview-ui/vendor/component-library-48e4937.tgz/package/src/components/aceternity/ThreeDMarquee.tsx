import { motion } from 'framer-motion';

export const ThreeDMarquee = () => {
    const icons = ["React", "Vite", "Tailwind", "Framer", "Node", "TypeScript", "Next"];

    return (
        <div className="relative flex w-full h-full overflow-hidden items-center justify-center [mask-image:linear-gradient(to_right,transparent,black_20%,black_80%,transparent)]">
            <motion.div
                className="flex gap-8 whitespace-nowrap"
                animate={{
                    x: [0, -400],
                }}
                transition={{
                    duration: 10,
                    repeat: Infinity,
                    ease: "linear",
                }}
            >
                {[...icons, ...icons, ...icons].map((icon, i) => (
                    <div key={i} className="text-sm font-bold text-neutral-400 bg-neutral-100 px-3 py-1 rounded-md border border-neutral-200">
                        {icon}
                    </div>
                ))}
            </motion.div>
        </div>
    );
};
