import { motion } from "framer-motion";
import { useState, useRef } from "react";

export const Compare = () => {
    const [sliderX, setSliderX] = useState(50);
    const containerRef = useRef<HTMLDivElement>(null);

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!containerRef.current) return;
        const rect = containerRef.current.getBoundingClientRect();
        const x = Math.max(0, Math.min(100, ((e.clientX - rect.left) / rect.width) * 100));
        setSliderX(x);
    };

    return (
        <div
            ref={containerRef}
            onMouseMove={handleMouseMove}
            className="relative w-full h-full overflow-hidden bg-neutral-100 dark:bg-neutral-900 cursor-ew-resize flex items-center justify-center"
        >
            <div className="absolute inset-0 flex items-center justify-center bg-white">
                <span className="text-neutral-900 font-bold text-xl opacity-20">LIGHT</span>
            </div>

            <motion.div
                className="absolute inset-0 flex items-center justify-center bg-black overflow-hidden"
                style={{ clipPath: `inset(0 ${100 - sliderX}% 0 0)` }}
            >
                <span className="text-white font-bold text-xl opacity-20">DARK</span>
            </motion.div>

            <div
                className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-10"
                style={{ left: `${sliderX}%` }}
            >
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg border border-neutral-200" />
            </div>
        </div>
    );
};
