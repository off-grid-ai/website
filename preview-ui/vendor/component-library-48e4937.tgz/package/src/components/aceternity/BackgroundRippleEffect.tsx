import { motion } from "framer-motion";

export const BackgroundRippleEffect = () => {
    return (
        <div className="relative w-full h-full bg-white dark:bg-black flex flex-col items-center justify-center overflow-hidden">
            <h2 className="z-10 text-xl font-bold text-black dark:text-white">Ripple</h2>

            {/* Ripples */}
            {[...Array(5)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute border border-black/5 dark:border-white/5 rounded-full"
                    style={{
                        width: "100px",
                        height: "100px",
                    }}
                    animate={{
                        scale: [1, 5],
                        opacity: [0.5, 0],
                        borderWidth: ["1px", "0px"]
                    }}
                    transition={{
                        duration: 3,
                        repeat: Infinity,
                        delay: i * 0.6,
                        ease: "easeOut"
                    }}
                />
            ))}
        </div>
    );
};
