
import { useRef, useState } from "react";

export const GlareCard = () => {
    const ref = useRef<HTMLDivElement>(null);
    const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        if (!ref.current) return;
        const rect = ref.current.getBoundingClientRect();
        setMousePosition({
            x: (e.clientX - rect.left) / rect.width,
            y: (e.clientY - rect.top) / rect.height,
        });
    };

    return (
        <div className="w-full h-full flex items-center justify-center p-4 bg-neutral-900">
            <div
                ref={ref}
                onMouseMove={handleMouseMove}
                className="w-32 h-44 bg-neutral-800 rounded-xl relative overflow-hidden group"
            >
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-400 to-yellow-300" />
                </div>

                {/* Glare Layer */}
                <div
                    className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300 mix-blend-overlay"
                    style={{
                        transform: `translateX(${(mousePosition.x - 0.5) * 200}%) translateY(${(mousePosition.y - 0.5) * 200}%) rotate(45deg)`
                    }}
                />

                <div className="absolute bottom-2 left-2 text-white/50 text-[10px] font-mono">
                    GLARE
                </div>
            </div>
        </div>
    );
};
