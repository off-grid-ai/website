import { motion } from "framer-motion";

export const ResizableNavbar = () => {
    return (
        <div className="w-full h-full bg-neutral-900 flex flex-col justify-end pb-8 items-center">
            <motion.div
                className="bg-neutral-800 border border-white/10 rounded-2xl flex items-center justify-between px-4 overflow-hidden"
                animate={{
                    width: ["200px", "280px", "200px"],
                    height: ["50px", "60px", "50px"]
                }}
                transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                }}
            >
                <div className="w-6 h-6 bg-white/20 rounded-full" />
                <div className="flex gap-2">
                    <div className="w-12 h-2 bg-white/10 rounded-full" />
                    <div className="w-8 h-2 bg-white/10 rounded-full" />
                </div>
            </motion.div>
        </div>
    );
};
