import { motion } from "framer-motion";

export const ColourfulText = () => {
    const colors = [
        "text-purple-500",
        "text-blue-500",
        "text-green-500",
        "text-yellow-500",
        "text-orange-500",
        "text-red-500",
    ];

    return (
        <div className="flex flex-col items-center justify-center h-full w-full bg-black">
            <div className="flex text-3xl font-bold">
                {"RAINBOW".split("").map((char, i) => (
                    <motion.span
                        key={i}
                        className={colors[i % colors.length]}
                        animate={{
                            y: [-5, 5, -5],
                            filter: ["brightness(1)", "brightness(1.5)", "brightness(1)"]
                        }}
                        transition={{
                            duration: 2,
                            repeat: Infinity,
                            delay: i * 0.1,
                            ease: "easeInOut"
                        }}
                    >
                        {char}
                    </motion.span>
                ))}
            </div>
        </div>
    );
};
