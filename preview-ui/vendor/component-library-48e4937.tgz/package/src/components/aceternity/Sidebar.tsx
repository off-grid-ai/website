"use client";
import React, { useState, createContext, useContext } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X, ChevronDown } from "lucide-react";
import { cn } from "../../utils/cn";
import { Link } from "react-router-dom";

// --- Types ---
interface Links {
    label: string;
    href: string;
    icon: React.JSX.Element | React.ReactNode;
}

// --- Context ---
interface SidebarContextProps {
    open: boolean;
    setOpen: React.Dispatch<React.SetStateAction<boolean>>;
    animate: boolean;
}

const SidebarContext = createContext<SidebarContextProps | undefined>(
    undefined
);

export const useSidebar = () => {
    const context = useContext(SidebarContext);
    if (!context) {
        throw new Error("useSidebar must be used within a SidebarProvider");
    }
    return context;
};

// --- Providers ---
export const SidebarProvider = ({
    children,
    open: openProp,
    setOpen: setOpenProp,
    animate = true,
}: {
    children: React.ReactNode;
    open?: boolean;
    setOpen?: React.Dispatch<React.SetStateAction<boolean>>;
    animate?: boolean;
}) => {
    const [openState, setOpenState] = useState(false);

    const open = openProp !== undefined ? openProp : openState;
    const setOpen = setOpenProp !== undefined ? setOpenProp : setOpenState;

    return (
        <SidebarContext.Provider value={{ open, setOpen, animate }}>
            {children}
        </SidebarContext.Provider>
    );
};

export const Sidebar = ({
    children,
    open,
    setOpen,
    animate,
}: {
    children: React.ReactNode;
    open?: boolean;
    setOpen?: React.Dispatch<React.SetStateAction<boolean>>;
    animate?: boolean;
}) => {
    return (
        <SidebarProvider open={open} setOpen={setOpen} animate={animate}>
            {children}
        </SidebarProvider>
    );
};

export const SidebarBody = (props: React.ComponentProps<typeof motion.div>) => {
    return (
        <>
            <DesktopSidebar {...props} />
            <MobileSidebar {...(props as React.ComponentProps<"div">)} />
        </>
    );
};

export const DesktopSidebar = ({
    className,
    children,
    ...props
}: React.ComponentProps<typeof motion.div>) => {
    const { open, setOpen, animate } = useSidebar();
    return (
        <>
            <motion.div
                className={cn(
                    "h-full px-4 py-8 hidden md:flex md:flex-col bg-neutral-100 dark:bg-neutral-800 w-[300px] flex-shrink-0 transition-[width] duration-300",
                    className
                )}
                animate={{
                    width: animate ? (open ? "300px" : "80px") : "300px",
                }}
                onMouseEnter={() => setOpen(true)}
                onMouseLeave={() => setOpen(false)}
                {...props}
            >
                {children}
            </motion.div>
        </>
    );
};

export const MobileSidebar = ({
    className,
    children,
    ...props
}: React.ComponentProps<"div">) => {
    const { open, setOpen } = useSidebar();
    return (
        <>
            <div
                className={cn(
                    "h-10 px-4 py-4 flex flex-row md:hidden  items-center justify-between bg-neutral-100 dark:bg-neutral-800 w-full"
                )}
                {...props}
            >
                <div className="flex justify-end z-20 w-full">
                    <Menu
                        className="text-neutral-800 dark:text-neutral-200"
                        onClick={() => setOpen(!open)}
                    />
                </div>
                <AnimatePresence>
                    {open && (
                        <motion.div
                            initial={{ x: "-100%", opacity: 0 }}
                            animate={{ x: 0, opacity: 1 }}
                            exit={{ x: "-100%", opacity: 0 }}
                            transition={{
                                duration: 0.3,
                                ease: "easeInOut",
                            }}
                            className={cn(
                                "fixed h-full w-full inset-0 bg-white dark:bg-neutral-900 p-10 z-[100] flex flex-col justify-between",
                                className
                            )}
                        >
                            <div
                                className="absolute right-10 top-10 z-50 text-neutral-800 dark:text-neutral-200"
                                onClick={() => setOpen(!open)}
                            >
                                <X />
                            </div>
                            {children}
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </>
    );
};

export const SidebarLink = ({
    link,
    className,
    ...props
}: {
    link: Links;
    className?: string;
    props?: LinkProps; // Correctly typed down below
}) => {
    const { open, animate } = useSidebar();
    return (
        <Link
            to={link.href}
            className={cn(
                "flex items-center justify-start gap-3 group/sidebar py-3 px-2 rounded-md hover:bg-black/5 dark:hover:bg-white/5 transition-colors",
                className
            )}
            {...props}
        >
            {link.icon}

            <motion.span
                animate={{
                    display: animate ? (open ? "inline-block" : "none") : "inline-block",
                    opacity: animate ? (open ? 1 : 0) : 1,
                }}
                className="text-neutral-700 dark:text-neutral-200 text-sm font-medium whitespace-pre inline-block !p-0 !m-0 transition duration-150"
            >
                {link.label}
            </motion.span>
        </Link>
    );
};

// --- New Component: Sidebar Group ---

export const SidebarGroup = ({
    icon,
    label,
    children,
    initiallyOpen = false,
}: {
    icon: React.ReactNode;
    label: string;
    children: React.ReactNode;
    initiallyOpen?: boolean;
}) => {
    const { open, animate } = useSidebar();
    const [isOpen, setIsOpen] = useState(initiallyOpen);
    // const location = useLocation();

    // Basic check if any child is active to auto-expand
    // This logic depends on children strictly being SidebarLinks with hrefs matching location.pathname
    // For simplicity, we manage state locally or rely on user interaction. 

    return (
        <div className="flex flex-col gap-1">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="flex items-center justify-start gap-3 group/sidebar py-3 px-2 rounded-md hover:bg-black/5 dark:hover:bg-white/5 transition-colors w-full text-left"
            >
                {icon}
                <motion.div
                    animate={{
                        display: animate ? (open ? "flex" : "none") : "flex",
                        opacity: animate ? (open ? 1 : 0) : 1,
                    }}
                    className="flex-1 flex items-center justify-between overflow-hidden"
                >
                    <span className="text-neutral-700 dark:text-neutral-200 text-sm font-medium whitespace-pre">
                        {label}
                    </span>
                    <ChevronDown
                        className={cn(
                            "w-4 h-4 text-neutral-500 transition-transform duration-200",
                            isOpen && "rotate-180"
                        )}
                    />
                </motion.div>
            </button>

            <AnimatePresence>
                {isOpen && open && (
                    <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden pl-4 border-l border-neutral-200 dark:border-neutral-700 ml-5"
                    >
                        <div className="flex flex-col gap-1 py-1">
                            {children}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};

import { type LinkProps } from "react-router-dom";
