import { useEffect } from "react";
import { motion, useAnimate, stagger } from "framer-motion";

export const TextGenerateEffect = ({
    words,
    className,
}: {
    words: string;
    className?: string;
}) => {
    const [scope, animate] = useAnimate();
    let wordsArray = words.split(" ");

    useEffect(() => {
        animate(
            "span",
            {
                opacity: 1,
                filter: "blur(0px)",
                y: 0,
            },
            {
                duration: 0.5,
                delay: stagger(0.08),
                ease: [0.25, 0.46, 0.45, 0.94], // easeOut as per design guide
            }
        );
    }, [scope.current]);

    const renderWords = () => {
        return (
            <motion.div ref={scope}>
                {wordsArray.map((word, idx) => {
                    return (
                        <motion.span
                            key={word + idx}
                            className="inline-block opacity-0 blur-sm translate-y-3"
                            style={{ display: "inline-block", marginRight: "0.2em" }}
                        >
                            {word}
                        </motion.span>
                    );
                })}
            </motion.div>
        );
    };

    return (
        <div className={className}>
            <div className="mt-4">
                <div className="leading-tight tracking-tight">
                    {renderWords()}
                </div>
            </div>
        </div>
    );
};
