import { motion } from "framer-motion";
import { useState } from "react";

export const CanvasRevealEffect = () => {
    const [hovered, setHovered] = useState(false);

    return (
        <div
            className="w-full h-full relative bg-neutral-950 flex items-center justify-center overflow-hidden cursor-crosshair"
            onMouseEnter={() => setHovered(true)}
            onMouseLeave={() => setHovered(false)}
        >
            <div className="grid grid-cols-10 grid-rows-6 gap-0.5 w-full h-full opacity-20">
                {[...Array(60)].map((_, i) => (
                    <motion.div
                        key={i}
                        className="w-full h-full bg-emerald-500 rounded-full"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: hovered ? Math.random() : 0 }}
                        transition={{ duration: 0.5 }}
                    />
                ))}
            </div>

            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className="text-emerald-400 font-bold text-lg bg-neutral-950/50 px-2 rounded">
                    {hovered ? "REVEALED" : "HOVER ME"}
                </span>
            </div>
        </div>
    );
};
