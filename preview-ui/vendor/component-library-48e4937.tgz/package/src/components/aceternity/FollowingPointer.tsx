import { motion, useMotionValue } from "framer-motion";


export const FollowingPointer = () => {
    const x = useMotionValue(0);
    const y = useMotionValue(0);

    const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
        const rect = e.currentTarget.getBoundingClientRect();
        x.set(e.clientX - rect.left);
        y.set(e.clientY - rect.top);
    };

    return (
        <div
            className="w-full h-full bg-neutral-100 dark:bg-neutral-900 relative overflow-hidden cursor-none"
            onMouseMove={handleMouseMove}
        >
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className="text-neutral-400 font-bold opacity-30">Move Mouse</span>
            </div>

            <motion.div
                className="absolute top-0 left-0 pointer-events-none z-50"
                style={{ x, y }}
            >
                <div className="relative">
                    <svg
                        stroke="currentColor"
                        fill="currentColor"
                        strokeWidth="1"
                        viewBox="0 0 16 16"
                        className="h-6 w-6 text-black dark:text-white transform -rotate-[70deg] -translate-x-[12px] -translate-y-[10px]"
                        xmlns="http://www.w3.org/2000/svg"
                    >
                        <path d="M14.082 2.182a.5.5 0 0 1 .103.557L8.528 15.467a.5.5 0 0 1-.917-.007L5.57 10.694.803 8.652a.5.5 0 0 1-.006-.916l12.728-5.657a.5.5 0 0 1 .556.103z"></path>
                    </svg>
                    <div className="px-2 py-1 bg-emerald-500 rounded-full text-[10px] text-white font-bold whitespace-nowrap ml-2">
                        User
                    </div>
                </div>
            </motion.div>
        </div>
    );
};
