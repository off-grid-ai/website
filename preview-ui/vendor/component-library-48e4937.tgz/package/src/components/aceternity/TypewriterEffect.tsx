import { motion } from "framer-motion";
import { useState, useEffect } from "react";

const text = "Typewriter Effect";

export const TypewriterEffect = () => {
    const [displayedText, setDisplayedText] = useState("");

    useEffect(() => {
        let i = 0;
        const interval = setInterval(() => {
            setDisplayedText(text.slice(0, i + 1));
            i++;
            if (i > text.length) {
                i = 0;
                setDisplayedText("");
            }
        }, 150);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-black">
            <div className="flex items-center">
                <span className="text-2xl md:text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-b from-neutral-50 to-neutral-400">
                    {displayedText}
                </span>
                <motion.div
                    animate={{ opacity: [0, 1, 0] }}
                    transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                    className="w-[2px] h-8 bg-blue-500 ml-1"
                />
            </div>
        </div>
    );
};
