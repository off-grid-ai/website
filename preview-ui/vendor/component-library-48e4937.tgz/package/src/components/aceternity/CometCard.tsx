import { motion } from "framer-motion";

export const CometCard = () => {
    return (
        <div className="relative w-full h-full flex items-center justify-center overflow-hidden bg-slate-900 rounded-xl">
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/20 to-purple-500/20" />

            {/* Comet Tail */}
            <motion.div
                className="absolute w-20 h-1 bg-gradient-to-r from-transparent via-cyan-400 to-white rounded-full blur-[1px]"
                animate={{
                    x: [-100, 200],
                    y: [100, -50],
                    opacity: [0, 1, 0]
                }}
                transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut"
                }}
                style={{ rotate: -25 }}
            />
            <motion.div
                className="absolute w-20 h-1 bg-gradient-to-r from-transparent via-pink-400 to-white rounded-full blur-[1px]"
                animate={{
                    x: [-100, 200],
                    y: [50, -100],
                    opacity: [0, 1, 0]
                }}
                transition={{
                    duration: 2.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 1
                }}
                style={{ rotate: -25 }}
            />

            <div className="z-10 bg-black/40 backdrop-blur-md border border-white/10 p-3 rounded-lg shadow-xl">
                <span className="text-white font-bold text-sm">Comet</span>
            </div>
        </div>
    );
};
