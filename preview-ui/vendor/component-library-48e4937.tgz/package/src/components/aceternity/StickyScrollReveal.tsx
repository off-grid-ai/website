

export const StickyScrollReveal = () => {
    return (
        <div className="h-full w-full bg-neutral-950 p-4 flex gap-4 overflow-hidden relative">
            {/* Content */}
            <div className="w-1/2 h-full overflow-y-auto scrollbar-hide space-y-10 py-10">
                {[1, 2, 3].map((item) => (
                    <div key={item}>
                        <h3 className="text-white font-bold text-lg mb-2">Title {item}</h3>
                        <p className="text-neutral-400 text-xs">Section description goes here.</p>
                    </div>
                ))}
            </div>
            {/* Sticky Image */}
            <div className="w-1/2 h-full flex items-center justify-center">
                <div className="w-full aspect-square bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl" />
            </div>
        </div>
    );
};
