import { motion } from "framer-motion";

const items = ["Faster", "Better", "Stronger", "Smarter", "Cooler"];

export const InfiniteMovingCards = () => {
    return (
        <div className="h-full w-full rounded-md flex flex-col antialiased bg-white dark:bg-black dark:bg-grid-white/[0.05] items-center justify-center relative overflow-hidden">

            <div className="flex w-full overflow-hidden [mask-image:linear-gradient(to_right,transparent,white_20%,white_80%,transparent)]">
                <motion.div
                    className="flex min-w-full shrink-0 gap-4 py-4 w-max flex-nowrap"
                    animate={{
                        x: [0, -200],
                    }}
                    transition={{
                        duration: 10,
                        ease: "linear",
                        repeat: Infinity
                    }}
                >
                    {[...items, ...items, ...items].map((item, idx) => (
                        <div
                            key={idx}
                            className="w-[100px] h-[60px] max-w-full relative rounded-xl border border-b-0 flex-shrink-0 border-slate-700 px-4 py-2 md:w-[120px] bg-gradient-to-b from-slate-800 to-slate-900 flex items-center justify-center"
                        >
                            <span className="text-sm leading-[1.6] text-gray-100 font-normal">
                                {item}
                            </span>
                        </div>
                    ))}
                </motion.div>
            </div>
        </div>
    );
};
