import { motion, useMotionValue } from "framer-motion";
import { Home, Terminal, Settings, User, Mail } from "lucide-react";

export const FloatingDock = () => {
    const mouseX = useMotionValue(Infinity);

    return (
        <div className="w-full h-full flex items-end justify-center pb-6">
            <div
                className="flex gap-4 items-end bg-neutral-900/10 p-2 rounded-2xl border border-neutral-200 backdrop-blur-md"
                onMouseMove={(e) => mouseX.set(e.pageX)}
                onMouseLeave={() => mouseX.set(Infinity)}
            >
                {[Home, Terminal, User, Settings, Mail].map((Icon, i) => (
                    <DockIcon key={i} mouseX={mouseX}>
                        <Icon className="w-4 h-4 text-neutral-600" />
                    </DockIcon>
                ))}
            </div>
        </div>
    );
};

function DockIcon({ children }: { mouseX: any, children: React.ReactNode }) {
    // Simplified scaling for preview without complex ref logic
    return (
        <motion.div
            className="aspect-square rounded-full bg-white shadow-sm border border-neutral-200 flex items-center justify-center relative w-8 h-8"
            whileHover={{ scale: 1.5, translateY: -10 }}
        >
            {children}
        </motion.div>
    );
}
