import { motion } from "framer-motion";

export const BackgroundBeams = () => {
    return (
        <div className="relative w-full h-full bg-neutral-950 flex flex-col items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_10%,#0a0a0a_100%)] z-10" />

            {/* Beams */}
            {[...Array(6)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute h-[100px] w-full bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent opacity-0"
                    style={{
                        top: `${i * 30}px`,
                        left: -100,
                        rotate: -35
                    }}
                    animate={{
                        x: [0, 400],
                        opacity: [0, 1, 0]
                    }}
                    transition={{
                        duration: 3 + i,
                        repeat: Infinity,
                        ease: "linear",
                        delay: i * 0.5
                    }}
                />
            ))}

            <div className="z-20 text-center">
                <h2 className="text-white text-lg font-bold">Background Beams</h2>
                <p className="text-neutral-500 text-xs mt-1">Stunning visual effects</p>
            </div>
        </div>
    );
};
