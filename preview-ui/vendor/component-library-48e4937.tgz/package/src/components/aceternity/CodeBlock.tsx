import { motion } from "framer-motion";

export const CodeBlock = () => {
    const codeLines = [
        "const greet = () => {",
        "  console.log('Hello');",
        "  return true;",
        "};"
    ];

    return (
        <div className="w-full max-w-[240px] bg-[#1e1e1e] rounded-lg p-3 font-mono text-[10px] text-gray-300 shadow-lg border border-gray-700">
            <div className="flex gap-1.5 mb-2">
                <div className="w-2 h-2 rounded-full bg-red-500" />
                <div className="w-2 h-2 rounded-full bg-yellow-500" />
                <div className="w-2 h-2 rounded-full bg-green-500" />
            </div>
            {codeLines.map((line, i) => (
                <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.5 }}
                >
                    <span className="text-gray-500 mr-2">{i + 1}</span>
                    <span>{line}</span>
                </motion.div>
            ))}
        </div>
    );
};
