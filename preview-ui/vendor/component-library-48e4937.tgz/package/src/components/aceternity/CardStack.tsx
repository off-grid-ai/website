import { motion } from "framer-motion";
import { useState, useEffect } from "react";

export const CardStack = () => {
    const [cards, setCards] = useState([
        { id: 0, color: "bg-emerald-500" },
        { id: 1, color: "bg-blue-500" },
        { id: 2, color: "bg-pink-500" },
    ]);

    useEffect(() => {
        const interval = setInterval(() => {
            setCards((prevCards) => {
                const newArray = [...prevCards];
                newArray.unshift(newArray.pop()!);
                return newArray;
            });
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="relative h-full w-full flex items-center justify-center">
            {cards.map((card, index) => (
                <motion.div
                    key={card.id}
                    className={`absolute w-32 h-20 rounded-xl shadow-xl flex items-center justify-center border border-white/10 ${card.color}`}
                    animate={{
                        zIndex: index, // This might not animate perfectly with reorder but works for simple stack
                        scale: 1 - index * 0.1,
                        top: index * -5,
                    }}
                    transition={{
                        duration: 0.5,
                        ease: "easeInOut",
                    }}
                >
                </motion.div>
            ))}
        </div>
    );
};
