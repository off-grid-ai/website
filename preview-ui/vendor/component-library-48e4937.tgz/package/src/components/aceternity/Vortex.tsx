import { motion } from "framer-motion";

export const Vortex = () => {
    return (
        <div className="w-full h-full bg-black overflow-hidden relative flex items-center justify-center">
            {/* Simplified Vortex Visualization */}
            {[...Array(20)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute border border-blue-500/30 rounded-[40%]"
                    style={{
                        width: `${(i + 1) * 20}px`,
                        height: `${(i + 1) * 10}px`,
                    }}
                    animate={{
                        rotate: 360,
                        scale: [1, 1.2, 1]
                    }}
                    transition={{
                        duration: 5 + i * 0.2,
                        repeat: Infinity,
                        ease: "linear",
                        delay: i * 0.1
                    }}
                />
            ))}
            <div className="z-10 bg-black/50 backdrop-blur-md px-4 py-2 rounded-full border border-white/10">
                <h2 className="text-white text-sm font-bold">VORTEX</h2>
            </div>
        </div>
    );
};
