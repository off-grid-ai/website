import { motion } from "framer-motion";

export const TracingBeam = () => {
    return (
        <div className="w-full h-full bg-black flex p-4 relative overflow-hidden">
            <div className="w-12 h-full flex flex-col items-center justify-center relative">
                <div className="w-[1px] h-full bg-neutral-800" />

                <motion.div
                    className="absolute w-2 h-2 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500"
                    animate={{
                        top: ["10%", "90%", "10%"]
                    }}
                    transition={{
                        duration: 4,
                        repeat: Infinity,
                        ease: "easeInOut"
                    }}
                >
                    <motion.div
                        className="absolute top-2 w-[1px] bg-gradient-to-b from-indigo-500 to-purple-500 h-20 -left-[1px]"
                    />
                </motion.div>
            </div>
            <div className="flex-1 flex flex-col justify-center space-y-4">
                <div className="h-2 w-32 bg-neutral-800 rounded-full" />
                <div className="h-2 w-48 bg-neutral-800 rounded-full" />
                <div className="h-20 w-full bg-neutral-900 rounded-lg" />
            </div>
        </div>
    );
};
