import { motion } from "framer-motion";

export const PixelatedCanvas = () => {
    return (
        <div className="w-full h-full bg-black flex items-center justify-center relative overflow-hidden">
            <div className="absolute inset-0 grid grid-cols-12 grid-rows-8 gap-[1px]">
                {[...Array(96)].map((_, i) => (
                    <motion.div
                        key={i}
                        className="bg-purple-900"
                        initial={{ opacity: 0.1 }}
                        animate={{ opacity: Math.random() > 0.7 ? [0.1, 0.8, 0.1] : 0.1 }}
                        transition={{ duration: 2, repeat: Infinity, delay: Math.random() * 2 }}
                    />
                ))}
            </div>
            <div className="relative z-10 text-white font-mono text-sm">Pixelated</div>
        </div>
    );
};
