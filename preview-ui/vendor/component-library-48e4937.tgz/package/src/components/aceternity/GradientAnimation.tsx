import { motion } from "framer-motion";

export const GradientAnimation = () => {
    return (
        <div className="w-full h-full flex items-center justify-center overflow-hidden bg-neutral-900">
            <motion.div
                className="w-full h-full opacity-60"
                style={{
                    background: "linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab)",
                    backgroundSize: "400% 400%",
                }}
                animate={{
                    backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"]
                }}
                transition={{
                    duration: 10,
                    ease: "linear",
                    repeat: Infinity
                }}
            />
            <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-black/50 backdrop-blur-sm p-3 rounded-lg border border-white/10">
                    <span className="text-white font-bold text-sm">Gradient Flow</span>
                </div>
            </div>
        </div>
    );
};
