export const TailwindCSSButtons = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-center gap-3 bg-white dark:bg-black">
            <button className="px-4 py-2 rounded-md border border-neutral-300 bg-neutral-100 dark:bg-neutral-800 dark:border-neutral-700 text-neutral-500 text-xs hover:-translate-y-1 transform transition duration-200 hover:shadow-md">
                Simple
            </button>
            <button className="shadow-[0_4px_14px_0_rgb(0,118,255,39%)] hover:shadow-[0_6px_20px_rgba(0,118,255,23%)] hover:bg-[rgba(0,118,255,0.9)] px-4 py-2 bg-[#0070f3] rounded-md text-white font-light transition duration-200 ease-linear text-xs">
                Shadow
            </button>
            <button className="px-4 py-2 rounded-xl bg-black dark:bg-white text-white dark:text-black hover:bg-neutral-800 border-2 border-transparent text-xs font-bold transition duration-200">
                Border
            </button>
        </div>
    );
};
