import { useState } from "react";
import { motion } from "framer-motion";

export const Lens = () => {
    const [hovering, setHovering] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden relative"
            onMouseEnter={() => setHovering(true)}
            onMouseLeave={() => setHovering(false)}
        >
            <div className="text-center p-4">
                <p className="text-neutral-500 text-xs text-justify">
                    The lens effect zooms into content. Hover over this card to see the effect simulation.
                </p>
            </div>

            {hovering && (
                <motion.div
                    layoutId="lens"
                    className="absolute w-20 h-20 rounded-full border-2 border-white/20 bg-white/10 backdrop-blur-sm shadow-2xl flex items-center justify-center overflow-hidden"
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                >
                    <div className="bg-white/20 absolute inset-0 mix-blend-overlay" />
                </motion.div>
            )}
        </div>
    );
};
