import { motion } from "framer-motion";

export const LampEffect = () => {
    return (
        <div className="relative flex w-full h-full flex-col items-center justify-center overflow-hidden bg-slate-950 w-full rounded-md z-0">

            <div className="relative flex w-full flex-1 scale-y-125 items-center justify-center isolate z-0 ">
                <motion.div
                    initial={{ opacity: 0.5, width: "5rem" }}
                    animate={{ opacity: 1, width: "10rem" }}
                    transition={{
                        delay: 0.3,
                        duration: 0.8,
                        ease: "easeInOut",
                    }}
                    style={{
                        backgroundImage: `conic-gradient(var(--conic-position), var(--tw-gradient-stops))`,
                    }}
                    className="absolute inset-auto right-1/2 h-24 overflow-visible w-[10rem] bg-gradient-to-b from-cyan-500 via-transparent to-transparent text-white [--conic-position:from_70deg_at_center_top]"
                >
                    <div className="absolute  w-[100%] left-0 bg-slate-950 h-20 bottom-0 z-20 [mask-image:linear-gradient(to_top,white,transparent)]" />
                    <div className="absolute  w-20 h-[100%] left-0 bg-slate-950  bottom-0 z-20 [mask-image:linear-gradient(to_right,white,transparent)]" />
                </motion.div>
                <div className="absolute w-[10rem] h-10 bottom-0 bg-cyan-500 blur-2xl" />
            </div>

            <div className="relative z-50 flex -translate-y-10 flex-col items-center px-5">
                <h1 className="bg-gradient-to-br from-slate-300 to-slate-500 py-2 bg-clip-text text-center text-xl font-medium tracking-tight text-transparent md:text-2xl">
                    Lamp
                </h1>
            </div>
        </div>
    );
};
