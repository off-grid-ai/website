import { useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

export const DirectionAwareHover = () => {
    const ref = useRef<HTMLDivElement>(null);

    const [direction, setDirection] = useState<"top" | "bottom" | "left" | "right" | string>("left");

    const handleMouseEnter = (event: React.MouseEvent<HTMLDivElement, MouseEvent>) => {
        if (!ref.current) return;
        const dir = getDirection(event, ref.current);
        switch (dir) {
            case 0: setDirection("top"); break;
            case 1: setDirection("right"); break;
            case 2: setDirection("bottom"); break;
            case 3: setDirection("left"); break;
            default: setDirection("left"); break;
        }
    };

    const getDirection = (ev: any, obj: any) => {
        const { width: w, height: h, left, top } = obj.getBoundingClientRect();
        const x = ev.clientX - left - (w / 2) * (w > h ? h / w : 1);
        const y = ev.clientY - top - (h / 2) * (h > w ? w / h : 1);
        const d = Math.round(Math.atan2(y, x) / 1.57079633 + 5) % 4;
        return d;
    };

    // Removed unused variants object

    const textVariants = {
        initial: { y: 0, x: 0, opacity: 0 },
        exit: { y: 0, x: 0, opacity: 0 },
        top: { y: -20, opacity: 1 },
        bottom: { y: 20, opacity: 1 },
        left: { x: -20, opacity: 1 },
        right: { x: 20, opacity: 1 },
    };

    return (
        <motion.div
            onMouseEnter={handleMouseEnter}
            ref={ref}
            className="h-full w-full bg-transparent rounded-lg overflow-hidden group/card relative"
        >
            <AnimatePresence mode="wait">
                <motion.div
                    className="relative h-full w-full bg-cover bg-center"
                    style={{ backgroundImage: `url(https://images.unsplash.com/photo-1663765970236-f2acfde22237?q=80&w=3542&auto=format&fit=crop)` }}
                >
                    <motion.div
                        className="group-hover/card:block hidden absolute inset-0 w-full h-full bg-black/40 z-10 transition duration-500"
                    />
                    <motion.div
                        variants={textVariants}
                        initial="initial"
                        exit="exit"
                        animate={direction}
                        transition={{ duration: 0.2, ease: "easeOut" }}
                        className="text-white absolute inset-0 z-20 flex items-center justify-center font-bold"
                    >
                        Hover
                    </motion.div>
                </motion.div>
            </AnimatePresence>
        </motion.div>
    );
};
