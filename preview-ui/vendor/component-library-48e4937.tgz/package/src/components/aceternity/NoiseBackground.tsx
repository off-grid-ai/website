export const NoiseBackground = () => {
    return (
        <div className="relative w-full h-full bg-orange-500 flex items-center justify-center overflow-hidden">
            {/* Simple noise using CSS repeating-linear-gradient as a lightweight approximation or an SVG pattern */}
            <div
                className="absolute inset-0 opacity-20"
                style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
                }}
            />
            <h3 className="relative z-10 font-bold text-white text-2xl drop-shadow-md">NOISE</h3>
        </div>
    );
};
