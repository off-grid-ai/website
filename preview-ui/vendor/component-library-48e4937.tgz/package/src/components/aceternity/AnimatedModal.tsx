import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { X } from 'lucide-react';

export const AnimatedModal = () => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="flex items-center justify-center">
            <button
                onClick={() => setIsOpen(true)}
                className="px-4 py-2 bg-neutral-100 text-neutral-600 rounded-lg text-xs font-medium border border-neutral-200 hover:bg-neutral-200 transition-colors"
            >
                Open Preview
            </button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={() => setIsOpen(false)}
                    >
                        <motion.div
                            className="bg-white rounded-2xl p-4 w-full h-full max-w-[200px] max-h-[120px] shadow-2xl flex flex-col items-center justify-center text-center relative"
                            initial={{ scale: 0.8, opacity: 0, y: 10 }}
                            animate={{ scale: 1, opacity: 1, y: 0 }}
                            exit={{ scale: 0.8, opacity: 0, y: 10 }}
                            onClick={(e) => e.stopPropagation()}
                        >
                            <button
                                onClick={() => setIsOpen(false)}
                                className="absolute top-2 right-2 p-1 bg-neutral-100 rounded-full text-neutral-500 hover:bg-neutral-200"
                            >
                                <X className="w-3 h-3" />
                            </button>
                            <span className="text-2xl mb-1">✨</span>
                            <h4 className="text-sm font-bold text-neutral-800">Hello!</h4>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};
