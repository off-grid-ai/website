import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";

const items = [
    { title: "Netflix", description: "Streaming service" },
    { title: "Google", description: "Search engine" },
    { title: "Meta", description: "Social media" },
];

export const CardHoverEffect = () => {
    const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

    return (
        <div className="grid grid-cols-3 gap-2 px-2 py-4 w-full h-full items-center">
            {items.map((item, idx) => (
                <div
                    key={idx}
                    className="relative group block p-2 h-full w-full"
                    onMouseEnter={() => setHoveredIndex(idx)}
                    onMouseLeave={() => setHoveredIndex(null)}
                >
                    <AnimatePresence>
                        {hoveredIndex === idx && (
                            <motion.span
                                className="absolute inset-0 h-full w-full bg-neutral-200 dark:bg-slate-800/[0.8] block rounded-xl"
                                layoutId="hoverBackground"
                                initial={{ opacity: 0 }}
                                animate={{
                                    opacity: 1,
                                    transition: { duration: 0.15 },
                                }}
                                exit={{
                                    opacity: 0,
                                    transition: { duration: 0.15, delay: 0.2 },
                                }}
                            />
                        )}
                    </AnimatePresence>
                    <div className="rounded-lg h-full w-full bg-white dark:bg-black border border-transparent dark:border-white/[0.2] group-hover:border-slate-700 relative z-20 p-2 flex flex-col items-center justify-center">
                        <h4 className="text-zinc-100 font-bold tracking-wide text-[10px]">{item.title}</h4>
                        <p className="hidden md:block mt-1 text-zinc-400 tracking-wide leading-relaxed text-[8px] text-center">
                            {item.description}
                        </p>
                    </div>
                </div>
            ))}
        </div>
    );
};
