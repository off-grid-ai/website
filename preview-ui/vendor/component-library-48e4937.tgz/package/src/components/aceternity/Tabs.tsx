import { motion } from "framer-motion";
import { useState } from "react";

const tabs = ["Product", "Services", "About"];

export const Tabs = () => {
    const [active, setActive] = useState(tabs[0]);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-gray-50 dark:bg-neutral-900 p-4">
            <div className="flex space-x-1 border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 p-1 rounded-full">
                {tabs.map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActive(tab)}
                        className="relative px-3 py-1.5 text-xs font-medium text-black dark:text-white rounded-full transition focus-visible:outline-2"
                    // style={{ WebkitTapHighlightColor: "transparent" }}
                    >
                        {active === tab && (
                            <motion.span
                                layoutId="bubble"
                                className="absolute inset-0 z-10 bg-neutral-200 dark:bg-neutral-700 mix-blend-multiply dark:mix-blend-screen rounded-full"
                                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                            />
                        )}
                        <span className="relative z-20">{tab}</span>
                    </button>
                ))}
            </div>

            <div className="mt-4 p-4 w-full h-24 bg-white dark:bg-neutral-800 rounded-xl border border-neutral-200 dark:border-neutral-700 flex items-center justify-center">
                <span className="text-neutral-500 text-sm">Content for {active}</span>
            </div>
        </div>
    );
};
