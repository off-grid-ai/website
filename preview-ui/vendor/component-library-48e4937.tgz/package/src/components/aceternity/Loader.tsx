import { motion } from "framer-motion";

export const Loader = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black gap-1">
            {[...Array(5)].map((_, i) => (
                <motion.div
                    key={i}
                    className="w-2 h-10 bg-gradient-to-b from-indigo-500 to-purple-500 rounded-full"
                    animate={{
                        scaleY: [1, 1.5, 1],
                        opacity: [0.5, 1, 0.5]
                    }}
                    transition={{
                        duration: 1,
                        repeat: Infinity,
                        delay: i * 0.1,
                        ease: "easeInOut"
                    }}
                />
            ))}
        </div>
    );
};
