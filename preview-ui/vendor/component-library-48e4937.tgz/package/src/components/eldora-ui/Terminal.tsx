export const Terminal = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-4">
            <div className="w-full h-40 bg-black rounded-lg shadow-xl overflow-hidden border border-neutral-800 font-mono text-xs">
                <div className="flex items-center gap-1.5 px-3 py-2 bg-neutral-900 border-b border-neutral-800">
                    <div className="w-2.5 h-2.5 bg-red-500 rounded-full" />
                    <div className="w-2.5 h-2.5 bg-yellow-500 rounded-full" />
                    <div className="w-2.5 h-2.5 bg-green-500 rounded-full" />
                </div>
                <div className="p-3 text-green-400">
                    <p>$ npm install eldora-ui</p>
                    <p className="text-white mt-1">Installing dependencies...</p>
                    <p className="text-white mt-1">Done in 1.45s</p>
                    <p className="mt-1 flex items-center gap-1">
                        $<span className="w-2 h-4 bg-white animate-pulse" />
                    </p>
                </div>
            </div>
        </div>
    );
};
