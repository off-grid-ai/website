import { motion } from "framer-motion";

export const ScaleLetterText = () => {
    const text = "Scale";

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex gap-1">
                {text.split("").map((char, i) => (
                    <motion.div
                        key={i}
                        whileHover={{ scale: 1.5 }}
                        className="text-4xl font-black cursor-default"
                        transition={{ type: "spring", stiffness: 300 }}
                    >
                        {char}
                    </motion.div>
                ))}
            </div>
        </div>
    );
};
