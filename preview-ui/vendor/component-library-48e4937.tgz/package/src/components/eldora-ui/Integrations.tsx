import { motion } from "framer-motion";

export const Integrations = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative w-32 h-32">
                <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 bg-black dark:bg-white rounded-xl shadow-lg z-10" />
                </div>
                {[0, 1, 2, 3].map((i) => (
                    <motion.div
                        key={i}
                        className="absolute w-8 h-8 bg-neutral-200 dark:bg-neutral-700 rounded-lg"
                        animate={{
                            x: [0, (i % 2 === 0 ? 40 : -40)],
                            y: [0, (i < 2 ? -40 : 40)],
                            opacity: [0, 1]
                        }}
                        transition={{ delay: 0.5, duration: 0.5 }}
                        style={{ top: 'calc(50% - 16px)', left: 'calc(50% - 16px)' }}
                    />
                ))}
            </div>
        </div>
    );
};
