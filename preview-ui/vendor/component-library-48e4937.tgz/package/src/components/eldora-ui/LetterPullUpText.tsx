import { motion } from "framer-motion";

export const LetterPullUpText = () => {
    const text = "Pull Up";

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex overflow-hidden">
                {text.split("").map((char, i) => (
                    <motion.div
                        key={i}
                        initial={{ y: 20 }}
                        animate={{ y: 0 }}
                        transition={{ delay: i * 0.1, type: "spring" }}
                        className="text-3xl font-bold"
                    >
                        {char === " " ? "\u00A0" : char}
                    </motion.div>
                ))}
            </div>
        </div>
    );
};
