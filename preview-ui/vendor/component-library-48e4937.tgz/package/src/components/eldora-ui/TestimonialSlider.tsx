import { motion } from "framer-motion";
import { useState, useEffect } from "react";

export const TestimonialSlider = () => {
    const testimonials = ["Amazing!", "Great work", "Love it"];
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % testimonials.length);
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="text-center p-4"
            >
                <p className="text-lg font-medium italic">"{testimonials[index]}"</p>
                <p className="text-xs text-neutral-500 mt-2">- User {index + 1}</p>
            </motion.div>
        </div>
    );
};
