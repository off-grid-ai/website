export const AnimatedShinyButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <button className="relative px-6 py-2 rounded-lg bg-neutral-900 text-neutral-400 border border-neutral-800 overflow-hidden group">
                <span className="relative z-10 group-hover:text-white transition-colors duration-500">Shiny Button</span>
                <div className="absolute inset-0 -translate-x-full group-hover:translate-x-[150%] transition-transform duration-1000 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-12" />
            </button>
        </div>
    );
};
