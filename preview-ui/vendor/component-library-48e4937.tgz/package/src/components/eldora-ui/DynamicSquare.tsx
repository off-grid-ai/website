import { motion } from "framer-motion";

export const DynamicSquare = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900">
            <motion.div
                animate={{
                    borderRadius: ["20%", "50%", "50%", "20%"],
                    rotate: [0, 0, 180, 180, 0],
                    scale: [1, 1.2, 1.2, 1, 1],
                }}
                transition={{
                    duration: 2,
                    ease: "easeInOut",
                    times: [0, 0.2, 0.5, 0.8, 1],
                    repeat: Infinity,
                    repeatDelay: 1
                }}
                className="w-20 h-20 bg-black dark:bg-white"
            />
        </div>
    );
};
