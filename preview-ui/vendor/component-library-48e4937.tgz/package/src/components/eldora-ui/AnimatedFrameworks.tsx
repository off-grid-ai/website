import { motion } from "framer-motion";

export const AnimatedFrameworks = () => {
    const icons = ["⚛️", "🟢", "🔷", "🔥", "🅰️"];

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden">
            <div className="flex gap-4">
                {icons.map((icon, i) => (
                    <motion.div
                        key={i}
                        animate={{ y: [0, -10, 0] }}
                        transition={{ duration: 2, repeat: Infinity, delay: i * 0.2, ease: "easeInOut" }}
                        className="text-2xl"
                    >
                        {icon}
                    </motion.div>
                ))}
            </div>
        </div>
    );
};
