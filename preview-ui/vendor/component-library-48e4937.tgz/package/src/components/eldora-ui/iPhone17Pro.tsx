export const iPhone17Pro = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900">
            <div className="w-32 h-64 bg-black rounded-[36px] p-1.5 border-[3px] border-neutral-400 dark:border-neutral-600 shadow-2xl ring-1 ring-black/5">
                <div className="w-full h-full bg-white dark:bg-neutral-900 rounded-[30px] overflow-hidden relative">
                    <div className="absolute top-2 left-1/2 -translate-x-1/2 w-20 h-6 bg-black rounded-full z-10" />
                    <img
                        src="https://images.unsplash.com/photo-1605648916361-9bc12ad6a569?q=80&w=2670&auto=format&fit=crop"
                        alt="Wallpaper"
                        className="w-full h-full object-cover"
                    />
                </div>
            </div>
        </div>
    );
};
