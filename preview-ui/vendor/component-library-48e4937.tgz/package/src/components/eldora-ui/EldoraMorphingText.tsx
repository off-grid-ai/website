// Renaming to EldoraMorphingText to avoid collision
import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

export const EldoraMorphingText = () => {
    const text = ["Create", "Build", "Ship"];
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % text.length);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <AnimatePresence mode="wait">
                <motion.div
                    key={text[index]}
                    initial={{ opacity: 0, filter: "blur(10px)" }}
                    animate={{ opacity: 1, filter: "blur(0px)" }}
                    exit={{ opacity: 0, filter: "blur(10px)" }}
                    transition={{ duration: 0.5 }}
                    className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500"
                >
                    {text[index]}
                </motion.div>
            </AnimatePresence>
        </div>
    );
};
