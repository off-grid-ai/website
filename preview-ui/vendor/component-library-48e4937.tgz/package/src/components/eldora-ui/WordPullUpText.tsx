import { motion } from "framer-motion";

export const WordPullUpText = () => {
    const words = ["Pull", "Up", "Words"];

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 gap-2">
            {words.map((word, i) => (
                <motion.div
                    key={i}
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: i * 0.2, type: "spring" }}
                    className="text-2xl font-bold"
                >
                    {word}
                </motion.div>
            ))}
        </div>
    );
};
