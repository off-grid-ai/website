import { Star } from "lucide-react";

export const GitStarButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex rounded-md shadow-sm" role="group">
                <button className="flex items-center gap-2 px-3 py-1.5 text-xs font-semibold text-gray-900 dark:text-white bg-gray-100 dark:bg-neutral-800 border border-gray-300 dark:border-neutral-700 rounded-l-md hover:bg-gray-200 dark:hover:bg-neutral-700">
                    <Star className="w-3.5 h-3.5" />
                    Star
                </button>
                <button className="px-3 py-1.5 text-xs font-semibold text-gray-900 dark:text-white bg-white dark:bg-black border-t border-b border-r border-gray-300 dark:border-neutral-700 rounded-r-md hover:text-blue-600">
                    1,234
                </button>
            </div>
        </div>
    );
};
