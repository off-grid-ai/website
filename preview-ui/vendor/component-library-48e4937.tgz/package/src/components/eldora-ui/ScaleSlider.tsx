import { useState } from "react";

export const ScaleSlider = () => {
    const [value, setValue] = useState(50);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-white dark:bg-neutral-900 p-8">
            <div
                className="w-16 h-16 bg-blue-500 rounded-lg mb-8 transition-transform"
                style={{ transform: `scale(${0.5 + value / 100})` }}
            />
            <input
                type="range"
                min="0"
                max="100"
                value={value}
                onChange={(e) => setValue(Number(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
            />
        </div>
    );
};
