export const HoverMeButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <button className="group relative px-6 py-3 font-bold text-black border-2 border-black rounded-lg overflow-hidden transition-colors hover:text-white dark:text-white dark:border-white dark:hover:text-black">
                <span className="relative z-10 transition-colors">Hover Me</span>
                <div className="absolute inset-0 bg-black dark:bg-white translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-300 ease-out" />
            </button>
        </div>
    );
};
