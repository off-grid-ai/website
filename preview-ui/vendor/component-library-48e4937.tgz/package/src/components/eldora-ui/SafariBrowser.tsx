export const SafariBrowser = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-zinc-100 dark:bg-zinc-900 p-8">
            <div className="w-full max-w-[240px] bg-white dark:bg-zinc-800 rounded-xl shadow-xl overflow-hidden border border-zinc-200 dark:border-zinc-700">
                <div className="h-8 bg-zinc-100 dark:bg-zinc-800/50 backdrop-blur-md flex items-center px-4 justify-between">
                    <div className="flex gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full bg-red-400" />
                        <div className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
                        <div className="w-2.5 h-2.5 rounded-full bg-green-400" />
                    </div>
                </div>
                <div className="h-24 flex items-center justify-center text-4xl text-zinc-300">
                    🧭
                </div>
            </div>
        </div>
    );
};
