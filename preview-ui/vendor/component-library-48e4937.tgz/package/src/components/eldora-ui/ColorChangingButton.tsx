import { motion } from "framer-motion";
import { useState } from "react";

export const ColorChangingButton = () => {
    const colors = ["#3b82f6", "#ef4444", "#10b981", "#f59e0b"];
    const [index, setIndex] = useState(0);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.button
                animate={{ backgroundColor: colors[index] }}
                onClick={() => setIndex((prev) => (prev + 1) % colors.length)}
                className="px-6 py-2 rounded-lg text-white font-medium shadow-md transition-shadow hover:shadow-lg"
            >
                Click Me
            </motion.button>
        </div>
    );
};
