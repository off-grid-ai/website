export const LiveButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <button className="flex items-center gap-2 px-3 py-1 bg-red-600 rounded text-white text-xs font-bold uppercase tracking-wider animate-pulse">
                <div className="w-2 h-2 bg-white rounded-full" />
                Live
            </button>
        </div>
    );
};
