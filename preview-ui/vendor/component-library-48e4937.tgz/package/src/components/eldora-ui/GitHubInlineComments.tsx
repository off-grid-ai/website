export const GitHubInlineComments = () => {
    return (
        <div className="w-full h-full flex flex-col justify-center bg-white dark:bg-[#0d1117] p-4 text-sm font-sans">
            <div className="border border-neutral-200 dark:border-[#30363d] rounded-md">
                <div className="bg-neutral-100 dark:bg-[#161b22] px-3 py-2 border-b border-neutral-200 dark:border-[#30363d] flex justify-between items-center">
                    <span className="font-semibold dark:text-[#c9d1d9]">mac-user</span>
                    <span className="text-neutral-500 text-xs">now</span>
                </div>
                <div className="p-3 dark:text-[#c9d1d9]">
                    Could you update the documentation for this?
                </div>
            </div>
        </div>
    );
};
