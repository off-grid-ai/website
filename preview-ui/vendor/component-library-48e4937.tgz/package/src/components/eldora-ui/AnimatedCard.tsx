import { motion } from "framer-motion";

export const AnimatedCard = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-900 p-4">
            <motion.div
                whileHover={{ scale: 1.05 }}
                className="w-full max-w-[200px] h-32 bg-neutral-800 rounded-xl border border-neutral-700 p-4 relative overflow-hidden group"
            >
                <div className="absolute inset-0 bg-gradient-to-tr from-purple-500/20 to-blue-500/20 opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="w-10 h-10 bg-neutral-700 rounded-full mb-3" />
                <div className="h-2 w-2/3 bg-neutral-700 rounded mb-2" />
                <div className="h-2 w-1/2 bg-neutral-700 rounded" />
            </motion.div>
        </div>
    );
};
