import { motion, useScroll, useSpring } from "framer-motion";

export const EldoraScrollProgress = () => {
    const { scrollYProgress } = useScroll();
    const scaleX = useSpring(scrollYProgress, {
        stiffness: 100,
        damping: 30,
        restDelta: 0.001
    });

    return (
        <div className="w-full h-full flex flex-col bg-white dark:bg-neutral-900 overflow-hidden relative">
            <motion.div
                className="absolute top-0 left-0 right-0 h-2 bg-blue-500 origin-left z-10"
                style={{ scaleX }}
            />
            <div className="flex-1 overflow-auto p-4 space-y-4">
                <p>Scroll me!</p>
                {[...Array(10)].map((_, i) => (
                    <div key={i} className="h-20 bg-neutral-100 dark:bg-neutral-800 rounded w-full" />
                ))}
            </div>
        </div>
    );
};
