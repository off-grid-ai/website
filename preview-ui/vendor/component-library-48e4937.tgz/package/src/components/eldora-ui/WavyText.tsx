import { motion } from "framer-motion";

export const WavyText = () => {
    const text = "Wavy";

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex">
                {text.split("").map((char, i) => (
                    <motion.h1
                        key={i}
                        animate={{ y: [0, -10, 0] }}
                        transition={{ duration: 1, repeat: Infinity, delay: i * 0.1 }}
                        className="text-4xl font-bold"
                    >
                        {char}
                    </motion.h1>
                ))}
            </div>
        </div>
    );
};
