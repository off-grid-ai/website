export const SphereAnimation = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden relative">
            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 animate-pulse blur-md opacity-75" />
            <div className="absolute w-32 h-32 rounded-full border border-white/20 animate-spin-slow" />
            <div className="absolute w-24 h-24 rounded-full border border-white/30 animate-[spin_3s_linear_infinite]" />
        </div>
    );
};
