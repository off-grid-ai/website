export const CobeGlobe = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden relative">
            <div className="w-full h-full absolute inset-0 bg-gradient-to-b from-black via-blue-900/20 to-black z-0" />
            <div className="w-40 h-40 rounded-full border border-blue-500/30 bg-blue-900/10 backdrop-blur-sm flex items-center justify-center relative z-10 animate-spin-slow">
                <div className="w-32 h-32 rounded-full border border-blue-400/20 border-dashed" />
            </div>
            <p className="absolute bottom-4 text-xs text-blue-400">Interactive Globe</p>
        </div>
    );
};
