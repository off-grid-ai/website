export const iPad = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900">
            <div className="w-48 h-64 bg-black rounded-[24px] p-2 border-4 border-neutral-300 dark:border-neutral-700 shadow-xl">
                <div className="w-full h-full bg-white dark:bg-neutral-800 rounded-[16px] overflow-hidden relative">
                    <div className="absolute top-2 w-full flex justify-center">
                        <div className="w-16 h-1 bg-neutral-200 dark:bg-neutral-700 rounded-full" />
                    </div>
                    <div className="flex items-center justify-center h-full text-neutral-300 text-4xl">
                        
                    </div>
                </div>
            </div>
        </div>
    );
};
