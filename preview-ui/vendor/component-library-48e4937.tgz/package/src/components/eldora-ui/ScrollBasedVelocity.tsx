import { motion } from "framer-motion";

export const ScrollBasedVelocity = () => {
    return (
        <div className="w-full h-full flex flex-col justify-center bg-white dark:bg-neutral-900 overflow-hidden">
            <motion.div
                animate={{ x: ["0%", "-50%"] }}
                transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
                className="whitespace-nowrap text-4xl font-black text-neutral-200 dark:text-neutral-800"
            >
                VELOCITY SCROLL VELOCITY SCROLL VELOCITY SCROLL
            </motion.div>
            <motion.div
                animate={{ x: ["-50%", "0%"] }}
                transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
                className="whitespace-nowrap text-4xl font-black text-black dark:text-white"
            >
                VELOCITY SCROLL VELOCITY SCROLL VELOCITY SCROLL
            </motion.div>
        </div>
    );
};
