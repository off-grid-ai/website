export const NovatrixBackground = () => {
    return (
        <div className="w-full h-full bg-black relative overflow-hidden flex items-center justify-center">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/40 via-black to-black animate-pulse" />
            <div className="grid grid-cols-12 gap-1 w-full h-full opacity-20 transform scale-150 rotate-12">
                {[...Array(144)].map((_, i) => (
                    <div key={i} className="bg-blue-500 rounded-full w-1 h-1" />
                ))}
            </div>
            <h2 className="relative z-10 text-white font-bold tracking-widest">NOVATRIX</h2>
        </div>
    );
};
