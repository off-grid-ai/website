export const CodeSnippet = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-[#0d1117] p-4">
            <div className="w-full bg-[#161b22] rounded-lg border border-[#30363d] overflow-hidden">
                <div className="flex items-center px-4 py-2 border-b border-[#30363d] bg-[#0d1117]">
                    <div className="flex gap-1.5">
                        <div className="w-2.5 h-2.5 rounded-full bg-[#fa7970]" />
                        <div className="w-2.5 h-2.5 rounded-full bg-[#faa356]" />
                        <div className="w-2.5 h-2.5 rounded-full bg-[#7ce38b]" />
                    </div>
                </div>
                <div className="p-4 font-mono text-xs text-[#c9d1d9]">
                    <span className="text-[#ff7b72]">const</span> <span className="text-[#d2a8ff]">App</span> = () {'=>'} {'{'}<br />
                    &nbsp;&nbsp;<span className="text-[#ff7b72]">return</span> <span className="text-[#a5d6ff]">"Hello"</span>;<br />
                    {'}'}
                </div>
            </div>
        </div>
    );
};
