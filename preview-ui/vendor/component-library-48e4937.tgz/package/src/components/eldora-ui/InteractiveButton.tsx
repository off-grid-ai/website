import { motion } from "framer-motion";

export const InteractiveButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.button
                whileTap={{ scale: 0.9 }}
                whileHover={{ scale: 1.1 }}
                className="px-8 py-3 bg-blue-600 text-white rounded-full font-bold shadow-lg shadow-blue-500/30"
            >
                Press
            </motion.button>
        </div>
    );
};
