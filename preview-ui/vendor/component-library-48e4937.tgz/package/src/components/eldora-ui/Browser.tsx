export const Browser = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-zinc-100 dark:bg-zinc-900 p-8">
            <div className="w-full max-w-[240px] bg-white dark:bg-zinc-950 rounded-xl shadow-xl overflow-hidden border border-zinc-200 dark:border-zinc-800">
                <div className="h-8 bg-zinc-100 dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800 flex items-center px-3 gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-400" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-400" />
                    <div className="ml-2 flex-1 h-5 bg-zinc-200 dark:bg-zinc-800 rounded-md" />
                </div>
                <div className="h-24 bg-white dark:bg-zinc-950 p-4 flex items-center justify-center text-zinc-300">
                    Wait...
                </div>
            </div>
        </div>
    );
};
