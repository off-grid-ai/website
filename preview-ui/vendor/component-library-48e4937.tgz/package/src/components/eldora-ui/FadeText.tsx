import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

export const FadeText = () => {
    const words = ["Fade", "In", "Out"];
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % words.length);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <AnimatePresence mode="wait">
                <motion.h1
                    key={words[index]}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className="text-3xl font-bold"
                >
                    {words[index]}
                </motion.h1>
            </AnimatePresence>
        </div>
    );
};
