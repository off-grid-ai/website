import { motion } from "framer-motion";

export const GradualSpacingText = () => {
    const text = "Spaced Out";

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex">
                {text.split("").map((char, i) => (
                    <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.5, delay: i * 0.1 }}
                        className="text-2xl font-bold"
                    >
                        {char === " " ? "\u00A0" : char}
                    </motion.div>
                ))}
            </div>
        </div>
    );
};
