import { motion } from "framer-motion";

export const MultiDirectionSlide = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden gap-2">
            <motion.div
                animate={{ x: [-50, 50] }}
                transition={{ repeat: Infinity, repeatType: "mirror", duration: 3 }}
                className="flex gap-2"
            >
                <div className="px-4 py-1 bg-neutral-200 dark:bg-neutral-800 rounded">Slide Left</div>
                <div className="px-4 py-1 bg-neutral-200 dark:bg-neutral-800 rounded">To Right</div>
            </motion.div>

            <motion.div
                animate={{ x: [50, -50] }}
                transition={{ repeat: Infinity, repeatType: "mirror", duration: 3 }}
                className="flex gap-2"
            >
                <div className="px-4 py-1 bg-black dark:bg-white text-white dark:text-black rounded">Slide Right</div>
                <div className="px-4 py-1 bg-black dark:bg-white text-white dark:text-black rounded">To Left</div>
            </motion.div>
        </div>
    );
};
