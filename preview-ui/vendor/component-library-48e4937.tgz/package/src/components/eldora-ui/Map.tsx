export const Map = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900 overflow-hidden relative">
            <div className="absolute inset-0 opacity-20"
                style={{
                    backgroundImage: 'radial-gradient(circle at 1px 1px, gray 1px, transparent 0)',
                    backgroundSize: '20px 20px'
                }}
            />
            <div className="relative z-10">
                <div className="w-4 h-4 bg-blue-500 rounded-full animate-ping absolute" />
                <div className="w-4 h-4 bg-blue-600 rounded-full border-2 border-white relative z-10" />
                <div className="mt-2 bg-white dark:bg-black px-2 py-1 rounded shadow-lg text-xs font-bold">You</div>
            </div>
        </div>
    );
};
