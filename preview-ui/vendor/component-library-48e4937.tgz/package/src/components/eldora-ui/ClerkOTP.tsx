import { motion } from "framer-motion";

export const ClerkOTP = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 gap-2">
            {[0, 1, 2, 3].map((i) => (
                <motion.div
                    key={i}
                    className="w-10 h-12 bg-white dark:bg-neutral-800 border border-neutral-300 dark:border-neutral-700 rounded-lg flex items-center justify-center text-xl font-bold shadow-sm"
                    initial={{ opacity: 0.5 }}
                    animate={{ opacity: 1 }}
                >
                    <motion.div
                        className="w-0.5 h-6 bg-black dark:bg-white"
                        animate={{ opacity: [0, 1, 0] }}
                        transition={{ duration: 0.8, repeat: Infinity }}
                    />
                </motion.div>
            ))}
        </div>
    );
};
