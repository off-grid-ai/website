import { motion } from "framer-motion";

export const ScratchToReveal = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative w-40 h-20 rounded-lg overflow-hidden border border-neutral-200 dark:border-neutral-700">
                <div className="absolute inset-0 flex items-center justify-center bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-300 font-bold">
                    WINNER!
                </div>
                <motion.div
                    whileHover={{ opacity: 0 }}
                    transition={{ duration: 0.5 }}
                    className="absolute inset-0 bg-neutral-300 dark:bg-neutral-600 flex items-center justify-center cursor-pointer"
                >
                    <span className="text-neutral-500 dark:text-neutral-300 text-xs font-bold uppercase tracking-wider">Scratch Here</span>
                </motion.div>
            </div>
        </div>
    );
};
