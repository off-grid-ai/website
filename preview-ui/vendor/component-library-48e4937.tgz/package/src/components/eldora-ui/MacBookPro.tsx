export const MacBookPro = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900">
            <div className="relative">
                <div className="w-48 h-32 bg-black rounded-t-xl border-4 border-neutral-800 relative z-10 overflow-hidden">
                    <div className="absolute inset-0 bg-blue-900/20 flex items-center justify-center text-white text-xs">Screen</div>
                </div>
                <div className="w-60 h-2 bg-neutral-300 dark:bg-neutral-700 rounded-b-lg -ml-6 shadow-xl relative z-20">
                    <div className="w-8 h-1 bg-neutral-400 absolute top-0 left-1/2 -translate-x-1/2 rounded-b" />
                </div>
            </div>
        </div>
    );
};
