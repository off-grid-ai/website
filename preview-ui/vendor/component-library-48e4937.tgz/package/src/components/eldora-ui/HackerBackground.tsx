import { useEffect, useRef } from "react";

export const HackerBackground = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        let width = canvas.width = canvas.parentElement?.clientWidth || 300;
        let height = canvas.height = canvas.parentElement?.clientHeight || 200;
        const columns = Math.floor(width / 10);
        const drops: number[] = new Array(columns).fill(1);

        const draw = () => {
            ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
            ctx.fillRect(0, 0, width, height);
            ctx.fillStyle = "#0F0";
            ctx.font = "10px monospace";

            for (let i = 0; i < drops.length; i++) {
                const text = String.fromCharCode(Math.random() * 128);
                ctx.fillText(text, i * 10, drops[i] * 10);
                if (drops[i] * 10 > height && Math.random() > 0.975) drops[i] = 0;
                drops[i]++;
            }
        };
        const interval = setInterval(draw, 50);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full bg-black overflow-hidden relative">
            <canvas ref={canvasRef} className="absolute inset-0" />
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <h2 className="text-white bg-black p-2 font-bold font-mono border border-green-500">SYSTEM READY</h2>
            </div>
        </div>
    );
};
