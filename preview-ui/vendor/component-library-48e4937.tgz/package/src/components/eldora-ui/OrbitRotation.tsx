import { motion } from "framer-motion";

export const OrbitRotation = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden relative">
            <div className="absolute w-40 h-40 border border-white/20 rounded-full" />
            <div className="absolute w-24 h-24 border border-white/20 rounded-full" />

            <motion.div
                className="absolute w-40 h-40"
                animate={{ rotate: 360 }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            >
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-blue-500 rounded-full shadow-[0_0_10px_#3b82f6]" />
            </motion.div>

            <motion.div
                className="absolute w-24 h-24"
                animate={{ rotate: -360 }}
                transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
            >
                <div className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-red-500 rounded-full shadow-[0_0_10px_#ef4444]" />
            </motion.div>

            <div className="w-8 h-8 bg-white rounded-full shadow-[0_0_20px_rgba(255,255,255,0.5)] z-10" />
        </div>
    );
};
