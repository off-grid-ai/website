import { motion } from "framer-motion";

export const SeparateAwayText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.div
                className="flex gap-0"
                whileHover={{ gap: "20px" }}
            >
                <span className="text-2xl font-bold bg-black dark:bg-white text-white dark:text-black px-2">SEPARATE</span>
                <span className="text-2xl font-bold bg-black dark:bg-white text-white dark:text-black px-2">AWAY</span>
            </motion.div>
        </div>
    );
};
