

export const CardFlipHover = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900 perspective-1000">
            <div className="w-32 h-40 relative group preserve-3d">
                <div className="absolute inset-0 bg-white dark:bg-neutral-800 rounded-xl shadow-lg border border-neutral-200 dark:border-neutral-700 flex items-center justify-center backface-hidden transition-transform duration-500 group-hover:rotate-y-180">
                    <span className="font-bold">Hover</span>
                </div>
                <div className="absolute inset-0 bg-blue-500 rounded-xl shadow-lg flex items-center justify-center text-white backface-hidden rotate-y-180 transition-transform duration-500 group-hover:rotate-y-0">
                    <span className="font-bold">Flip!</span>
                </div>
            </div>
        </div>
    );
};
