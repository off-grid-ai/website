import { motion } from "framer-motion";

export const BlurInText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.h2
                initial={{ filter: "blur(10px)", opacity: 0 }}
                animate={{ filter: "blur(0px)", opacity: 1 }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="text-2xl font-bold"
            >
                Blur In
            </motion.h2>
        </div>
    );
};
