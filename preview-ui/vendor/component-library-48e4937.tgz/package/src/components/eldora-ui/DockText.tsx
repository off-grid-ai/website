import { motion } from "framer-motion";

export const DockText = () => {
    const letters = "DOCK".split("");

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex gap-1">
                {letters.map((l, i) => (
                    <motion.div
                        key={i}
                        whileHover={{ y: -10, scale: 1.2 }}
                        className="text-3xl font-black bg-clip-text text-transparent bg-gradient-to-b from-neutral-800 to-neutral-500 dark:from-white dark:to-neutral-400 cursor-default"
                    >
                        {l}
                    </motion.div>
                ))}
            </div>
        </div>
    );
};
