import { motion } from "framer-motion";

export const SVGRippleEffect = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden">
            <div className="relative">
                <div className="absolute inset-0 flex items-center justify-center">
                    {[1, 2, 3].map((i) => (
                        <motion.div
                            key={i}
                            className="absolute border border-blue-500/50 rounded-full"
                            style={{ width: i * 40, height: i * 40 }}
                            animate={{ scale: [1, 1.5], opacity: [0.5, 0] }}
                            transition={{ duration: 2, repeat: Infinity, delay: i * 0.4 }}
                        />
                    ))}
                </div>
                <div className="relative z-10 w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center">
                    <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
            </div>
        </div>
    );
};
