export const LogoTimeline = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative h-48 w-full max-w-[200px] flex flex-col justify-between ml-8 border-l-2 border-neutral-200 dark:border-neutral-700">
                {[1, 2, 3].map((i) => (
                    <div key={i} className="relative pl-6">
                        <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-white dark:bg-neutral-900 border-2 border-blue-500" />
                        <div className="w-8 h-8 bg-neutral-100 dark:bg-neutral-800 rounded-md mb-1" />
                        <div className="text-xs text-neutral-500">202{i}</div>
                    </div>
                ))}
            </div>
        </div>
    );
};
