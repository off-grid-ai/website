import { motion } from "framer-motion";

export const FontWeightText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.h1
                animate={{ fontWeight: [100, 900, 100] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="text-4xl text-black dark:text-white"
            >
                Weight
            </motion.h1>
        </div>
    );
};
