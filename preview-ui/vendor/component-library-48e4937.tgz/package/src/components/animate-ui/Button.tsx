import { motion } from "framer-motion";

export const Button = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 gap-4">
            <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-2 bg-black dark:bg-white text-white dark:text-black rounded-lg font-medium shadow-lg"
            >
                Click Me
            </motion.button>

            <button className="px-6 py-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-lg font-medium shadow-lg hover:shadow-blue-500/50 transition-all duration-300 transform hover:-translate-y-1">
                Gradient
            </button>
        </div>
    );
};
