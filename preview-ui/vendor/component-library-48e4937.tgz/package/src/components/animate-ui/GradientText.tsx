export const GradientText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 animate-gradient-x bg-300%">
                Animate UI
            </h1>
        </div>
    );
};
