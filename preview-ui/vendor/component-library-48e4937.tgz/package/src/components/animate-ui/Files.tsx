import { Folder, FileCode, FileImage } from "lucide-react";
import { motion } from "framer-motion";

export const Files = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-white dark:bg-neutral-900 p-8">
            <div className="w-full max-w-[200px] border border-neutral-200 dark:border-neutral-800 rounded-lg p-2 bg-neutral-50 dark:bg-neutral-800/50">
                <div className="flex items-center gap-2 mb-2 px-2 py-1 bg-blue-100 dark:bg-blue-900/30 rounded text-blue-600 dark:text-blue-400 text-sm font-medium">
                    <Folder className="w-4 h-4" />
                    src
                </div>
                <div className="pl-4 space-y-1">
                    <motion.div
                        className="flex items-center gap-2 px-2 py-1 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded cursor-pointer text-xs text-neutral-600 dark:text-neutral-300"
                        whileHover={{ x: 2 }}
                    >
                        <FileCode className="w-3.5 h-3.5 text-yellow-500" />
                        App.tsx
                    </motion.div>
                    <motion.div
                        className="flex items-center gap-2 px-2 py-1 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded cursor-pointer text-xs text-neutral-600 dark:text-neutral-300"
                        whileHover={{ x: 2 }}
                    >
                        <FileCode className="w-3.5 h-3.5 text-blue-500" />
                        index.css
                    </motion.div>
                    <motion.div
                        className="flex items-center gap-2 px-2 py-1 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded cursor-pointer text-xs text-neutral-600 dark:text-neutral-300"
                        whileHover={{ x: 2 }}
                    >
                        <FileImage className="w-3.5 h-3.5 text-purple-500" />
                        logo.svg
                    </motion.div>
                </div>
            </div>
        </div>
    );
};
