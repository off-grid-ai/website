import { motion } from "framer-motion";

export const ImageZoom = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden">
            <div className="w-64 h-40 overflow-hidden rounded-xl relative group cursor-zoom-in">
                <motion.img
                    src="https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=2670&auto=format&fit=crop"
                    alt="Mountain"
                    className="w-full h-full object-cover"
                    whileHover={{ scale: 1.5 }}
                    transition={{ duration: 0.5 }}
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none flex items-center justify-center text-white font-medium">
                    Zooming...
                </div>
            </div>
        </div>
    );
};
