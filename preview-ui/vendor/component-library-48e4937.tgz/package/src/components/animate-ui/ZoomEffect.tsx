import { motion } from "framer-motion";

export const ZoomEffect = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden">
            <div className="grid grid-cols-2 gap-4">
                {[1, 2, 3, 4].map((i) => (
                    <motion.div
                        key={i}
                        className="w-16 h-16 bg-neutral-200 dark:bg-neutral-800 rounded-lg"
                        whileHover={{ scale: 1.2, zIndex: 10 }}
                        initial={{ opacity: 0, scale: 0.5 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: i * 0.1 }}
                    />
                ))}
            </div>
        </div>
    );
};
