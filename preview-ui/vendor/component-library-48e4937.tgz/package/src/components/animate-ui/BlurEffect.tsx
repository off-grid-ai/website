import { motion } from "framer-motion";

export const BlurEffect = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden relative">
            <div className="absolute inset-0 grid grid-cols-2">
                <div className="bg-pink-500/30" />
                <div className="bg-blue-500/30" />
                <div className="bg-yellow-500/30" />
                <div className="bg-purple-500/30" />
            </div>

            <motion.div
                initial={{ filter: "blur(0px)" }}
                animate={{ filter: ["blur(0px)", "blur(10px)", "blur(0px)"] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="z-10 bg-white/10 backdrop-blur-md border border-white/20 p-6 rounded-2xl shadow-2xl"
            >
                <h2 className="text-2xl font-bold text-black dark:text-white">Blur</h2>
            </motion.div>
        </div>
    );
};
