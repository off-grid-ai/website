import { motion } from "framer-motion";
import { useState } from "react";

export const FlipCard = () => {
    const [isFlipped, setIsFlipped] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900">
            <div
                className="w-40 h-56 cursor-pointer perspective-1000"
                onClick={() => setIsFlipped(!isFlipped)}
                style={{ perspective: 1000 }}
            >
                <motion.div
                    className="w-full h-full relative preserve-3d"
                    animate={{ rotateY: isFlipped ? 180 : 0 }}
                    transition={{ duration: 0.6, type: "spring", stiffness: 260, damping: 20 }}
                    style={{ transformStyle: "preserve-3d" }}
                >
                    {/* Front */}
                    <div className="absolute inset-0 backface-hidden bg-white dark:bg-neutral-800 rounded-xl shadow-lg flex items-center justify-center border border-neutral-200 dark:border-neutral-700">
                        <h3 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-br from-blue-500 to-purple-500">
                            Front
                        </h3>
                        <span className="absolute bottom-4 text-xs text-neutral-400">Click to flip</span>
                    </div>

                    {/* Back */}
                    <div
                        className="absolute inset-0 backface-hidden bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl shadow-lg flex items-center justify-center text-white"
                        style={{ transform: "rotateY(180deg)" }}
                    >
                        <h3 className="text-xl font-bold">Back</h3>
                    </div>
                </motion.div>
            </div>
        </div>
    );
};
