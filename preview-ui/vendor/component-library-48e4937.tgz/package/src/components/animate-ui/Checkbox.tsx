import { motion } from "framer-motion";
import { useState } from "react";
import { Check } from "lucide-react";

export const Checkbox = () => {
    const [checked, setChecked] = useState(true);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div
                className="flex items-center gap-3 cursor-pointer select-none"
                onClick={() => setChecked(!checked)}
            >
                <div className={`w-6 h-6 rounded-md border-2 flex items-center justify-center transition-colors duration-200 ${checked ? 'bg-blue-500 border-blue-500' : 'border-neutral-300 dark:border-neutral-600'}`}>
                    <motion.div
                        initial={false}
                        animate={{ scale: checked ? 1 : 0 }}
                        transition={{ type: "spring", stiffness: 300, damping: 20 }}
                    >
                        <Check className="w-4 h-4 text-white" strokeWidth={3} />
                    </motion.div>
                </div>
                <span className={`text-sm font-medium ${checked ? 'text-neutral-900 dark:text-white' : 'text-neutral-500'}`}>
                    Animated Checkbox
                </span>
            </div>
        </div>
    );
};
