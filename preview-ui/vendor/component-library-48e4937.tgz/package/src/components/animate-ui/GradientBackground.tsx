import { motion, useReducedMotion } from "motion/react";
import { cn } from "../../sourced/coss/lib/utils.js";

// Existing Animate UI catalogue gradient. The ambient variant keeps its moving
// background positions, with Off Grid tokens and reduced-motion support.
export const GradientBackground = ({
  ambient = false,
  className = "",
}: {
  ambient?: boolean;
  className?: string;
}) => {
  const reduced = useReducedMotion();
  return (
    <div
      aria-hidden={ambient || undefined}
      className={cn(
        "w-full h-full relative overflow-hidden flex items-center justify-center",
        ambient ? "bg-background" : "bg-neutral-900",
        className,
      )}
    >
      <motion.div
        className={
          ambient
            ? "absolute inset-0 bg-gradient-to-br from-primary/20 via-background to-primary/10"
            : "absolute inset-0 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500"
        }
        animate={
          reduced
            ? undefined
            : {
                backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
              }
        }
        transition={{
          duration: ambient ? 18 : 5,
          repeat: Infinity,
          ease: "linear",
        }}
        style={{ backgroundSize: "200% 200%" }}
      />
      {!ambient && (
        <h2 className="relative z-10 text-white font-bold text-2xl mix-blend-overlay">
          Gradient
        </h2>
      )}
    </div>
  );
};
