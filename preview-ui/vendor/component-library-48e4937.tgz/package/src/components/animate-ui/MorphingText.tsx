import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

const words = ["Dream", "Create", "Inspire"];

export const MorphingText = () => {
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % words.length);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <AnimatePresence mode="wait">
                <motion.h2
                    key={words[index]}
                    initial={{ opacity: 0, filter: "blur(10px)", y: 20 }}
                    animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
                    exit={{ opacity: 0, filter: "blur(10px)", y: -20 }}
                    transition={{ duration: 0.5 }}
                    className="text-4xl font-bold text-white tracking-widest uppercase"
                >
                    {words[index]}
                </motion.h2>
            </AnimatePresence>
        </div>
    );
};
