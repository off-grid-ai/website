export const HoleBackground = () => {
    return (
        <div className="w-full h-full bg-black relative flex items-center justify-center overflow-hidden">

            <div
                className="absolute w-[200%] h-[200%] bg-[radial-gradient(circle_at_center,transparent_0%,black_70%)] pointer-events-none z-10"
            />

            <div className="grid grid-cols-12 gap-4 opacity-30 transform scale-150 animate-spin-slow">
                {[...Array(144)].map((_, i) => (
                    <div key={i} className="w-2 h-2 bg-white rounded-full" />
                ))}
            </div>

            <div className="relative z-20 text-white text-2xl font-bold">Black Hole</div>
        </div>
    );
};
