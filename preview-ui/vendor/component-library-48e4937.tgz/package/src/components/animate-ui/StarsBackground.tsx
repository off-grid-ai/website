import { motion } from "framer-motion";

export const StarsBackground = () => {
    return (
        <div className="w-full h-full bg-slate-900 relative overflow-hidden flex items-center justify-center">
            {[...Array(50)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute bg-white rounded-full"
                    style={{
                        width: Math.random() * 2 + 1,
                        height: Math.random() * 2 + 1,
                        left: `${Math.random() * 100}%`,
                        top: `${Math.random() * 100}%`,
                    }}
                    animate={{ opacity: [0.2, 1, 0.2] }}
                    transition={{
                        duration: Math.random() * 2 + 1,
                        repeat: Infinity,
                        delay: Math.random() * 2
                    }}
                />
            ))}
            <h2 className="text-white font-thin text-xl tracking-[0.5em] z-10">STARS</h2>
        </div>
    );
};
