export const Code = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-950 p-6">
            <div className="w-full bg-neutral-900 rounded-lg p-4 font-mono text-xs overflow-hidden border border-neutral-800 shadow-xl">
                <div className="flex gap-1.5 mb-3">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-500" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-500" />
                </div>
                <div className="space-y-1">
                    <div className="text-purple-400">const<span className="text-blue-400"> greeting</span> = <span className="text-green-400">"Hello World"</span>;</div>
                    <div className="text-purple-400">function<span className="text-blue-400"> sayHello</span>() {'{'}</div>
                    <div className="pl-4 text-neutral-300">console.<span className="text-yellow-400">log</span>(greeting);</div>
                    <div className="text-neutral-300">{'}'}</div>
                </div>
            </div>
        </div>
    );
};
