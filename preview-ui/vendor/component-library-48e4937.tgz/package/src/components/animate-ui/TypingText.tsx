import { motion } from "framer-motion";
import { useState, useEffect } from "react";

const text = "Typing...";

export const TypingText = () => {
    const [displayText, setDisplayText] = useState("");

    useEffect(() => {
        let i = 0;
        const interval = setInterval(() => {
            setDisplayText(text.slice(0, i + 1));
            i = (i + 1) % (text.length + 1);
            if (i === 0) i = 0; // Restart
        }, 300);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-black font-mono text-2xl text-green-500">
            {displayText}
            <motion.span
                animate={{ opacity: [0, 1] }}
                transition={{ duration: 0.5, repeat: Infinity }}
                className="w-2 h-6 bg-green-500 ml-1 inline-block"
            />
        </div>
    );
};
