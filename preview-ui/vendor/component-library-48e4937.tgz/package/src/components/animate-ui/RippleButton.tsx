export const RippleButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <button className="relative overflow-hidden px-8 py-3 bg-blue-600 text-white rounded-lg font-bold shadow-lg transition-transform active:scale-95 group">
                <span className="relative z-10">Ripple</span>
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-32 h-32 bg-white/30 rounded-full animate-ping absolute" />
                </div>
            </button>
        </div>
    );
};
