import { motion } from "framer-motion";

export const ParticlesEffect = () => {
    return (
        <div className="w-full h-full bg-black relative flex items-center justify-center overflow-hidden">
            {[...Array(30)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute w-1 h-1 bg-white rounded-full opacity-50"
                    initial={{
                        x: Math.random() * 300 - 150,
                        y: Math.random() * 200 - 100,
                        scale: Math.random() * 0.5 + 0.5,
                    }}
                    animate={{
                        x: [null, Math.random() * 300 - 150],
                        y: [null, Math.random() * 200 - 100],
                    }}
                    transition={{
                        duration: Math.random() * 5 + 5,
                        repeat: Infinity,
                        repeatType: "mirror",
                        ease: "linear"
                    }}
                />
            ))}
            <h2 className="z-10 text-white font-bold tracking-widest border-2 border-white p-4">PARTICLES</h2>
        </div>
    );
};
