import { motion } from "framer-motion";

export const MotionCarousel = () => {
    return (
        <div className="w-full h-full flex items-center overflow-hidden bg-white dark:bg-neutral-900">
            <motion.div
                className="flex gap-4 px-4"
                animate={{ x: ["0%", "-50%"] }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            >
                {[...Array(6)].map((_, i) => (
                    <div
                        key={i}
                        className="w-32 h-40 bg-neutral-200 dark:bg-neutral-800 rounded-xl flex-shrink-0"
                        style={{ backgroundColor: `hsl(${i * 60}, 70%, 50%)` }}
                    />
                ))}
                {[...Array(6)].map((_, i) => (
                    <div
                        key={`dup-${i}`}
                        className="w-32 h-40 bg-neutral-200 dark:bg-neutral-800 rounded-xl flex-shrink-0"
                        style={{ backgroundColor: `hsl(${i * 60}, 70%, 50%)` }}
                    />
                ))}
            </motion.div>
        </div>
    );
};
