import { motion } from "framer-motion";
import { useState } from "react";

export const AlertDialog = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 relative">
            <button
                onClick={() => setOpen(true)}
                className="px-4 py-2 bg-red-500 text-white rounded-md text-sm font-medium hover:bg-red-600 transition-colors"
            >
                Delete Account
            </button>

            {open && (
                <div className="absolute inset-0 z-50 flex items-center justify-center p-4">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
                        onClick={() => setOpen(false)}
                    />
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="relative bg-white dark:bg-neutral-800 rounded-lg p-6 shadow-xl max-w-sm w-full z-10"
                    >
                        <h3 className="text-lg font-bold text-neutral-900 dark:text-white mb-2">Are you sure?</h3>
                        <p className="text-sm text-neutral-500 dark:text-neutral-400 mb-4">
                            This action cannot be undone. This will permanently delete your account.
                        </p>
                        <div className="flex justify-end gap-2">
                            <button
                                onClick={() => setOpen(false)}
                                className="px-3 py-1.5 text-sm font-medium text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-md"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={() => setOpen(false)}
                                className="px-3 py-1.5 text-sm font-medium text-white bg-red-500 hover:bg-red-600 rounded-md"
                            >
                                Delete
                            </button>
                        </div>
                    </motion.div>
                </div>
            )}
        </div>
    );
};
