export const ShineEffect = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <button className="relative px-6 py-2 bg-neutral-900 text-white rounded-lg font-bold overflow-hidden">
                Shine Button
                <div className="absolute top-0 -inset-full h-full w-1/2 z-5 block transform -skew-x-12 bg-gradient-to-r from-transparent to-white opacity-40 animate-shine" />
            </button>
        </div>
    );
};
