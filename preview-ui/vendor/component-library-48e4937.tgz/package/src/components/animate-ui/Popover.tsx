import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";

export const Popover = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative">
                <button
                    onMouseEnter={() => setOpen(true)}
                    onMouseLeave={() => setOpen(false)}
                    className="px-4 py-2 bg-neutral-100 dark:bg-neutral-800 rounded-md font-medium text-sm"
                >
                    Hover me
                </button>

                <AnimatePresence>
                    {open && (
                        <motion.div
                            initial={{ opacity: 0, y: 10, scale: 0.9 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 10, scale: 0.9 }}
                            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 bg-black text-white p-3 rounded-lg text-xs text-center z-20 pointer-events-none"
                        >
                            <p>This is a popover appearing on hover.</p>
                            <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-black rotate-45" />
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
};
