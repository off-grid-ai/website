import { motion } from "framer-motion";

export const GravityStars = () => {
    return (
        <div className="w-full h-full bg-black flex items-center justify-center relative overflow-hidden">
            {[...Array(20)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute w-1 h-1 bg-white rounded-full"
                    style={{
                        left: `${Math.random() * 100}%`,
                        top: `-10%`,
                    }}
                    animate={{
                        y: ["0%", "120%"],
                        opacity: [0, 1, 0]
                    }}
                    transition={{
                        duration: Math.random() * 2 + 2,
                        repeat: Infinity,
                        delay: Math.random() * 5,
                        ease: "linear"
                    }}
                />
            ))}
            <h2 className="text-white font-bold text-lg border border-white/20 px-4 py-2 rounded-full backdrop-blur-sm z-10">Gravity</h2>
        </div>
    );
};
