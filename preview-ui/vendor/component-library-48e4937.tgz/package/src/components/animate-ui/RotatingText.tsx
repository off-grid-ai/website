import { motion, AnimatePresence } from "framer-motion";
import { useState, useEffect } from "react";

const careers = ["Designer", "Developer", "Creator"];

export const RotatingText = () => {
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % careers.length);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-white dark:bg-neutral-900 font-bold text-xl">
            <span className="text-neutral-500 mb-1">I am a</span>
            <div className="h-8 overflow-hidden relative w-32 text-center">
                <AnimatePresence mode="popLayout">
                    <motion.div
                        key={careers[index]}
                        initial={{ y: 30, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -30, opacity: 0 }}
                        transition={{ duration: 0.5 }}
                        className="text-blue-600"
                    >
                        {careers[index]}
                    </motion.div>
                </AnimatePresence>
            </div>
        </div>
    );
};
