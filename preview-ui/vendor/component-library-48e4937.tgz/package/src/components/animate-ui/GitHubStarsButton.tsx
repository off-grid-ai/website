import { Star } from "lucide-react";

export const GitHubStarsButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <button className="flex items-center gap-2 px-4 py-2 bg-neutral-900 text-white rounded-lg hover:bg-neutral-800 transition-colors group">
                <Star className="w-4 h-4 text-neutral-400 group-hover:text-yellow-400 transition-colors" />
                <span className="font-medium text-sm">Star on GitHub</span>
                <span className="px-2 py-0.5 bg-neutral-700 rounded text-xs text-neutral-300">4.5k</span>
            </button>
        </div>
    );
};
