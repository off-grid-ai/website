import { motion } from "framer-motion";
import { Menu, Home, Settings, User } from "lucide-react";
import { useState } from "react";

export const Sidebar = () => {
    const [expanded, setExpanded] = useState(true);

    return (
        <div className="w-full h-full flex bg-neutral-100 dark:bg-neutral-900 overflow-hidden relative">
            <motion.div
                className="bg-white dark:bg-neutral-800 border-r border-neutral-200 dark:border-neutral-700 flex flex-col"
                animate={{ width: expanded ? 120 : 50 }}
            >
                <div className="p-3 border-b border-neutral-200 dark:border-neutral-700 flex items-center gap-2">
                    <button onClick={() => setExpanded(!expanded)}><Menu className="w-4 h-4" /></button>
                    {expanded && <span className="text-xs font-bold">Menu</span>}
                </div>
                <div className="p-2 space-y-1">
                    <div className="flex items-center gap-2 p-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded cursor-pointer">
                        <Home className="w-4 h-4" />
                        {expanded && <span className="text-xs">Home</span>}
                    </div>
                    <div className="flex items-center gap-2 p-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded cursor-pointer">
                        <User className="w-4 h-4" />
                        {expanded && <span className="text-xs">Profile</span>}
                    </div>
                    <div className="flex items-center gap-2 p-2 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded cursor-pointer">
                        <Settings className="w-4 h-4" />
                        {expanded && <span className="text-xs">Settings</span>}
                    </div>
                </div>
            </motion.div>
            <div className="flex-1 p-4">
                <div className="h-full bg-white dark:bg-neutral-800 rounded border border-neutral-200 dark:border-neutral-700 opacity-50" />
            </div>
        </div>
    );
};
