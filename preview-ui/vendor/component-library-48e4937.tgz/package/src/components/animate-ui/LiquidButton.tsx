export const LiquidButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <button className="relative px-8 py-3 bg-indigo-600 text-white rounded-full overflow-hidden group font-bold tracking-wider">
                <span className="relative z-10">Liquid</span>
                <div className="absolute inset-0 h-full w-full scale-0 rounded-full group-hover:scale-[2.5] transition-transform duration-700 bg-indigo-500 ease-in-out" />
            </button>
        </div>
    );
};
