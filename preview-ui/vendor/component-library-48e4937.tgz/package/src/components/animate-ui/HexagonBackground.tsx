export const HexagonBackground = () => {
    return (
        <div className="w-full h-full bg-neutral-900 relative overflow-hidden flex flex-wrap gap-1 p-2 opacity-50">
            {[...Array(40)].map((_, i) => (
                <div
                    key={i}
                    className="w-12 h-12 bg-neutral-800 clip-path-hexagon hover:bg-blue-500/50 transition-colors duration-300"
                    style={{
                        clipPath: "polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)"
                    }}
                />
            ))}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <span className="text-white font-bold text-xl drop-shadow-lg">Hex Grid</span>
            </div>
        </div>
    );
};
