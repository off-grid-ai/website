import { Heart, Share2, MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

export const IconButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center gap-4 bg-white dark:bg-neutral-900">
            <motion.button
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                className="p-3 bg-rose-50 text-rose-500 rounded-full hover:bg-rose-100 transition-colors"
            >
                <Heart className="w-5 h-5 fill-current" />
            </motion.button>

            <motion.button
                whileHover={{ scale: 1.1, rotate: 15 }}
                whileTap={{ scale: 0.9 }}
                className="p-3 bg-blue-50 text-blue-500 rounded-full hover:bg-blue-100 transition-colors"
            >
                <Share2 className="w-5 h-5" />
            </motion.button>

            <motion.button
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.9 }}
                className="p-3 bg-emerald-50 text-emerald-500 rounded-full hover:bg-emerald-100 transition-colors"
            >
                <MessageCircle className="w-5 h-5" />
            </motion.button>
        </div>
    );
};
