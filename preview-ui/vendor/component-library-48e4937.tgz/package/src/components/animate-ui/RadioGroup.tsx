import { motion } from "framer-motion";
import { useState } from "react";

const plans = ["Starter", "Pro", "Enterprise"];

export const RadioGroup = () => {
    const [selected, setSelected] = useState(plans[1]);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center gap-3 bg-white dark:bg-neutral-900 p-4">
            {plans.map((plan) => (
                <div
                    key={plan}
                    onClick={() => setSelected(plan)}
                    className="relative w-full max-w-xs flex items-center gap-3 p-3 rounded-xl border border-neutral-200 dark:border-neutral-800 cursor-pointer overflow-hidden"
                >
                    {selected === plan && (
                        <motion.div
                            layoutId="radio-highlight"
                            className="absolute inset-0 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800"
                            initial={false}
                            transition={{ type: "spring", stiffness: 300, damping: 30 }}
                        />
                    )}

                    <div className={`relative z-10 w-4 h-4 rounded-full border-2 flex items-center justify-center ${selected === plan ? 'border-blue-500' : 'border-neutral-300'}`}>
                        {selected === plan && <motion.div layoutId="radio-dot" className="w-2 h-2 bg-blue-500 rounded-full" />}
                    </div>
                    <span className="relative z-10 text-sm font-medium text-neutral-900 dark:text-white">{plan} Plan</span>
                </div>
            ))}
        </div>
    );
};
