import { motion } from "framer-motion";
import { useState } from "react";

export const Switch = () => {
    const [isOn, setIsOn] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div
                className={`w-14 h-8 bg-neutral-200 dark:bg-neutral-700 rounded-full p-1 cursor-pointer flex items-center ${isOn ? 'justify-end bg-green-500 dark:bg-green-500' : 'justify-start'}`}
                onClick={() => setIsOn(!isOn)}
            >
                <motion.div
                    layout
                    className="w-6 h-6 bg-white rounded-full shadow-md"
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                />
            </div>
        </div>
    );
};
