import { motion } from "framer-motion";
import { useState } from "react";

const tabs = ["New", "Popular", "Trending"];

export const Tabs = () => {
    const [active, setActive] = useState(tabs[0]);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-lg">
                {tabs.map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActive(tab)}
                        className="relative px-3 py-1.5 text-xs font-medium rounded-md transition-colors z-0"
                    >
                        {active === tab && (
                            <motion.div
                                layoutId="bubble-tab"
                                className="absolute inset-0 bg-white dark:bg-neutral-700 shadow-sm rounded-md -z-10"
                                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                            />
                        )}
                        {tab}
                    </button>
                ))}
            </div>
        </div>
    );
};
