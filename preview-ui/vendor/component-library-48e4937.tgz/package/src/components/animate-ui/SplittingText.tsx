import { motion } from "framer-motion";

export const SplittingText = () => {
    const text = "SPLIT";
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden group">
            <div className="relative text-5xl font-black text-white tracking-widest cursor-default">
                {text.split("").map((char, i) => (
                    <motion.span
                        key={i}
                        className="inline-block"
                        whileHover={{ y: -20, color: "#3b82f6" }}
                        transition={{ type: "spring", stiffness: 300 }}
                    >
                        {char}
                    </motion.span>
                ))}
            </div>
        </div>
    );
};
