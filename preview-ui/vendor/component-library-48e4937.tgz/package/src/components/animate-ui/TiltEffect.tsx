import { motion, useMotionValue, useTransform } from "framer-motion";

export const TiltEffect = () => {
    const x = useMotionValue(0);
    const y = useMotionValue(0);
    const rotateX = useTransform(y, [-100, 100], [30, -30]);
    const rotateY = useTransform(x, [-100, 100], [-30, 30]);

    function handleMouse(event: React.MouseEvent<HTMLDivElement>) {
        const rect = event.currentTarget.getBoundingClientRect();
        const width = rect.width;
        const height = rect.height;
        const mouseX = event.clientX - rect.left;
        const mouseY = event.clientY - rect.top;
        const xPct = mouseX / width - 0.5;
        const yPct = mouseY / height - 0.5;
        x.set(xPct * 200);
        y.set(yPct * 200);
    }

    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900 perspective-1000">
            <motion.div
                onMouseMove={handleMouse}
                onMouseLeave={() => { x.set(0); y.set(0); }}
                style={{ rotateX, rotateY }}
                className="w-32 h-32 bg-gradient-to-br from-blue-400 to-purple-500 rounded-xl shadow-2xl flex items-center justify-center cursor-pointer"
            >
                <span className="text-white font-bold text-lg">Tilt Me</span>
            </motion.div>
        </div>
    );
};
