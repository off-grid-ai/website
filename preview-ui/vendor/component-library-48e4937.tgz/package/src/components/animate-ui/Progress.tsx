import { motion } from "framer-motion";
import { useState, useEffect } from "react";

export const Progress = () => {
    const [progress, setProgress] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setProgress((prev) => (prev >= 100 ? 0 : prev + 10));
        }, 800);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center gap-4 bg-white dark:bg-neutral-900 p-8">
            <div className="w-full h-2 bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                <motion.div
                    className="h-full bg-blue-500"
                    animate={{ width: `${progress}%` }}
                    transition={{ duration: 0.5 }}
                />
            </div>
            <div className="text-sm font-bold font-mono text-neutral-500">{progress}%</div>
        </div>
    );
};
