import { ExternalLink } from "lucide-react";

export const PreviewLinkCard = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-8">
            <div className="w-full max-w-sm rounded-xl border border-neutral-200 dark:border-neutral-700 bg-white dark:bg-neutral-800 overflow-hidden shadow-sm hover:shadow-lg transition-shadow duration-300 group cursor-pointer">
                <div className="h-24 bg-neutral-100 dark:bg-neutral-700 relative overflow-hidden">
                    <div className="absolute inset-0 bg-blue-500/10 group-hover:bg-blue-500/20 transition-colors" />
                    <ExternalLink className="absolute top-2 right-2 w-4 h-4 text-neutral-400 group-hover:text-blue-500 transition-colors" />
                </div>
                <div className="p-4">
                    <h3 className="font-bold text-sm text-neutral-900 dark:text-white mb-1 group-hover:text-blue-500 transition-colors">Amazing Component</h3>
                    <p className="text-xs text-neutral-500 line-clamp-2">Check out this link preview card that animates on hover.</p>
                </div>
            </div>
        </div>
    );
};
