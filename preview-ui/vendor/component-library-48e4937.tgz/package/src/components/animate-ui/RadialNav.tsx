import { motion } from "framer-motion";

export const RadialNav = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden relative">
            <div className="absolute w-[200px] h-[200px] border border-neutral-800 rounded-full flex items-center justify-center">
                <div className="w-[100px] h-[100px] border border-neutral-700 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">NAV</span>
                </div>

                {[0, 90, 180, 270].map((deg) => (
                    <motion.div
                        key={deg}
                        className="absolute w-2 h-2 bg-blue-500 rounded-full"
                        style={{
                            rotate: deg,
                            translateX: 100, // Radius
                        }}
                        animate={{ scale: [1, 1.5, 1] }}
                        transition={{ duration: 2, repeat: Infinity, delay: deg / 360 }}
                    />
                ))}
            </div>
        </div>
    );
};
