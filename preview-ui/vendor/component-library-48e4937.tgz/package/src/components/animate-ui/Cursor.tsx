import { motion } from "framer-motion";
import { useState, useRef } from "react";

export const Cursor = () => {
    const ref = useRef<HTMLDivElement>(null);
    const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
    const [isHovered, setIsHovered] = useState(false);

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!ref.current) return;
        const rect = ref.current.getBoundingClientRect();
        setMousePosition({
            x: e.clientX - rect.left,
            y: e.clientY - rect.top,
        });
    };

    return (
        <div
            ref={ref}
            className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 relative overflow-hidden cursor-none"
            onMouseMove={handleMouseMove}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
        >
            <p className="z-10 text-neutral-500 font-medium pointer-events-none">Move your mouse</p>

            {isHovered && (
                <>
                    {/* Main Cursor */}
                    <motion.div
                        className="absolute w-4 h-4 bg-black dark:bg-white rounded-full pointer-events-none z-20 mix-blend-difference"
                        animate={{
                            x: mousePosition.x - 8,
                            y: mousePosition.y - 8,
                        }}
                        transition={{ type: "tween", ease: "backOut", duration: 0.1 }}
                    />
                    {/* Trailing Cursor */}
                    <motion.div
                        className="absolute w-8 h-8 border border-black dark:border-white rounded-full pointer-events-none z-20 opacity-50"
                        animate={{
                            x: mousePosition.x - 16,
                            y: mousePosition.y - 16,
                        }}
                        transition={{ type: "spring", stiffness: 100, damping: 20 }}
                    />
                </>
            )}
        </div>
    );
};
