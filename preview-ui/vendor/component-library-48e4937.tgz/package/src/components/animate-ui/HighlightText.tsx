import { motion } from "framer-motion";

export const HighlightText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-8">
            <h2 className="text-2xl font-bold text-neutral-900 dark:text-white leading-relaxed text-center">
                Make your content{" "}
                <span className="relative inline-block px-2">
                    <motion.span
                        initial={{ scaleX: 0 }}
                        whileInView={{ scaleX: 1 }}
                        transition={{ duration: 0.5, delay: 0.2 }}
                        className="absolute inset-0 bg-yellow-300 dark:bg-yellow-600/50 -skew-y-2 origin-left -z-10 rounded-sm"
                    />
                    <span className="relative z-10">stand out</span>
                </span>
                {" "}with ease.
            </h2>
        </div>
    );
};
