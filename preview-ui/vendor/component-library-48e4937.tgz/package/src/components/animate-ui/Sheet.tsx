import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { X } from "lucide-react";

export const Sheet = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 relative">
            <button
                onClick={() => setOpen(true)}
                className="px-4 py-2 border border-neutral-300 dark:border-neutral-700 rounded-md hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
            >
                Open Sheet
            </button>

            <AnimatePresence>
                {open && (
                    <>
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onClick={() => setOpen(false)}
                            className="absolute inset-0 bg-black/50 z-10"
                        />
                        <motion.div
                            initial={{ x: "100%" }}
                            animate={{ x: "0%" }}
                            exit={{ x: "100%" }}
                            transition={{ type: "spring", damping: 20 }}
                            className="absolute right-0 top-0 bottom-0 w-2/3 bg-white dark:bg-neutral-800 shadow-xl z-20 p-4 border-l border-neutral-200 dark:border-neutral-700"
                        >
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="font-bold">Sheet</h3>
                                <button onClick={() => setOpen(false)}><X className="w-4 h-4" /></button>
                            </div>
                            <div className="space-y-2">
                                <div className="h-4 bg-neutral-100 dark:bg-neutral-700 rounded w-full" />
                                <div className="h-4 bg-neutral-100 dark:bg-neutral-700 rounded w-3/4" />
                            </div>
                        </motion.div>
                    </>
                )}
            </AnimatePresence>
        </div>
    );
};
