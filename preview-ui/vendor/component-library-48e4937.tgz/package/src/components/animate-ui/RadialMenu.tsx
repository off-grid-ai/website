import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { Plus, Home, User, Settings } from "lucide-react";

export const RadialMenu = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative">
                <button
                    onClick={() => setOpen(!open)}
                    className="w-12 h-12 bg-blue-500 text-white rounded-full flex items-center justify-center shadow-lg relative z-10 hover:bg-blue-600 transition-colors"
                >
                    <motion.div animate={{ rotate: open ? 45 : 0 }}>
                        <Plus className="w-6 h-6" />
                    </motion.div>
                </button>

                <AnimatePresence>
                    {open && (
                        <>
                            {[
                                { icon: Home, angle: -90, color: "bg-red-500" },
                                { icon: User, angle: -30, color: "bg-green-500" },
                                { icon: Settings, angle: 30, color: "bg-purple-500" },
                            ].map((item, i) => (
                                <motion.button
                                    key={i}
                                    initial={{ scale: 0, x: 0, y: 0 }}
                                    animate={{
                                        scale: 1,
                                        x: Math.cos(item.angle * (Math.PI / 180)) * 60,
                                        y: Math.sin(item.angle * (Math.PI / 180)) * 60
                                    }}
                                    exit={{ scale: 0, x: 0, y: 0 }}
                                    transition={{ duration: 0.3, delay: i * 0.05 }}
                                    className={`absolute top-0 left-0 w-10 h-10 ${item.color} text-white rounded-full flex items-center justify-center shadow-sm hover:scale-110 transition-transform`}
                                >
                                    <item.icon className="w-4 h-4" />
                                </motion.button>
                            ))}
                        </>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
};
