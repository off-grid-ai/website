import { motion } from "framer-motion";
import { useState } from "react";
import { Sun, Moon } from "lucide-react";

export const ThemeToggler = () => {
    const [isDark, setIsDark] = useState(false);

    return (
        <div className={`w-full h-full flex items-center justify-center transition-colors duration-500 ${isDark ? 'bg-neutral-900' : 'bg-orange-50'}`}>
            <button
                onClick={() => setIsDark(!isDark)}
                className="relative w-12 h-12 rounded-full flex items-center justify-center overflow-hidden bg-white/20 backdrop-blur-sm border border-white/20 shadow-lg"
            >
                <motion.div
                    initial={false}
                    animate={{ rotate: isDark ? 180 : 0, scale: isDark ? 0 : 1 }}
                    className="absolute"
                >
                    <Sun className="w-6 h-6 text-orange-500" />
                </motion.div>
                <motion.div
                    initial={false}
                    animate={{ rotate: isDark ? 0 : -180, scale: isDark ? 1 : 0 }}
                    className="absolute"
                >
                    <Moon className="w-6 h-6 text-blue-300" />
                </motion.div>
            </button>
        </div>
    );
};
