import { motion, useSpring, useTransform } from "framer-motion";
import { useState, useEffect } from "react";

export const CountingNumber = () => {
    const [, setCount] = useState(0);
    const spring = useSpring(0, { bounce: 0, duration: 2000 });
    const formatted = useTransform(spring, (value) => Math.round(value).toLocaleString());

    useEffect(() => {
        const interval = setInterval(() => {
            const next = Math.floor(Math.random() * 10000);
            spring.set(next);
            setCount(next);
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-white dark:bg-neutral-900">
            <motion.div className="text-4xl font-bold font-mono text-neutral-900 dark:text-white">
                {formatted}
            </motion.div>
            <p className="text-sm text-neutral-500 mt-2">Live Users</p>
        </div>
    );
};
