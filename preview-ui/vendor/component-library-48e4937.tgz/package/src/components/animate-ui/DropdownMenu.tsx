import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { ChevronDown, User, Settings, LogOut } from "lucide-react";

export const DropdownMenu = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative">
                <button
                    onClick={() => setOpen(!open)}
                    className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-neutral-800 border border-neutral-200 dark:border-neutral-700 rounded-lg shadow-sm hover:bg-neutral-50 dark:hover:bg-neutral-700 transition-colors"
                >
                    <span className="text-sm font-medium">My Account</span>
                    <motion.div animate={{ rotate: open ? 180 : 0 }}>
                        <ChevronDown className="w-4 h-4 text-neutral-500" />
                    </motion.div>
                </button>

                <AnimatePresence>
                    {open && (
                        <motion.div
                            initial={{ opacity: 0, y: 10, scale: 0.95 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 10, scale: 0.95 }}
                            transition={{ duration: 0.2 }}
                            className="absolute top-full mt-2 left-0 w-48 bg-white dark:bg-neutral-800 rounded-lg shadow-xl border border-neutral-100 dark:border-neutral-700 overflow-hidden z-20"
                        >
                            <div className="p-1">
                                <button onClick={() => setOpen(false)} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-md text-left">
                                    <User className="w-4 h-4" /> Profile
                                </button>
                                <button onClick={() => setOpen(false)} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-neutral-700 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-700 rounded-md text-left">
                                    <Settings className="w-4 h-4" /> Settings
                                </button>
                                <hr className="my-1 border-neutral-100 dark:border-neutral-700" />
                                <button onClick={() => setOpen(false)} className="flex items-center gap-2 w-full px-3 py-2 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-md text-left">
                                    <LogOut className="w-4 h-4" /> Logout
                                </button>
                            </div>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
};
