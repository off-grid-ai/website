import { motion } from "framer-motion";
import { useState, useEffect } from "react";

export const ScrollingNumber = () => {
    const [num, setNum] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setNum((prev) => (prev + 1) % 10);
        }, 300);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 text-6xl font-mono font-bold">
            <div className="h-[1em] overflow-hidden relative">
                <motion.div
                    key={num}
                    initial={{ y: "100%" }}
                    animate={{ y: "0%" }}
                    className="text-neutral-900 dark:text-white"
                >
                    {num}
                </motion.div>
            </div>
        </div>
    );
};
