import { motion } from "framer-motion";

export const FlipButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.button
                className="relative px-6 py-3 bg-black dark:bg-white text-white dark:text-black font-bold uppercase rounded-none overflow-hidden group"
                initial="initial"
                whileHover="hover"
            >
                <span className="relative z-10 block group-hover:-translate-y-[150%] transition-transform duration-300">
                    Hover Me
                </span>
                <span className="absolute inset-0 flex items-center justify-center translate-y-[150%] group-hover:translate-y-0 transition-transform duration-300 z-10 text-yellow-400">
                    Ta-da!
                </span>
            </motion.button>
        </div>
    );
};
