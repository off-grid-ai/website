import { motion } from "framer-motion";
import { useState, useEffect } from "react";

export const FadeEffect = () => {

    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % 3);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="text-2xl font-bold text-center">
                {index === 0 && (
                    <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        key="1"
                        className="text-blue-500"
                    >
                        Fade In Up
                    </motion.div>
                )}
                {index === 1 && (
                    <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        key="2"
                        className="text-purple-500"
                    >
                        Fade In Right
                    </motion.div>
                )}
                {index === 2 && (
                    <motion.div
                        initial={{ opacity: 0, scale: 0.5 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 1.5 }}
                        key="3"
                        className="text-emerald-500"
                    >
                        Fade In Scale
                    </motion.div>
                )}
            </div>
        </div>
    );
};
