import { motion } from "framer-motion";

export const ScrollProgress = () => {
    return (
        <div className="w-full h-full flex flex-col bg-white dark:bg-neutral-900 overflow-hidden relative">
            <motion.div
                className="w-full h-2 bg-red-500 origin-left"
                animate={{ scaleX: [0, 1] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
            />
            <div className="flex-1 p-4 opacity-30 flex flex-col gap-2">
                {[...Array(6)].map((_, i) => (
                    <div key={i} className="h-4 bg-neutral-200 dark:bg-neutral-700 rounded w-full" style={{ width: `${Math.random() * 40 + 50}%` }} />
                ))}
            </div>
        </div>
    );
};
