import { motion } from "framer-motion";
import { useState } from "react";
import { X } from "lucide-react";

export const Dialog = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 relative">
            <button
                onClick={() => setOpen(true)}
                className="px-6 py-2 bg-neutral-900 dark:bg-white text-white dark:text-black rounded-lg font-medium shadow-lg hover:opacity-90 transition-opacity"
            >
                Open Dialog
            </button>

            {open && (
                <div className="absolute inset-0 z-50 flex items-center justify-center p-4">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
                        onClick={() => setOpen(false)}
                    />
                    <motion.div
                        initial={{ opacity: 0, scale: 0.9, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        className="relative bg-white dark:bg-neutral-800 rounded-xl p-6 shadow-2xl max-w-sm w-full z-10"
                    >
                        <button
                            onClick={() => setOpen(false)}
                            className="absolute top-4 right-4 text-neutral-400 hover:text-neutral-600 dark:hover:text-neutral-200"
                        >
                            <X className="w-4 h-4" />
                        </button>
                        <h3 className="text-xl font-bold text-neutral-900 dark:text-white mb-2">Welcome!</h3>
                        <p className="text-neutral-500 dark:text-neutral-400 mb-6">
                            This is a beautifully animated dialog component. It handles stacking and backdrop blurring automatically.
                        </p>
                        <div className="flex justify-end">
                            <button
                                onClick={() => setOpen(false)}
                                className="px-4 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors"
                            >
                                Got it
                            </button>
                        </div>
                    </motion.div>
                </div>
            )}
        </div>
    );
};
