import { motion } from "framer-motion";

export const FireworksBackground = () => {
    return (
        <div className="w-full h-full bg-black relative overflow-hidden flex items-center justify-center">
            {[...Array(3)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute w-2 h-2 rounded-full"
                    style={{
                        left: `${20 + i * 30}%`,
                        top: "50%",
                        backgroundColor: i === 0 ? "#ef4444" : i === 1 ? "#3b82f6" : "#22c55e",
                    }}
                    animate={{
                        y: [-100, 0],
                        opacity: [0, 1, 0],
                        scale: [0, 20],
                    }}
                    transition={{
                        duration: 2,
                        repeat: Infinity,
                        delay: i * 0.5,
                        ease: "easeOut",
                    }}
                >
                    {/* Particles simulating explosion */}
                    {[...Array(6)].map((_, j) => (
                        <motion.div
                            key={j}
                            className="absolute w-1 h-1 rounded-full"
                            style={{
                                backgroundColor: "inherit",
                                transform: `rotate(${j * 60}deg) translate(10px)`,
                            }}
                        />
                    ))}
                </motion.div>
            ))}
            <h2 className="relative z-10 text-white font-bold text-xl mix-blend-difference">Celebrate</h2>
        </div>
    );
};
