import { motion } from "framer-motion";

export const BubbleBackground = () => {
    return (
        <div className="w-full h-full bg-blue-500 relative overflow-hidden flex items-center justify-center">
            {[...Array(15)].map((_, i) => (
                <motion.div
                    key={i}
                    className="absolute bg-white/20 rounded-full"
                    style={{
                        width: Math.random() * 50 + 10,
                        height: Math.random() * 50 + 10,
                        left: `${Math.random() * 100}%`,
                    }}
                    animate={{
                        y: ["120%", "-20%"],
                        x: [0, Math.random() * 50 - 25]
                    }}
                    transition={{
                        duration: Math.random() * 5 + 5,
                        repeat: Infinity,
                        ease: "linear",
                        delay: Math.random() * 5
                    }}
                />
            ))}
            <h2 className="relative z-10 text-white font-bold text-xl drop-shadow-md">Bubbles</h2>
        </div>
    );
};
