import { useState } from "react";
import { motion } from "framer-motion";

export const CodeTabs = () => {
    const [active, setActive] = useState("React");
    const tabs = ["React", "Vue", "Svelte"];

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-neutral-900 p-4">
            <div className="flex w-full max-w-xs bg-neutral-800 rounded-t-lg overflow-hidden border-b border-neutral-700">
                {tabs.map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActive(tab)}
                        className={`px-4 py-2 text-xs font-mono transition-colors relative flex-1 ${active === tab ? 'text-white' : 'text-neutral-500 hover:text-neutral-300'}`}
                    >
                        {tab}
                        {active === tab && (
                            <motion.div
                                layoutId="code-tab-active"
                                className="absolute top-0 left-0 right-0 h-[2px] bg-blue-500"
                            />
                        )}
                    </button>
                ))}
            </div>
            <div className="w-full max-w-xs h-32 bg-neutral-950 rounded-b-lg border border-t-0 border-neutral-700 p-4 font-mono text-xs text-neutral-400 flex items-center justify-center">
                Code for {active}
            </div>
        </div>
    );
};
