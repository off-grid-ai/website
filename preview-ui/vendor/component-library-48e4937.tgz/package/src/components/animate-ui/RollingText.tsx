import { motion } from "framer-motion";

export const RollingText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden relative">
            <motion.div
                className="whitespace-nowrap text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-neutral-800 via-neutral-200 to-neutral-800"
                animate={{ x: ["0%", "-50%"] }}
                transition={{ duration: 5, repeat: Infinity, ease: "linear" }}
            >
                ROLLING TEXT ROLLING TEXT ROLLING TEXT ROLLING TEXT
            </motion.div>
        </div>
    );
};
