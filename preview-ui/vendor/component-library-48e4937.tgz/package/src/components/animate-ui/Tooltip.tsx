import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { Info } from "lucide-react";

export const Tooltip = () => {
    const [show, setShow] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative">
                <button
                    onMouseEnter={() => setShow(true)}
                    onMouseLeave={() => setShow(false)}
                    className="p-2 text-neutral-500 hover:text-blue-500 transition-colors"
                >
                    <Info className="w-6 h-6" />
                </button>
                <AnimatePresence>
                    {show && (
                        <motion.div
                            initial={{ opacity: 0, y: 10, scale: 0.8 }}
                            animate={{ opacity: 1, y: 0, scale: 1 }}
                            exit={{ opacity: 0, y: 10, scale: 0.8 }}
                            style={{ translateX: "-50%" }}
                            className="absolute bottom-full left-1/2 mb-2 px-3 py-1.5 bg-neutral-900 text-white text-xs rounded-md whitespace-nowrap z-50 pointer-events-none"
                        >
                            Helpful information
                            <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-neutral-900" />
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
};
