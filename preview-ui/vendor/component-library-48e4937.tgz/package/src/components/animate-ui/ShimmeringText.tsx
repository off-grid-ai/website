export const ShimmeringText = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <h1 className="text-3xl font-bold bg-clip-text text-transparent bg-[linear-gradient(110deg,#939393,45%,#1e293b,55%,#939393)] bg-[length:250%_100%] animate-shimmer">
                Shimmer
            </h1>
        </div>
    );
};
