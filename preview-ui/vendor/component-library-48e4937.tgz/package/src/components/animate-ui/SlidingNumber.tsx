import { motion } from "framer-motion";
import { useState, useEffect } from "react";

export const SlidingNumber = () => {
    const [value, setValue] = useState(100);

    useEffect(() => {
        const interval = setInterval(() => {
            setValue((v) => v + Math.floor(Math.random() * 20 - 10));
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-white dark:bg-neutral-900">
            <div className="text-4xl font-bold flex">
                <span className="mr-2">$</span>
                <motion.span
                    key={value}
                    initial={{ y: -20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="text-green-500"
                >
                    {value}
                </motion.span>
            </div>
            <p className="text-xs text-neutral-400 mt-2">Daily Revenue</p>
        </div>
    );
};
