import { motion } from "framer-motion";
import { useState } from "react";

const tabs = ["Daily", "Weekly", "Monthly", "Yearly"];

export const RadioTabs = () => {
    const [selected, setSelected] = useState(tabs[0]);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex bg-neutral-100 dark:bg-neutral-800 p-1 rounded-lg">
                {tabs.map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setSelected(tab)}
                        className={`relative px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${selected === tab ? 'text-black dark:text-white' : 'text-neutral-500 hover:text-neutral-700'}`}
                    >
                        {selected === tab && (
                            <motion.div
                                layoutId="active-tab"
                                className="absolute inset-0 bg-white dark:bg-neutral-600 shadow-sm rounded-md"
                                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                            />
                        )}
                        <span className="relative z-10">{tab}</span>
                    </button>
                ))}
            </div>
        </div>
    );
};
