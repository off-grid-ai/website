import { motion } from "framer-motion";

export const Availability = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-white dark:bg-neutral-900 gap-4">
            <div className="flex items-center gap-3 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-full border border-emerald-100 shadow-sm">
                <span className="relative flex h-3 w-3">
                    <motion.span
                        className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"
                        transition={{ duration: 1.5, repeat: Infinity }}
                    />
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
                </span>
                <span className="text-sm font-medium">Available Now</span>
            </div>

            <div className="flex items-center gap-3 px-4 py-2 bg-neutral-50 text-neutral-500 rounded-full border border-neutral-100 shadow-sm opacity-60">
                <span className="h-3 w-3 bg-neutral-400 rounded-full" />
                <span className="text-sm font-medium">Busy / Away</span>
            </div>
        </div>
    );
};
