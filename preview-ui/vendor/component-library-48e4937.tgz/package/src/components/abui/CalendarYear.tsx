import { motion } from "framer-motion";

export const CalendarYear = () => {
    const days = Array.from({ length: 31 }, (_, i) => i + 1);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-4">
            <div className="w-64 border border-neutral-200 dark:border-neutral-800 rounded-xl p-4 shadow-sm bg-neutral-50/50">
                <h3 className="text-center font-bold text-neutral-800 dark:text-neutral-200 mb-4 text-sm">January 2026</h3>
                <div className="grid grid-cols-7 gap-1 text-center">
                    {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d) => (
                        <div key={d} className="text-xs font-semibold text-neutral-400 mb-2">{d}</div>
                    ))}
                    {Array(4).fill(null).map((_, i) => <div key={`empty-${i}`} />)}
                    {days.slice(0, 24).map((d) => (
                        <motion.div
                            key={d}
                            className={`text-xs p-1 rounded-full ${d === 15 ? 'bg-blue-500 text-white' : 'text-neutral-600 hover:bg-neutral-200 cursor-pointer'}`}
                            whileHover={{ scale: 1.1 }}
                        >
                            {d}
                        </motion.div>
                    ))}
                </div>
            </div>
        </div>
    );
};
