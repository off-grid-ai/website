import { motion } from "framer-motion";
import { useState } from "react";
import { Check } from "lucide-react";

export const ColorSwatchSelector = () => {
    const colors = ["#ef4444", "#3b82f6", "#22c55e", "#eab308", "#a855f7"];
    const [selected, setSelected] = useState(colors[1]);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center gap-4 bg-white dark:bg-neutral-900">
            <div
                className="w-32 h-32 rounded-2xl shadow-lg transition-colors duration-300 flex items-center justify-center text-white font-bold"
                style={{ backgroundColor: selected }}
            >
                Preview
            </div>

            <div className="flex gap-2 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-full border border-neutral-200 dark:border-neutral-700">
                {colors.map((color) => (
                    <button
                        key={color}
                        onClick={() => setSelected(color)}
                        className="w-8 h-8 rounded-full relative focus:outline-none"
                        style={{ backgroundColor: color }}
                    >
                        {selected === color && (
                            <motion.div
                                layoutId="check"
                                className="absolute inset-0 flex items-center justify-center"
                                initial={{ opacity: 0, scale: 0.5 }}
                                animate={{ opacity: 1, scale: 1 }}
                            >
                                <Check className="w-4 h-4 text-white drop-shadow-md" strokeWidth={3} />
                            </motion.div>
                        )}
                    </button>
                ))}
            </div>
        </div>
    );
};
