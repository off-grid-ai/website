export const TextGradient = () => {
    return (
        <div className="w-full h-full flex flex-col items-center justify-center gap-4 bg-black p-4">
            <h1 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400">
                Cool Gradient
            </h1>
            <h2 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-br from-purple-400 via-pink-400 to-red-400">
                Another One
            </h2>
            <p className="text-xl font-medium text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-500">
                Vertical Fade
            </p>
        </div>
    );
};
