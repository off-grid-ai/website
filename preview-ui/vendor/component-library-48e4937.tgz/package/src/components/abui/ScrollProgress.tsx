import { motion } from "framer-motion";

export const ScrollProgress = () => {
    return (
        <div className="w-full h-full flex flex-col bg-white dark:bg-neutral-900 relative overflow-hidden">
            <motion.div
                className="w-full h-1 bg-blue-500 origin-left"
                animate={{ scaleX: [0, 1] }}
                transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            />
            <div className="p-4 space-y-4 opacity-50 overflow-hidden">
                <h3 className="font-bold text-lg">Article Title</h3>
                {[...Array(6)].map((_, i) => (
                    <div key={i} className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-full" style={{ width: `${Math.random() * 40 + 60}%` }} />
                ))}
            </div>
        </div>
    );
};
