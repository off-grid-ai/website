import { Check } from "lucide-react";

export const TimelineSteps = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex items-center">
                {[1, 2, 3, 4].map((step, i) => (
                    <div key={step} className="flex items-center">
                        <div className={`relative flex items-center justify-center w-8 h-8 rounded-full border-2 ${i < 2 ? 'bg-blue-500 border-blue-500 text-white' : i === 2 ? 'border-blue-500 text-blue-500' : 'border-neutral-300 text-neutral-300'}`}>
                            {i < 2 ? <Check className="w-4 h-4" /> : step}
                            <div className="absolute -bottom-6 w-max text-[10px] font-medium text-neutral-500">
                                Step {step}
                            </div>
                        </div>
                        {i < 3 && (
                            <div className={`w-12 h-[2px] ${i < 2 ? 'bg-blue-500' : 'bg-neutral-200'}`} />
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};
