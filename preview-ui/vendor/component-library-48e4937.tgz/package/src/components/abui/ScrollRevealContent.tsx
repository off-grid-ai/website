import { motion } from "framer-motion";

export const ScrollRevealContent = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden relative">
            <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-center space-y-2 p-4"
            >
                <motion.h2
                    className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-500"
                    animate={{ backgroundPosition: ["0%", "100%"] }}
                    transition={{ duration: 2, repeat: Infinity, repeatType: "reverse" }}
                >
                    Reveal Me
                </motion.h2>
                <p className="text-sm text-neutral-500 max-w-[200px] mx-auto">
                    Content fades in and slides up as you scroll into view.
                </p>
            </motion.div>
        </div>
    );
};
