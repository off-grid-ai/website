import { motion } from "framer-motion";

export const AnimatedChart = () => {
    const data = [40, 70, 50, 90, 60, 80];

    return (
        <div className="w-full h-full flex items-end justify-center gap-2 p-8 bg-white dark:bg-neutral-900">
            {data.map((h, i) => (
                <motion.div
                    key={i}
                    className="w-8 bg-blue-500 rounded-t-lg relative group"
                    initial={{ height: 0 }}
                    animate={{ height: `${h}%` }}
                    transition={{
                        duration: 0.8,
                        delay: i * 0.1,
                        ease: "backOut"
                    }}
                >
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-neutral-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                        Value: {h}
                    </div>
                </motion.div>
            ))}
        </div>
    );
};
