import { motion } from "framer-motion";
import { useState, useEffect } from "react";

const items = ["Introduction", "Installation", "Usage", "API"];

export const TableOfContents = () => {
    const [active, setActive] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setActive(prev => (prev + 1) % items.length);
        }, 1500);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-4">
            <div className="w-48 border-l-2 border-neutral-200 dark:border-neutral-800 space-y-4 pl-4">
                {items.map((item, idx) => (
                    <div key={item} className="relative">
                        {active === idx && (
                            <motion.div
                                layoutId="toc-indicator"
                                className="absolute -left-[18px] top-0 h-full w-[2px] bg-blue-500"
                            />
                        )}
                        <span className={`text-sm transition-colors ${active === idx ? 'text-blue-500 font-medium' : 'text-neutral-500'}`}>
                            {item}
                        </span>
                    </div>
                ))}
            </div>
        </div>
    );
};
