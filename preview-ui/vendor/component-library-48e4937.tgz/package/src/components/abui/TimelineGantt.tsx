import { motion } from "framer-motion";

export const TimelineGantt = () => {
    return (
        <div className="w-full h-full flex flex-col justify-center bg-white dark:bg-neutral-900 p-4 gap-3 overflow-hidden">
            {/* Header */}
            <div className="flex gap-8 text-xs text-neutral-400 border-b pb-2 mb-2 ml-20">
                <span>Jan</span><span>Feb</span><span>Mar</span><span>Apr</span>
            </div>

            {/* Rows */}
            {["Design", "Dev", "Test"].map((task, i) => (
                <div key={task} className="flex items-center gap-4">
                    <span className="w-16 text-xs font-medium text-neutral-600 text-right">{task}</span>
                    <div className="flex-1 h-6 bg-neutral-100 dark:bg-neutral-800 rounded relative overflow-hidden">
                        <div className="absolute inset-y-0 w-px bg-neutral-200 left-8" />
                        <div className="absolute inset-y-0 w-px bg-neutral-200 left-16" />
                        <div className="absolute inset-y-0 w-px bg-neutral-200 left-24" />

                        <motion.div
                            className={`absolute top-1 bottom-1 rounded ${i === 0 ? "bg-purple-400 left-0 w-16" :
                                    i === 1 ? "bg-blue-400 left-12 w-20" :
                                        "bg-green-400 left-28 w-12"
                                }`}
                            initial={{ width: 0 }}
                            animate={{ width: i === 0 ? 64 : i === 1 ? 80 : 48 }}
                            transition={{ duration: 1, delay: i * 0.2 }}
                        />
                    </div>
                </div>
            ))}
        </div>
    );
};
