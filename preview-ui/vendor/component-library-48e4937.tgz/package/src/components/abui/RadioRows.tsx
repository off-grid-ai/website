
import { useState } from "react";
import { Check } from "lucide-react";

export const RadioRows = () => {
    const [selected, setSelected] = useState(1);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-gray-50 dark:bg-neutral-900">
            <div className="w-full max-w-sm space-y-2">
                {[1, 2, 3].map((item) => (
                    <div
                        key={item}
                        onClick={() => setSelected(item)}
                        className={`relative p-4 rounded-xl border cursor-pointer transition-all duration-200 flex items-center justify-between ${selected === item
                            ? "bg-white border-blue-500 shadow-sm ring-1 ring-blue-500/20"
                            : "bg-white border-neutral-200 hover:border-neutral-300"
                            }`}
                    >
                        <div className="flex flex-col">
                            <span className="text-sm font-semibold text-neutral-800">Option {item}</span>
                            <span className="text-xs text-neutral-500">Description for option {item}</span>
                        </div>
                        <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${selected === item ? 'border-blue-500 bg-blue-500' : 'border-neutral-300'}`}>
                            {selected === item && <Check className="w-3 h-3 text-white" />}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
