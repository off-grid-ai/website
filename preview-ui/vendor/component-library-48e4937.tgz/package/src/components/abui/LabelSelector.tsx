import { motion } from "framer-motion";
import { useState } from "react";

const labels = ["Bug", "Feature", "Enhancement", "Documentation"];

export const LabelSelector = () => {
    const [selected, setSelected] = useState<string[]>(["Feature"]);

    const toggle = (label: string) => {
        setSelected(prev =>
            prev.includes(label)
                ? prev.filter(l => l !== label)
                : [...prev, label]
        );
    };

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-4">
            <div className="flex flex-wrap gap-2 max-w-xs justify-center">
                {labels.map((label) => {
                    const isSelected = selected.includes(label);
                    return (
                        <button
                            key={label}
                            onClick={() => toggle(label)}
                            className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200 relative overflow-hidden ${isSelected
                                    ? "bg-neutral-900 text-white border-neutral-900 dark:bg-white dark:text-black"
                                    : "bg-white text-neutral-600 border-neutral-200 hover:border-neutral-300"
                                }`}
                        >
                            {isSelected && (
                                <motion.div
                                    layoutId="bg"
                                    className="absolute inset-0 bg-neutral-900 dark:bg-white z-0"
                                />
                            )}
                            <span className="relative z-10">{label}</span>
                        </button>
                    );
                })}
            </div>
        </div>
    );
};
