import { motion } from "framer-motion";
import { useState } from "react";
import { ChevronDown } from "lucide-react";

export const AccordionMultiselect = () => {
    const [open, setOpen] = useState<string | null>("item-1");

    return (
        <div className="w-full h-full p-4 flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="w-full max-w-sm space-y-2">
                {["Design System", "Components", "Templates"].map((item, idx) => {
                    const id = `item-${idx + 1}`;
                    const isOpen = open === id;
                    return (
                        <div key={id} className="border border-neutral-200 dark:border-neutral-800 rounded-lg overflow-hidden bg-neutral-50 dark:bg-neutral-800/50">
                            <button
                                onClick={() => setOpen(isOpen ? null : id)}
                                className="w-full flex items-center justify-between p-3 text-sm font-medium text-neutral-900 dark:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors"
                            >
                                {item}
                                <motion.div
                                    animate={{ rotate: isOpen ? 180 : 0 }}
                                    transition={{ duration: 0.2 }}
                                >
                                    <ChevronDown className="w-4 h-4 text-neutral-500" />
                                </motion.div>
                            </button>
                            <motion.div
                                initial={false}
                                animate={{ height: isOpen ? "auto" : 0 }}
                                className="overflow-hidden"
                            >
                                <div className="p-3 text-xs text-neutral-500 dark:text-neutral-400 border-t border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
                                    Select options for {item}.
                                </div>
                            </motion.div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
};
