export const Spinner = () => {
    return (
        <div className="w-full h-full flex items-center justify-center gap-8 bg-white dark:bg-neutral-900">
            {/* Simple Spinner */}
            <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />

            {/* Bouncing Dots */}
            <div className="flex gap-1">
                {[0, 0.2, 0.4].map((delay) => (
                    <div
                        key={delay}
                        className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"
                        style={{ animationDelay: `${delay}s` }}
                    />
                ))}
            </div>
        </div>
    );
};
