import { ExternalLink, RotateCw } from 'lucide-react';
import type { ComponentData } from '../data/components';
import { motion } from 'framer-motion';
import { getComponentPreview } from '../componentRegistry';
import { useState } from 'react';

interface ComponentCardProps {
    component: ComponentData;
}

const getLibraryBadgeClass = (lib: string) => {
    const lower = lib.toLowerCase();
    const base = "px-3 py-1 rounded-full text-xs font-medium border transition-all duration-300";

    if (lower.includes('aceternity')) return `${base} bg-purple-50 text-purple-700 border-purple-200 group-hover:border-purple-300`;
    if (lower.includes('magic')) return `${base} bg-amber-50 text-amber-700 border-amber-200 group-hover:border-amber-300`;
    if (lower.includes('animate')) return `${base} bg-blue-50 text-blue-700 border-blue-200 group-hover:border-blue-300`;
    if (lower.includes('eldora')) return `${base} bg-emerald-50 text-emerald-700 border-emerald-200 group-hover:border-emerald-300`;
    if (lower.includes('cult')) return `${base} bg-pink-50 text-pink-700 border-pink-200 group-hover:border-pink-300`;
    return `${base} bg-gray-50 text-gray-700 border-gray-200 group-hover:border-gray-300`;
};

export const ComponentCard = ({ component }: ComponentCardProps) => {
    const PreviewComponent = getComponentPreview(component.name, component.library);
    const [previewKey, setPreviewKey] = useState(0);

    const handleReplay = (e: React.MouseEvent) => {
        e.preventDefault();
        e.stopPropagation();
        setPreviewKey(prev => prev + 1);
    };

    return (
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-50px" }}
            whileHover={{ y: -8 }}
            className="group relative flex flex-col overflow-hidden rounded-[24px] bg-white border border-green-400/15 transition-all duration-300 ease-out shadow-[var(--shadow-card)] hover:shadow-[var(--shadow-card-hover)] hover:border-green-400/30"
        >
            {/* Preview Section - Added rounded-t-[24px] to match card radius explicitly */}
            <div className="h-64 bg-surface-tertiary border-b border-neutral-100 relative overflow-hidden flex items-center justify-center p-4 rounded-t-[24px]">
                {PreviewComponent ? (
                    <div className="w-full h-full flex items-center justify-center">
                        <PreviewComponent key={previewKey} words="Preview Text" />
                    </div>
                ) : (
                    <div className="absolute inset-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-50" />
                )}
            </div>

            {/* Metadata Section */}
            <div className="p-6 flex flex-col flex-1">
                {/* Header: Title and Category */}
                <div className="flex items-start justify-between mb-2">
                    <h3 className="text-[20px] font-serif font-normal text-neutral-900 leading-[1.3] group-hover:text-green-600 transition-colors duration-300 line-clamp-1">
                        {component.name}
                    </h3>
                </div>

                <p className="text-[14px] leading-relaxed text-neutral-500 line-clamp-2 font-sans mb-auto">
                    {component.description}
                </p>

                {/* Footer: Controls and Badges */}
                <div className="pt-4 mt-4 border-t border-neutral-100 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                        {/* Left: Library Badge */}
                        <span className={getLibraryBadgeClass(component.library)}>
                            {component.library}
                        </span>

                        {/* Category Badge */}
                        <span className="text-[11px] font-medium text-neutral-400 uppercase tracking-widest border border-neutral-100 px-2 py-1 rounded-full bg-neutral-50">
                            {component.category}
                        </span>
                    </div>

                    {/* Right: Action Buttons */}
                    <div className="flex items-center gap-2">
                        {PreviewComponent && (
                            <button
                                onClick={handleReplay}
                                className="p-2 rounded-full bg-neutral-50 border border-neutral-200 text-neutral-500 hover:text-green-600 hover:bg-green-50 hover:border-green-200 transition-all shadow-sm"
                                title="Replay Animation"
                            >
                                <RotateCw className="h-4 w-4" />
                            </button>
                        )}
                        <a
                            href={component.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="p-2 rounded-full bg-neutral-50 border border-neutral-200 text-neutral-500 hover:text-green-600 hover:bg-green-50 hover:border-green-200 transition-all shadow-sm"
                            title="View Documentation"
                        >
                            <ExternalLink className="h-4 w-4" />
                        </a>
                    </div>
                </div>
            </div>
        </motion.div>
    );
};
