export const TextureOverlay = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-blue-600 relative overflow-hidden">
            <div className="absolute inset-0 mix-blend-overlay opacity-50"
                style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
                }}
            />
            <h2 className="text-white font-black text-2xl relative z-10">NOISE</h2>
        </div>
    );
};
