export const BackgroundTexture = () => {
    return (
        <div className="w-full h-full bg-neutral-100 dark:bg-neutral-900 relative overflow-hidden flex items-center justify-center">
            <div className="absolute inset-0 opacity-[0.05] dark:opacity-[0.1]"
                style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='1'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
                }}
            />
            <div className="relative z-10 p-6 bg-white/80 dark:bg-black/50 backdrop-blur-sm rounded-xl border border-white/20 shadow-xl">
                <h3 className="font-bold text-lg">Textured BG</h3>
            </div>
        </div>
    );
};
