import { motion } from "framer-motion";
import { useState } from "react";
import { Play } from "lucide-react";

export const HoverVideoPlayer = () => {
    const [hover, setHover] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <div
                className="w-48 h-28 bg-neutral-800 rounded-lg overflow-hidden relative cursor-pointer"
                onMouseEnter={() => setHover(true)}
                onMouseLeave={() => setHover(false)}
            >
                <div className="absolute inset-0 flex items-center justify-center z-10 pointer-events-none">
                    <motion.div animate={{ opacity: hover ? 0 : 1 }}>
                        <Play className="w-8 h-8 text-white fill-current" />
                    </motion.div>
                </div>

                {hover ? (
                    <div className="w-full h-full bg-blue-900 flex items-center justify-center text-white text-xs">
                        Video Playing...
                    </div>
                ) : (
                    <div className="w-full h-full bg-neutral-700 flex items-center justify-center text-neutral-500 text-xs">
                        Thumbnail
                    </div>
                )}

                <div className="absolute bottom-2 right-2 px-1.5 py-0.5 bg-black/70 rounded text-[10px] text-white">
                    0:15
                </div>
            </div>
        </div>
    );
};
