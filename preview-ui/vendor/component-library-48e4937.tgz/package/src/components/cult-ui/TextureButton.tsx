export const TextureButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <button className="relative px-6 py-3 bg-stone-100 rounded-lg overflow-hidden border border-stone-200 shadow-sm active:translate-y-0.5 transition-transform">
                <div className="absolute inset-0 opacity-20"
                    style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23000000' fill-opacity='0.2' fill-rule='evenodd'%3E%3Ccircle cx='3' cy='3' r='3'/%3E%3Ccircle cx='13' cy='13' r='3'/%3E%3C/g%3E%3C/svg%3E")`
                    }}
                />
                <span className="relative z-10 font-medium text-stone-700">Stone</span>
            </button>
        </div>
    );
};
