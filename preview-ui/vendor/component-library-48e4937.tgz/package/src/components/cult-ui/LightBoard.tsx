export const LightBoard = () => {
    return (
        <div className="w-full h-full bg-black flex items-center justify-center p-4">
            <div className="grid grid-cols-10 gap-1 opacity-80">
                {[...Array(50)].map((_, i) => (
                    <div
                        key={i}
                        className={`w-3 h-3 rounded-full ${Math.random() > 0.5 ? 'bg-red-500 shadow-[0_0_10px_#ef4444]' : 'bg-neutral-800'}`}
                    />
                ))}
            </div>
        </div>
    );
};
