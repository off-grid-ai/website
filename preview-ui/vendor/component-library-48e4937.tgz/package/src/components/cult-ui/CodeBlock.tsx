import { Check, Copy } from "lucide-react";
import { useState } from "react";

export const CodeBlock = () => {
    const [copied, setCopied] = useState(false);
    const code = `function hello() {\n  return "World";\n}`;

    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-950 p-6">
            <div className="w-full bg-neutral-900 rounded-lg overflow-hidden border border-neutral-800">
                <div className="flex justify-between items-center px-4 py-2 bg-neutral-800/50">
                    <span className="text-xs text-neutral-400">script.js</span>
                    <button onClick={() => { setCopied(true); setTimeout(() => setCopied(false), 2000); }}>
                        {copied ? <Check className="w-3 h-3 text-green-500" /> : <Copy className="w-3 h-3 text-neutral-400" />}
                    </button>
                </div>
                <pre className="p-4 text-xs font-mono text-neutral-300 overflow-x-auto">
                    <code>{code}</code>
                </pre>
            </div>
        </div>
    );
};
