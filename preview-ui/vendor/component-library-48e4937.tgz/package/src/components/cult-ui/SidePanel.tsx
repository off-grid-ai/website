import { motion } from "framer-motion";
import { useState } from "react";
import { ChevronRight } from "lucide-react";

export const SidePanel = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex bg-white dark:bg-neutral-900 overflow-hidden relative">
            <div className="flex-1 p-4 flex items-center justify-center">
                <button
                    onClick={() => setOpen(!open)}
                    className="p-2 bg-neutral-100 dark:bg-neutral-800 rounded-full"
                >
                    <ChevronRight className={`transition-transform ${open ? 'rotate-180' : ''}`} />
                </button>
            </div>
            <motion.div
                initial={{ x: "100%" }}
                animate={{ x: open ? "0%" : "100%" }}
                className="absolute right-0 top-0 bottom-0 w-24 bg-neutral-100 dark:bg-neutral-800 border-l border-neutral-200 dark:border-neutral-700 shadow-xl"
            />
        </div>
    );
};
