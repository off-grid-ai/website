export const StripeBgGuides = () => {
    return (
        <div className="w-full h-full relative bg-white dark:bg-neutral-950 overflow-hidden flex items-center justify-center">
            <div className="absolute inset-0 flex justify-evenly opacity-10">
                {[...Array(5)].map((_, i) => (
                    <div key={i} className="w-px h-full bg-black dark:bg-white" />
                ))}
            </div>
            <div className="z-10 font-bold text-lg">Guides</div>
        </div>
    );
};
