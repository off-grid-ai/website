import { motion } from "framer-motion";

export const LogoCarousel = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 overflow-hidden">

            <div className="absolute inset-y-0 left-0 w-8 bg-gradient-to-r from-white dark:from-neutral-900 to-transparent z-10" />
            <div className="absolute inset-y-0 right-0 w-8 bg-gradient-to-l from-white dark:from-neutral-900 to-transparent z-10" />

            <motion.div
                className="flex gap-8 items-center opacity-50 grayscale"
                animate={{ x: ["0%", "-50%"] }}
                transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            >
                {/* Mock Logos */}
                {[...Array(8)].map((_, i) => (
                    <div key={i} className="flex-shrink-0 font-bold text-xl">LOGO{i + 1}</div>
                ))}
                {[...Array(8)].map((_, i) => (
                    <div key={`dup-${i}`} className="flex-shrink-0 font-bold text-xl">LOGO{i + 1}</div>
                ))}
            </motion.div>
        </div>
    );
};
