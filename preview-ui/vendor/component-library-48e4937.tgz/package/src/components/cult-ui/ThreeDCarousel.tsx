

export const ThreeDCarousel = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black overflow-hidden perspective-1000">
            <div className="relative w-40 h-40 transform-style-3d animate-spin-slow">
                {[0, 1, 2, 3, 4, 5].map((i) => (
                    <div
                        key={i}
                        className="absolute inset-0 bg-gradient-to-br from-purple-500/50 to-blue-500/50 border border-white/20"
                        style={{
                            transform: `rotateY(${i * 60}deg) translateZ(100px)`
                        }}
                    />
                ))}
            </div>
        </div>
    );
};
