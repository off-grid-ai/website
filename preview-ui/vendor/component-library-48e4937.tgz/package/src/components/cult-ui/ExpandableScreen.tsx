import { motion } from "framer-motion";
import { useState } from "react";

export const ExpandableScreen = () => {
    const [expanded, setExpanded] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-900">
            <motion.div
                layout
                className="bg-black rounded-3xl overflow-hidden border-4 border-neutral-800"
                animate={{
                    width: expanded ? 240 : 100,
                    height: expanded ? 160 : 180,
                }}
                onClick={() => setExpanded(!expanded)}
            >
                <div className="w-full h-full relative">
                    <div className="absolute top-2 left-1/2 -translate-x-1/2 w-16 h-4 bg-neutral-900 rounded-full z-20" />
                    <img
                        src="https://images.unsplash.com/photo-1616469829941-c7200edec809?q=80&w=2670&auto=format&fit=crop"
                        alt="Screen"
                        className="w-full h-full object-cover opacity-80"
                    />
                </div>
            </motion.div>
        </div>
    );
};
