import { motion } from "framer-motion";
import { useState } from "react";

export const FeatureCarousel = () => {
    const [index, setIndex] = useState(0);
    const colors = ["bg-blue-500", "bg-purple-500", "bg-green-500"];

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-white dark:bg-neutral-900 gap-4">
            <div className="relative w-40 h-24 overflow-hidden rounded-xl bg-neutral-100 dark:bg-neutral-800">
                <motion.div
                    key={index}
                    initial={{ x: "100%" }}
                    animate={{ x: "0%" }}
                    exit={{ x: "-100%" }}
                    className={`absolute inset-0 ${colors[index]} flex items-center justify-center text-white font-bold`}
                >
                    Feature {index + 1}
                </motion.div>
            </div>
            <div className="flex gap-2">
                {[0, 1, 2].map((i) => (
                    <button
                        key={i}
                        onClick={() => setIndex(i)}
                        className={`w-2 h-2 rounded-full transition-colors ${i === index ? 'bg-black dark:bg-white' : 'bg-neutral-300 dark:bg-neutral-700'}`}
                    />
                ))}
            </div>
        </div>
    );
};
