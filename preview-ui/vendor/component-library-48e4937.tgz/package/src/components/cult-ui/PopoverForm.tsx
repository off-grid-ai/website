import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";

export const PopoverForm = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative">
                <button
                    onClick={() => setOpen(!open)}
                    className="px-4 py-2 border border-neutral-300 dark:border-neutral-700 rounded-md text-sm font-medium"
                >
                    Subscribe
                </button>

                <AnimatePresence>
                    {open && (
                        <motion.div
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="absolute top-full left-1/2 -translate-x-1/2 mt-2 w-56 p-4 bg-white dark:bg-neutral-800 rounded-xl shadow-2xl border border-neutral-100 dark:border-neutral-700 z-10"
                        >
                            <h3 className="text-sm font-bold mb-2">Newsletter</h3>
                            <input className="w-full px-2 py-1 mb-2 text-xs border rounded bg-neutral-50 dark:bg-neutral-900" placeholder="Email" />
                            <button className="w-full py-1 bg-blue-600 text-white rounded text-xs">Submit</button>
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
};
