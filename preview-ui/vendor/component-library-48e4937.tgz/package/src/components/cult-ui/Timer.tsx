import { motion } from "framer-motion";

export const Timer = () => {


    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <div className="relative w-24 h-24 flex items-center justify-center">
                <svg className="absolute inset-0 w-full h-full -rotate-90">
                    <circle cx="48" cy="48" r="40" stroke="#333" strokeWidth="4" fill="none" />
                    <motion.circle
                        cx="48"
                        cy="48"
                        r="40"
                        stroke="#fff"
                        strokeWidth="4"
                        fill="none"
                        strokeDasharray="251.2"
                        animate={{ strokeDashoffset: [0, 251.2] }}
                        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                    />
                </svg>
                <span className="text-white font-mono text-xl">00:10</span>
            </div>
        </div>
    );
};
