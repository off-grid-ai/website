import { useEffect, useRef } from "react";

export const CanvasFractalGrid = () => {
    const canvasRef = useRef<HTMLCanvasElement>(null);

    useEffect(() => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        let frame = 0;
        const draw = () => {
            frame++;
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = "#3b82f6";

            for (let i = 0; i < 10; i++) {
                for (let j = 0; j < 10; j++) {
                    const size = Math.sin((frame * 0.05) + i + j) * 5 + 5;
                    ctx.fillRect(i * 30 + 10, j * 30 + 10, size, size);
                }
            }
            requestAnimationFrame(draw);
        };
        draw();
    }, []);

    return (
        <div className="w-full h-full bg-black flex items-center justify-center overflow-hidden">
            <canvas ref={canvasRef} width={300} height={300} className="opacity-50" />
            <div className="absolute text-white font-mono text-sm">Fractal Grid</div>
        </div>
    );
};
