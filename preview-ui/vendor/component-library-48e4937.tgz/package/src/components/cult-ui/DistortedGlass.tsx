import { motion } from "framer-motion";

export const DistortedGlass = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 opacity-50" />
            <div className="w-32 h-32 bg-blue-500 rounded-full absolute top-10 right-10 blur-xl animate-pulse" />

            <motion.div
                className="relative w-64 h-40 bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-xl flex items-center justify-center"
                animate={{
                    backdropFilter: ["blur(10px)", "blur(20px)", "blur(10px)"],
                    scale: [1, 1.02, 1]
                }}
                transition={{ duration: 4, repeat: Infinity }}
            >
                <h2 className="text-white font-bold text-2xl tracking-widest drop-shadow-md">GLASS</h2>
            </motion.div>
        </div>
    );
};
