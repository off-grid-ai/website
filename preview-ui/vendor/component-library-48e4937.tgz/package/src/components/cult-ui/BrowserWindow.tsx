export const BrowserWindow = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-100 dark:bg-neutral-900 p-8">
            <div className="w-full max-w-sm bg-white dark:bg-neutral-800 rounded-lg shadow-xl overflow-hidden border border-neutral-200 dark:border-neutral-700">
                <div className="h-8 bg-neutral-100 dark:bg-neutral-800 border-b border-neutral-200 dark:border-neutral-700 flex items-center px-3 gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-red-400" />
                    <div className="w-2.5 h-2.5 rounded-full bg-yellow-400" />
                    <div className="w-2.5 h-2.5 rounded-full bg-green-400" />
                    <div className="ml-2 flex-1 h-5 bg-white dark:bg-neutral-900 rounded text-[10px] flex items-center px-2 text-neutral-400">
                        example.com
                    </div>
                </div>
                <div className="h-32 bg-white dark:bg-neutral-900 p-4 flex items-center justify-center text-neutral-400 text-sm">
                    Browser Content
                </div>
            </div>
        </div>
    );
};
