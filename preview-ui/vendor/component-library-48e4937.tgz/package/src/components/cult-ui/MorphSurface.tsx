import { motion } from "framer-motion";

export const MorphSurface = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.div
                className="w-32 h-32 bg-gradient-to-br from-indigo-500 to-pink-500 rounded-[30%]"
                animate={{
                    borderRadius: ["30%", "50%", "30%"],
                    rotate: [0, 90, 180, 270, 360],
                }}
                transition={{
                    duration: 8,
                    repeat: Infinity,
                    ease: "linear"
                }}
            />
        </div>
    );
};
