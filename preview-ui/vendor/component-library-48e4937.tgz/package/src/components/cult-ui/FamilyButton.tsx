import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { Plus } from "lucide-react";

export const FamilyButton = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative">
                <AnimatePresence>
                    {open && (
                        <>
                            {[1, 2, 3].map((i) => (
                                <motion.div
                                    key={i}
                                    initial={{ scale: 0, y: 0 }}
                                    animate={{ scale: 1, y: -50 * i }}
                                    exit={{ scale: 0, y: 0 }}
                                    transition={{ delay: i * 0.05 }}
                                    className="absolute bottom-0 left-0 w-12 h-12 bg-neutral-200 dark:bg-neutral-800 rounded-full shadow-md z-0"
                                />
                            ))}
                        </>
                    )}
                </AnimatePresence>

                <button
                    onClick={() => setOpen(!open)}
                    className="relative z-10 w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white shadow-lg"
                >
                    <motion.div animate={{ rotate: open ? 45 : 0 }}>
                        <Plus className="w-6 h-6" />
                    </motion.div>
                </button>
            </div>
        </div>
    );
};
