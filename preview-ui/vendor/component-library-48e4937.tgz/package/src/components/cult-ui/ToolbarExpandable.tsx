import { motion } from "framer-motion";
import { useState } from "react";
import { Plus, Search, User, Settings } from "lucide-react";

export const ToolbarExpandable = () => {
    const [expanded, setExpanded] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.div
                className="bg-black text-white rounded-full flex items-center overflow-hidden"
                animate={{ width: expanded ? 180 : 48 }}
                transition={{ type: "spring", bounce: 0, duration: 0.4 }}
            >
                <button
                    onClick={() => setExpanded(!expanded)}
                    className="w-12 h-12 flex items-center justify-center flex-shrink-0"
                >
                    <Plus className={`transition-transform duration-300 ${expanded ? "rotate-45" : ""}`} />
                </button>

                <div className="flex gap-4 pr-4">
                    <Search className="w-5 h-5" />
                    <User className="w-5 h-5" />
                    <Settings className="w-5 h-5" />
                </div>
            </motion.div>
        </div>
    );
};
