export const ShaderLensBlur = () => {
    return (
        <div className="w-full h-full relative overflow-hidden flex items-center justify-center bg-neutral-900">
            <div className="absolute inset-0 bg-gradient-to-tr from-blue-500 via-purple-500 to-orange-500" />
            <div className="absolute inset-4 bg-white/10 backdrop-blur-2xl rounded-3xl border border-white/20 flex items-center justify-center shadow-2xl">
                <h1 className="text-4xl font-black text-white mix-blend-overlay">BLUR</h1>
            </div>
        </div>
    );
};
