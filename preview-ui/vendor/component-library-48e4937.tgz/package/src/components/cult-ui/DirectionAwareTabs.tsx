import { useState } from "react";
import { motion } from "framer-motion";

const tabs = ["Account", "Password", "Settings"];

export const DirectionAwareTabs = () => {
    const [activeTab, setActiveTab] = useState(tabs[0]);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center bg-neutral-900 p-4">
            <div className="flex space-x-1 bg-neutral-800 p-1 rounded-lg">
                {tabs.map((tab) => (
                    <button
                        key={tab}
                        onClick={() => setActiveTab(tab)}
                        className={`${activeTab === tab ? "" : "hover:text-white/60"
                            } relative rounded-md px-3 py-1.5 text-sm font-medium text-white outline-sky-400 transition focus-visible:outline-2`}
                        style={{
                            "WebkitTapHighlightColor": "transparent",
                        }}
                    >
                        {activeTab === tab && (
                            <motion.span
                                layoutId="bubble"
                                className="absolute inset-0 z-10 bg-white mix-blend-difference rounded-md"
                                transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                            />
                        )}
                        {tab}
                    </button>
                ))}
            </div>
            <div className="mt-4 text-neutral-400 text-xs">
                Selected: {activeTab}
            </div>
        </div >
    );
};
