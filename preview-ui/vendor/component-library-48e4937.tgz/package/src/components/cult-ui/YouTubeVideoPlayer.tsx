import { Play } from "lucide-react";

export const YouTubeVideoPlayer = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <div className="relative w-full aspect-video bg-neutral-800 flex items-center justify-center group cursor-pointer">
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <div className="w-12 h-8 bg-red-600 rounded-[20%] flex items-center justify-center transition-transform group-hover:scale-110">
                    <Play className="w-5 h-5 text-white fill-current ml-0.5" />
                </div>

                <div className="absolute bottom-2 left-2 right-2 text-white text-xs opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="h-1 bg-neutral-600 rounded-full overflow-hidden">
                        <div className="h-full w-1/3 bg-red-600" />
                    </div>
                </div>
            </div>
        </div>
    );
};
