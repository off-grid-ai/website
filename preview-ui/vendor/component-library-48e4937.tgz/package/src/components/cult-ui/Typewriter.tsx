import { motion } from "framer-motion";

export const Typewriter = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="font-mono text-lg font-bold">
                <span>Code</span>
                <motion.span
                    animate={{ opacity: [0, 1, 0] }}
                    transition={{ duration: 0.8, repeat: Infinity, repeatDelay: 0.1 }}
                    className="inline-block w-2.5 h-5 bg-blue-500 ml-1 translate-y-0.5"
                />
            </div>
        </div>
    );
};
