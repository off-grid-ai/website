export const TextGIF = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-black">
            <h1
                className="text-5xl font-black text-transparent bg-clip-text bg-cover bg-center"
                style={{
                    backgroundImage: 'url("https://media.giphy.com/media/26BRsIjbXRMwRkN56/giphy.gif")',
                    WebkitTextStroke: '1px rgba(255,255,255,0.2)'
                }}
            >
                GIF
            </h1>
        </div>
    );
};
