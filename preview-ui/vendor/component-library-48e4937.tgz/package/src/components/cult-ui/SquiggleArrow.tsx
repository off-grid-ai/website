export const SquiggleArrow = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <svg width="100" height="50" viewBox="0 0 100 50" fill="none" xmlns="http://www.w3.org/2000/svg" className="stroke-black dark:stroke-white stroke-2">
                <path d="M10 40 C 30 10, 50 40, 90 20" />
                <path d="M80 15 L 90 20 L 85 30" />
            </svg>
        </div>
    );
};
