import { motion } from "framer-motion";

export const FloatingPanel = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-100 to-purple-100 dark:from-indigo-950 dark:to-purple-950">
            <motion.div
                className="bg-white dark:bg-neutral-900 p-6 rounded-2xl shadow-xl max-w-[200px]"
                animate={{
                    y: [0, -10, 0],
                }}
                transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                }}
            >
                <div className="w-12 h-12 bg-indigo-500 rounded-full mb-4 flex items-center justify-center text-white">
                    ✨
                </div>
                <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-full mb-2" />
                <div className="h-4 bg-neutral-200 dark:bg-neutral-800 rounded w-2/3" />
            </motion.div>
        </div>
    );
};
