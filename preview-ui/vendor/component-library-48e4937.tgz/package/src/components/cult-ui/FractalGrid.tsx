export const FractalGrid = () => {
    return (
        <div className="w-full h-full bg-black relative overflow-hidden flex items-center justify-center">
            <div className="grid grid-cols-4 gap-4 w-64 h-64 opacity-50 rotate-12 scale-150">
                {[...Array(16)].map((_, i) => (
                    <div key={i} className="bg-neutral-800 border border-neutral-700 rounded-lg aspect-square flex items-center justify-center">
                        <div className="w-1/2 h-1/2 bg-neutral-700 rounded-md" />
                    </div>
                ))}
            </div>
            <h2 className="absolute text-white font-bold text-xl mix-blend-difference">GRID</h2>
        </div>
    );
};
