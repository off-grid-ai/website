import { useState } from "react";
import { motion } from "framer-motion";

export const ColorPicker = () => {
    const colors = ["#ef4444", "#f97316", "#eab308", "#22c55e", "#3b82f6", "#a855f7", "#ec4899"];
    const [selected, setSelected] = useState(colors[4]);

    return (
        <div className="w-full h-full flex flex-col items-center justify-center gap-4 bg-white dark:bg-neutral-900">
            <motion.div
                className="w-24 h-24 rounded-2xl shadow-lg"
                animate={{ backgroundColor: selected }}
            />
            <div className="flex gap-2 p-2 bg-neutral-100 dark:bg-neutral-800 rounded-full">
                {colors.map((c) => (
                    <button
                        key={c}
                        onClick={() => setSelected(c)}
                        className="w-6 h-6 rounded-full relative focus:outline-none"
                        style={{ backgroundColor: c }}
                    >
                        {selected === c && (
                            <motion.div
                                layoutId="ring"
                                className="absolute -inset-1 rounded-full border-2 border-neutral-900 dark:border-white"
                            />
                        )}
                    </button>
                ))}
            </div>
        </div>
    );
};
