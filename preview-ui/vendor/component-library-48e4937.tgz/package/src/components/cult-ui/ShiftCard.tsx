import { motion } from "framer-motion";

export const ShiftCard = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-zinc-900 p-8">
            <motion.div
                className="w-full max-w-[200px] bg-zinc-800 border border-zinc-700 p-4 rounded-lg"
                whileHover={{ x: 5, y: -5 }}
                transition={{ type: "spring", stiffness: 300 }}
            >
                <div className="w-8 h-8 bg-white rounded-md mb-4" />
                <h3 className="text-white font-bold mb-1">Shift</h3>
                <p className="text-zinc-400 text-xs">Hover to shift position</p>
            </motion.div>
        </div>
    );
};
