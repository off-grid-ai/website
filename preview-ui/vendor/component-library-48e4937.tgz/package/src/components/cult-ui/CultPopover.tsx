// Renamed to avoid collision with Animate UI Popover in the same project context if needed,
// but since files are separate, we can keep the name inside the file.
// The export name matters for import in registry.

import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";

export const CultPopover = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="relative">
                <button
                    onClick={() => setOpen(!open)}
                    className="px-4 py-2 bg-black text-white rounded-md text-sm font-medium"
                >
                    Click Me
                </button>

                <AnimatePresence>
                    {open && (
                        <motion.div
                            initial={{ opacity: 0, scale: 0.9, y: 10 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.9, y: 10 }}
                            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-40 p-3 bg-white dark:bg-neutral-800 rounded-xl shadow-xl border border-neutral-100 dark:border-neutral-700 text-center"
                        >
                            <h4 className="font-bold text-sm">Popover</h4>
                            <p className="text-xs text-neutral-500">Cult UI style</p>
                            <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-2 w-4 h-4 bg-white dark:bg-neutral-800 rotate-45 border-b border-r border-neutral-100 dark:border-neutral-700" />
                        </motion.div>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
};
