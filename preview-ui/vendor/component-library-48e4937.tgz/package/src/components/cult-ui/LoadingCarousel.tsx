import { motion } from "framer-motion";

export const LoadingCarousel = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex gap-2">
                {[0, 1, 2, 3].map((i) => (
                    <motion.div
                        key={i}
                        className="w-3 h-12 bg-black dark:bg-white rounded-full"
                        animate={{ height: ["35px", "60px", "35px"] }}
                        transition={{ duration: 1, repeat: Infinity, delay: i * 0.1 }}
                    />
                ))}
            </div>
        </div>
    );
};
