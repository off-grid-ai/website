import { motion } from "framer-motion";
import { useState } from "react";


export const FamilyDrawer = () => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="w-full h-full flex flex-col justify-end bg-neutral-100 dark:bg-neutral-900 overflow-hidden relative">
            <div className="p-4 text-center text-neutral-400 text-sm">Main Content</div>

            <motion.div
                initial={{ y: "80%" }}
                animate={{ y: isOpen ? "10%" : "80%" }}
                transition={{ type: "spring", damping: 20 }}
                className="absolute inset-x-0 bottom-0 h-[300px] bg-white dark:bg-neutral-800 rounded-t-3xl shadow-[0_-10px_40px_rgba(0,0,0,0.1)] p-4 cursor-pointer"
                onClick={() => setIsOpen(!isOpen)}
            >
                <div className="w-full flex justify-center mb-4">
                    <div className="w-12 h-1.5 bg-neutral-300 dark:bg-neutral-600 rounded-full" />
                </div>
                <h3 className="text-lg font-bold text-center mb-2">Drawer</h3>
                <p className="text-center text-neutral-500 text-sm">
                    Tap to {isOpen ? "close" : "open"}
                </p>
            </motion.div>
        </div>
    );
};
