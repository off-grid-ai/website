export const BgMediaHero = () => {
    return (
        <div className="w-full h-full relative overflow-hidden flex items-center justify-center bg-black">
            <div className="absolute inset-0 opacity-50">
                <img
                    src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=2670&auto=format&fit=crop"
                    alt="Hero"
                    className="w-full h-full object-cover animate-pulse-slow"
                />
            </div>
            <div className="relative z-10 text-center text-white">
                <h1 className="text-3xl font-bold mb-2 drop-shadow-lg">Hero Section</h1>
                <p className="text-sm opacity-80 max-w-[200px] mx-auto">With background media support</p>
            </div>
        </div>
    );
};
