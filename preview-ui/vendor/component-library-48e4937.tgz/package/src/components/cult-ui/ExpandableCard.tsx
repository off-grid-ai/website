import { motion } from "framer-motion";
import { useState } from "react";
import { Plus } from "lucide-react";

export const ExpandableCard = () => {
    const [open, setOpen] = useState(false);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-4">
            <motion.div
                layout
                onClick={() => setOpen(!open)}
                className="bg-neutral-100 dark:bg-neutral-800 rounded-2xl p-4 cursor-pointer overflow-hidden w-full max-w-[200px]"
                animate={{ height: open ? 180 : 80 }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
            >
                <motion.div layout className="flex justify-between items-start">
                    <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
                        A
                    </div>
                    <motion.div animate={{ rotate: open ? 45 : 0 }}>
                        <Plus className="w-5 h-5 text-neutral-500" />
                    </motion.div>
                </motion.div>

                <motion.div layout className="mt-2">
                    <h3 className="font-bold text-neutral-900 dark:text-white">Card Title</h3>
                    {open && (
                        <motion.p
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="text-xs text-neutral-500 mt-2"
                        >
                            This minimal card expands to show more content when clicked.
                        </motion.p>
                    )}
                </motion.div>
            </motion.div>
        </div>
    );
};
