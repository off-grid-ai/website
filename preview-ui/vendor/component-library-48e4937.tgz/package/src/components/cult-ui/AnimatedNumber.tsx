import { motion, useSpring, useTransform } from "framer-motion";
import { useEffect, useState } from "react";

export const AnimatedNumber = () => {
    const [, setTarget] = useState(0);
    const spring = useSpring(0, { bounce: 0, duration: 1000 });
    const display = useTransform(spring, (current) => Math.round(current));

    useEffect(() => {
        const interval = setInterval(() => {
            const next = Math.floor(Math.random() * 1000);
            setTarget(next);
            spring.set(next);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.div className="text-5xl font-mono font-bold text-neutral-900 dark:text-white">
                {display}
            </motion.div>
        </div>
    );
};
