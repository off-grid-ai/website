export const NeumorphButton = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-[#e0e5ec]">
            <button className="px-8 py-4 rounded-xl bg-[#e0e5ec] text-neutral-600 font-bold shadow-[9px_9px_16px_rgb(163,177,198,0.6),-9px_-9px_16px_rgba(255,255,255,0.5)] active:shadow-[inset_9px_9px_16px_rgb(163,177,198,0.6),inset_-9px_-9px_16px_rgba(255,255,255,0.5)] transition-shadow">
                Soft UI
            </button>
        </div>
    );
};
