export const GradientHeading = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900 p-8">
            <div className="text-center">
                <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 pb-2">
                    Amazing<br />Gradient
                </h1>
            </div>
        </div>
    );
};
