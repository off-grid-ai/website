export const TextureCard = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-neutral-900 p-6">
            <div className="w-full h-full bg-[#1a1a1a] rounded-xl border border-white/5 relative overflow-hidden p-4">
                <div className="absolute inset-0 opacity-[0.15]"
                    style={{
                        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`
                    }}
                />
                <div className="relative z-10">
                    <div className="w-8 h-8 rounded-full bg-white/10 mb-3" />
                    <div className="h-2 w-2/3 bg-white/10 rounded mb-2" />
                    <div className="h-2 w-1/2 bg-white/10 rounded" />
                </div>
            </div>
        </div>
    );
};
