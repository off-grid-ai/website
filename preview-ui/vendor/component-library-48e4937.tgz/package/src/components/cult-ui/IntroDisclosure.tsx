import { motion } from "framer-motion";

export const IntroDisclosure = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <motion.div
                initial={{ clipPath: "circle(0% at 50% 50%)" }}
                animate={{ clipPath: "circle(100% at 50% 50%)" }}
                transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
                className="w-full h-full flex items-center justify-center bg-black dark:bg-white"
            >
                <h1 className="text-4xl font-bold text-white dark:text-black">HELLO</h1>
            </motion.div>
        </div>
    );
};
