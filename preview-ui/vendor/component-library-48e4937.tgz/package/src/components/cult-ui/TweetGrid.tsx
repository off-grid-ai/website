export const TweetGrid = () => {
    return (
        <div className="w-full h-full p-4 bg-white dark:bg-neutral-900 overflow-hidden">
            <div className="grid grid-cols-2 gap-2 rotate-6 opacity-30">
                {[...Array(6)].map((_, i) => (
                    <div key={i} className="bg-neutral-100 dark:bg-neutral-800 p-2 rounded border border-neutral-200 dark:border-neutral-700">
                        <div className="flex gap-2 mb-1">
                            <div className="w-4 h-4 rounded-full bg-neutral-300 dark:bg-neutral-600" />
                            <div className="w-12 h-2 rounded bg-neutral-300 dark:bg-neutral-600 mt-1" />
                        </div>
                        <div className="w-full h-2 rounded bg-neutral-200 dark:bg-neutral-700 mb-1" />
                        <div className="w-2/3 h-2 rounded bg-neutral-200 dark:bg-neutral-700" />
                    </div>
                ))}
            </div>
        </div>
    );
};
