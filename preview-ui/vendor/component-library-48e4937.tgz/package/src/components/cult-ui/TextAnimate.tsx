import { motion } from "framer-motion";

export const TextAnimate = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex overflow-hidden">
                {Array.from("Animated").map((letter, index) => (
                    <motion.span
                        key={index}
                        initial={{ y: "100%" }}
                        animate={{ y: "0%" }}
                        transition={{
                            duration: 0.5,
                            delay: index * 0.05,
                            ease: [0.33, 1, 0.68, 1],
                            repeat: Infinity,
                            repeatDelay: 2
                        }}
                        className="text-2xl font-bold inline-block"
                    >
                        {letter}
                    </motion.span>
                ))}
            </div>
        </div>
    );
};
