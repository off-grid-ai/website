import { motion } from "framer-motion";
import { AppWindow, Music, Mail, MessageSquare } from "lucide-react";

export const MacOSDock = () => {
    return (
        <div className="w-full h-full flex items-end justify-center pb-4 bg-gradient-to-t from-blue-100 to-white dark:from-blue-900/20 dark:to-black">
            <div className="bg-white/50 dark:bg-black/50 backdrop-blur-md border border-white/20 p-2 rounded-2xl flex gap-2 items-end">
                {[AppWindow, Music, Mail, MessageSquare].map((Icon, i) => (
                    <motion.div
                        key={i}
                        whileHover={{ scale: 1.5, y: -10 }}
                        className="w-8 h-8 bg-gradient-to-b from-neutral-200 to-neutral-300 dark:from-neutral-700 dark:to-neutral-800 rounded-lg shadow-lg flex items-center justify-center"
                    >
                        <Icon className="w-4 h-4 text-neutral-600 dark:text-neutral-300" />
                    </motion.div>
                ))}
            </div>
        </div>
    );
};
