import { motion } from "framer-motion";

export const SortableList = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-white dark:bg-neutral-900">
            <div className="flex flex-col gap-2 w-32">
                {[1, 2, 3].map((i) => (
                    <motion.div
                        key={i}
                        layout
                        className="bg-neutral-100 dark:bg-neutral-800 p-3 rounded-lg flex items-center gap-2 cursor-grab active:cursor-grabbing shadow-sm"
                    >
                        <div className="w-4 h-4 bg-neutral-300 dark:bg-neutral-600 rounded-full" />
                        <div className="h-2 bg-neutral-300 dark:bg-neutral-600 w-12 rounded" />
                    </motion.div>
                ))}
            </div>
        </div>
    );
};
