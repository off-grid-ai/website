export const MinimalCard = () => {
    return (
        <div className="w-full h-full flex items-center justify-center bg-gray-50 dark:bg-neutral-900">
            <div className="w-48 h-64 bg-white dark:bg-neutral-800 border-2 border-dashed border-neutral-300 dark:border-neutral-700 rounded-xl p-4 flex flex-col justify-between hover:border-black dark:hover:border-white transition-colors duration-300">
                <div className="w-8 h-8 rounded-full bg-neutral-100 dark:bg-neutral-700" />
                <div>
                    <div className="h-4 bg-neutral-100 dark:bg-neutral-700 w-3/4 rounded mb-2" />
                    <div className="h-4 bg-neutral-100 dark:bg-neutral-700 w-1/2 rounded" />
                </div>
            </div>
        </div>
    );
};
