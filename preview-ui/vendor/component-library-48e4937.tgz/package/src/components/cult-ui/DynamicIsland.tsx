import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";

export const DynamicIsland = () => {
    const [expanded, setExpanded] = useState(false);

    return (
        <div className="w-full h-full flex items-start justify-center pt-8 bg-neutral-100 dark:bg-neutral-900">
            <motion.div
                onClick={() => setExpanded(!expanded)}
                layout
                className="bg-black text-white rounded-[24px] overflow-hidden cursor-pointer"
                initial={{ width: 120, height: 32 }}
                animate={{
                    width: expanded ? 300 : 120,
                    height: expanded ? 80 : 32,
                    borderRadius: 24
                }}
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
            >
                <AnimatePresence mode="wait">
                    {expanded ? (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="flex items-center justify-between p-4 h-full"
                        >
                            <div className="w-10 h-10 bg-neutral-800 rounded-lg" />
                            <div className="text-sm">Now Playing</div>
                            <div className="flex gap-2">
                                <div className="w-6 h-6 bg-neutral-800 rounded-full" />
                            </div>
                        </motion.div>
                    ) : (
                        <motion.div
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            className="w-full h-full flex items-center justify-center"
                        >
                            <div className="w-20 h-full bg-transparent" />
                        </motion.div>
                    )}
                </AnimatePresence>
            </motion.div>
        </div>
    );
};
