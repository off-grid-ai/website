export const Tilt = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="w-24 h-24 bg-gradient-to-br from-pink-500 to-orange-400 rounded-xl transform rotate-3 hover:rotate-0 transition-transform shadow-lg"></div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                3D tilt effect on hover
            </p>
        </div>
    );
};
