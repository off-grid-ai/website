export const TextRoll = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="text-2xl font-bold text-gray-900 dark:text-white rotate-6 transform transition-transform duration-500 hover:rotate-0">
                Rolling
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Character rotation animation
            </p>
        </div>
    );
};
