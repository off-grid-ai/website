export const AnimatedBackground = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="flex gap-2 p-1 bg-gray-100 dark:bg-gray-900 rounded-lg">
                <div className="px-3 py-1 rounded-md bg-white dark:bg-gray-800 shadow-sm text-xs font-medium">Item 1</div>
                <div className="px-3 py-1 rounded-md text-xs font-medium text-gray-500">Item 2</div>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Shared layout animation
            </p>
        </div>
    );
};
