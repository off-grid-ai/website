export const Dock = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
            <div className="flex gap-2 p-2 bg-gray-100 dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800">
                {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="w-8 h-8 rounded-lg bg-gray-300 dark:bg-gray-700 hover:scale-125 transition-transform duration-200" />
                ))}
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                macOS dock-style animation
            </p>
        </div>
    );
};
