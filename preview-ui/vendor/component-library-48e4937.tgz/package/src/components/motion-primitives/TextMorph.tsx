export const TextMorph = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="text-2xl font-bold text-gray-900 dark:text-white">
                Morphing
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Fluid letter morphing (Family app style)
            </p>
        </div>
    );
};
