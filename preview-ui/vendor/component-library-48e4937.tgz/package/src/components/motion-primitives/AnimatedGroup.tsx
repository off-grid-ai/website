export const AnimatedGroup = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="flex -space-x-2">
                {[1, 2, 3].map((i) => (
                    <div key={i} className="w-8 h-8 rounded-full border-2 border-white dark:border-black bg-gray-300 dark:bg-gray-700" />
                ))}
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Animate children staggering
            </p>
        </div>
    );
};
