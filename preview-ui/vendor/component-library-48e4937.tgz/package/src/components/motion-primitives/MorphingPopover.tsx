export const MorphingPopover = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <button className="w-8 h-8 bg-gray-200 dark:bg-gray-800 rounded-full flex items-center justify-center">
                ?
            </button>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Trigger morphs into popover
            </p>
        </div>
    );
};
