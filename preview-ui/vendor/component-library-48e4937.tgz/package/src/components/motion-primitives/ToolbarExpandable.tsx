export const ToolbarExpandable = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="flex items-center gap-1 p-1 bg-gray-100 dark:bg-gray-800 rounded-full border border-gray-200 dark:border-gray-700">
                <div className="w-6 h-6 rounded-full bg-white dark:bg-gray-600 shadow-sm"></div>
                <div className="w-6 h-6 rounded-full hover:bg-white dark:hover:bg-gray-600 transition-colors"></div>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Expandable toolset
            </p>
        </div>
    );
};
