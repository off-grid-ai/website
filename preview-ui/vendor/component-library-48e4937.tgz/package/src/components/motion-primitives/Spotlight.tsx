export const Spotlight = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-black rounded-xl border border-gray-800 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent transform -skew-x-12 translate-x-[-100%] animate-[shimmer_2s_infinite]"></div>
            <div className="text-white font-bold z-10">Spotlight</div>
            <p className="text-sm text-gray-500 mt-2 text-center z-10">
                Light cone effect
            </p>
        </div>
    );
};
