export const TextShimmer = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-gray-500 via-white to-gray-500 animate-pulse">
                Shimmer
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Shimmer gradient with spread control
            </p>
        </div>
    );
};
