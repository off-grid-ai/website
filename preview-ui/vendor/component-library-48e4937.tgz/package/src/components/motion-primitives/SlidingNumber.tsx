import { useState, useEffect } from 'react';

export const SlidingNumber = () => {
    const [num, setNum] = useState(1234);

    useEffect(() => {
        const interval = setInterval(() => {
            setNum(prev => prev + 1111);
        }, 2500);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="text-3xl font-mono font-bold text-green-500">
                {num}
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Slot machine number animation
            </p>
        </div>
    );
};
