export const Magnetic = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <button className="px-4 py-2 rounded-full border border-gray-300 dark:border-gray-600 hover:border-blue-500 transition-colors">
                Magnetic
            </button>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Elements stick to cursor
            </p>
        </div>
    );
};
