export const Cursor = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="w-4 h-4 rounded-full bg-black dark:bg-white border-2 border-gray-200"></div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Custom cursor effects
            </p>
        </div>
    );
};
