export const ProgressiveBlur = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800 relative overflow-hidden">
            <div className="w-full h-full absolute inset-0 bg-gradient-to-b from-transparent to-white dark:to-black z-10"></div>
            <div className="text-4xl font-bold opacity-20">BLURRY</div>
            <p className="text-sm text-gray-500 mt-2 text-center z-20 relative">
                Gradient blur mask
            </p>
        </div>
    );
};
