export const InfiniteSlider = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
            <div className="flex gap-2 opacity-50">
                <div className="w-10 h-10 bg-gray-200 dark:bg-gray-800 rounded"></div>
                <div className="w-10 h-10 bg-gray-200 dark:bg-gray-800 rounded"></div>
                <div className="w-10 h-10 bg-gray-200 dark:bg-gray-800 rounded"></div>
                <div className="w-10 h-10 bg-gray-200 dark:bg-gray-800 rounded"></div>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Infinite logos/content slider
            </p>
        </div>
    );
};
