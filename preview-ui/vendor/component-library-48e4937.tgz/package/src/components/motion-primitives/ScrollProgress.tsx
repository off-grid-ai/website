export const ScrollProgress = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800 relative">
            <div className="absolute top-0 left-0 w-full h-1 bg-gray-200 dark:bg-gray-800">
                <div className="h-full w-1/2 bg-blue-500"></div>
            </div>
            <p className="text-sm text-gray-500 mt-4 text-center">
                Reading progress bar
            </p>
        </div>
    );
};
