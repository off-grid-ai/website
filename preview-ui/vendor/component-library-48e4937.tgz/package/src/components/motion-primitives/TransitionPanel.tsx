export const TransitionPanel = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="flex gap-2 mb-2">
                <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                <div className="w-2 h-2 rounded-full bg-gray-300 dark:bg-gray-700"></div>
            </div>
            <div className="w-full h-16 bg-gray-50 dark:bg-gray-900 rounded-lg flex items-center justify-center text-xs text-gray-400">
                Panel Content
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Animated content switching
            </p>
        </div>
    );
};
