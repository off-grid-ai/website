

export const TextEffect = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-500 animate-pulse">
                Text Effect
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Per-character/word animations with presets
            </p>
        </div>
    );
};
