export const ImageComparison = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="w-32 h-20 bg-gray-100 dark:bg-gray-800 rounded-lg relative overflow-hidden border border-gray-200 dark:border-gray-700">
                <div className="absolute top-0 left-0 h-full w-1/2 bg-gray-300 dark:bg-gray-600 border-r-2 border-white"></div>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Before/After slider
            </p>
        </div>
    );
};
