export const TextShimmerWave = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="text-2xl font-bold text-gray-900 dark:text-white shimmer-wave">
                Wave Shimmer
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Wave-style shimmer effect
            </p>
            <style>{`
                .shimmer-wave {
                    /* Placeholder for actual wave styles */
                    background: linear-gradient(45deg, #000 40%, #666 50%, #000 60%);
                    -webkit-background-clip: text;
                    background-clip: text;
                    color: transparent;
                }
                @media (prefers-color-scheme: dark) {
                    .shimmer-wave {
                         background: linear-gradient(45deg, #fff 40%, #aaa 50%, #fff 60%);
                         -webkit-background-clip: text;
                         background-clip: text;
                    }
                }
            `}</style>
        </div>
    );
};
