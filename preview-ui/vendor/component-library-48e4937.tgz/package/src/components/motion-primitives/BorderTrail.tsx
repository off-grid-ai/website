export const BorderTrail = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="w-24 h-16 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg animate-pulse"></div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Animated border path
            </p>
        </div>
    );
};
