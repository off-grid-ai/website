export const SpinningText = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="relative w-20 h-20 animate-spin-slow">
                <svg viewBox="0 0 100 100" className="w-full h-full">
                    <path
                        id="circlePath"
                        d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"
                        fill="transparent"
                    />
                    <text className="text-[10px] uppercase font-bold fill-current text-gray-900 dark:text-white">
                        <textPath xlinkHref="#circlePath" className="tracking-widest">
                            Motion Primitives • Motion Primitives •
                        </textPath>
                    </text>
                </svg>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Circular rotating text
            </p>
        </div>
    );
};
