import { useState, useEffect } from 'react';

export const AnimatedNumber = () => {
    const [num, setNum] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setNum(Math.floor(Math.random() * 100));
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="text-4xl font-bold text-indigo-500">
                {num}
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Smooth number transitions
            </p>
        </div>
    );
};
