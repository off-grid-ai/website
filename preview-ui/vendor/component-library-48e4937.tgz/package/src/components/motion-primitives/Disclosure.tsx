export const Disclosure = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="w-full max-w-[200px] border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                <div className="bg-gray-50 dark:bg-gray-800 p-2 text-xs font-semibold">Details</div>
                <div className="p-2 text-xs bg-white dark:bg-gray-900">
                    Expanded content goes here...
                </div>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Expand/collapse accordion
            </p>
        </div>
    );
};
