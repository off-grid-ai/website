export const InView = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="transform translate-y-2 opacity-80">
                <div className="w-16 h-16 bg-blue-500 rounded-lg shadow-lg"></div>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Animate when element enters viewport
            </p>
        </div>
    );
};
