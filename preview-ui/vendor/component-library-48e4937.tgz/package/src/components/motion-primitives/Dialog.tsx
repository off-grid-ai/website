export const Dialog = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="p-4 bg-white dark:bg-gray-900 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 transform scale-90 opacity-80">
                <div className="h-2 w-20 bg-gray-200 dark:bg-gray-700 rounded mb-2"></div>
                <div className="h-2 w-32 bg-gray-200 dark:bg-gray-700 rounded"></div>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Smooth dialog animations
            </p>
        </div>
    );
};
