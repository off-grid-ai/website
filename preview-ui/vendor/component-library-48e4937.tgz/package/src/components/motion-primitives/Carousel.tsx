export const Carousel = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800 overflow-hidden">
            <div className="flex gap-4">
                <div className="w-24 h-32 bg-gray-100 dark:bg-gray-800 rounded-lg flex-shrink-0 border border-gray-200 dark:border-gray-700"></div>
                <div className="w-24 h-32 bg-gray-100 dark:bg-gray-800 rounded-lg flex-shrink-0 border border-gray-200 dark:border-gray-700"></div>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Embla carousel wrapper
            </p>
        </div>
    );
};
