export const MorphingDialog = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <button className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm">
                Open Dialog
            </button>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Trigger morphs into dialog
            </p>
        </div>
    );
};
