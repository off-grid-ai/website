import { useState, useEffect } from 'react';

export const TextLoop = () => {
    const words = ["Design", "Develop", "Deploy"];
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setIndex((prev) => (prev + 1) % words.length);
        }, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="text-2xl font-bold text-gray-900 dark:text-white transition-all duration-300 transform">
                {words[index]}
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Cycles through text with transitions
            </p>
        </div>
    );
};
