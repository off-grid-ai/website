export const ToolbarDynamic = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="flex items-center gap-2 p-1 bg-black text-white rounded-full">
                <div className="w-6 h-6 rounded-full bg-gray-700"></div>
                <div className="w-16 h-2 bg-gray-700 rounded"></div>
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Dynamic toolbar resizing
            </p>
        </div>
    );
};
