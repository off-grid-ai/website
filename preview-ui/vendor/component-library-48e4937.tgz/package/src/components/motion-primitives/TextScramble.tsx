import { useState, useEffect } from 'react';

export const TextScramble = () => {
    const [text, setText] = useState("Scramble");

    // Simplified simulation
    useEffect(() => {
        const interval = setInterval(() => {
            setText(Math.random().toString(36).substring(7));
            setTimeout(() => setText("Scramble"), 500);
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="text-2xl font-mono font-bold text-gray-900 dark:text-white">
                {text}
            </div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Cryptographic character cycling
            </p>
        </div>
    );
};
