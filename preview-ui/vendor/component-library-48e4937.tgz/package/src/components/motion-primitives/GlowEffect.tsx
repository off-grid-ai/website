export const GlowEffect = () => {
    return (
        <div className="flex flex-col items-center justify-center h-full p-4 bg-white dark:bg-black rounded-xl border border-gray-200 dark:border-gray-800">
            <div className="w-20 h-20 rounded-xl bg-gray-900 dark:bg-gray-100 shadow-[0_0_20px_rgba(59,130,246,0.5)]"></div>
            <p className="text-sm text-gray-500 mt-2 text-center">
                Glow on hover/focus
            </p>
        </div>
    );
};
