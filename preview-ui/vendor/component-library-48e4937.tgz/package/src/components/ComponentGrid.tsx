import type { ComponentData } from '../data/components';
import { ComponentCard } from './ComponentCard';


interface ComponentGridProps {
    components: ComponentData[];
}

export const ComponentGrid = ({ components }: ComponentGridProps) => {
    if (components.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center py-20 text-center">
                <p className="text-xl text-gray-400">No components found matching your criteria.</p>
            </div>
        );
    }

    return (
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-3">
            {components.map((component, index) => (
                <ComponentCard key={`${component.name}-${index}`} component={component} />
            ))}
        </div>
    );
};
