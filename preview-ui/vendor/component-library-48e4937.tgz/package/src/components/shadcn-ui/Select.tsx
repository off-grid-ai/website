import { ChevronDown } from "lucide-react";

export const Select = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full max-w-xs mx-auto">
            <div className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground shadow-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50">
                <span>Select an option</span>
                <ChevronDown className="h-4 w-4 opacity-50" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">Custom select trigger</p>
        </div>
    );
};
