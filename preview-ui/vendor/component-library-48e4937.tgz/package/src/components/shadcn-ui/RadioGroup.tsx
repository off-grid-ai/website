export const RadioGroup = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="flex flex-col gap-2">
                <div className="flex items-center space-x-2">
                    <div className="aspect-square h-4 w-4 rounded-full border border-primary text-primary flex items-center justify-center">
                        <div className="h-2 w-2 rounded-full bg-primary" />
                    </div>
                    <label className="text-sm font-medium leading-none">Option A</label>
                </div>
                <div className="flex items-center space-x-2">
                    <div className="aspect-square h-4 w-4 rounded-full border border-input text-primary disabled:cursor-not-allowed disabled:opacity-50"></div>
                    <label className="text-sm font-medium leading-none">Option B</label>
                </div>
            </div>
        </div>
    );
};
