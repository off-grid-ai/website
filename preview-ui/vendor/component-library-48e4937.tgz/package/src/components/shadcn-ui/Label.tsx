export const Label = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="grid w-full max-w-sm items-center gap-1.5">
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    Email
                </label>
                <div className="h-9 w-full rounded-md border border-input bg-muted/50"></div>
            </div>
        </div>
    );
};
