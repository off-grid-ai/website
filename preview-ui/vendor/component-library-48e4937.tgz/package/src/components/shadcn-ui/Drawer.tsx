export const Drawer = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="w-full max-w-sm rounded-t-[10px] border bg-background shadow-xl h-32 relative mt-16 border-b-0">
                <div className="mx-auto mt-4 h-2 w-[100px] rounded-full bg-muted" />
                <div className="p-4 text-center">
                    <h3 className="font-semibold">Drawer Title</h3>
                </div>
                <div className="absolute inset-x-0 bottom-0 h-10 bg-gradient-to-t from-background to-transparent"></div>
            </div>
        </div>
    );
};
