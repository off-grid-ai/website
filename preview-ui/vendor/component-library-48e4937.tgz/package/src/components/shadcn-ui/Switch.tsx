export const Switch = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="flex items-center space-x-2">
                <div className="peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 bg-primary">
                    <div className="pointer-events-none block h-5 w-5 rounded-full bg-background shadow-lg ring-0 transition-transform translate-x-5"></div>
                </div>
                <label className="text-sm font-medium leading-none">Airplane Mode</label>
            </div>
        </div>
    );
};
