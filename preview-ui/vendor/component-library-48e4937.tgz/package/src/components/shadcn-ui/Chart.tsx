export const Chart = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="h-[100px] w-full max-w-[200px] flex items-end justify-between gap-1 p-2 border rounded bg-card">
                <div className="w-full bg-primary rounded-t opacity-90 h-[40%]"></div>
                <div className="w-full bg-primary rounded-t opacity-90 h-[70%]"></div>
                <div className="w-full bg-primary rounded-t opacity-90 h-[50%]"></div>
                <div className="w-full bg-primary rounded-t opacity-90 h-[90%]"></div>
                <div className="w-full bg-primary rounded-t opacity-90 h-[60%]"></div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Recharts wrapper</p>
        </div>
    );
};
