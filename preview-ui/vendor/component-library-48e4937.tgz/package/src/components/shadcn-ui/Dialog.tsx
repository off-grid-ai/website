export const Dialog = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="relative w-full max-w-sm rounded-[var(--radius)] border bg-background p-6 shadow-lg sm:rounded-lg">
                <div className="flex flex-col space-y-1.5 text-center sm:text-left">
                    <h2 className="text-lg font-semibold leading-none tracking-tight">Edit profile</h2>
                    <p className="text-sm text-muted-foreground">Make changes to your profile here.</p>
                </div>
                <div className="grid gap-4 py-4">
                    <div className="h-8 rounded bg-muted"></div>
                    <div className="h-8 rounded bg-muted"></div>
                </div>
                <div className="flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2">
                    <div className="h-9 w-20 rounded bg-primary"></div>
                </div>
            </div>
        </div>
    );
};
