export const DropdownMenu = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="border rounded-md p-2 shadow-md bg-popover min-w-[8rem] text-popover-foreground">
                <div className="px-2 py-1.5 text-sm font-semibold">My Account</div>
                <div className="h-px bg-muted my-1" />
                <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors hover:bg-accent hover:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50">Profile</div>
                <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors hover:bg-accent hover:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50">Billing</div>
                <div className="relative flex cursor-default select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors hover:bg-accent hover:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50">Settings</div>
            </div>
        </div>
    );
};
