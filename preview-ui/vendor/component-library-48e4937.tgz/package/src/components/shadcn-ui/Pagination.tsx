import { ChevronLeft, ChevronRight, MoreHorizontal } from "lucide-react";

export const Pagination = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <nav role="navigation" aria-label="pagination" className="mx-auto flex w-full justify-center">
                <ul className="flex flex-row items-center gap-1">
                    <li className="h-9 w-9 flex items-center justify-center rounded-md border border-input bg-background hover:bg-accent hover:text-accent-foreground">
                        <ChevronLeft className="h-4 w-4" />
                    </li>
                    <li className="h-9 w-9 flex items-center justify-center rounded-md border border-input bg-background hover:bg-accent hover:text-accent-foreground">1</li>
                    <li className="h-9 w-9 flex items-center justify-center rounded-md border border-input bg-accent text-accent-foreground">2</li>
                    <li className="h-9 w-9 flex items-center justify-center">
                        <MoreHorizontal className="h-4 w-4" />
                    </li>
                    <li className="h-9 w-9 flex items-center justify-center rounded-md border border-input bg-background hover:bg-accent hover:text-accent-foreground">
                        <ChevronRight className="h-4 w-4" />
                    </li>
                </ul>
            </nav>
        </div>
    );
};
