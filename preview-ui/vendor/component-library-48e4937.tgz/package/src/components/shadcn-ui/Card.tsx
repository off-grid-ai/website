export const Card = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="rounded-xl border bg-card text-card-foreground shadow w-full max-w-[200px]">
                <div className="flex flex-col space-y-1.5 p-4">
                    <h3 className="font-semibold leading-none tracking-tight">Card Title</h3>
                    <p className="text-xs text-muted-foreground">Card Description</p>
                </div>
                <div className="p-4 pt-0 text-sm">
                    Card Content
                </div>
                <div className="flex items-center p-4 pt-0">
                    <div className="h-8 w-16 rounded-md bg-secondary"></div>
                </div>
            </div>
        </div>
    );
};
