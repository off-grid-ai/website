import { ChevronsUpDown } from "lucide-react";

export const Combobox = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full max-w-xs mx-auto">
            <div className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                <span>Next.js</span>
                <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">Searchable select</p>
        </div>
    );
};
