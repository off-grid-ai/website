export const Table = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full">
            <div className="w-full relative overflow-hidden rounded-md border">
                <table className="w-full caption-bottom text-xs text-left">
                    <thead className="[&_tr]:border-b">
                        <tr className="border-b transition-colors hover:bg-muted/50 data-[state=selected]:bg-muted">
                            <th className="h-10 px-2 align-middle font-medium text-muted-foreground">Invoice</th>
                            <th className="h-10 px-2 align-middle font-medium text-muted-foreground text-right">Amount</th>
                        </tr>
                    </thead>
                    <tbody className="[&_tr:last-child]:border-0">
                        <tr className="border-b transition-colors hover:bg-muted/50">
                            <td className="p-2 align-middle font-medium">INV001</td>
                            <td className="p-2 align-middle text-right">$250.00</td>
                        </tr>
                        <tr className="border-b transition-colors hover:bg-muted/50">
                            <td className="p-2 align-middle font-medium">INV002</td>
                            <td className="p-2 align-middle text-right">$150.00</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    );
};
