export const Sheet = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="flex h-full w-full max-w-sm flex-col overflow-y-auto bg-background p-6 shadow-xl border-l h-48 ml-auto">
                <div className="flex flex-col space-y-2 text-center sm:text-left">
                    <h2 className="text-lg font-semibold">Edit profile</h2>
                    <p className="text-sm text-muted-foreground">Make changes to your profile.</p>
                </div>
            </div>
        </div>
    );
};
