

export const DataTable = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full">
            <div className="rounded-md border p-2 w-full max-w-[250px]">
                <div className="flex items-center py-2">
                    <input placeholder="Filter..." className="max-w-sm flex h-8 w-full rounded-md border border-input bg-background px-3 py-1 text-sm shadow-sm transition-colors" />
                </div>
                <div className="text-xs text-muted-foreground text-center">
                    0 of 5 row(s) selected
                </div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Advanced data grid</p>
        </div>
    );
};
