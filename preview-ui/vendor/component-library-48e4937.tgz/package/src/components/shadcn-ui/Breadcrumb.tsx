import { ChevronRight } from "lucide-react";

export const Breadcrumb = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <nav aria-label="breadcrumb">
                <ol className="flex flex-wrap items-center gap-1.5 break-words text-sm text-muted-foreground sm:gap-2.5">
                    <li className="inline-flex items-center gap-1.5">
                        <span className="transition-colors hover:text-foreground">Home</span>
                    </li>
                    <li ><ChevronRight className="h-4 w-4" /></li>
                    <li className="inline-flex items-center gap-1.5">
                        <span className="transition-colors hover:text-foreground">Components</span>
                    </li>
                    <li ><ChevronRight className="h-4 w-4" /></li>
                    <li className="inline-flex items-center gap-1.5">
                        <span className="font-normal text-foreground">Breadcrumb</span>
                    </li>
                </ol>
            </nav>
        </div>
    );
};
