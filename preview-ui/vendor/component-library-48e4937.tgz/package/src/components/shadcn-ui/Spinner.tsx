import { Loader2 } from "lucide-react";

export const Spinner = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-xs text-muted-foreground mt-2">Loading state</p>
        </div>
    );
};
