import { useState } from "react";
import { Bold } from "lucide-react";

export const Toggle = () => {
    const [pressed, setPressed] = useState(false);

    return (
        <div className="flex flex-col items-center justify-center p-4">
            <button
                onClick={() => setPressed(!pressed)}
                className={`p-2 rounded-md transition-colors ${pressed ? 'bg-accent text-accent-foreground' : 'hover:bg-muted text-muted-foreground'}`}
            >
                <Bold className="h-4 w-4" />
            </button>
            <p className="text-xs text-muted-foreground mt-2">Toggle state</p>
        </div>
    );
};
