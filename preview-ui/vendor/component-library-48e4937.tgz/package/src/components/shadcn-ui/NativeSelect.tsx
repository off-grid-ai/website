export const NativeSelect = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full max-w-xs mx-auto">
            <select className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50">
                <option>Option 1</option>
                <option>Option 2</option>
                <option>Option 3</option>
            </select>
            <p className="text-xs text-muted-foreground mt-2">Native browser select</p>
        </div>
    );
};
