export const AlertDialog = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="relative w-full max-w-sm rounded-[var(--radius)] border bg-background p-6 shadow-lg">
                <div className="flex flex-col space-y-2 text-center sm:text-left">
                    <h2 className="text-lg font-semibold">Are you absolutely sure?</h2>
                    <p className="text-sm text-muted-foreground">This action cannot be undone.</p>
                </div>
                <div className="flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2 mt-4">
                    <div className="h-9 w-20 rounded border bg-background"></div>
                    <div className="h-9 w-20 rounded bg-destructive"></div>
                </div>
            </div>
        </div>
    );
};
