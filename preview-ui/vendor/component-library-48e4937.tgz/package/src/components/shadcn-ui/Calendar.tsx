import { ChevronLeft, ChevronRight } from "lucide-react";

export const Calendar = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="p-3 border rounded-md max-w-[250px] bg-card text-card-foreground">
                <div className="flex justify-between items-center mb-2">
                    <ChevronLeft className="h-4 w-4 opacity-50" />
                    <span className="text-sm font-medium">January 2026</span>
                    <ChevronRight className="h-4 w-4 opacity-50" />
                </div>
                <div className="grid grid-cols-7 gap-1 text-center text-xs text-muted-foreground mb-1">
                    <span>Su</span><span>Mo</span><span>Tu</span><span>We</span><span>Th</span><span>Fr</span><span>Sa</span>
                </div>
                <div className="grid grid-cols-7 gap-1 text-center text-sm">
                    {Array.from({ length: 31 }, (_, i) => i + 1).slice(0, 10).map((d) => (
                        <div key={d} className={`h-7 w-7 flex items-center justify-center rounded-md ${d === 5 ? "bg-primary text-primary-foreground" : "hover:bg-accent hover:text-accent-foreground"}`}>{d}</div>
                    ))}
                    <div className="col-span-4 text-xs text-muted-foreground flex items-center justify-center">...</div>
                </div>
            </div>
        </div>
    );
};
