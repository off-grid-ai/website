export const Field = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full max-w-xs mx-auto">
            <fieldset className="grid gap-2 rounded-lg border p-4">
                <legend className="-ml-1 px-1 text-sm font-medium">Settings</legend>
                <div className="flex items-center gap-2">
                    <div className="h-4 w-4 rounded border border-input"></div>
                    <span className="text-sm">Enable notifications</span>
                </div>
            </fieldset>
        </div>
    );
};
