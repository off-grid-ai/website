export const Slider = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full max-w-[200px] mx-auto">
            <div className="relative flex w-full touch-none select-none items-center">
                <div className="relative h-2 w-full grow overflow-hidden rounded-full bg-secondary">
                    <div className="absolute h-full bg-primary w-[50%]"></div>
                </div>
                <div className="block h-5 w-5 rounded-full border-2 border-primary bg-background ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 absolute left-[50%] -translate-x-1/2"></div>
            </div>
            <p className="text-xs text-muted-foreground mt-4 text-center">Value: 50</p>
        </div>
    );
};
