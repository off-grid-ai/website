export const Progress = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full max-w-[200px] mx-auto">
            <div className="relative h-2 w-full overflow-hidden rounded-full bg-secondary">
                <div className="h-full w-full flex-1 bg-primary transition-all" style={{ transform: 'translateX(-40%)' }}></div>
            </div>
            <p className="text-xs text-muted-foreground mt-2">60% Complete</p>
        </div>
    );
};
