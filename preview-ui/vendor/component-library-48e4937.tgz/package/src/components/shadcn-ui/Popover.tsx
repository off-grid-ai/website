export const Popover = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none w-64">
                <div className="space-y-2">
                    <h4 className="font-medium leading-none">Dimensions</h4>
                    <p className="text-sm text-muted-foreground">Set the dimensions for the layer.</p>
                </div>
            </div>
        </div>
    );
};
