export const Skeleton = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full">
            <div className="flex items-center space-x-4 w-full max-w-[200px]">
                <div className="h-10 w-10 rounded-full bg-muted animate-pulse" />
                <div className="space-y-2 flex-1">
                    <div className="h-3 w-full rounded bg-muted animate-pulse" />
                    <div className="h-3 w-[80%] rounded bg-muted animate-pulse" />
                </div>
            </div>
        </div>
    );
};
