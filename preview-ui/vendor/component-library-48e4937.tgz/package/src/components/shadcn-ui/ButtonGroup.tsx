export const ButtonGroup = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="flex -space-x-px">
                <button className="px-3 py-1.5 bg-background border border-input rounded-l-md hover:bg-accent hover:text-accent-foreground text-sm">
                    Prev
                </button>
                <button className="px-3 py-1.5 bg-background border-y border-input hover:bg-accent hover:text-accent-foreground text-sm">
                    Today
                </button>
                <button className="px-3 py-1.5 bg-background border border-input rounded-r-md hover:bg-accent hover:text-accent-foreground text-sm">
                    Next
                </button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Grouped actions</p>
        </div>
    );
};
