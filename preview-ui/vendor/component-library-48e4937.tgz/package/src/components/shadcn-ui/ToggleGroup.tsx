import { Bold, Italic, Underline } from "lucide-react";

export const ToggleGroup = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="flex items-center gap-1 p-1 rounded-md border border-input bg-transparent">
                <button className="p-1.5 rounded-sm hover:bg-muted text-muted-foreground">
                    <Bold className="h-4 w-4" />
                </button>
                <button className="p-1.5 rounded-sm bg-accent text-accent-foreground">
                    <Italic className="h-4 w-4" />
                </button>
                <button className="p-1.5 rounded-sm hover:bg-muted text-muted-foreground">
                    <Underline className="h-4 w-4" />
                </button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Rich text formatting</p>
        </div>
    );
};
