export const Form = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full max-w-xs mx-auto">
            <div className="space-y-4 w-full">
                <div className="space-y-2">
                    <label className="text-sm font-medium leading-none">Username</label>
                    <div className="h-9 w-full rounded-md border border-input bg-background"></div>
                    <p className="text-[0.8rem] text-muted-foreground">This is your public display name.</p>
                </div>
            </div>
        </div>
    );
};
