export const Menubar = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="flex h-9 items-center space-x-1 rounded-md border bg-background p-1 shadow-sm">
                <div className="flex cursor-default select-none items-center rounded-sm px-3 py-1 text-sm font-medium outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground">File</div>
                <div className="flex cursor-default select-none items-center rounded-sm px-3 py-1 text-sm font-medium outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground">Edit</div>
                <div className="flex cursor-default select-none items-center rounded-sm px-3 py-1 text-sm font-medium outline-none focus:bg-accent focus:text-accent-foreground data-[state=open]:bg-accent data-[state=open]:text-accent-foreground">View</div>
            </div>
        </div>
    );
};
