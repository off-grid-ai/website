export const Button = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <button className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors text-sm font-medium">
                Button
            </button>
            <p className="text-xs text-muted-foreground mt-2">Standard button</p>
        </div>
    );
};
