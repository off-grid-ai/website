export const Checkbox = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="flex items-center space-x-2">
                <div className="h-4 w-4 rounded border border-primary bg-primary text-primary-foreground flex items-center justify-center">
                    <svg
                        xmlns="http://www.w3.org/2000/svg"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="h-3 w-3"
                    >
                        <polyline points="20 6 9 17 4 12" />
                    </svg>
                </div>
                <label className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                    Accept terms
                </label>
            </div>
        </div>
    );
};
