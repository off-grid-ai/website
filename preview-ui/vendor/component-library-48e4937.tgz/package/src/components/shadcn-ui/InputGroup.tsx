import { Mail } from "lucide-react";

export const InputGroup = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4 w-full max-w-xs mx-auto">
            <div className="relative w-full">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-muted-foreground">
                    <Mail className="h-4 w-4" />
                </div>
                <input
                    type="email"
                    placeholder="Email"
                    className="flex h-10 w-full rounded-md border border-input bg-background pl-10 pr-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                />
            </div>
            <p className="text-xs text-muted-foreground mt-2">Input with icon</p>
        </div>
    );
};
