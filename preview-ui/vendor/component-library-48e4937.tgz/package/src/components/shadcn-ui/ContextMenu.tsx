export const ContextMenu = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="flex h-[100px] w-full max-w-[200px] items-center justify-center rounded-md border border-dashed text-sm">
                Right click here
            </div>
            <p className="text-xs text-muted-foreground mt-2">Simulated context menu area</p>
        </div>
    );
};
