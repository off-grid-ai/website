import { CalendarIcon } from "lucide-react";

export const DatePicker = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="flex h-10 w-[200px] items-center justify-start rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 text-muted-foreground">
                <CalendarIcon className="mr-2 h-4 w-4" />
                <span>Pick a date</span>
            </div>
        </div>
    );
};
