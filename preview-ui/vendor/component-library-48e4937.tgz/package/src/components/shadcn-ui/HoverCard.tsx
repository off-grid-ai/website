export const HoverCard = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <span className="underline decoration-dotted cursor-pointer hover:opacity-75 relative group">
                Hover me
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 hidden group-hover:block z-50">
                    <div className="flex justify-between space-x-4">
                        <div className="space-y-1">
                            <h4 className="text-sm font-semibold">@nextjs</h4>
                            <p className="text-xs">The React Framework – created and maintained by @vercel.</p>
                        </div>
                    </div>
                </div>
            </span>
        </div>
    );
};
