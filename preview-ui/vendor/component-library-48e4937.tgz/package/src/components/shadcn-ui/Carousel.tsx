import { ChevronLeft, ChevronRight } from "lucide-react";

export const Carousel = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="relative w-full max-w-xs">
                <div className="overflow-hidden rounded-xl border bg-card text-card-foreground">
                    <div className="flex aspect-square items-center justify-center p-6">
                        <span className="text-4xl font-semibold">1</span>
                    </div>
                </div>
                <div className="absolute top-1/2 left-2 -translate-y-1/2 h-8 w-8 rounded-full border border-input bg-background flex items-center justify-center opacity-50">
                    <ChevronLeft className="h-4 w-4" />
                </div>
                <div className="absolute top-1/2 right-2 -translate-y-1/2 h-8 w-8 rounded-full border border-input bg-background flex items-center justify-center">
                    <ChevronRight className="h-4 w-4" />
                </div>
            </div>
        </div>
    );
};
