export const InputOTP = () => {
    return (
        <div className="flex flex-col items-center justify-center p-4">
            <div className="flex gap-2">
                {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="flex h-10 w-10 items-center justify-center rounded-md border border-input bg-background text-lg font-semibold ring-offset-background transition-all">
                        {i % 2 === 0 ? "•" : i}
                    </div>
                ))}
            </div>
            <p className="text-xs text-muted-foreground mt-2">One-time password input</p>
        </div>
    );
};
