import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { RootLayout } from './layouts/RootLayout';
import { ComponentLibrary } from './pages/ComponentLibrary';
import { MemoriaLandingPage } from './design-systems/memoria/MemoriaLandingPage';
import LightGreenLandingPage from './design-systems/light-green/LightGreenLandingPage';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<RootLayout />}>
          <Route path="/" element={<ComponentLibrary />} />
          <Route path="/design-systems/memoria" element={<MemoriaLandingPage />} />
          <Route path="/design-systems/light-green" element={<LightGreenLandingPage />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
