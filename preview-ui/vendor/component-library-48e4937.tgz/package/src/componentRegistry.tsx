import React from 'react';
import { TextGenerateEffect } from './components/aceternity/TextGenerateEffect';
import { ThreeDCardEffect } from './components/aceternity/ThreeDCardEffect';
import { ThreeDMarquee } from './components/aceternity/ThreeDMarquee';
import { ThreeDPin } from './components/aceternity/ThreeDPin';
import { AnimatedModal } from './components/aceternity/AnimatedModal';
import { AnimatedTestimonials } from './components/aceternity/AnimatedTestimonials';
import { AnimatedTooltip } from './components/aceternity/AnimatedTooltip';
import { AppleCardsCarousel } from './components/aceternity/AppleCardsCarousel';
import { AuroraBackground } from './components/aceternity/AuroraBackground';
import { BackgroundBeams } from './components/aceternity/BackgroundBeams';
import { BackgroundBeamsCollision } from './components/aceternity/BackgroundBeamsCollision';
import { BackgroundBoxes } from './components/aceternity/BackgroundBoxes';
import { BackgroundLines } from './components/aceternity/BackgroundLines';
import { BackgroundRippleEffect } from './components/aceternity/BackgroundRippleEffect';
import { CanvasRevealEffect } from './components/aceternity/CanvasRevealEffect';
import { CardHoverEffect } from './components/aceternity/CardHoverEffect';
import { CardSpotlight } from './components/aceternity/CardSpotlight';
import { CardStack } from './components/aceternity/CardStack';
import { Carousel } from './components/aceternity/Carousel';
import { CodeBlock } from './components/aceternity/CodeBlock';
import { ColourfulText } from './components/aceternity/ColourfulText';
import { CometCard } from './components/aceternity/CometCard';
import { Compare } from './components/aceternity/Compare';
import { ContainerScrollAnimation } from './components/aceternity/ContainerScrollAnimation';
import { ContainerTextFlip } from './components/aceternity/ContainerTextFlip';
import { DirectionAwareHover } from './components/aceternity/DirectionAwareHover';
import { DitherShader } from './components/aceternity/DitherShader';
import { DottedGlowBackground } from './components/aceternity/DottedGlowBackground';
import { DraggableCard } from './components/aceternity/DraggableCard';
import { EncryptedText } from './components/aceternity/EncryptedText';
import { EvervaultCard } from './components/aceternity/EvervaultCard';
import { ExpandableCard } from './components/aceternity/ExpandableCard';
import { FileUpload } from './components/aceternity/FileUpload';
import { FlipWords } from './components/aceternity/FlipWords';
import { FloatingDock } from './components/aceternity/FloatingDock';
import { FloatingNavbar } from './components/aceternity/FloatingNavbar';
import { FocusCards } from './components/aceternity/FocusCards';
import { FollowingPointer } from './components/aceternity/FollowingPointer';
import { GitHubGlobe } from './components/aceternity/GitHubGlobe';
import { GlareCard } from './components/aceternity/GlareCard';
import { GlowingEffect } from './components/aceternity/GlowingEffect';
import { GlowingStars } from './components/aceternity/GlowingStars';
import { GoogleGeminiEffect } from './components/aceternity/GoogleGeminiEffect';
import { GradientAnimation } from './components/aceternity/GradientAnimation';
import { GridAndDotBackgrounds } from './components/aceternity/GridAndDotBackgrounds';
import { HeroHighlight } from './components/aceternity/HeroHighlight';
import { HeroParallax } from './components/aceternity/HeroParallax';
import { HoverBorderGradient } from './components/aceternity/HoverBorderGradient';
import { ImagesSlider } from './components/aceternity/ImagesSlider';
import { InfiniteMovingCards } from './components/aceternity/InfiniteMovingCards';
import { LampEffect } from './components/aceternity/LampEffect';
import { LayoutTextFlip } from './components/aceternity/LayoutTextFlip';
import { Lens } from './components/aceternity/Lens';
import { LinkPreview } from './components/aceternity/LinkPreview';
import { Loader } from './components/aceternity/Loader';
import { MacbookScroll } from './components/aceternity/MacbookScroll';
import { Meteors } from './components/aceternity/Meteors';
import { MovingBorder } from './components/aceternity/MovingBorder';
import { MultiStepLoader } from './components/aceternity/MultiStepLoader';
import { NavbarMenu } from './components/aceternity/NavbarMenu';
import { NoiseBackground } from './components/aceternity/NoiseBackground';
import { ParallaxScroll } from './components/aceternity/ParallaxScroll';
import { PixelatedCanvas } from './components/aceternity/PixelatedCanvas';
import { PlaceholdersVanishInput } from './components/aceternity/PlaceholdersVanishInput';
import { PointerHighlight } from './components/aceternity/PointerHighlight';
import { ResizableNavbar } from './components/aceternity/ResizableNavbar';
import { ShootingStars } from './components/aceternity/ShootingStars';
import { Sidebar } from './components/aceternity/Sidebar';
import { SignupForm } from './components/aceternity/SignupForm';
import { Sparkles } from './components/aceternity/Sparkles';
import { Spotlight } from './components/aceternity/Spotlight';
import { SpotlightNew } from './components/aceternity/SpotlightNew';
import { StatefulButton } from './components/aceternity/StatefulButton';
import { StickyBanner } from './components/aceternity/StickyBanner';
import { StickyScrollReveal } from './components/aceternity/StickyScrollReveal';
import { SVGMaskEffect } from './components/aceternity/SVGMaskEffect';
import { Tabs } from './components/aceternity/Tabs';
import { TailwindCSSButtons } from './components/aceternity/TailwindCSSButtons';
import { TextHoverEffect } from './components/aceternity/TextHoverEffect';
import { TextRevealCard } from './components/aceternity/TextRevealCard';
import { Timeline } from './components/aceternity/Timeline';
import { TooltipCard } from './components/aceternity/TooltipCard';
import { TracingBeam } from './components/aceternity/TracingBeam';
import { TypewriterEffect } from './components/aceternity/TypewriterEffect';
import { Vortex } from './components/aceternity/Vortex';
import { WavyBackground } from './components/aceternity/WavyBackground';
import { WebcamPixelGrid } from './components/aceternity/WebcamPixelGrid';
import { WobbleCard } from './components/aceternity/WobbleCard';
import { WorldMap } from './components/aceternity/WorldMap';
import { AccordionMultiselect } from './components/abui/AccordionMultiselect';
import { AnimatedChart } from './components/abui/AnimatedChart';
import { Availability } from './components/abui/Availability';
import { CalendarYear } from './components/abui/CalendarYear';
import { ColorSwatchSelector } from './components/abui/ColorSwatchSelector';
import { LabelSelector } from './components/abui/LabelSelector';
import { RadioRows } from './components/abui/RadioRows';
import { RadioTabs } from './components/abui/RadioTabs';
import { ScrollProgress } from './components/abui/ScrollProgress';
import { ScrollRevealContent } from './components/abui/ScrollRevealContent';
import { Spinner } from './components/abui/Spinner';
import { TableOfContents } from './components/abui/TableOfContents';
import { TextGradient } from './components/abui/TextGradient';
import { TimelineGantt } from './components/abui/TimelineGantt';
import { TimelineSteps } from './components/abui/TimelineSteps';

// Animate UI Imports
import { AlertDialog } from './components/animate-ui/AlertDialog';
import { BlurEffect } from './components/animate-ui/BlurEffect';
import { BubbleBackground } from './components/animate-ui/BubbleBackground';
import { Button } from './components/animate-ui/Button';
import { Checkbox } from './components/animate-ui/Checkbox';
import { Code } from './components/animate-ui/Code';
import { CodeTabs } from './components/animate-ui/CodeTabs';
import { CopyButton } from './components/animate-ui/CopyButton';
import { CountingNumber } from './components/animate-ui/CountingNumber';
import { Cursor } from './components/animate-ui/Cursor';
import { Dialog } from './components/animate-ui/Dialog';
import { DropdownMenu } from './components/animate-ui/DropdownMenu';
import { FadeEffect } from './components/animate-ui/FadeEffect';
import { Files } from './components/animate-ui/Files';
import { FireworksBackground } from './components/animate-ui/FireworksBackground';
import { FlipButton } from './components/animate-ui/FlipButton';
import { FlipCard } from './components/animate-ui/FlipCard';
import { GitHubStarsButton } from './components/animate-ui/GitHubStarsButton';
import { GradientBackground } from './components/animate-ui/GradientBackground';
import { GradientText } from './components/animate-ui/GradientText';
import { GravityStars } from './components/animate-ui/GravityStars';
import { HexagonBackground } from './components/animate-ui/HexagonBackground';
import { HighlightText } from './components/animate-ui/HighlightText';
import { HoleBackground } from './components/animate-ui/HoleBackground';
import { IconButton } from './components/animate-ui/IconButton';
import { ImageZoom } from './components/animate-ui/ImageZoom';
import { LiquidButton } from './components/animate-ui/LiquidButton';
import { MagneticEffect } from './components/animate-ui/MagneticEffect';
import { MorphingText } from './components/animate-ui/MorphingText';
import { MotionCarousel } from './components/animate-ui/MotionCarousel';
import { ParticlesEffect } from './components/animate-ui/ParticlesEffect';
import { Popover } from './components/animate-ui/Popover';
import { PreviewLinkCard } from './components/animate-ui/PreviewLinkCard';
import { Progress } from './components/animate-ui/Progress';
import { RadialMenu } from './components/animate-ui/RadialMenu';
import { RadialNav } from './components/animate-ui/RadialNav';
import { RadioGroup } from './components/animate-ui/RadioGroup';
import { RippleButton } from './components/animate-ui/RippleButton';
import { RollingText } from './components/animate-ui/RollingText';
import { RotatingText } from './components/animate-ui/RotatingText';
import { ScrollProgress as AnimateScrollProgress } from './components/animate-ui/ScrollProgress';
import { ScrollingNumber } from './components/animate-ui/ScrollingNumber';
import { Sheet } from './components/animate-ui/Sheet';
import { ShimmeringText } from './components/animate-ui/ShimmeringText';
import { ShineEffect } from './components/animate-ui/ShineEffect';
import { Sidebar as AnimateSidebar } from './components/animate-ui/Sidebar';
import { SlidingNumber } from './components/animate-ui/SlidingNumber';
import { SplittingText } from './components/animate-ui/SplittingText';
import { StarsBackground } from './components/animate-ui/StarsBackground';
import { Switch } from './components/animate-ui/Switch';
import { Tabs as AnimateTabs } from './components/animate-ui/Tabs';
import { ThemeToggler } from './components/animate-ui/ThemeToggler';
import { TiltEffect } from './components/animate-ui/TiltEffect';
import { Tooltip } from './components/animate-ui/Tooltip';
import { TypingText } from './components/animate-ui/TypingText';
import { ZoomEffect } from './components/animate-ui/ZoomEffect';

// Cult UI Imports
import { ThreeDCarousel } from './components/cult-ui/ThreeDCarousel';
import { AnimatedNumber } from './components/cult-ui/AnimatedNumber';
import { BackgroundTexture } from './components/cult-ui/BackgroundTexture';
import { BgAnimateButton } from './components/cult-ui/BgAnimateButton';
import { BgMediaHero } from './components/cult-ui/BgMediaHero';
import { BrowserWindow } from './components/cult-ui/BrowserWindow';
import { CanvasFractalGrid } from './components/cult-ui/CanvasFractalGrid';
import { CodeBlock as CultCodeBlock } from './components/cult-ui/CodeBlock';
import { ColorPicker } from './components/cult-ui/ColorPicker';
import { CultPopover } from './components/cult-ui/CultPopover';
import { DirectionAwareTabs } from './components/cult-ui/DirectionAwareTabs';
import { DistortedGlass } from './components/cult-ui/DistortedGlass';
import { DynamicIsland } from './components/cult-ui/DynamicIsland';
import { ExpandableCard as CultExpandableCard } from './components/cult-ui/ExpandableCard';
import { ExpandableScreen } from './components/cult-ui/ExpandableScreen';
import { FamilyButton } from './components/cult-ui/FamilyButton';
import { FamilyDrawer } from './components/cult-ui/FamilyDrawer';
import { FeatureCarousel } from './components/cult-ui/FeatureCarousel';
import { FloatingPanel } from './components/cult-ui/FloatingPanel';
import { FractalGrid } from './components/cult-ui/FractalGrid';
import { GradientHeading } from './components/cult-ui/GradientHeading';
import { HoverVideoPlayer } from './components/cult-ui/HoverVideoPlayer';
import { IntroDisclosure } from './components/cult-ui/IntroDisclosure';
import { LightBoard } from './components/cult-ui/LightBoard';
import { LoadingCarousel } from './components/cult-ui/LoadingCarousel';
import { LogoCarousel } from './components/cult-ui/LogoCarousel';
import { MacOSDock } from './components/cult-ui/MacOSDock';
import { MinimalCard } from './components/cult-ui/MinimalCard';
import { MorphSurface } from './components/cult-ui/MorphSurface';
import { NeumorphButton } from './components/cult-ui/NeumorphButton';
import { PopoverForm } from './components/cult-ui/PopoverForm';
import { ShaderLensBlur } from './components/cult-ui/ShaderLensBlur';
import { ShiftCard } from './components/cult-ui/ShiftCard';
import { SidePanel } from './components/cult-ui/SidePanel';
import { SortableList } from './components/cult-ui/SortableList';
import { SquiggleArrow } from './components/cult-ui/SquiggleArrow';
import { StripeBgGuides } from './components/cult-ui/StripeBgGuides';
import { TextAnimate } from './components/cult-ui/TextAnimate';
import { TextGIF } from './components/cult-ui/TextGIF';
import { TextureButton } from './components/cult-ui/TextureButton';
import { TextureCard } from './components/cult-ui/TextureCard';
import { TextureOverlay } from './components/cult-ui/TextureOverlay';
import { Timer } from './components/cult-ui/Timer';
import { ToolbarExpandable } from './components/cult-ui/ToolbarExpandable';
import { TweetGrid } from './components/cult-ui/TweetGrid';
import { Typewriter as CultTypewriter } from './components/cult-ui/Typewriter';
import { YouTubeVideoPlayer } from './components/cult-ui/YouTubeVideoPlayer';

// Magic UI Imports
import { Android } from './components/magic-ui/Android';
import { AnimatedBeam } from './components/magic-ui/AnimatedBeam';
import { AnimatedCircularProgress } from './components/magic-ui/AnimatedCircularProgress';
import { AnimatedGradientText } from './components/magic-ui/AnimatedGradientText';
import { AnimatedGridPattern } from './components/magic-ui/AnimatedGridPattern';
import { AnimatedList } from './components/magic-ui/AnimatedList';
import { AnimatedShinyText } from './components/magic-ui/AnimatedShinyText';
import { AnimatedThemeToggler } from './components/magic-ui/AnimatedThemeToggler';
import { AuroraText } from './components/magic-ui/AuroraText';
import { AvatarCircles } from './components/magic-ui/AvatarCircles';
import { BentoGrid } from './components/magic-ui/BentoGrid';
import { BlurFade } from './components/magic-ui/BlurFade';
import { BorderBeam } from './components/magic-ui/BorderBeam';
import { CodeComparison } from './components/magic-ui/CodeComparison';
import { ComicText } from './components/magic-ui/ComicText';
import { Confetti } from './components/magic-ui/Confetti';
import { CoolMode } from './components/magic-ui/CoolMode';
import { Dock as MagicDock } from './components/magic-ui/Dock';
import { DotPattern } from './components/magic-ui/DotPattern';
import { DottedMap } from './components/magic-ui/DottedMap';
import { FileTree } from './components/magic-ui/FileTree';
import { FlickeringGrid } from './components/magic-ui/FlickeringGrid';
import { Globe as MagicGlobe } from './components/magic-ui/Globe';
import { GridPattern } from './components/magic-ui/GridPattern';
import { HeroVideoDialog } from './components/magic-ui/HeroVideoDialog';
import { HyperText } from './components/magic-ui/HyperText';
import { IconCloud } from './components/magic-ui/IconCloud';
import { InteractiveGridPattern } from './components/magic-ui/InteractiveGridPattern';
import { InteractiveHoverButton } from './components/magic-ui/InteractiveHoverButton';
import { iPhone } from './components/magic-ui/iPhone';
import { Lens as MagicLens } from './components/magic-ui/Lens'; // Lens exists in Aceternity
import { LightRays } from './components/magic-ui/LightRays';
import { LineShadowText } from './components/magic-ui/LineShadowText';
import { MagicCard } from './components/magic-ui/MagicCard';
import { Marquee as MagicMarquee } from './components/magic-ui/Marquee';
import { Meteors as MagicMeteors } from './components/magic-ui/Meteors';
import { MagicMorphingText } from './components/magic-ui/MagicMorphingText';
import { NeonGradientCard } from './components/magic-ui/NeonGradientCard';
import { NumberTicker } from './components/magic-ui/NumberTicker';
import { OrbitingCircles } from './components/magic-ui/OrbitingCircles';
import { Particles as MagicParticles } from './components/magic-ui/Particles';
import { PixelImage } from './components/magic-ui/PixelImage';
import { Pointer } from './components/magic-ui/Pointer';
import { ProgressiveBlur } from './components/magic-ui/ProgressiveBlur';
import { PulsatingButton } from './components/magic-ui/PulsatingButton';
import { RainbowButton } from './components/magic-ui/RainbowButton';
import { RetroGrid } from './components/magic-ui/RetroGrid';
import { Ripple } from './components/magic-ui/Ripple';
import { RippleButton as MagicRippleButton } from './components/magic-ui/RippleButton';
import { Safari } from './components/magic-ui/Safari';
import { ScrollBasedVelocity as MagicScrollBasedVelocity } from './components/magic-ui/ScrollBasedVelocity';
import { MagicScrollProgress } from './components/magic-ui/MagicScrollProgress';
import { ShimmerButton as MagicShimmerButton } from './components/magic-ui/ShimmerButton';
import { ShineBorder } from './components/magic-ui/ShineBorder';
import { ShinyButton } from './components/magic-ui/ShinyButton';
import { SmoothCursor } from './components/magic-ui/SmoothCursor';
import { SparklesText } from './components/magic-ui/SparklesText';
import { SpinningText } from './components/magic-ui/SpinningText';
import { StripedPattern } from './components/magic-ui/StripedPattern';
import { Terminal as MagicTerminal } from './components/magic-ui/Terminal';
import { MagicTextAnimate } from './components/magic-ui/MagicTextAnimate';
import { TextHighlighter } from './components/magic-ui/TextHighlighter';
import { TextReveal } from './components/magic-ui/TextReveal';
import { TweetCard } from './components/magic-ui/TweetCard';
import { TypingAnimation } from './components/magic-ui/TypingAnimation';
import { VideoText } from './components/magic-ui/VideoText';
import { WarpBackground } from './components/magic-ui/WarpBackground';
import { WordRotate } from './components/magic-ui/WordRotate';

// Motion Primitives Imports
import { TextEffect } from './components/motion-primitives/TextEffect';
import { TextLoop } from './components/motion-primitives/TextLoop';
import { TextMorph } from './components/motion-primitives/TextMorph';
import { TextRoll } from './components/motion-primitives/TextRoll';
import { TextScramble } from './components/motion-primitives/TextScramble';
import { TextShimmer } from './components/motion-primitives/TextShimmer';
import { TextShimmerWave } from './components/motion-primitives/TextShimmerWave';
import { AnimatedNumber as MotionAnimatedNumber } from './components/motion-primitives/AnimatedNumber';
import { SlidingNumber as MotionSlidingNumber } from './components/motion-primitives/SlidingNumber';
import { Dock as MotionDock } from './components/motion-primitives/Dock';
import { Dialog as MotionDialog } from './components/motion-primitives/Dialog';
import { MorphingDialog } from './components/motion-primitives/MorphingDialog';
import { MorphingPopover } from './components/motion-primitives/MorphingPopover';
import { Disclosure } from './components/motion-primitives/Disclosure';
import { TransitionPanel } from './components/motion-primitives/TransitionPanel';
import { ToolbarDynamic } from './components/motion-primitives/ToolbarDynamic';
import { ToolbarExpandable as MotionToolbarExpandable } from './components/motion-primitives/ToolbarExpandable';
import { AnimatedBackground } from './components/motion-primitives/AnimatedBackground';
import { AnimatedGroup } from './components/motion-primitives/AnimatedGroup';
import { GlowEffect } from './components/motion-primitives/GlowEffect';
import { InView } from './components/motion-primitives/InView';
import { ScrollProgress as MotionScrollProgress } from './components/motion-primitives/ScrollProgress';
import { Carousel as MotionPrimitivesCarousel } from './components/motion-primitives/Carousel';
import { InfiniteSlider } from './components/motion-primitives/InfiniteSlider';
import { ImageComparison } from './components/motion-primitives/ImageComparison';
import { Tilt } from './components/motion-primitives/Tilt';
import { Cursor as MotionCursor } from './components/motion-primitives/Cursor';
import { Magnetic } from './components/motion-primitives/Magnetic';
import { BorderTrail } from './components/motion-primitives/BorderTrail';
import { Spotlight as MotionSpotlight } from './components/motion-primitives/Spotlight';
import { SpinningText as MotionSpinningText } from './components/motion-primitives/SpinningText';
import { ProgressiveBlur as MotionProgressiveBlur } from './components/motion-primitives/ProgressiveBlur';

// shadcn/ui Imports
import { Button as ShadcnButton } from './components/shadcn-ui/Button';
import { ButtonGroup as ShadcnButtonGroup } from './components/shadcn-ui/ButtonGroup';
import { Toggle as ShadcnToggle } from './components/shadcn-ui/Toggle';
import { ToggleGroup as ShadcnToggleGroup } from './components/shadcn-ui/ToggleGroup';
import { Checkbox as ShadcnCheckbox } from './components/shadcn-ui/Checkbox';
import { RadioGroup as ShadcnRadioGroup } from './components/shadcn-ui/RadioGroup';
import { Switch as ShadcnSwitch } from './components/shadcn-ui/Switch';
import { Input as ShadcnInput } from './components/shadcn-ui/Input';
import { InputGroup as ShadcnInputGroup } from './components/shadcn-ui/InputGroup';
import { InputOTP as ShadcnInputOTP } from './components/shadcn-ui/InputOTP';
import { Textarea as ShadcnTextarea } from './components/shadcn-ui/Textarea';
import { Select as ShadcnSelect } from './components/shadcn-ui/Select';
import { NativeSelect as ShadcnNativeSelect } from './components/shadcn-ui/NativeSelect';
import { Combobox as ShadcnCombobox } from './components/shadcn-ui/Combobox';
import { Label as ShadcnLabel } from './components/shadcn-ui/Label';
import { Form as ShadcnForm } from './components/shadcn-ui/Form';
import { Field as ShadcnField } from './components/shadcn-ui/Field';
import { Card as ShadcnCard } from './components/shadcn-ui/Card';
import { HoverCard as ShadcnHoverCard } from './components/shadcn-ui/HoverCard';
import { Tabs as ShadcnTabs } from './components/shadcn-ui/Tabs';
import { Breadcrumb as ShadcnBreadcrumb } from './components/shadcn-ui/Breadcrumb';
import { Pagination as ShadcnPagination } from './components/shadcn-ui/Pagination';
import { NavigationMenu as ShadcnNavigationMenu } from './components/shadcn-ui/NavigationMenu';
import { Menubar as ShadcnMenubar } from './components/shadcn-ui/Menubar';
import { DropdownMenu as ShadcnDropdownMenu } from './components/shadcn-ui/DropdownMenu';
import { ContextMenu as ShadcnContextMenu } from './components/shadcn-ui/ContextMenu';
import { Dialog as ShadcnDialog } from './components/shadcn-ui/Dialog';
import { AlertDialog as ShadcnAlertDialog } from './components/shadcn-ui/AlertDialog';
import { Drawer as ShadcnDrawer } from './components/shadcn-ui/Drawer';
import { Sheet as ShadcnSheet } from './components/shadcn-ui/Sheet';
import { Popover as ShadcnPopover } from './components/shadcn-ui/Popover';
import { Tooltip as ShadcnTooltip } from './components/shadcn-ui/Tooltip';
import { Carousel as ShadcnCarousel } from './components/shadcn-ui/Carousel';
import { Slider as ShadcnSlider } from './components/shadcn-ui/Slider';
import { Calendar as ShadcnCalendar } from './components/shadcn-ui/Calendar';
import { DatePicker as ShadcnDatePicker } from './components/shadcn-ui/DatePicker';
import { Table as ShadcnTable } from './components/shadcn-ui/Table';
import { DataTable as ShadcnDataTable } from './components/shadcn-ui/DataTable';
import { Chart as ShadcnChart } from './components/shadcn-ui/Chart';
import { Progress as ShadcnProgress } from './components/shadcn-ui/Progress';
import { Spinner as ShadcnSpinner } from './components/shadcn-ui/Spinner';
import { Skeleton as ShadcnSkeleton } from './components/shadcn-ui/Skeleton';

// Eldora UI Imports
import { AnimatedBorderButton } from './components/eldora-ui/AnimatedBorderButton';
import { AnimatedCard } from './components/eldora-ui/AnimatedCard';
import { AnimatedFrameworks } from './components/eldora-ui/AnimatedFrameworks';
import { AnimatedShinyButton } from './components/eldora-ui/AnimatedShinyButton';
import { BlurInText } from './components/eldora-ui/BlurInText';
import { Browser } from './components/eldora-ui/Browser';
import { CardFlipHover } from './components/eldora-ui/CardFlipHover';
import { ClerkOTP } from './components/eldora-ui/ClerkOTP';
import { CobeGlobe } from './components/eldora-ui/CobeGlobe';
import { CodeSnippet } from './components/eldora-ui/CodeSnippet';
import { ColorChangingButton } from './components/eldora-ui/ColorChangingButton';
import { DockText } from './components/eldora-ui/DockText';
import { DynamicSquare } from './components/eldora-ui/DynamicSquare';
import { FadeText } from './components/eldora-ui/FadeText';
import { FontWeightText } from './components/eldora-ui/FontWeightText';
import { GitStarButton } from './components/eldora-ui/GitStarButton';
import { GitHubInlineComments } from './components/eldora-ui/GitHubInlineComments';
import { GradualSpacingText } from './components/eldora-ui/GradualSpacingText';
import { HackerBackground } from './components/eldora-ui/HackerBackground';
import { HoverMeButton } from './components/eldora-ui/HoverMeButton';
import { Integrations } from './components/eldora-ui/Integrations';
import { InteractiveButton } from './components/eldora-ui/InteractiveButton';
import { iPad } from './components/eldora-ui/iPad';
import { iPhone17Pro } from './components/eldora-ui/iPhone17Pro';
import { LetterPullUpText } from './components/eldora-ui/LetterPullUpText';
import { LiveButton } from './components/eldora-ui/LiveButton';
import { LogoTimeline } from './components/eldora-ui/LogoTimeline';
import { MacBookPro } from './components/eldora-ui/MacBookPro';
import { Map } from './components/eldora-ui/Map';
import { EldoraMorphingText } from './components/eldora-ui/EldoraMorphingText';
import { MultiDirectionSlide } from './components/eldora-ui/MultiDirectionSlide';
import { NovatrixBackground } from './components/eldora-ui/NovatrixBackground';
import { OrbitRotation } from './components/eldora-ui/OrbitRotation';
import { SafariBrowser } from './components/eldora-ui/SafariBrowser';
import { ScaleLetterText } from './components/eldora-ui/ScaleLetterText';
import { ScaleSlider } from './components/eldora-ui/ScaleSlider';
import { ScratchToReveal } from './components/eldora-ui/ScratchToReveal';
import { ScrollBasedVelocity } from './components/eldora-ui/ScrollBasedVelocity';
import { EldoraScrollProgress } from './components/eldora-ui/ScrollProgress';
import { SeparateAwayText } from './components/eldora-ui/SeparateAwayText';
import { ShimmerButton } from './components/eldora-ui/ShimmerButton';
import { SphereAnimation } from './components/eldora-ui/SphereAnimation';
import { SpotlightButton } from './components/eldora-ui/SpotlightButton';
import { SVGRippleEffect } from './components/eldora-ui/SVGRippleEffect';
import { Terminal } from './components/eldora-ui/Terminal';
import { TestimonialSlider } from './components/eldora-ui/TestimonialSlider';
import { WavyText } from './components/eldora-ui/WavyText';
import { WordPullUpText } from './components/eldora-ui/WordPullUpText';


// Map component names (from data/components.ts) to actual React components
// We use a lazy loading strategy or direct mapping. For now, direct mapping for the PoC.

export const componentRegistry: Record<string, React.ComponentType<any>> = {
    "Text Generate Effect": TextGenerateEffect,
    "3D Card Effect": ThreeDCardEffect,
    "3D Marquee": ThreeDMarquee,
    "3D Pin": ThreeDPin,
    "Animated Modal": AnimatedModal,
    "Animated Testimonials": AnimatedTestimonials,
    "Animated Tooltip": AnimatedTooltip,
    "Apple Cards Carousel": AppleCardsCarousel,
    "Aurora Background": AuroraBackground,
    "Background Beams": BackgroundBeams,
    "Background Beams Collision": BackgroundBeamsCollision,
    "Background Boxes": BackgroundBoxes,
    "Background Lines": BackgroundLines,
    "Background Ripple Effect": BackgroundRippleEffect,
    "Canvas Reveal Effect": CanvasRevealEffect,
    "Card Hover Effect": CardHoverEffect,
    "Card Spotlight": CardSpotlight,
    "Card Stack": CardStack,
    "Carousel": Carousel,
    "Code Block": CodeBlock,
    "Colourful Text": ColourfulText,
    "Comet Card": CometCard,
    "Compare": Compare,
    "Container Scroll Animation": ContainerScrollAnimation,
    "Container Text Flip": ContainerTextFlip,
    "Direction Aware Hover": DirectionAwareHover,
    "Dither Shader": DitherShader,
    "Dotted Glow Background": DottedGlowBackground,
    "Draggable Card": DraggableCard,
    "Encrypted Text": EncryptedText,
    "Evervault Card": EvervaultCard,
    "Expandable Card": ExpandableCard,
    "File Upload": FileUpload,
    "Flip Words": FlipWords,
    "Floating Dock": FloatingDock,
    "Floating Navbar": FloatingNavbar,
    "Focus Cards": FocusCards,
    "Following Pointer": FollowingPointer,
    "GitHub Globe": GitHubGlobe,
    "Glare Card": GlareCard,
    "Glowing Effect": GlowingEffect,
    "Glowing Stars": GlowingStars,
    "Google Gemini Effect": GoogleGeminiEffect,
    "Gradient Animation": GradientAnimation,
    "Grid and Dot Backgrounds": GridAndDotBackgrounds,
    "Hero Highlight": HeroHighlight,
    "Hero Parallax": HeroParallax,
    "Hover Border Gradient": HoverBorderGradient,
    "Images Slider": ImagesSlider,
    "Infinite Moving Cards": InfiniteMovingCards,
    "Lamp Effect": LampEffect,
    "Layout Text Flip": LayoutTextFlip,
    "Lens": Lens,
    "Link Preview": LinkPreview,
    "Loader": Loader,
    "Macbook Scroll": MacbookScroll,
    "Meteors": Meteors,
    "Moving Border": MovingBorder,
    "Multi Step Loader": MultiStepLoader,
    "Navbar Menu": NavbarMenu,
    "Noise Background": NoiseBackground,
    "Parallax Scroll": ParallaxScroll,
    "Pixelated Canvas": PixelatedCanvas,
    "Placeholders Vanish Input": PlaceholdersVanishInput,
    "Pointer Highlight": PointerHighlight,
    "Resizable Navbar": ResizableNavbar,
    "Shooting Stars": ShootingStars,
    "Sidebar": Sidebar,
    "Signup Form": SignupForm,
    "Sparkles": Sparkles,
    "Spotlight": Spotlight,
    "Spotlight New": SpotlightNew,
    "Stateful Button": StatefulButton,
    "Sticky Banner": StickyBanner,
    "Sticky Scroll Reveal": StickyScrollReveal,
    "SVG Mask Effect": SVGMaskEffect,
    "Tabs": Tabs,
    "Tailwind CSS Buttons": TailwindCSSButtons,
    "Text Hover Effect": TextHoverEffect,
    "Text Reveal Card": TextRevealCard,
    "Timeline": Timeline,
    "Tooltip Card": TooltipCard,
    "Tracing Beam": TracingBeam,
    "Typewriter Effect": TypewriterEffect,
    "Vortex": Vortex,
    "Wavy Background": WavyBackground,
    "Webcam Pixel Grid": WebcamPixelGrid,
    "Wobble Card": WobbleCard,
    "World Map": WorldMap,
    "Accordion Multiselect": AccordionMultiselect,
    "Animated Chart": AnimatedChart,
    "Availability": Availability,
    "Calendar Year": CalendarYear,
    "Color Swatch Selector": ColorSwatchSelector,
    "Label Selector": LabelSelector,
    "Radio Rows": RadioRows,
    "Radio Tabs": RadioTabs,
    "Scroll Progress": ScrollProgress,
    "Scroll Reveal Content": ScrollRevealContent,
    "Spinner": Spinner,
    "Table of Contents": TableOfContents,
    "Text Gradient": TextGradient,
    "Timeline (Gantt)": TimelineGantt,
    "Timeline Steps": TimelineSteps,

    // Animate UI Mappings
    "Alert Dialog": AlertDialog,
    "Blur Effect": BlurEffect,
    "Bubble Background": BubbleBackground,
    "Button": Button,
    "Checkbox": Checkbox,
    "Code": Code,
    "Code Tabs": CodeTabs,
    "Copy Button": CopyButton,
    "Counting Number": CountingNumber,
    "Cursor": Cursor,
    "Dialog": Dialog,
    "Dropdown Menu": DropdownMenu,
    "Fade Effect": FadeEffect,
    "Files": Files,
    "Fireworks Background": FireworksBackground,
    "Flip Button": FlipButton,
    "Flip Card": FlipCard,
    "GitHub Stars Button": GitHubStarsButton,
    "Gradient Background": GradientBackground,
    "Gradient Text": GradientText,
    "Gravity Stars": GravityStars,
    "Hexagon Background": HexagonBackground,
    "Highlight Text": HighlightText,
    "Hole Background": HoleBackground,
    "Icon Button": IconButton,
    "Image Zoom": ImageZoom,
    "Liquid Button": LiquidButton,
    "Magnetic Effect": MagneticEffect,
    "Morphing Text": MorphingText,
    "Motion Carousel": MotionCarousel,
    "Particles Effect": ParticlesEffect,
    "Popover": Popover,
    "Preview Link Card": PreviewLinkCard,
    "Progress": Progress,
    "Radial Menu": RadialMenu,
    "Radial Nav": RadialNav,
    "Radio Group": RadioGroup,
    "Ripple Button": RippleButton,
    "Rolling Text": RollingText,
    "Rotating Text": RotatingText,
    "Scroll Progress (Animate UI)": AnimateScrollProgress,
    "Scrolling Number": ScrollingNumber,
    "Sheet": Sheet,
    "Shimmering Text": ShimmeringText,
    "Shine Effect": ShineEffect,
    "Sidebar (Animate UI)": AnimateSidebar,
    "Sliding Number": SlidingNumber,
    "Splitting Text": SplittingText,
    "Stars Background": StarsBackground,
    "Switch": Switch,
    "Tabs (Animate UI)": AnimateTabs,
    "Theme Toggler": ThemeToggler,
    "Tilt Effect": TiltEffect,
    "Tooltip": Tooltip,
    "Typing Text": TypingText,
    "Zoom Effect": ZoomEffect,

    // Cult UI Mappings
    "3D Carousel": ThreeDCarousel,
    "Animated Number": AnimatedNumber,
    "Background Texture": BackgroundTexture,
    "Bg Animate Button": BgAnimateButton,
    "Bg Media Hero": BgMediaHero,
    "Browser Window": BrowserWindow,
    "Canvas Fractal Grid": CanvasFractalGrid,
    "Code Block (Cult UI)": CultCodeBlock,
    "Color Picker": ColorPicker,
    "Direction Aware Tabs": DirectionAwareTabs,
    "Distorted Glass": DistortedGlass,
    "Dynamic Island": DynamicIsland,
    "Expandable Card (Cult UI)": CultExpandableCard,
    "Expandable Screen": ExpandableScreen,
    "Family Button": FamilyButton,
    "Family Drawer": FamilyDrawer,
    "Feature Carousel": FeatureCarousel,
    "Floating Panel": FloatingPanel,
    "Fractal Grid": FractalGrid,
    "Gradient Heading": GradientHeading,
    "Hover Video Player": HoverVideoPlayer,
    "Intro Disclosure": IntroDisclosure,
    "LightBoard": LightBoard,
    "Loading Carousel": LoadingCarousel,
    "Logo Carousel": LogoCarousel,
    "MacOS Dock": MacOSDock,
    "Minimal Card": MinimalCard,
    "Morph Surface": MorphSurface,
    "Neumorph Button": NeumorphButton,
    "Popover (Cult UI)": CultPopover,
    "Popover Form": PopoverForm,
    "Shader Lens Blur": ShaderLensBlur,
    "Shift Card": ShiftCard,
    "Side Panel": SidePanel,
    "Sortable List": SortableList,
    "Squiggle Arrow": SquiggleArrow,
    "Stripe Bg Guides": StripeBgGuides,
    "Text Animate": TextAnimate,
    "Text GIF": TextGIF,
    "Texture Button": TextureButton,
    "Texture Card": TextureCard,
    "Texture Overlay": TextureOverlay,
    "Timer": Timer,
    "Toolbar Expandable": ToolbarExpandable,
    "Tweet Grid": TweetGrid,
    "Typewriter": CultTypewriter,
    "YouTube Video Player": YouTubeVideoPlayer,

    // Eldora UI Mappings
    "Animated Border Button": AnimatedBorderButton,
    "Animated Card": AnimatedCard,
    "Animated Frameworks": AnimatedFrameworks,
    "Animated Shiny Button": AnimatedShinyButton,
    "Blur In Text": BlurInText,
    "Browser": Browser,
    "Card Flip Hover": CardFlipHover,
    "Clerk OTP": ClerkOTP,
    "Cobe Globe": CobeGlobe,
    "Code Snippet": CodeSnippet,
    "Color Changing Button": ColorChangingButton,
    "Dock Text": DockText,
    "Dynamic Square": DynamicSquare,
    "Fade Text": FadeText,
    "Font Weight Text": FontWeightText,
    "Git Star Button": GitStarButton,
    "GitHub Inline Comments": GitHubInlineComments,
    "Gradual Spacing Text": GradualSpacingText,
    "Hacker Background": HackerBackground,
    "Hover Me Button": HoverMeButton,
    "Integrations": Integrations,
    "Interactive Button": InteractiveButton,
    "iPad": iPad,
    "iPhone 17 Pro": iPhone17Pro,
    "Letter Pull Up Text": LetterPullUpText,
    "Live Button": LiveButton,
    "Logo Timeline": LogoTimeline,
    "MacBook Pro": MacBookPro,
    "Map": Map,
    "Morphing Text (Eldora UI)": EldoraMorphingText,
    "Eldora UI__Morphing Text": EldoraMorphingText,
    "Multi Direction Slide": MultiDirectionSlide,
    "Novatrix Background": NovatrixBackground,
    "Orbit Rotation": OrbitRotation,
    "Safari Browser": SafariBrowser,
    "Scale Letter Text": ScaleLetterText,
    "Scale Slider": ScaleSlider,
    "Scratch To Reveal": ScratchToReveal,
    "Scroll Based Velocity": ScrollBasedVelocity,
    "Scroll Progress (Eldora UI)": EldoraScrollProgress,
    "Eldora UI__Scroll Progress": EldoraScrollProgress,
    "Separate Away Text": SeparateAwayText,
    "Shimmer Button": ShimmerButton,
    "Eldora UI__Shimmer Button": ShimmerButton,
    "Sphere Animation": SphereAnimation,
    "Spotlight Button": SpotlightButton,
    "SVG Ripple Effect": SVGRippleEffect,
    "Terminal": Terminal,
    "Eldora UI__Terminal": Terminal,
    "Testimonial Slider": TestimonialSlider,
    "Wavy Text": WavyText,
    "Word Pull Up Text": WordPullUpText,
    "Eldora UI__Scroll Based Velocity": ScrollBasedVelocity,

    // Magic UI Mappings
    "Android": Android,
    "Animated Beam": AnimatedBeam,
    "Animated Circular Progress": AnimatedCircularProgress,
    "Animated Gradient Text": AnimatedGradientText,
    "Animated Grid Pattern": AnimatedGridPattern,
    "Animated List": AnimatedList,
    "Animated Shiny Text": AnimatedShinyText,
    "Animated Theme Toggler": AnimatedThemeToggler,
    "Aurora Text": AuroraText,
    "Avatar Circles": AvatarCircles,
    "Bento Grid": BentoGrid,
    "Blur Fade": BlurFade,
    "Border Beam": BorderBeam,
    "Code Comparison": CodeComparison,
    "Comic Text": ComicText,
    "Confetti": Confetti,
    "Cool Mode": CoolMode,
    "Dock": MagicDock,
    "Magic UI__Dock": MagicDock,
    "Dot Pattern": DotPattern,
    "Dotted Map": DottedMap,
    "File Tree": FileTree,
    "Flickering Grid": FlickeringGrid,
    "Globe": MagicGlobe,
    "Magic UI__Globe": MagicGlobe,
    "Grid Pattern": GridPattern,
    "Hero Video Dialog": HeroVideoDialog,
    "Hyper Text": HyperText,
    "Icon Cloud": IconCloud,
    "Interactive Grid Pattern": InteractiveGridPattern,
    "Interactive Hover Button": InteractiveHoverButton,
    "iPhone": iPhone,
    "Magic UI__Lens": MagicLens,
    "Light Rays": LightRays,
    "Line Shadow Text": LineShadowText,
    "Magic Card": MagicCard,
    "Marquee": MagicMarquee,
    "Magic UI__Marquee": MagicMarquee,
    "Magic UI__Meteors": MagicMeteors,
    "Magic UI__Morphing Text": MagicMorphingText,
    "Neon Gradient Card": NeonGradientCard,
    "Number Ticker": NumberTicker,
    "Orbiting Circles": OrbitingCircles,
    "Particles": MagicParticles,
    "Magic UI__Particles": MagicParticles,
    "Pixel Image": PixelImage,
    "Pointer": Pointer,
    "Progressive Blur": ProgressiveBlur,
    "Pulsating Button": PulsatingButton,
    "Rainbow Button": RainbowButton,
    "Retro Grid": RetroGrid,
    "Ripple": Ripple,
    "Magic UI__Ripple Button": MagicRippleButton,
    "Safari": Safari,
    "Magic UI__Scroll Based Velocity": MagicScrollBasedVelocity,
    "Magic UI__Scroll Progress": MagicScrollProgress,
    "Magic UI__Shimmer Button": MagicShimmerButton,
    "Shine Border": ShineBorder,
    "Shiny Button": ShinyButton,
    "Smooth Cursor": SmoothCursor,
    "Sparkles Text": SparklesText,
    "Spinning Text": SpinningText,
    "Striped Pattern": StripedPattern,
    "Magic UI__Terminal": MagicTerminal,
    "Magic UI__Text Animate": MagicTextAnimate,
    "Text Highlighter": TextHighlighter,
    "Text Reveal": TextReveal,
    "Tweet Card": TweetCard,
    "Typing Animation": TypingAnimation,
    "Video Text": VideoText,
    "Warp Background": WarpBackground,
    "Word Rotate": WordRotate,

    // Motion Primitives Mappings
    "Text Effect": TextEffect,
    "Text Loop": TextLoop,
    "Text Morph": TextMorph,
    "Text Roll": TextRoll,
    "Text Scramble": TextScramble,
    "Text Shimmer": TextShimmer,
    "Text Shimmer Wave": TextShimmerWave,
    "Motion Primitives__Animated Number": MotionAnimatedNumber,
    "Motion Primitives__Sliding Number": MotionSlidingNumber,
    "Motion Primitives__Dock": MotionDock,
    "Motion Primitives__Dialog": MotionDialog,
    "Morphing Dialog": MorphingDialog,
    "Morphing Popover": MorphingPopover,
    "Disclosure": Disclosure,
    "Transition Panel": TransitionPanel,
    "Toolbar Dynamic": ToolbarDynamic,
    "Motion Primitives__Toolbar Expandable": MotionToolbarExpandable,
    "Animated Background": AnimatedBackground,
    "Animated Group": AnimatedGroup,
    "Glow Effect": GlowEffect,
    "In View": InView,
    "Motion Primitives__Scroll Progress": MotionScrollProgress,
    "Motion Primitives__Carousel": MotionPrimitivesCarousel,
    "Infinite Slider": InfiniteSlider,
    "Image Comparison": ImageComparison,
    "Tilt": Tilt,
    "Motion Primitives__Cursor": MotionCursor,
    "Magnetic": Magnetic,
    "Border Trail": BorderTrail,
    "Motion Primitives__Spotlight": MotionSpotlight,
    "Motion Primitives__Spinning Text": MotionSpinningText,
    "Motion Primitives__Progressive Blur": MotionProgressiveBlur,

    // shadcn/ui Mappings
    "shadcn/ui__Button": ShadcnButton,
    "Button Group": ShadcnButtonGroup,
    "shadcn/ui__Button Group": ShadcnButtonGroup,
    "Toggle": ShadcnToggle,
    "shadcn/ui__Toggle": ShadcnToggle,
    "Toggle Group": ShadcnToggleGroup,
    "shadcn/ui__Toggle Group": ShadcnToggleGroup,
    "shadcn/ui__Checkbox": ShadcnCheckbox,
    "shadcn/ui__Radio Group": ShadcnRadioGroup,
    "shadcn/ui__Switch": ShadcnSwitch,
    "Input": ShadcnInput,
    "shadcn/ui__Input": ShadcnInput,
    "Input Group": ShadcnInputGroup,
    "shadcn/ui__Input Group": ShadcnInputGroup,
    "Input OTP": ShadcnInputOTP,
    "shadcn/ui__Input OTP": ShadcnInputOTP,
    "Textarea": ShadcnTextarea,
    "shadcn/ui__Textarea": ShadcnTextarea,
    "Select": ShadcnSelect,
    "shadcn/ui__Select": ShadcnSelect,
    "Native Select": ShadcnNativeSelect,
    "shadcn/ui__Native Select": ShadcnNativeSelect,
    "Combobox": ShadcnCombobox,
    "shadcn/ui__Combobox": ShadcnCombobox,
    "Label": ShadcnLabel,
    "shadcn/ui__Label": ShadcnLabel,
    "Form": ShadcnForm,
    "shadcn/ui__Form": ShadcnForm,
    "Field": ShadcnField,
    "shadcn/ui__Field": ShadcnField,
    "Card": ShadcnCard,
    "shadcn/ui__Card": ShadcnCard,
    "Hover Card": ShadcnHoverCard,
    "shadcn/ui__Hover Card": ShadcnHoverCard,
    "shadcn/ui__Tabs": ShadcnTabs,
    "Breadcrumb": ShadcnBreadcrumb,
    "shadcn/ui__Breadcrumb": ShadcnBreadcrumb,
    "Pagination": ShadcnPagination,
    "shadcn/ui__Pagination": ShadcnPagination,
    "Navigation Menu": ShadcnNavigationMenu,
    "shadcn/ui__Navigation Menu": ShadcnNavigationMenu,
    "Menubar": ShadcnMenubar,
    "shadcn/ui__Menubar": ShadcnMenubar,
    "shadcn/ui__Dropdown Menu": ShadcnDropdownMenu,
    "Context Menu": ShadcnContextMenu,
    "shadcn/ui__Context Menu": ShadcnContextMenu,
    "shadcn/ui__Dialog": ShadcnDialog,
    "shadcn/ui__Alert Dialog": ShadcnAlertDialog,
    "Drawer": ShadcnDrawer,
    "shadcn/ui__Drawer": ShadcnDrawer,
    "shadcn/ui__Sheet": ShadcnSheet,
    "shadcn/ui__Popover": ShadcnPopover,
    "shadcn/ui__Tooltip": ShadcnTooltip,
    "shadcn/ui__Carousel": ShadcnCarousel,
    "Slider": ShadcnSlider,
    "shadcn/ui__Slider": ShadcnSlider,
    "Calendar": ShadcnCalendar,
    "shadcn/ui__Calendar": ShadcnCalendar,
    "Date Picker": ShadcnDatePicker,
    "shadcn/ui__Date Picker": ShadcnDatePicker,
    "Table": ShadcnTable,
    "shadcn/ui__Table": ShadcnTable,
    "Data Table": ShadcnDataTable,
    "shadcn/ui__Data Table": ShadcnDataTable,
    "Chart": ShadcnChart,
    "shadcn/ui__Chart": ShadcnChart,
    "shadcn/ui__Progress": ShadcnProgress,
    "shadcn/ui__Spinner": ShadcnSpinner,
    "Skeleton": ShadcnSkeleton,
    "shadcn/ui__Skeleton": ShadcnSkeleton,

    // Conflict Resolutions (Composite Keys for Library Specific Lookups)
    "Aceternity UI__Meteors": Meteors,
    "Aceternity UI__Lens": Lens,
    "Animate UI__Dialog": Dialog,
    "ABUI__Scroll Progress": ScrollProgress,
    "Animate UI__Scroll Progress": AnimateScrollProgress,
    "Aceternity UI__Carousel": Carousel,
    "Animate UI__Cursor": Cursor,
    "Aceternity UI__Spotlight": Spotlight,
    "Cult UI__Toolbar Expandable": ToolbarExpandable,
    "Animate UI__Switch": Switch,
    "Animate UI__Tabs": AnimateTabs,
    "Aceternity UI__Tabs": AnimateTabs, // Note: Aceternity Tabs assumed to be same or handled here if name conflicted. Wait, Aceternity Tabs has existing import? 
    "Animate UI__Popover": Popover,
    "Cult UI__Popover": CultPopover,
    "Motion Primitives__Popover": MorphingPopover, // Wait, MP has component registered as "Morphing Popover", but maybe also "Popover"? No.
    "Animate UI__Tooltip": Tooltip,
    "Animate UI__Progress": Progress,
    "ABUI__Spinner": Spinner,

};

export const getComponentPreview = (name: string, library?: string) => {
    if (library) {
        const compositeKey = `${library}__${name}`;
        if (componentRegistry[compositeKey]) {
            return componentRegistry[compositeKey];
        }
    }
    return componentRegistry[name] || null;
};
