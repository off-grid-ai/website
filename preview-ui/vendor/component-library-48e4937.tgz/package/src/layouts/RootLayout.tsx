import { useState } from 'react';
import { Sidebar, SidebarBody, SidebarLink, SidebarGroup } from '../components/aceternity/Sidebar';
import { Outlet, useLocation } from 'react-router-dom';
import {
    LayoutGrid,
    Palette,
    Moon,
    Sun,
} from 'lucide-react';
import { cn } from '../utils/cn';

export const RootLayout = () => {
    const [open, setOpen] = useState(false);
    const location = useLocation();

    return (
        <div className={cn(
            "rounded-md flex flex-col md:flex-row bg-gray-100 dark:bg-neutral-800 w-full flex-1 mx-auto border border-neutral-200 dark:border-neutral-700 overflow-hidden",
            "h-screen"
        )}>
            <Sidebar open={open} setOpen={setOpen}>
                <SidebarBody className="justify-between gap-10">
                    <div className="flex flex-col flex-1 overflow-y-auto overflow-x-hidden">

                        {/* Branding / Logo Area */}
                        <div className="mb-8 flex items-center gap-2 px-2">
                            <div className="h-6 w-6 rounded-md bg-neutral-900 dark:bg-white flex-shrink-0" />
                            {open && (
                                <span className="font-semibold text-neutral-700 dark:text-neutral-200 text-sm">
                                    Antigravity
                                </span>
                            )}
                        </div>

                        <div className="flex flex-col gap-2">
                            {/* Root Link */}
                            <SidebarLink
                                link={{
                                    label: "Component Library",
                                    href: "/",
                                    icon: <LayoutGrid className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />
                                }}
                                className={cn(
                                    location.pathname === "/" && "bg-neutral-200 dark:bg-neutral-700 font-semibold"
                                )}
                            />

                            {/* Design Systems Group */}
                            <SidebarGroup
                                label="Design Systems"
                                icon={<Palette className="text-neutral-700 dark:text-neutral-200 h-5 w-5 flex-shrink-0" />}
                                initiallyOpen={true}
                            >
                                <SidebarLink
                                    link={{
                                        label: "Memoria",
                                        href: "/design-systems/memoria",
                                        icon: <Moon className="text-neutral-500 dark:text-neutral-400 h-4 w-4 flex-shrink-0" />
                                    }}
                                    className={cn(
                                        location.pathname === "/design-systems/memoria" && "text-neutral-900 dark:text-white font-medium bg-neutral-200/50 dark:bg-neutral-700/50"
                                    )}
                                />
                                <SidebarLink
                                    link={{
                                        label: "Light Green",
                                        href: "/design-systems/light-green",
                                        icon: <Sun className="text-neutral-500 dark:text-neutral-400 h-4 w-4 flex-shrink-0" />
                                    }}
                                    className={cn(
                                        location.pathname === "/design-systems/light-green" && "text-neutral-900 dark:text-white font-medium bg-neutral-200/50 dark:bg-neutral-700/50"
                                    )}
                                />
                            </SidebarGroup>
                        </div>
                    </div>
                </SidebarBody>
            </Sidebar>

            <main className="flex-1 overflow-y-auto bg-white dark:bg-neutral-900">
                <Outlet />
            </main>
        </div>
    );
};
