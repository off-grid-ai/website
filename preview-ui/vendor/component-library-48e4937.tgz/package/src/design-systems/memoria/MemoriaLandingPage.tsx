import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../utils/cn';
import { BorderBeam } from '../../components/magic-ui/BorderBeam'; // Assuming path
import { TextGenerateEffect } from '../../components/aceternity/TextGenerateEffect'; // Assuming path
import { Spotlight } from '../../components/aceternity/Spotlight'; // Assuming path

// --- Components based on Memoria Design System ---

const MemoriaCard = ({
    children,
    className,
    withBeam = false,
    beamDuration = 10
}: {
    children: React.ReactNode;
    className?: string;
    withBeam?: boolean;
    beamDuration?: number;
}) => {
    return (
        <div className={cn(
            "relative bg-neutral-900/60 border border-neutral-800 rounded-xl overflow-hidden backdrop-blur-sm transition-colors hover:border-neutral-700",
            className
        )}>
            <div className="p-6 relative z-10">
                {children}
            </div>
            {withBeam && (
                <BorderBeam
                    size={200}
                    duration={beamDuration}
                    borderWidth={1.5}
                    className="from-transparent via-neutral-500 to-transparent"
                />
            )}
        </div>
    );
};

const AnimatedCounter = ({ value, className }: { value: number, className?: string }) => {
    const [count, setCount] = useState(0);

    useEffect(() => {
        let start = 0;
        const end = value;
        const duration = 2000;
        const increment = end / (duration / 16);

        const timer = setInterval(() => {
            start += increment;
            if (start >= end) {
                setCount(end);
                clearInterval(timer);
            } else {
                setCount(Math.floor(start));
            }
        }, 16);

        return () => clearInterval(timer);
    }, [value]);

    return <span className={className}>{count.toLocaleString()}</span>;
};

// --- Page Layout ---

export const MemoriaLandingPage = () => {
    return (
        <div className="min-h-screen bg-neutral-950 text-white font-sans selection:bg-neutral-800 selection:text-white pb-32">

            {/* Background Ambience */}
            <div className="fixed inset-0 pointer-events-none">
                <Spotlight
                    className="-top-40 left-0 md:left-60 md:-top-20"
                    fill="white"
                />
            </div>

            <div className="max-w-7xl mx-auto px-6 pt-24 relative z-10">

                {/* Header Section */}
                <div className="mb-24 space-y-8">
                    <motion.div
                        initial={{ opacity: 0, filter: 'blur(10px)' }}
                        animate={{ opacity: 1, filter: 'blur(0px)' }}
                        transition={{ duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
                    >
                        <h2 className="text-xs font-medium text-neutral-500 uppercase tracking-widest mb-4">
                            System Analytics
                        </h2>
                        <h1 className="text-6xl md:text-8xl font-light tracking-tight text-white mb-6">
                            <TextGenerateEffect words="Numbers are heroes." />
                        </h1>
                        <p className="text-xl text-neutral-400 max-w-2xl font-light leading-relaxed">
                            A design language for premium, dark-themed knowledge interfaces.
                            Restraint, depth, and data-forward aesthetics.
                        </p>
                    </motion.div>

                    <div className="flex gap-4">
                        <button className="px-6 py-3 bg-neutral-100 text-neutral-900 rounded-lg hover:bg-neutral-200 transition-colors font-medium text-sm">
                            Explore Documentation
                        </button>
                        <button className="px-6 py-3 border border-neutral-800 text-neutral-300 rounded-lg hover:bg-neutral-900/50 hover:text-white transition-colors font-medium text-sm">
                            View Components
                        </button>
                    </div>
                </div>

                {/* Bento Grid Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
                    {/* Main Hero Card */}
                    <MemoriaCard className="md:col-span-2 min-h-[300px] flex flex-col justify-between" withBeam>
                        <div className="flex justify-between items-start">
                            <div>
                                <h3 className="text-sm font-medium text-neutral-400 uppercase tracking-wider mb-2">Total Memories</h3>
                                <AnimatedCounter value={12483} className="text-6xl font-light text-white tracking-tight" />
                            </div>
                            <div className="px-2 py-1 rounded bg-neutral-900 border border-neutral-800 text-xs text-green-400 flex items-center gap-1">
                                <span>+12.4%</span>
                            </div>
                        </div>
                        <div className="h-32 flex items-end gap-1 pb-4">
                            {[40, 65, 50, 80, 55, 90, 70, 85, 60, 75, 50, 95].map((h, i) => (
                                <motion.div
                                    key={i}
                                    initial={{ height: 0 }}
                                    animate={{ height: `${h}%` }}
                                    transition={{ duration: 1, delay: i * 0.05, ease: [0.22, 1, 0.36, 1] }}
                                    className="flex-1 bg-neutral-800/80 hover:bg-neutral-700/80 transition-colors rounded-sm"
                                />
                            ))}
                        </div>
                    </MemoriaCard>

                    {/* Secondary Stats */}
                    <div className="space-y-6">
                        <MemoriaCard className="flex-1 h-[140px]">
                            <h3 className="text-xs text-neutral-500 uppercase tracking-widest mb-2">Active Entities</h3>
                            <div className="flex items-baseline gap-2">
                                <span className="text-4xl font-light text-white">842</span>
                                <span className="text-sm text-neutral-500">nodes</span>
                            </div>
                        </MemoriaCard>
                        <MemoriaCard className="flex-1 h-[140px]">
                            <h3 className="text-xs text-neutral-500 uppercase tracking-widest mb-2">Processing Time</h3>
                            <div className="flex items-baseline gap-2">
                                <span className="text-4xl font-light text-white">124</span>
                                <span className="text-sm text-neutral-500">ms</span>
                            </div>
                        </MemoriaCard>
                    </div>
                </div>

                {/* Feature List / Details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div className="space-y-6">
                        <h3 className="text-xl font-light text-white mb-6">Recent Activity</h3>
                        {[1, 2, 3, 4].map((item) => (
                            <motion.div
                                key={item}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ delay: item * 0.1 }}
                                className="group flex items-center justify-between p-4 border-b border-neutral-800/50 hover:bg-neutral-900/30 transition-colors rounded-lg cursor-pointer"
                            >
                                <div className="flex items-center gap-4">
                                    <div className="w-10 h-10 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center text-neutral-500 group-hover:text-white group-hover:border-neutral-700 transition-colors">
                                        <span className="text-xs font-mono">0{item}</span>
                                    </div>
                                    <div>
                                        <h4 className="text-sm text-neutral-300 group-hover:text-white transition-colors">System Optimization</h4>
                                        <p className="text-xs text-neutral-500">Automated maintenance cycle</p>
                                    </div>
                                </div>
                                <span className="text-xs text-neutral-600 font-mono">2m ago</span>
                            </motion.div>
                        ))}
                    </div>

                    <div className="space-y-6">
                        <h3 className="text-xl font-light text-white mb-6">Visual Principles</h3>
                        <div className="grid grid-cols-2 gap-4">
                            {['Restraint', 'Hierarchy', 'Opacity', 'Depth'].map((principle, idx) => (
                                <motion.div
                                    key={principle}
                                    initial={{ opacity: 0, scale: 0.9 }}
                                    whileInView={{ opacity: 1, scale: 1 }}
                                    viewport={{ once: true }}
                                    transition={{ delay: idx * 0.1 }}
                                    className="p-6 rounded-xl border border-neutral-800 bg-neutral-900/20 hover:bg-neutral-900/40 transition-colors"
                                >
                                    <div className="w-8 h-8 mb-4 rounded bg-neutral-800/50" />
                                    <h4 className="text-sm font-medium text-neutral-200">{principle}</h4>
                                </motion.div>
                            ))}
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
};
