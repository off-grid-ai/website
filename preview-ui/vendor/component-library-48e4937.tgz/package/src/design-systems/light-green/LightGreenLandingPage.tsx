import React, { useState, useEffect, useRef } from 'react';
import { designGuideContent } from './designGuideData';

// ============================================
// LIGHT GREEN LANDING PAGE
// With scroll-driven animations & interactivity
// ============================================

export default function LightGreenLandingPage() {
  const [scrollY, setScrollY] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current?.parentElement;
    if (!container) return;

    const handleScroll = () => setScrollY(container.scrollTop);
    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div
      ref={containerRef}
      style={{
        background: '#FFFFFF',
        fontFamily: "'DM Sans', sans-serif",
        position: 'relative',
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:wght@400;500;600;700&display=swap');

        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-12px) rotate(1deg); }
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.7; transform: scale(1.1); }
        }

        @keyframes shimmer {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }

        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(40px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }

        @keyframes drawLine {
          from { width: 0%; }
          to { width: 100%; }
        }

        @keyframes bounce {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.15); }
        }

        @keyframes glow {
          0%, 100% { box-shadow: 0 0 5px rgba(74, 222, 128, 0.3); }
          50% { box-shadow: 0 0 20px rgba(74, 222, 128, 0.6); }
        }

        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }

        @keyframes wiggle {
          0%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(-3deg); }
          75% { transform: rotate(3deg); }
        }

        .light-green-landing .fade-in-up {
          opacity: 0;
          transform: translateY(40px);
          transition: opacity 0.8s ease, transform 0.8s ease;
        }

        .light-green-landing .fade-in-up.visible {
          opacity: 1;
          transform: translateY(0);
        }

        .light-green-landing .scale-in {
          opacity: 0;
          transform: scale(0.9);
          transition: opacity 0.6s ease, transform 0.6s ease;
        }

        .light-green-landing .scale-in.visible {
          opacity: 1;
          transform: scale(1);
        }

        .light-green-landing .stagger-1 { transition-delay: 0.1s; }
        .light-green-landing .stagger-2 { transition-delay: 0.2s; }
        .light-green-landing .stagger-3 { transition-delay: 0.3s; }
        .light-green-landing .stagger-4 { transition-delay: 0.4s; }
        .light-green-landing .stagger-5 { transition-delay: 0.5s; }
        .light-green-landing .stagger-6 { transition-delay: 0.6s; }

        /* Nav link hover animation */
        .light-green-landing .nav-link {
          position: relative;
        }
        .light-green-landing .nav-link::after {
          content: '';
          position: absolute;
          bottom: -4px;
          left: 0;
          width: 0;
          height: 2px;
          background: linear-gradient(90deg, #4ADE80, #0D9488);
          transition: width 0.3s ease;
        }
        .light-green-landing .nav-link:hover::after {
          width: 100%;
        }

        /* Interactive button press states */
        .light-green-landing button:active {
          transform: scale(0.97) !important;
        }

        /* Clickable card press feedback */
        .light-green-landing .interactive-card:active {
          transform: scale(0.98) !important;
        }
      `}</style>

      <div className="light-green-landing">
        <Navigation />
        <HeroSection scrollY={scrollY} />
        <FeaturesSection />
        <HowItWorksSection />
        <ComparisonSection />
        <TestimonialsSection />
        <CTASection />
        <Footer />
      </div>
    </div>
  );
}


// ============================================
// SCROLL REVEAL HOOK
// ============================================

function useScrollReveal(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [threshold]);

  return { ref, isVisible };
}

// ============================================
// ANIMATED COUNTER
// ============================================

function AnimatedCounter({ value, suffix = '', duration = 2000 }: { value: number; suffix?: string; duration?: number }) {
  const [count, setCount] = useState(0);
  const { ref, isVisible } = useScrollReveal(0.5);
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (isVisible && !hasAnimated.current) {
      hasAnimated.current = true;
      const startTime = Date.now();
      const animate = () => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        // Ease out cubic
        const eased = 1 - Math.pow(1 - progress, 3);
        setCount(Math.floor(value * eased));
        if (progress < 1) {
          requestAnimationFrame(animate);
        }
      };
      requestAnimationFrame(animate);
    }
  }, [isVisible, value, duration]);

  return <span ref={ref}>{count}{suffix}</span>;
}

// ============================================
// NAVIGATION
// ============================================

function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const container = navRef.current?.closest('.light-green-landing')?.parentElement?.parentElement;
    if (!container) return;

    const handleScroll = () => setScrolled(container.scrollTop > 50);
    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, []);

  const handleDownload = () => {
    const blob = new Blob([designGuideContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'light-green-design-guide.md';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <nav
      ref={navRef}
      style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        padding: scrolled ? '16px 32px' : '20px 32px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        background: scrolled ? 'rgba(255, 255, 255, 0.95)' : '#FFFFFF',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        borderBottom: scrolled ? '1px solid rgba(0,0,0,0.05)' : '1px solid rgba(0,0,0,0.03)',
        transition: 'all 0.3s ease',
      }}
    >
      <LogoWithHover />

      <div style={{ display: 'flex', alignItems: 'center', gap: '32px' }}>
        {['Features', 'How it Works', 'Pricing'].map((item) => (
          <a
            key={item}
            href={`#${item.toLowerCase().replace(/ /g, '-')}`}
            className="nav-link"
            style={{
              fontSize: '15px',
              color: '#71717A',
              textDecoration: 'none',
              transition: 'color 0.2s ease',
              position: 'relative',
              paddingBottom: '4px',
            }}
            onMouseOver={(e) => e.currentTarget.style.color = '#18181B'}
            onMouseOut={(e) => e.currentTarget.style.color = '#71717A'}
          >
            {item}
          </a>
        ))}

        <button
          onClick={handleDownload}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '10px 20px',
            background: '#FFFFFF',
            border: '1px solid #E5E5E5',
            borderRadius: '100px',
            cursor: 'pointer',
            fontSize: '14px',
            fontWeight: '500',
            color: '#18181B',
            transition: 'all 0.2s',
          }}
          onMouseOver={(e) => {
            e.currentTarget.style.borderColor = '#4ADE80';
            e.currentTarget.style.boxShadow = '0 4px 12px rgba(74,222,128,0.15)';
          }}
          onMouseOut={(e) => {
            e.currentTarget.style.borderColor = '#E5E5E5';
            e.currentTarget.style.boxShadow = 'none';
          }}
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="7 10 12 15 17 10" />
            <line x1="12" y1="15" x2="12" y2="3" />
          </svg>
          Download Guide
        </button>

        <PrimaryButton small>Get Started</PrimaryButton>
      </div>
    </nav>
  );
}

// ============================================
// HERO SECTION - IMMERSIVE & INTERACTIVE
// ============================================

function HeroSection({ scrollY }: { scrollY: number }) {
  const parallaxY = scrollY * 0.3;
  const fadeOpacity = Math.max(0, 1 - scrollY / 600);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const heroRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect();
        setMousePosition({
          x: e.clientX - rect.left,
          y: e.clientY - rect.top,
        });
      }
    };

    const heroEl = heroRef.current;
    if (heroEl) {
      heroEl.addEventListener('mousemove', handleMouseMove);
      return () => heroEl.removeEventListener('mousemove', handleMouseMove);
    }
  }, []);

  return (
    <section
      ref={heroRef}
      style={{
        minHeight: '85vh',
        display: 'flex',
        alignItems: 'center',
        padding: '60px 32px 80px',
        position: 'relative',
        overflow: 'hidden',
        background: 'linear-gradient(180deg, #FFFFFF 0%, #F8FDF9 50%, #F0FDF4 100%)',
      }}
    >
      {/* Cursor-following spotlight */}
      <div
        style={{
          position: 'absolute',
          width: '600px',
          height: '600px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(74,222,128,0.15) 0%, transparent 70%)',
          left: mousePosition.x - 300,
          top: mousePosition.y - 300,
          pointerEvents: 'none',
          transition: 'left 0.3s ease-out, top 0.3s ease-out',
          filter: 'blur(40px)',
        }}
      />

      {/* Animated gradient orbs */}
      <div style={{
        position: 'absolute',
        top: '10%',
        left: '5%',
        width: '400px',
        height: '400px',
        background: 'radial-gradient(circle, rgba(74,222,128,0.08) 0%, transparent 70%)',
        borderRadius: '50%',
        filter: 'blur(60px)',
        animation: 'float 8s ease-in-out infinite',
      }} />
      <div style={{
        position: 'absolute',
        bottom: '10%',
        right: '10%',
        width: '350px',
        height: '350px',
        background: 'radial-gradient(circle, rgba(13,148,136,0.08) 0%, transparent 70%)',
        borderRadius: '50%',
        filter: 'blur(50px)',
        animation: 'float 10s ease-in-out infinite reverse',
      }} />

      {/* Animated particles */}
      <FloatingParticles />

      {/* Grid pattern overlay */}
      <div style={{
        position: 'absolute',
        inset: 0,
        backgroundImage: `
          linear-gradient(rgba(74,222,128,0.03) 1px, transparent 1px),
          linear-gradient(90deg, rgba(74,222,128,0.03) 1px, transparent 1px)
        `,
        backgroundSize: '60px 60px',
        maskImage: 'radial-gradient(ellipse at center, black 20%, transparent 70%)',
        WebkitMaskImage: 'radial-gradient(ellipse at center, black 20%, transparent 70%)',
      }} />

      <div style={{
        maxWidth: '1100px',
        margin: '0 auto',
        display: 'grid',
        gridTemplateColumns: '1.1fr 0.9fr',
        gap: '48px',
        alignItems: 'center',
        position: 'relative',
        zIndex: 1,
        opacity: fadeOpacity,
        transform: `translateY(${parallaxY * 0.15}px)`,
      }}>
        {/* Left content */}
        <div>
          <Badge animated>Design System</Badge>

          {/* Animated headline */}
          <div style={{ marginTop: '20px', marginBottom: '24px' }}>
            <TextRevealHeadline />
          </div>

          {/* Animated subtitle with FlipWords */}
          <div style={{ marginBottom: '32px' }}>
            <FlipWordsSubtitle />
          </div>

          <p style={{
            fontSize: '17px',
            lineHeight: 1.8,
            color: '#71717A',
            marginBottom: '36px',
            maxWidth: '460px',
          }}>
            Every component crafted with purpose, every pixel placed with care.
            A design system that whispers premium.
          </p>

          <div style={{ display: 'flex', gap: '16px', marginBottom: '48px' }}>
            <ShinyButton>Explore Components</ShinyButton>
            <SecondaryButton>View Documentation</SecondaryButton>
          </div>

          {/* Animated stats */}
          <div style={{ display: 'flex', gap: '40px' }}>
            <StatCard value={50} suffix="+" label="Components" delay={0} />
            <StatCard value={100} suffix="%" label="Accessible" delay={0.1} />
            <StatCard value={0} suffix="" label="Dependencies" delay={0.2} />
          </div>
        </div>

        {/* Right content - Interactive 3D card */}
        <div style={{ position: 'relative', transform: `translateY(${-parallaxY * 0.2}px)` }}>
          <Interactive3DCard mousePosition={mousePosition} />
        </div>
      </div>

      {/* Scroll indicator */}
      <ScrollIndicator fadeOpacity={fadeOpacity} />
    </section>
  );
}

// ============================================
// FLOATING PARTICLES
// ============================================

function FloatingParticles() {
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    x: Math.random() * 100,
    y: Math.random() * 100,
    size: 2 + Math.random() * 4,
    duration: 15 + Math.random() * 20,
    delay: Math.random() * 10,
  }));

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
      {particles.map((p) => (
        <div
          key={p.id}
          style={{
            position: 'absolute',
            left: `${p.x}%`,
            top: `${p.y}%`,
            width: `${p.size}px`,
            height: `${p.size}px`,
            borderRadius: '50%',
            background: `rgba(74, 222, 128, ${0.2 + Math.random() * 0.3})`,
            animation: `float ${p.duration}s ease-in-out infinite`,
            animationDelay: `${p.delay}s`,
            boxShadow: '0 0 10px rgba(74, 222, 128, 0.3)',
          }}
        />
      ))}
    </div>
  );
}

// ============================================
// TEXT REVEAL HEADLINE
// ============================================

function TextRevealHeadline() {
  const [isVisible, setIsVisible] = useState(false);
  const words = ['Beautiful', 'interfaces.'];

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <h1 style={{
      fontFamily: "'Instrument Serif', serif",
      fontSize: '56px',
      lineHeight: 1.05,
      color: '#18181B',
      fontWeight: '400',
      letterSpacing: '-0.02em',
    }}>
      {words.map((word, wordIndex) => (
        <span key={wordIndex} style={{ display: 'inline-block', marginRight: '0.2em' }}>
          {word.split('').map((char, charIndex) => (
            <span
              key={charIndex}
              style={{
                display: 'inline-block',
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0) rotateX(0)' : 'translateY(30px) rotateX(-90deg)',
                transition: `all 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)`,
                transitionDelay: `${(wordIndex * word.length + charIndex) * 0.03}s`,
              }}
            >
              {char}
            </span>
          ))}
        </span>
      ))}
    </h1>
  );
}

// ============================================
// FLIP WORDS SUBTITLE
// ============================================

function FlipWordsSubtitle() {
  const words = ['intentional', 'premium', 'elegant', 'crafted'];
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % words.length);
        setIsAnimating(false);
      }, 300);
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  return (
    <p style={{
      fontFamily: "'Instrument Serif', serif",
      fontSize: '42px',
      lineHeight: 1.1,
      fontStyle: 'italic',
      color: '#71717A',
      fontWeight: '400',
    }}>
      Built with{' '}
      <span
        style={{
          display: 'inline-block',
          position: 'relative',
          color: '#0D9488',
          minWidth: '200px',
        }}
      >
        <span
          style={{
            display: 'inline-block',
            opacity: isAnimating ? 0 : 1,
            transform: isAnimating ? 'translateY(-20px)' : 'translateY(0)',
            filter: isAnimating ? 'blur(8px)' : 'blur(0)',
            transition: 'all 0.3s ease',
          }}
        >
          {words[currentIndex]}
        </span>
        <span
          style={{
            position: 'absolute',
            bottom: '-4px',
            left: 0,
            right: 0,
            height: '3px',
            background: 'linear-gradient(90deg, #4ADE80, #0D9488)',
            borderRadius: '2px',
            transform: isAnimating ? 'scaleX(0)' : 'scaleX(1)',
            transformOrigin: 'left',
            transition: 'transform 0.3s ease',
          }}
        />
      </span>
      .
    </p>
  );
}

// ============================================
// SHINY BUTTON
// ============================================

function ShinyButton({ children }: { children: React.ReactNode }) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);
  const [ripplePosition, setRipplePosition] = useState({ x: 0, y: 0 });
  const buttonRef = useRef<HTMLButtonElement>(null);

  const handleMouseEnter = (e: React.MouseEvent) => {
    setHovered(true);
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      setRipplePosition({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    }
  };

  return (
    <button
      ref={buttonRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      style={{
        position: 'relative',
        padding: '16px 32px',
        background: 'linear-gradient(180deg, #4ADE80 0%, #22C55E 100%)',
        borderRadius: '14px',
        border: 'none',
        cursor: 'pointer',
        fontSize: '16px',
        fontWeight: '600',
        color: '#FFFFFF',
        boxShadow: pressed
          ? '0 2px 8px rgba(74,222,128,0.3), inset 0 2px 4px rgba(0,0,0,0.1)'
          : hovered
            ? '0 10px 40px rgba(74,222,128,0.4), 0 4px 12px rgba(74,222,128,0.3)'
            : '0 4px 20px rgba(74,222,128,0.3), 0 2px 8px rgba(74,222,128,0.2)',
        transform: pressed ? 'translateY(2px) scale(0.98)' : hovered ? 'translateY(-3px)' : 'translateY(0)',
        transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
        overflow: 'hidden',
      }}
    >
      {/* Shimmer effect */}
      <span
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)',
          transform: hovered ? 'translateX(100%)' : 'translateX(-100%)',
          transition: 'transform 0.6s ease',
        }}
      />
      {/* Ripple on hover */}
      {hovered && (
        <span
          style={{
            position: 'absolute',
            left: ripplePosition.x,
            top: ripplePosition.y,
            width: '200px',
            height: '200px',
            marginLeft: '-100px',
            marginTop: '-100px',
            background: 'radial-gradient(circle, rgba(255,255,255,0.3) 0%, transparent 70%)',
            animation: 'pulse 1s ease-out infinite',
          }}
        />
      )}
      <span style={{ position: 'relative', zIndex: 1 }}>{children}</span>
    </button>
  );
}

// ============================================
// STAT CARD
// ============================================

function StatCard({ value, suffix, label, delay }: { value: number; suffix: string; label: string; delay: number }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        cursor: 'default',
        transform: hovered ? 'translateY(-4px)' : 'translateY(0)',
        transition: 'transform 0.3s ease',
      }}
    >
      <div style={{
        fontSize: '36px',
        fontWeight: '700',
        color: hovered ? '#0D9488' : '#18181B',
        lineHeight: 1,
        transition: 'color 0.3s ease',
        fontFeatureSettings: '"tnum"',
      }}>
        <AnimatedCounter value={value} suffix={suffix} />
      </div>
      <div style={{
        fontSize: '14px',
        color: '#71717A',
        marginTop: '6px',
        opacity: hovered ? 1 : 0.8,
        transition: 'opacity 0.3s ease',
      }}>{label}</div>
    </div>
  );
}

// ============================================
// INTERACTIVE 3D CARD
// ============================================

function Interactive3DCard({ mousePosition }: { mousePosition: { x: number; y: number } }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [cardRotate, setCardRotate] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    if (cardRef.current && isHovered) {
      const rect = cardRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      const rotateY = ((mousePosition.x - rect.left) / rect.width - 0.5) * 20;
      const rotateX = -((mousePosition.y - rect.top) / rect.height - 0.5) * 20;
      setCardRotate({ x: rotateX, y: rotateY });
    } else {
      setCardRotate({ x: 0, y: 0 });
    }
  }, [mousePosition, isHovered]);

  return (
    <div
      ref={cardRef}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        perspective: '1000px',
        height: '420px',
      }}
    >
      <div
        style={{
          position: 'relative',
          width: '100%',
          height: '100%',
          transformStyle: 'preserve-3d',
          transform: `rotateX(${cardRotate.x}deg) rotateY(${cardRotate.y}deg)`,
          transition: isHovered ? 'transform 0.1s ease-out' : 'transform 0.5s ease-out',
        }}
      >
        {/* Main floating card */}
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%) translateZ(60px)',
          width: '300px',
          background: '#FFFFFF',
          borderRadius: '24px',
          padding: '28px',
          boxShadow: isHovered
            ? '0 30px 60px rgba(0,0,0,0.15), 0 0 40px rgba(74,222,128,0.2)'
            : '0 20px 40px rgba(0,0,0,0.1)',
          border: '1px solid rgba(74,222,128,0.2)',
          transition: 'box-shadow 0.3s ease',
        }}>
          {/* Glowing border effect */}
          <div style={{
            position: 'absolute',
            inset: '-1px',
            borderRadius: '24px',
            background: 'linear-gradient(135deg, rgba(74,222,128,0.4) 0%, transparent 50%, rgba(13,148,136,0.4) 100%)',
            opacity: isHovered ? 1 : 0,
            transition: 'opacity 0.3s ease',
            zIndex: -1,
          }} />

          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '24px' }}>
            <MetricDisplay label="PERFORMANCE" value="98%" color="#4ADE80" />
            <MetricDisplay label="COMPONENTS" value="50+" color="#18181B" />
            <MetricDisplay label="TOKENS" value="200+" color="#18181B" />
          </div>

          <div style={{
            height: '8px',
            background: '#F5F5F5',
            borderRadius: '4px',
            overflow: 'hidden',
            marginBottom: '20px',
          }}>
            <div style={{
              width: isHovered ? '98%' : '0%',
              height: '100%',
              background: 'linear-gradient(90deg, #4ADE80, #0D9488)',
              borderRadius: '4px',
              transition: 'width 1s ease-out',
            }} />
          </div>

          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '12px 16px',
            background: 'linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%)',
            borderRadius: '12px',
            border: '1px solid rgba(74,222,128,0.2)',
          }}>
            <span style={{ fontSize: '20px' }}>✨</span>
            <span style={{ fontSize: '14px', color: '#0D9488', fontWeight: '500' }}>
              Premium design tokens included
            </span>
          </div>
        </div>

        {/* Background accent card */}
        <div style={{
          position: 'absolute',
          top: '50%',
          left: '50%',
          transform: 'translate(-40%, -60%) translateZ(20px) rotate(-6deg)',
          width: '280px',
          height: '160px',
          background: 'linear-gradient(135deg, #18181B 0%, #27272A 100%)',
          borderRadius: '20px',
          padding: '20px',
          boxShadow: '0 10px 30px rgba(0,0,0,0.2)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
            <div style={{
              width: '8px',
              height: '8px',
              borderRadius: '50%',
              background: '#4ADE80',
              boxShadow: '0 0 10px rgba(74,222,128,0.5)',
            }} />
            <span style={{ fontSize: '12px', color: '#4ADE80', fontWeight: '600', letterSpacing: '0.05em' }}>
              LIVE INSIGHT
            </span>
          </div>
          <p style={{ fontSize: '15px', color: '#FFFFFF', fontWeight: '500', lineHeight: 1.5 }}>
            Design systems save teams an average of <span style={{ color: '#4ADE80' }}>34%</span> development time.
          </p>
        </div>
      </div>
    </div>
  );
}

function MetricDisplay({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <p style={{ fontSize: '10px', color: '#71717A', letterSpacing: '0.1em', marginBottom: '4px' }}>{label}</p>
      <p style={{ fontSize: '28px', fontWeight: '700', color, lineHeight: 1 }}>{value}</p>
    </div>
  );
}

// ============================================
// SCROLL INDICATOR
// ============================================

function ScrollIndicator({ fadeOpacity }: { fadeOpacity: number }) {
  return (
    <div style={{
      position: 'absolute',
      bottom: '32px',
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '8px',
      opacity: fadeOpacity * 0.6,
      transition: 'opacity 0.3s ease',
    }}>
      <span style={{ fontSize: '11px', color: '#A3A3A3', letterSpacing: '0.15em', fontWeight: '500' }}>
        SCROLL TO EXPLORE
      </span>
      <div style={{
        width: '28px',
        height: '44px',
        border: '2px solid rgba(74,222,128,0.3)',
        borderRadius: '14px',
        display: 'flex',
        justifyContent: 'center',
        paddingTop: '10px',
      }}>
        <div style={{
          width: '4px',
          height: '10px',
          background: 'linear-gradient(180deg, #4ADE80, #0D9488)',
          borderRadius: '2px',
          animation: 'float 1.5s ease-in-out infinite',
        }} />
      </div>
    </div>
  );
}

// ============================================
// FEATURES SECTION - ENHANCED WITH SPOTLIGHT
// ============================================

function FeaturesSection() {
  const { ref, isVisible } = useScrollReveal(0.1);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect();
        setMousePosition({
          x: e.clientX - rect.left,
          y: e.clientY - rect.top,
        });
      }
    };

    const section = sectionRef.current;
    if (section) {
      section.addEventListener('mousemove', handleMouseMove);
      return () => section.removeEventListener('mousemove', handleMouseMove);
    }
  }, []);

  const features = [
    { icon: '✨', title: 'Thoughtful Design', description: 'Every component follows strict design principles. No flat shadows, no harsh transitions, just beautiful interfaces.' },
    { icon: '🎨', title: 'Cohesive Colors', description: 'A sophisticated green-to-teal gradient system. Brand colors that whisper, never shout.' },
    { icon: '📐', title: 'Perfect Spacing', description: 'Built on a 4px grid system. Generous whitespace creates calm, premium experiences.' },
    { icon: '✍️', title: 'Typography First', description: 'Instrument Serif for headlines, DM Sans for body. Typography that creates hierarchy through elegance.' },
    { icon: '🌊', title: 'Smooth Animations', description: 'Purpose-driven motion. Elements float, pulse, and shimmer with intention.' },
    { icon: '📱', title: 'Fully Responsive', description: 'From mobile to desktop, every breakpoint considered. Beautiful at any size.' },
  ];

  return (
    <section
      id="features"
      ref={(node) => {
        (ref as any).current = node;
        (sectionRef as any).current = node;
      }}
      style={{
        padding: '100px 32px',
        background: 'linear-gradient(180deg, #FAFAFA 0%, #F0FDF4 50%, #FAFAFA 100%)',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Animated grid background */}
      <div style={{
        position: 'absolute',
        inset: 0,
        backgroundImage: `
          linear-gradient(rgba(74,222,128,0.03) 1px, transparent 1px),
          linear-gradient(90deg, rgba(74,222,128,0.03) 1px, transparent 1px)
        `,
        backgroundSize: '40px 40px',
        animation: 'pulse 10s ease-in-out infinite',
      }} />

      {/* Cursor glow */}
      <div
        style={{
          position: 'absolute',
          width: '400px',
          height: '400px',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(74,222,128,0.08) 0%, transparent 70%)',
          left: mousePosition.x - 200,
          top: mousePosition.y - 200,
          pointerEvents: 'none',
          transition: 'left 0.2s ease-out, top 0.2s ease-out',
        }}
      />

      <div style={{ maxWidth: '1100px', margin: '0 auto', position: 'relative', zIndex: 1 }}>
        <div
          className={`fade-in-up ${isVisible ? 'visible' : ''}`}
          style={{ textAlign: 'center', marginBottom: '72px' }}
        >
          <Badge>Features</Badge>
          <h2 style={{
            fontFamily: "'Instrument Serif', serif",
            fontSize: '48px',
            color: '#18181B',
            marginTop: '20px',
            fontWeight: '400',
            letterSpacing: '-0.02em',
          }}>
            Everything you need.
            <br />
            <span style={{ fontStyle: 'italic', color: '#71717A' }}>Nothing you don't.</span>
          </h2>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: '24px',
        }}>
          {features.map((feature, i) => (
            <div
              key={i}
              className={`scale-in stagger-${i + 1} ${isVisible ? 'visible' : ''}`}
            >
              <SpotlightFeatureCard {...feature} index={i} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function SpotlightFeatureCard({ icon, title, description, index }: { icon: string; title: string; description: string; index: number }) {
  const [hovered, setHovered] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const cardRef = useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (cardRef.current) {
      const rect = cardRef.current.getBoundingClientRect();
      setMousePos({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    }
  };

  return (
    <div
      ref={cardRef}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onMouseMove={handleMouseMove}
      style={{
        position: 'relative',
        background: '#FFFFFF',
        borderRadius: '24px',
        padding: '36px',
        border: '1px solid rgba(0,0,0,0.05)',
        boxShadow: hovered
          ? '0 20px 50px rgba(0,0,0,0.1)'
          : '0 4px 12px rgba(0,0,0,0.03)',
        transform: hovered ? 'translateY(-8px) scale(1.02)' : 'translateY(0) scale(1)',
        transition: 'all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)',
        cursor: 'default',
        overflow: 'hidden',
      }}
    >
      {/* Spotlight effect */}
      {hovered && (
        <div
          style={{
            position: 'absolute',
            width: '200px',
            height: '200px',
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(74,222,128,0.15) 0%, transparent 70%)',
            left: mousePos.x - 100,
            top: mousePos.y - 100,
            pointerEvents: 'none',
            transition: 'left 0.1s, top 0.1s',
          }}
        />
      )}

      {/* Animated border */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          borderRadius: '24px',
          padding: '1px',
          background: hovered
            ? 'linear-gradient(135deg, rgba(74,222,128,0.5), rgba(13,148,136,0.5))'
            : 'transparent',
          WebkitMask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
          WebkitMaskComposite: 'xor',
          maskComposite: 'exclude',
          opacity: hovered ? 1 : 0,
          transition: 'opacity 0.3s ease',
        }}
      />

      <div style={{
        position: 'relative',
        zIndex: 1,
      }}>
        <div style={{
          width: '56px',
          height: '56px',
          background: hovered
            ? 'linear-gradient(135deg, #4ADE80 0%, #0D9488 100%)'
            : 'linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%)',
          borderRadius: '16px',
          marginBottom: '24px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          fontSize: '28px',
          transform: hovered ? 'scale(1.1) rotate(5deg)' : 'scale(1) rotate(0deg)',
          transition: 'all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)',
          boxShadow: hovered ? '0 8px 24px rgba(74,222,128,0.3)' : 'none',
        }}>
          {hovered ? <span style={{ filter: 'grayscale(1) brightness(10)' }}>{icon}</span> : icon}
        </div>
        <h3 style={{
          fontFamily: "'Instrument Serif', serif",
          fontSize: '24px',
          color: hovered ? '#0D9488' : '#18181B',
          marginBottom: '12px',
          transition: 'color 0.3s ease',
        }}>
          {title}
        </h3>
        <p style={{
          fontSize: '15px',
          color: '#71717A',
          lineHeight: 1.7,
        }}>
          {description}
        </p>
      </div>
    </div>
  );
}

// ============================================
// HOW IT WORKS - ENHANCED WITH ANIMATED BEAM
// ============================================

function HowItWorksSection() {
  const { ref, isVisible } = useScrollReveal(0.2);
  const [activeStep, setActiveStep] = useState<number | null>(null);

  const steps = [
    { number: '01', title: 'Copy the code', description: 'Each component is self-contained. Just copy and paste into your project.', icon: '📋' },
    { number: '02', title: 'Customize colors', description: 'Update the CSS variables to match your brand. Everything adapts automatically.', icon: '🎨' },
    { number: '03', title: 'Ship beautiful UI', description: 'Your users get a premium experience. You save weeks of design work.', icon: '🚀' },
  ];

  return (
    <section id="how-it-works" ref={ref} style={{
      padding: '100px 32px',
      background: '#FFFFFF',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Subtle background pattern */}
      <div style={{
        position: 'absolute',
        inset: 0,
        backgroundImage: 'radial-gradient(rgba(74,222,128,0.03) 1px, transparent 1px)',
        backgroundSize: '24px 24px',
      }} />

      <div style={{ maxWidth: '1100px', margin: '0 auto', position: 'relative', zIndex: 1 }}>
        <div className={`fade-in-up ${isVisible ? 'visible' : ''}`} style={{ textAlign: 'center', marginBottom: '72px' }}>
          <Badge>How it Works</Badge>
          <h2 style={{
            fontFamily: "'Instrument Serif', serif",
            fontSize: '48px',
            color: '#18181B',
            marginTop: '20px',
            fontWeight: '400',
          }}>
            Three steps to<span style={{ fontStyle: 'italic', color: '#71717A' }}> beautiful.</span>
          </h2>
        </div>

        <div style={{ position: 'relative' }}>
          {/* Animated connecting beam */}
          <svg
            style={{
              position: 'absolute',
              top: '44px',
              left: '16.67%',
              width: '66.66%',
              height: '4px',
              zIndex: 0,
            }}
          >
            <defs>
              <linearGradient id="beamGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#4ADE80" />
                <stop offset="100%" stopColor="#0D9488" />
              </linearGradient>
            </defs>
            {/* Background line */}
            <line x1="0" y1="2" x2="100%" y2="2" stroke="#E5E5E5" strokeWidth="2" />
            {/* Animated gradient line */}
            <line
              x1="0"
              y1="2"
              x2="100%"
              y2="2"
              stroke="url(#beamGradient)"
              strokeWidth="3"
              strokeDasharray="100%"
              strokeDashoffset={isVisible ? '0%' : '100%'}
              style={{
                transition: 'stroke-dashoffset 1.5s ease-out',
                transitionDelay: '0.3s',
              }}
            />
            {/* Animated glow particle */}
            {isVisible && (
              <circle
                r="6"
                fill="#4ADE80"
                style={{
                  filter: 'blur(2px)',
                  animation: 'beamParticle 2s ease-in-out infinite',
                }}
              >
                <animateMotion dur="3s" repeatCount="indefinite">
                  <mpath href="#beamPath" />
                </animateMotion>
              </circle>
            )}
          </svg>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(3, 1fr)',
            gap: '48px',
            position: 'relative',
            zIndex: 1,
          }}>
            {steps.map((step, i) => (
              <EnhancedStepCard
                key={i}
                {...step}
                index={i}
                isVisible={isVisible}
                isActive={activeStep === i}
                onHover={() => setActiveStep(i)}
                onLeave={() => setActiveStep(null)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function EnhancedStepCard({
  number,
  title,
  description,
  icon,
  index,
  isVisible,
  isActive,
  onHover,
  onLeave,
}: {
  number: string;
  title: string;
  description: string;
  icon: string;
  index: number;
  isVisible: boolean;
  isActive: boolean;
  onHover: () => void;
  onLeave: () => void;
}) {
  return (
    <div
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
      className={`fade-in-up stagger-${index + 1} ${isVisible ? 'visible' : ''}`}
      style={{
        textAlign: 'center',
        cursor: 'default',
        transform: isActive ? 'translateY(-8px)' : 'translateY(0)',
        transition: 'transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
      }}
    >
      {/* Step circle */}
      <div style={{
        position: 'relative',
        width: '88px',
        height: '88px',
        margin: '0 auto 28px',
      }}>
        {/* Outer ring animation */}
        <div style={{
          position: 'absolute',
          inset: '-4px',
          borderRadius: '50%',
          border: '2px solid transparent',
          background: isActive
            ? 'linear-gradient(135deg, rgba(74,222,128,0.3), rgba(13,148,136,0.3))'
            : 'transparent',
          animation: isActive ? 'pulse 2s ease-in-out infinite' : 'none',
        }} />

        {/* Main circle */}
        <div style={{
          width: '100%',
          height: '100%',
          background: 'linear-gradient(135deg, #4ADE80 0%, #0D9488 100%)',
          borderRadius: '50%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: isActive
            ? '0 16px 40px rgba(74, 222, 128, 0.4), 0 0 0 4px rgba(74,222,128,0.1)'
            : '0 8px 24px rgba(74, 222, 128, 0.3)',
          transform: isActive ? 'scale(1.1)' : 'scale(1)',
          transition: 'all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1)',
        }}>
          <span style={{
            fontSize: '24px',
            marginBottom: '2px',
            transform: isActive ? 'scale(1.2)' : 'scale(1)',
            transition: 'transform 0.3s ease',
          }}>{icon}</span>
          <span style={{
            fontSize: '14px',
            fontWeight: '700',
            color: '#FFFFFF',
            opacity: 0.9,
          }}>{number}</span>
        </div>
      </div>

      <h3 style={{
        fontFamily: "'Instrument Serif', serif",
        fontSize: '26px',
        color: isActive ? '#0D9488' : '#18181B',
        marginBottom: '14px',
        transition: 'color 0.3s ease',
      }}>
        {title}
      </h3>
      <p style={{
        fontSize: '15px',
        color: '#71717A',
        lineHeight: 1.7,
        maxWidth: '280px',
        margin: '0 auto',
        opacity: isActive ? 1 : 0.8,
        transition: 'opacity 0.3s ease',
      }}>
        {description}
      </p>
    </div>
  );
}

// ============================================
// COMPARISON SECTION - ENHANCED
// ============================================

function ComparisonSection() {
  const { ref, isVisible } = useScrollReveal(0.2);

  const comparisons = [
    { before: 'Generic templates', after: 'Intentional design', icon: '🎯' },
    { before: 'Flat, lifeless shadows', after: 'Dimensional depth', icon: '✨' },
    { before: 'Random spacing', after: '4px grid precision', icon: '📐' },
    { before: 'Harsh transitions', after: 'Smooth animations', icon: '🌊' },
  ];

  return (
    <section ref={ref} style={{
      padding: '100px 32px',
      background: 'linear-gradient(180deg, #F0FDF4 0%, #FFFFFF 100%)',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Decorative circles */}
      <div style={{
        position: 'absolute',
        top: '20%',
        left: '-5%',
        width: '200px',
        height: '200px',
        borderRadius: '50%',
        border: '1px solid rgba(74,222,128,0.1)',
        animation: 'pulse 8s ease-in-out infinite',
      }} />
      <div style={{
        position: 'absolute',
        bottom: '10%',
        right: '-5%',
        width: '300px',
        height: '300px',
        borderRadius: '50%',
        border: '1px solid rgba(13,148,136,0.1)',
        animation: 'pulse 10s ease-in-out infinite reverse',
      }} />

      <div style={{ maxWidth: '900px', margin: '0 auto', position: 'relative', zIndex: 1 }}>
        <div className={`fade-in-up ${isVisible ? 'visible' : ''}`} style={{ textAlign: 'center', marginBottom: '72px' }}>
          <Badge>The Difference</Badge>
          <h2 style={{
            fontFamily: "'Instrument Serif', serif",
            fontSize: '48px',
            color: '#18181B',
            marginTop: '20px',
            fontWeight: '400',
          }}>
            Not just another
            <br />
            <span style={{ fontStyle: 'italic', color: '#71717A' }}>component library.</span>
          </h2>
        </div>

        <div style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '20px',
        }}>
          {comparisons.map((item, i) => (
            <EnhancedComparisonRow
              key={i}
              {...item}
              isVisible={isVisible}
              index={i}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function EnhancedComparisonRow({
  before,
  after,
  icon,
  isVisible,
  index,
}: {
  before: string;
  after: string;
  icon: string;
  isVisible: boolean;
  index: number;
}) {
  const [hovered, setHovered] = useState(false);
  const delay = index * 0.15;

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: 'grid',
        gridTemplateColumns: '1fr auto 1fr',
        gap: '32px',
        alignItems: 'center',
        padding: '24px 32px',
        borderRadius: '16px',
        background: hovered ? 'rgba(255,255,255,0.8)' : 'transparent',
        boxShadow: hovered ? '0 8px 32px rgba(0,0,0,0.06)' : 'none',
        opacity: isVisible ? 1 : 0,
        transform: isVisible
          ? hovered ? 'translateX(8px)' : 'translateX(0)'
          : 'translateX(-30px)',
        transition: `all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) ${delay}s`,
        cursor: 'default',
      }}
    >
      <div style={{
        textAlign: 'right',
        fontSize: '18px',
        color: '#A3A3A3',
        position: 'relative',
      }}>
        <span style={{
          display: 'inline-block',
          textDecoration: isVisible ? 'line-through' : 'none',
          textDecorationColor: '#EF4444',
          textDecorationThickness: '2px',
          transition: 'all 0.4s ease',
          transitionDelay: `${delay + 0.3}s`,
        }}>
          {before}
        </span>
      </div>

      <div style={{
        width: '52px',
        height: '52px',
        borderRadius: '50%',
        background: 'linear-gradient(135deg, #4ADE80 0%, #0D9488 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: hovered
          ? '0 8px 24px rgba(74, 222, 128, 0.4), 0 0 0 4px rgba(74,222,128,0.1)'
          : '0 4px 16px rgba(74, 222, 128, 0.3)',
        transform: isVisible
          ? hovered ? 'scale(1.15) rotate(10deg)' : 'scale(1)'
          : 'scale(0)',
        transition: `all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1) ${delay + 0.2}s`,
      }}>
        <span style={{ fontSize: '22px' }}>{icon}</span>
      </div>

      <div style={{
        fontSize: '20px',
        fontWeight: '600',
        color: hovered ? '#0D9488' : '#18181B',
        transition: 'color 0.3s ease',
      }}>
        {after}
      </div>
    </div>
  );
}

// ============================================
// TESTIMONIALS WITH AUTO-SCROLL
// ============================================

function TestimonialsSection() {
  const { ref, isVisible } = useScrollReveal(0.1);
  const [activeIndex, setActiveIndex] = useState(0);

  const testimonials = [
    { quote: "This design system saved us months of work. The attention to detail is incredible.", author: "Sarah Chen", role: "Design Lead at Vercel" },
    { quote: "Finally, a component library that understands premium design. Every pixel is perfect.", author: "Marcus Johnson", role: "Founder at Linear" },
    { quote: "The typography choices alone are worth it. Instrument Serif is chef's kiss.", author: "Emily Rodriguez", role: "Creative Director" },
  ];

  useEffect(() => {
    if (!isVisible) return;
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % testimonials.length);
    }, 4000);
    return () => clearInterval(interval);
  }, [isVisible, testimonials.length]);

  return (
    <section ref={ref} style={{
      padding: '80px 32px',
      background: '#FFFFFF',
    }}>
      <div style={{ maxWidth: '1100px', margin: '0 auto' }}>
        <div className={`fade-in-up ${isVisible ? 'visible' : ''}`} style={{ textAlign: 'center', marginBottom: '64px' }}>
          <Badge>Testimonials</Badge>
          <h2 style={{
            fontFamily: "'Instrument Serif', serif",
            fontSize: '48px',
            color: '#18181B',
            marginTop: '16px',
            fontWeight: '400',
          }}>
            Loved by designers.
          </h2>
        </div>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(3, 1fr)',
          gap: '24px',
        }}>
          {testimonials.map((t, i) => (
            <div
              key={i}
              className={`scale-in stagger-${i + 1} ${isVisible ? 'visible' : ''}`}
              style={{
                transform: i === activeIndex ? 'scale(1.02)' : 'scale(1)',
                transition: 'transform 0.3s ease',
              }}
            >
              <TestimonialCard {...t} active={i === activeIndex} />
            </div>
          ))}
        </div>

        {/* Dots indicator */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginTop: '32px' }}>
          {testimonials.map((_, i) => (
            <button
              key={i}
              onClick={() => setActiveIndex(i)}
              style={{
                width: i === activeIndex ? '32px' : '8px',
                height: '8px',
                borderRadius: '4px',
                border: 'none',
                background: i === activeIndex ? 'linear-gradient(90deg, #4ADE80, #0D9488)' : '#E5E5E5',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
              }}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

// ============================================
// CTA SECTION - ENHANCED WITH PARTICLES
// ============================================

function CTASection() {
  const { ref, isVisible } = useScrollReveal(0.2);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (sectionRef.current) {
        const rect = sectionRef.current.getBoundingClientRect();
        setMousePos({
          x: (e.clientX - rect.left) / rect.width,
          y: (e.clientY - rect.top) / rect.height,
        });
      }
    };

    const section = sectionRef.current;
    if (section) {
      section.addEventListener('mousemove', handleMouseMove);
      return () => section.removeEventListener('mousemove', handleMouseMove);
    }
  }, []);

  return (
    <section
      id="pricing"
      ref={(node) => {
        (ref as any).current = node;
        (sectionRef as any).current = node;
      }}
      style={{
        padding: '120px 32px',
        background: 'linear-gradient(135deg, #0F0F0F 0%, #1A1A1A 50%, #0F0F0F 100%)',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      {/* Animated mesh gradient */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: `
            radial-gradient(ellipse at ${mousePos.x * 100}% ${mousePos.y * 100}%, rgba(74,222,128,0.15) 0%, transparent 50%),
            radial-gradient(ellipse at ${100 - mousePos.x * 100}% ${100 - mousePos.y * 100}%, rgba(13,148,136,0.1) 0%, transparent 50%)
          `,
          transition: 'background 0.3s ease',
        }}
      />

      {/* Floating particles */}
      {Array.from({ length: 30 }).map((_, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            width: `${2 + Math.random() * 4}px`,
            height: `${2 + Math.random() * 4}px`,
            borderRadius: '50%',
            background: i % 2 === 0 ? 'rgba(74,222,128,0.4)' : 'rgba(13,148,136,0.4)',
            animation: `float ${10 + Math.random() * 10}s ease-in-out infinite`,
            animationDelay: `${Math.random() * 5}s`,
            boxShadow: '0 0 10px currentColor',
          }}
        />
      ))}

      {/* Grid overlay */}
      <div style={{
        position: 'absolute',
        inset: 0,
        backgroundImage: `
          linear-gradient(rgba(74,222,128,0.02) 1px, transparent 1px),
          linear-gradient(90deg, rgba(74,222,128,0.02) 1px, transparent 1px)
        `,
        backgroundSize: '50px 50px',
        maskImage: 'radial-gradient(ellipse at center, black 30%, transparent 70%)',
        WebkitMaskImage: 'radial-gradient(ellipse at center, black 30%, transparent 70%)',
      }} />

      <div className={`fade-in-up ${isVisible ? 'visible' : ''}`} style={{
        maxWidth: '800px',
        margin: '0 auto',
        textAlign: 'center',
        position: 'relative',
        zIndex: 1,
      }}>
        {/* Glowing badge */}
        <div style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: '8px',
          padding: '10px 20px',
          background: 'rgba(74,222,128,0.1)',
          border: '1px solid rgba(74,222,128,0.3)',
          borderRadius: '100px',
          marginBottom: '32px',
        }}>
          <span style={{
            width: '8px',
            height: '8px',
            borderRadius: '50%',
            background: '#4ADE80',
            animation: 'pulse 2s ease-in-out infinite',
            boxShadow: '0 0 12px rgba(74,222,128,0.8)',
          }} />
          <span style={{ fontSize: '14px', color: '#4ADE80', fontWeight: '600' }}>
            Free Forever
          </span>
        </div>

        <h2 style={{
          fontFamily: "'Instrument Serif', serif",
          fontSize: '52px',
          color: '#FFFFFF',
          marginBottom: '24px',
          fontWeight: '400',
          lineHeight: 1.1,
        }}>
          Ready to build
          <br />
          <span style={{
            fontStyle: 'italic',
            background: 'linear-gradient(90deg, #4ADE80, #0D9488)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}>something beautiful?</span>
        </h2>

        <p style={{
          fontSize: '18px',
          color: '#A3A3A3',
          marginBottom: '48px',
          lineHeight: 1.8,
          maxWidth: '500px',
          margin: '0 auto 48px',
        }}>
          Download the complete design guide and start building premium interfaces today.
        </p>

        <div style={{ display: 'flex', justifyContent: 'center', gap: '16px' }}>
          <CTADownloadButton />
          <CTASecondaryButton>View Components</CTASecondaryButton>
        </div>

        {/* Trust badges */}
        <div style={{
          display: 'flex',
          justifyContent: 'center',
          gap: '32px',
          marginTop: '48px',
          opacity: 0.6,
        }}>
          {['No credit card', 'No signup', 'No strings'].map((text, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4ADE80" strokeWidth="2">
                <polyline points="20 6 9 17 4 12" />
              </svg>
              <span style={{ fontSize: '14px', color: '#71717A' }}>{text}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTADownloadButton() {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  return (
    <button
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      style={{
        position: 'relative',
        padding: '20px 40px',
        background: 'linear-gradient(180deg, #4ADE80 0%, #22C55E 100%)',
        borderRadius: '16px',
        border: 'none',
        cursor: 'pointer',
        fontSize: '18px',
        fontWeight: '600',
        color: '#FFFFFF',
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        boxShadow: pressed
          ? '0 4px 12px rgba(74,222,128,0.3)'
          : hovered
            ? '0 16px 48px rgba(74,222,128,0.5), 0 0 0 1px rgba(74,222,128,0.3)'
            : '0 8px 32px rgba(74,222,128,0.4)',
        transform: pressed
          ? 'translateY(2px) scale(0.98)'
          : hovered
            ? 'translateY(-4px) scale(1.02)'
            : 'translateY(0) scale(1)',
        transition: 'all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1)',
        overflow: 'hidden',
      }}
    >
      {/* Shimmer */}
      <span style={{
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)',
        transform: hovered ? 'translateX(100%)' : 'translateX(-100%)',
        transition: 'transform 0.6s ease',
      }} />
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{ position: 'relative', zIndex: 1 }}>
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
        <polyline points="7 10 12 15 17 10" />
        <line x1="12" y1="15" x2="12" y2="3" />
      </svg>
      <span style={{ position: 'relative', zIndex: 1 }}>Download Guide</span>
    </button>
  );
}

function CTASecondaryButton({ children }: { children: React.ReactNode }) {
  const [hovered, setHovered] = useState(false);

  return (
    <button
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        padding: '20px 40px',
        background: 'transparent',
        borderRadius: '16px',
        border: `1px solid ${hovered ? 'rgba(74,222,128,0.5)' : 'rgba(255,255,255,0.2)'}`,
        cursor: 'pointer',
        fontSize: '18px',
        fontWeight: '600',
        color: hovered ? '#4ADE80' : '#FFFFFF',
        transition: 'all 0.3s ease',
        boxShadow: hovered ? '0 0 20px rgba(74,222,128,0.2)' : 'none',
      }}
    >
      {children}
    </button>
  );
}

// ============================================
// FOOTER - ENHANCED
// ============================================

function Footer() {
  const [logoHovered, setLogoHovered] = useState(false);

  const links = [
    { label: 'Components', href: '#features' },
    { label: 'How it Works', href: '#how-it-works' },
    { label: 'Download', href: '#pricing' },
  ];

  return (
    <footer style={{
      padding: '48px 32px',
      background: 'linear-gradient(180deg, #18181B 0%, #0F0F0F 100%)',
      borderTop: '1px solid #27272A',
    }}>
      <div style={{
        maxWidth: '1100px',
        margin: '0 auto',
      }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginBottom: '32px',
          paddingBottom: '32px',
          borderBottom: '1px solid #27272A',
        }}>
          {/* Logo */}
          <div
            onMouseEnter={() => setLogoHovered(true)}
            onMouseLeave={() => setLogoHovered(false)}
            style={{ display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer' }}
          >
            <div style={{
              width: '36px',
              height: '36px',
              background: 'linear-gradient(135deg, #4ADE80 0%, #0D9488 100%)',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: logoHovered ? '0 0 20px rgba(74,222,128,0.4)' : 'none',
              transform: logoHovered ? 'scale(1.1) rotate(-5deg)' : 'scale(1) rotate(0deg)',
              transition: 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
            }}>
              <span style={{ color: '#FFFFFF', fontSize: '16px', fontWeight: '700' }}>L</span>
            </div>
            <span style={{
              fontSize: '18px',
              fontWeight: '600',
              color: logoHovered ? '#FFFFFF' : '#E5E5E5',
              transition: 'color 0.2s ease',
            }}>
              LightGreen
            </span>
          </div>

          {/* Links */}
          <div style={{ display: 'flex', gap: '32px' }}>
            {links.map((link) => (
              <FooterLink key={link.label} {...link} />
            ))}
          </div>
        </div>

        {/* Bottom row */}
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
          <p style={{ fontSize: '14px', color: '#71717A' }}>
            Built with care. Designed with intention.
          </p>

          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{
              width: '6px',
              height: '6px',
              borderRadius: '50%',
              background: '#4ADE80',
              boxShadow: '0 0 8px rgba(74,222,128,0.5)',
              animation: 'pulse 2s ease-in-out infinite',
            }} />
            <span style={{ fontSize: '13px', color: '#4ADE80' }}>
              v1.0 — All systems operational
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterLink({ label, href }: { label: string; href: string }) {
  const [hovered, setHovered] = useState(false);

  return (
    <a
      href={href}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        fontSize: '14px',
        color: hovered ? '#4ADE80' : '#71717A',
        textDecoration: 'none',
        transition: 'all 0.2s ease',
        position: 'relative',
      }}
    >
      {label}
      <span style={{
        position: 'absolute',
        bottom: '-4px',
        left: 0,
        width: hovered ? '100%' : '0%',
        height: '1px',
        background: 'linear-gradient(90deg, #4ADE80, #0D9488)',
        transition: 'width 0.3s ease',
      }} />
    </a>
  );
}

// ============================================
// SHARED COMPONENTS
// ============================================

function Badge({ children, animated }: { children: React.ReactNode; animated?: boolean }) {
  const [hovered, setHovered] = useState(false);

  return (
    <span
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: '8px',
        padding: '8px 16px',
        background: hovered
          ? 'linear-gradient(180deg, #F0FDF4 0%, #DCFCE7 100%)'
          : 'linear-gradient(180deg, #FFFFFF 0%, #F0FDF4 100%)',
        borderRadius: '100px',
        border: `1px solid ${hovered ? 'rgba(74, 222, 128, 0.5)' : 'rgba(74, 222, 128, 0.3)'}`,
        fontSize: '13px',
        fontWeight: '600',
        color: '#0D9488',
        boxShadow: hovered
          ? '0 4px 16px rgba(74, 222, 128, 0.2)'
          : '0 2px 8px rgba(74, 222, 128, 0.1)',
        position: 'relative',
        overflow: 'hidden',
        cursor: 'default',
        transform: hovered ? 'scale(1.02)' : 'scale(1)',
        transition: 'all 0.2s ease',
      }}
    >
      <span style={{
        width: '6px',
        height: '6px',
        background: '#4ADE80',
        borderRadius: '50%',
        animation: 'pulse 2s ease-in-out infinite',
        boxShadow: hovered ? '0 0 12px rgba(74, 222, 128, 0.8)' : '0 0 8px rgba(74, 222, 128, 0.5)',
        transition: 'box-shadow 0.2s ease',
      }} />
      {children}
      {(animated || hovered) && (
        <span style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)',
          animation: 'shimmer 2s ease-in-out infinite',
        }} />
      )}
    </span>
  );
}

function PrimaryButton({ children, small, large, onClick }: { children: React.ReactNode; small?: boolean; large?: boolean; onClick?: () => void }) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  return (
    <button
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      onClick={onClick}
      style={{
        position: 'relative',
        padding: small ? '10px 20px' : large ? '20px 40px' : '16px 32px',
        background: pressed
          ? 'linear-gradient(180deg, #2AB862 0%, #229952 100%)'
          : hovered
            ? 'linear-gradient(180deg, #3BD975 0%, #2AB862 100%)'
            : 'linear-gradient(180deg, #4ADE80 0%, #2AB862 100%)',
        borderRadius: '12px',
        border: 'none',
        cursor: 'pointer',
        fontSize: small ? '14px' : large ? '18px' : '16px',
        fontWeight: '600',
        color: '#FFFFFF',
        boxShadow: pressed
          ? '0 2px 8px rgba(74,222,128,0.3), inset 0 2px 4px rgba(0,0,0,0.1)'
          : hovered
            ? '0 8px 24px rgba(74,222,128,0.4), inset 0 1px 1px rgba(255,255,255,0.3)'
            : '0 4px 12px rgba(74,222,128,0.3), inset 0 1px 1px rgba(255,255,255,0.3)',
        transform: pressed ? 'translateY(1px) scale(0.98)' : hovered ? 'translateY(-2px)' : 'translateY(0)',
        transition: 'all 0.15s ease',
        overflow: 'hidden',
      }}
    >
      {hovered && !pressed && (
        <span style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)',
          animation: 'shimmer 1s ease-out',
        }} />
      )}
      <span style={{ position: 'relative', zIndex: 1, display: 'flex', alignItems: 'center', gap: '8px' }}>
        {children}
      </span>
    </button>
  );
}

function LogoWithHover() {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      style={{ display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer' }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div style={{
        width: '40px',
        height: '40px',
        background: 'linear-gradient(135deg, #4ADE80 0%, #0D9488 100%)',
        borderRadius: '12px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: hovered ? '0 6px 20px rgba(74, 222, 128, 0.4)' : '0 4px 12px rgba(74, 222, 128, 0.3)',
        transform: hovered ? 'scale(1.05) rotate(-3deg)' : 'scale(1) rotate(0deg)',
        transition: 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
      }}>
        <span style={{
          color: '#FFFFFF',
          fontSize: '18px',
          fontWeight: '700',
          transform: hovered ? 'scale(1.1)' : 'scale(1)',
          transition: 'transform 0.3s ease',
        }}>L</span>
      </div>
      <span style={{
        fontSize: '20px',
        fontWeight: '600',
        color: '#18181B',
        transition: 'all 0.2s ease',
      }}>
        Light<span style={{
          fontWeight: '400',
          color: hovered ? '#0D9488' : '#71717A',
          transition: 'color 0.2s ease',
        }}>Green</span>
      </span>
    </div>
  );
}

function SecondaryButton({ children }: { children: React.ReactNode }) {
  const [hovered, setHovered] = useState(false);
  const [pressed, setPressed] = useState(false);

  return (
    <button
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => { setHovered(false); setPressed(false); }}
      onMouseDown={() => setPressed(true)}
      onMouseUp={() => setPressed(false)}
      style={{
        padding: '16px 32px',
        background: pressed ? '#EEEEEE' : hovered ? '#F5F5F5' : '#FFFFFF',
        borderRadius: '12px',
        border: `1px solid ${hovered || pressed ? '#4ADE80' : '#E5E5E5'}`,
        cursor: 'pointer',
        fontSize: '16px',
        fontWeight: '600',
        color: '#18181B',
        transition: 'all 0.15s ease',
        boxShadow: pressed
          ? 'inset 0 2px 4px rgba(0,0,0,0.05)'
          : hovered
            ? '0 4px 12px rgba(74,222,128,0.1)'
            : 'none',
        transform: pressed ? 'scale(0.98)' : 'scale(1)',
      }}
    >
      {children}
    </button>
  );
}

function PreviewCards() {
  return (
    <div style={{ position: 'relative', height: '420px' }}>
      {/* Card 1 - Back */}
      <div style={{
        position: 'absolute',
        top: '50px',
        left: '40px',
        width: '280px',
        background: '#FFFFFF',
        borderRadius: '24px',
        padding: '24px',
        boxShadow: '0 4px 24px rgba(0,0,0,0.08)',
        border: '1px solid rgba(0,0,0,0.05)',
        transform: 'rotate(-3deg)',
      }}>
        <div style={{
          width: '48px',
          height: '48px',
          background: 'linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%)',
          borderRadius: '12px',
          marginBottom: '16px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#0D9488" strokeWidth="2">
            <path d="M12 2L14 10L22 12L14 14L12 22L10 14L2 12L10 10L12 2Z" />
          </svg>
        </div>
        <h3 style={{ fontFamily: "'Instrument Serif', serif", fontSize: '22px', color: '#18181B', marginBottom: '8px' }}>
          Premium Quality
        </h3>
        <p style={{ fontSize: '14px', color: '#71717A', lineHeight: 1.6 }}>
          Every component crafted with attention to detail.
        </p>
      </div>

      {/* Card 2 - Middle */}
      <div style={{
        position: 'absolute',
        top: '25px',
        left: '20px',
        width: '280px',
        background: 'linear-gradient(135deg, #18181B 0%, #27272A 100%)',
        borderRadius: '24px',
        padding: '24px',
        boxShadow: '0 8px 32px rgba(0,0,0,0.15)',
        transform: 'rotate(2deg)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '16px' }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="#4ADE80">
            <path d="M12 2L14 10L22 12L14 14L12 22L10 14L2 12L10 10L12 2Z" />
          </svg>
          <span style={{ fontSize: '12px', color: '#4ADE80', fontWeight: '600' }}>INSIGHT</span>
        </div>
        <p style={{ fontSize: '16px', color: '#FFFFFF', fontWeight: '500', lineHeight: 1.5 }}>
          Design systems save teams an average of 34% development time.
        </p>
      </div>

      {/* Card 3 - Front (Floating) */}
      <div style={{
        position: 'absolute',
        top: '0',
        left: '0',
        width: '280px',
        background: '#FFFFFF',
        borderRadius: '24px',
        padding: '24px',
        boxShadow: '0 12px 48px rgba(74,222,128,0.15), 0 4px 24px rgba(0,0,0,0.08)',
        border: '1px solid rgba(74, 222, 128, 0.2)',
        animation: 'float 6s ease-in-out infinite',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
          <div>
            <p style={{ fontSize: '11px', color: '#71717A', letterSpacing: '0.1em' }}>PERFORMANCE</p>
            <p style={{ fontSize: '32px', fontWeight: '700', color: '#4ADE80' }}>98%</p>
          </div>
          <div style={{ textAlign: 'center' }}>
            <p style={{ fontSize: '11px', color: '#71717A', letterSpacing: '0.1em' }}>COMPONENTS</p>
            <p style={{ fontSize: '32px', fontWeight: '700', color: '#18181B' }}>50+</p>
          </div>
          <div style={{ textAlign: 'right' }}>
            <p style={{ fontSize: '11px', color: '#71717A', letterSpacing: '0.1em' }}>TOKENS</p>
            <p style={{ fontSize: '32px', fontWeight: '700', color: '#18181B' }}>200+</p>
          </div>
        </div>
        <div style={{ height: '6px', background: '#F5F5F5', borderRadius: '3px', overflow: 'hidden' }}>
          <div style={{
            width: '98%',
            height: '100%',
            background: 'linear-gradient(90deg, #4ADE80, #0D9488)',
            borderRadius: '3px',
          }} />
        </div>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: string; title: string; description: string }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: '#FFFFFF',
        borderRadius: '20px',
        padding: '32px',
        border: `1px solid ${hovered ? 'rgba(74,222,128,0.3)' : 'rgba(0,0,0,0.05)'}`,
        boxShadow: hovered
          ? '0 12px 40px rgba(0,0,0,0.08), 0 0 0 1px rgba(74,222,128,0.1)'
          : '0 2px 8px rgba(0,0,0,0.04)',
        transform: hovered ? 'translateY(-8px)' : 'translateY(0)',
        transition: 'all 0.3s ease',
        cursor: 'default',
      }}
    >
      <div style={{
        width: '48px',
        height: '48px',
        background: 'linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%)',
        borderRadius: '12px',
        marginBottom: '20px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '24px',
        transform: hovered ? 'scale(1.1)' : 'scale(1)',
        transition: 'transform 0.3s ease',
      }}>
        {icon}
      </div>
      <h3 style={{
        fontFamily: "'Instrument Serif', serif",
        fontSize: '22px',
        color: '#18181B',
        marginBottom: '12px',
      }}>
        {title}
      </h3>
      <p style={{
        fontSize: '15px',
        color: '#71717A',
        lineHeight: 1.7,
      }}>
        {description}
      </p>
    </div>
  );
}

function StepCard({ number, title, description }: { number: string; title: string; description: string }) {
  const [hovered, setHovered] = useState(false);

  return (
    <div
      style={{ textAlign: 'center', cursor: 'default' }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div style={{
        width: '56px',
        height: '56px',
        background: 'linear-gradient(135deg, #4ADE80 0%, #0D9488 100%)',
        borderRadius: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        margin: '0 auto 24px',
        boxShadow: hovered
          ? '0 12px 32px rgba(74, 222, 128, 0.5), 0 0 0 4px rgba(74, 222, 128, 0.1)'
          : '0 8px 24px rgba(74, 222, 128, 0.3)',
        position: 'relative',
        zIndex: 2,
        transform: hovered ? 'scale(1.1)' : 'scale(1)',
        transition: 'all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
      }}>
        <span style={{
          fontSize: '18px',
          fontWeight: '700',
          color: '#FFFFFF',
          transform: hovered ? 'scale(1.1)' : 'scale(1)',
          transition: 'transform 0.3s ease',
        }}>{number}</span>
      </div>
      <h3 style={{
        fontFamily: "'Instrument Serif', serif",
        fontSize: '24px',
        color: hovered ? '#0D9488' : '#18181B',
        marginBottom: '12px',
        transition: 'color 0.3s ease',
      }}>
        {title}
      </h3>
      <p style={{
        fontSize: '15px',
        color: '#71717A',
        lineHeight: 1.7,
        maxWidth: '280px',
        margin: '0 auto',
      }}>
        {description}
      </p>
    </div>
  );
}

function TestimonialCard({ quote, author, role, active }: { quote: string; author: string; role: string; active?: boolean }) {
  const [hovered, setHovered] = useState(false);
  const isHighlighted = active || hovered;

  return (
    <div
      className="interactive-card"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: '#FFFFFF',
        borderRadius: '20px',
        padding: '32px',
        border: `1px solid ${isHighlighted ? 'rgba(74,222,128,0.3)' : 'rgba(0,0,0,0.05)'}`,
        boxShadow: isHighlighted
          ? '0 12px 40px rgba(74,222,128,0.2)'
          : '0 2px 8px rgba(0,0,0,0.04)',
        transform: hovered ? 'translateY(-4px)' : 'translateY(0)',
        transition: 'all 0.3s ease',
        cursor: 'default',
      }}
    >
      <div style={{
        fontSize: '28px',
        color: isHighlighted ? '#4ADE80' : '#E5E5E5',
        marginBottom: '12px',
        transition: 'color 0.3s ease',
        lineHeight: 1,
      }}>
        "
      </div>
      <p style={{
        fontSize: '16px',
        color: '#18181B',
        lineHeight: 1.7,
        marginBottom: '24px',
      }}>
        {quote}
      </p>
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <div style={{
          width: '40px',
          height: '40px',
          borderRadius: '50%',
          background: 'linear-gradient(135deg, #4ADE80 0%, #0D9488 100%)',
          transform: hovered ? 'scale(1.1)' : 'scale(1)',
          transition: 'transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1)',
          boxShadow: hovered ? '0 4px 12px rgba(74, 222, 128, 0.3)' : 'none',
        }} />
        <div>
          <p style={{
            fontSize: '15px',
            fontWeight: '600',
            color: hovered ? '#0D9488' : '#18181B',
            transition: 'color 0.2s ease',
          }}>{author}</p>
          <p style={{ fontSize: '13px', color: '#71717A' }}>{role}</p>
        </div>
      </div>
    </div>
  );
}
