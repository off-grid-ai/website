import React from 'react';
import { cn } from '../../utils/cn';


export const DeviceMockup = ({ children, className }: { children: React.ReactNode; className?: string }) => {
    return (
        <div className={cn("relative mx-auto border-gray-800 dark:border-gray-800 bg-gray-900 border-[14px] rounded-[2.5rem] h-[600px] w-[300px]", className)}>
            <div className="h-[32px] w-[3px] bg-gray-800 absolute -start-[17px] top-[72px] rounded-s-lg"></div>
            <div className="h-[46px] w-[3px] bg-gray-800 absolute -start-[17px] top-[124px] rounded-s-lg"></div>
            <div className="h-[46px] w-[3px] bg-gray-800 absolute -start-[17px] top-[178px] rounded-s-lg"></div>
            <div className="h-[64px] w-[3px] bg-gray-800 absolute -end-[17px] top-[142px] rounded-e-lg"></div>

            <div className="rounded-[2rem] overflow-hidden w-[272px] h-[572px] bg-white dark:bg-gray-800">
                <div className="w-full h-full relative overflow-y-scroll scrollbar-hide">
                    {children}
                </div>
            </div>

            {/* Dynamic Island */}
            <div className="absolute top-2 left-1/2 -translate-x-1/2 h-7 w-24 bg-black rounded-full z-20"></div>

            {/* Rim Lighting (simulated via shadows/gradients on container) */}
            <div className="absolute inset-[-14px] rounded-[2.5rem] pointer-events-none ring-1 ring-white/10" />

            {/* Premium Glow effect */}
            <div className="absolute inset-0 rounded-[2.5rem] shadow-[0_0_60px_-15px_rgba(74,222,128,0.3)] pointer-events-none z-[-1]" />
        </div>
    );
};
