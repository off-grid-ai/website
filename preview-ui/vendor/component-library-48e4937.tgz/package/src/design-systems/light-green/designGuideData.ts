export const designGuideContent = `# Light Mode Green Design System

A design language for premium, light-themed scroll-driven landing pages.

---

## Philosophy

> "Scroll as narrative, depth through dimension, confidence through restraint."

This system creates interfaces that feel like high-end product landing pages—calm, confident, and visually rich. Think Apple, Linear, Stripe. The design should feel expensive without being flashy.

### Core Beliefs

1. **Scroll as Narrative** — The page unfolds like a story through scrolling
2. **Dimensional Depth** — Elements feel tangible through layered shadows and lighting
3. **Quiet Confidence** — Every element earns its place through purpose, not decoration
4. **Seamless Morphing** — Content transforms rather than cuts between sections
5. **Progressive Disclosure** — Reveal complexity gradually through scroll

### Strict Rules

- **No Emojis** — Use custom SVG icons instead
- **No Flat Shadows** — Always use color-tinted, multi-layer shadows
- **No Abrupt Transitions** — Everything animates smoothly
- **No Pure Black Shadows** — Tint with brand colors (green/teal)
- **No Skeleton Loaders** — Use staggered reveals instead

---

## Color Palette

### Brand Colors

\`\`\`css
/* Primary Green Scale */
--primary:          #4ADE80;  /* Main CTA, highlights */
--primary-dark:     #22C55E;  /* Hover states */
--primary-darker:   #16A34A;  /* Active/pressed states */

/* Accent Teal Scale */
--accent:           #0D9488;  /* Secondary accents, gradients */
--accent-dark:      #059669;  /* Deep variations */
--accent-light:     #14B8A6;  /* Light accents */
\`\`\`

### Neutral Scale

\`\`\`css
/* Backgrounds */
--background:       #FFFFFF;  /* Page background */
--surface:          #FAFAFA;  /* Cards, sections */
--surface-dark:     #F5F5F5;  /* Subtle differentiation */

/* Text Hierarchy */
--text-primary:     #18181B;  /* Headlines, primary text */
--text-secondary:   #71717A;  /* Body text, captions */
--text-muted:       #A3A3A3;  /* Helper text, disclaimers */
--text-faint:       #D4D4D8;  /* Placeholders */

/* Borders */
--border:           #E5E5E5;  /* Standard dividers */
--border-light:     #F4F4F5;  /* Subtle separators */
\`\`\`

### Shadow Colors

\`\`\`css
/* Green-tinted shadows for cards/buttons */
--shadow-green:     rgba(74, 222, 128, 0.4);
--shadow-teal:      rgba(13, 148, 136, 0.2);

/* Neutral shadows for depth */
--shadow-neutral:   rgba(0, 0, 0, 0.08);
\`\`\`

### Glow/Spotlight Colors

\`\`\`css
--glow-primary:     rgba(74, 222, 128, 0.25);
--glow-accent:      rgba(13, 148, 136, 0.15);
--glow-soft:        rgba(74, 222, 128, 0.12);
\`\`\`

---

## Typography

### Font Stack

\`\`\`css
/* Headlines - Elegant serif */
font-family: 'Instrument Serif', Georgia, serif;

/* Body & UI - Clean sans-serif */
font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
\`\`\`

### Type Scale

| Element | Font | Size | Weight | Line Height | Letter Spacing |
|---------|------|------|--------|-------------|----------------|
| Hero H1 | Instrument Serif | 60px | 400 | 1.08 | -0.02em |
| H2 Section | Instrument Serif | 44px | 400 | 1.1 | -0.02em |
| H3 Card Title | Instrument Serif | 22-28px | 400 | 1.3 | 0 |
| Body Large | DM Sans | 18px | 400 | 1.7 | 0 |
| Body | DM Sans | 15px | 400 | 1.6 | 0 |
| Body Small | DM Sans | 14px | 400 | 1.5 | 0 |
| Caption | DM Sans | 13px | 500 | 1.4 | 0.02em |
| Label | DM Sans | 11-12px | 600 | 1.3 | 0.1em |
| Overline | DM Sans | 12px | 600 | 1.3 | 0.15em |
| Micro | DM Sans | 10-11px | 500 | 1.4 | 0.05em |

### Typography Rules

1. **Headlines**: Always Instrument Serif, never bold—elegance comes from the typeface
2. **Italics for emotion**: Use italic serif for secondary headlines or emotional phrases
3. **Body text**: DM Sans at 400/500 weight with generous line height
4. **Uppercase sparingly**: Only for labels and overlines, always with letter-spacing
5. **Text gradients**: Apply to key phrases using background-clip: text

---

## Animation System

### Easing Functions

\`\`\`javascript
// JavaScript easing functions
const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
const easeOutQuart = (t) => 1 - Math.pow(1 - t, 4);
const easeInOutQuart = (t) => t < 0.5 ? 8 * t * t * t * t : 1 - Math.pow(-2 * t + 2, 4) / 2;
\`\`\`

\`\`\`css
/* CSS timing functions */
--ease-out-cubic: cubic-bezier(0.33, 1, 0.68, 1);
--ease-out-quart: cubic-bezier(0.25, 1, 0.5, 1);
--ease-in-out-quart: cubic-bezier(0.76, 0, 0.24, 1);
--ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
\`\`\`

### Scroll Progress Calculation

\`\`\`javascript
const handleScroll = () => {
  const scrollTop = window.scrollY;
  const scrollHeight = container.scrollHeight - window.innerHeight;
  const progress = Math.min(Math.max(scrollTop / scrollHeight, 0), 1);
  setScrollProgress(progress);
};
\`\`\`

### Animation Patterns

#### 1. Float Animation
\`\`\`css
@keyframes float {
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-8px); }
}
/* Duration: 6s, ease-in-out, infinite */
\`\`\`

#### 2. Breathe/Pulse Animation
\`\`\`css
@keyframes breathe {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.8; transform: scale(1.08); }
}
/* Duration: 4s, ease-in-out, infinite */
\`\`\`

#### 3. Shimmer Effect
\`\`\`css
@keyframes shimmer {
  0% { left: -100%; }
  50%, 100% { left: 200%; }
}
/* Duration: 3s, ease, infinite */
\`\`\`

#### 4. Text Reveal
\`\`\`css
@keyframes textReveal {
  0% { opacity: 0; transform: translateY(8px); filter: blur(4px); }
  100% { opacity: 1; transform: translateY(0); filter: blur(0); }
}
/* Duration: 0.4s, ease-out */
\`\`\`

#### 5. Draw Circle (SVG)
\`\`\`css
@keyframes drawCircle {
  0% { stroke-dashoffset: 1000; }
  100% { stroke-dashoffset: 0; }
}
/* Duration: 1.5s, ease-out */
\`\`\`

#### 6. Mega Pulse (Spotlight)
\`\`\`css
@keyframes megaPulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.7; transform: scale(1.03); }
}
/* Duration: 4s, ease-in-out, infinite */
\`\`\`

#### 7. Badge Shimmer
\`\`\`css
@keyframes shimmerBadge {
  0% { left: -100%; }
  50%, 100% { left: 200%; }
}
/* Duration: 4s, ease, infinite, delay: 2s */
\`\`\`

---

## UI Components

### 1. Premium 3D Button

\`\`\`tsx
const Premium3DButton = ({ children }) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isPressed, setIsPressed] = useState(false);

  return (
    <button
      style={{
        position: 'relative',
        padding: '18px 40px',
        background: isPressed
          ? 'linear-gradient(180deg, #1D8B54 0%, #2AA06A 50%, #34D480 100%)'
          : isHovered
          ? 'linear-gradient(180deg, #3BD975 0%, #2EBE68 50%, #25A85C 100%)'
          : 'linear-gradient(180deg, #4ADE80 0%, #3ACC72 50%, #2AB862 100%)',
        borderRadius: '14px',
        border: 'none',
        cursor: 'pointer',
        fontFamily: "'DM Sans', sans-serif",
        fontSize: '16px',
        fontWeight: '600',
        color: '#FFFFFF',
        letterSpacing: '-0.01em',
        boxShadow: isPressed
          ? 'inset 0 2px 4px rgba(0,0,0,0.2), 0 1px 2px rgba(0,0,0,0.1)'
          : isHovered
          ? 'inset 0 1px 1px rgba(255,255,255,0.4), 0 10px 30px -5px rgba(74,222,128,0.5), 0 20px 50px -10px rgba(13,148,136,0.3)'
          : 'inset 0 1px 1px rgba(255,255,255,0.3), 0 4px 12px -2px rgba(74,222,128,0.4), 0 8px 25px -5px rgba(13,148,136,0.2)',
        transform: isPressed ? 'translateY(1px)' : isHovered ? 'translateY(-2px)' : 'translateY(0)',
        transition: 'all 0.2s ease',
        overflow: 'hidden',
      }}
    >
      {/* Shimmer overlay */}
      <div style={{
        position: 'absolute',
        inset: 0,
        background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.3) 50%, transparent 100%)',
        animation: 'shimmerButton 3s ease infinite',
      }} />
      <span style={{ position: 'relative', zIndex: 1 }}>{children}</span>
    </button>
  );
};
\`\`\`

### 2. AI-Powered Badge

\`\`\`tsx
const AIPoweredBadge = () => (
  <div style={{
    display: 'inline-flex',
    alignItems: 'center',
    gap: '8px',
    padding: '10px 18px',
    background: 'linear-gradient(180deg, #FFFFFF 0%, #F8FDF9 50%, #F0FDF4 100%)',
    borderRadius: '100px',
    border: '1px solid rgba(74, 222, 128, 0.3)',
    boxShadow: '0 2px 8px rgba(74, 222, 128, 0.1)',
    position: 'relative',
    overflow: 'hidden',
  }}>
    {/* Pulsing dot */}
    <div style={{
      width: '8px',
      height: '8px',
      background: '#4ADE80',
      borderRadius: '50%',
      animation: 'pulse 2s ease-in-out infinite',
      boxShadow: '0 0 8px rgba(74, 222, 128, 0.6)',
    }} />
    <span style={{
      fontSize: '13px',
      fontWeight: '600',
      color: '#0D9488',
      letterSpacing: '0.02em',
    }}>
      AI-powered nutrition
    </span>
  </div>
);
\`\`\`

### 3. Metrics Card (White)

\`\`\`tsx
const MetricsCard = () => (
  <div style={{
    background: '#FFFFFF',
    borderRadius: '20px',
    padding: '20px',
    boxShadow: '0 4px 24px rgba(0,0,0,0.06), 0 12px 48px rgba(74,222,128,0.08)',
    border: '1px solid rgba(0,0,0,0.04)',
  }}>
    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
      <div>
        <p style={{ fontSize: '10px', color: '#71717A', letterSpacing: '0.1em' }}>RECOVERY</p>
        <p style={{ fontSize: '28px', fontWeight: '600', color: '#4ADE80' }}>87%</p>
      </div>
      <div>
        <p style={{ fontSize: '10px', color: '#71717A', letterSpacing: '0.1em' }}>HRV</p>
        <p style={{ fontSize: '28px', fontWeight: '600', color: '#18181B' }}>62</p>
      </div>
      <div>
        <p style={{ fontSize: '10px', color: '#71717A', letterSpacing: '0.1em' }}>SLEEP</p>
        <p style={{ fontSize: '28px', fontWeight: '600', color: '#18181B' }}>7.2h</p>
      </div>
    </div>
  </div>
);
\`\`\`

### 4. Insight Card (Dark)

\`\`\`tsx
const InsightCard = () => (
  <div style={{
    background: 'linear-gradient(135deg, #18181B 0%, #27272A 100%)',
    borderRadius: '16px',
    padding: '16px 20px',
    boxShadow: '0 4px 24px rgba(0,0,0,0.12), 0 12px 48px rgba(13,148,136,0.1)',
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
      {/* Sparkle icon */}
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
        <path d="M12 2L14 10L22 12L14 14L12 22L10 14L2 12L10 10L12 2Z"
              fill="#4ADE80" />
      </svg>
      <span style={{ fontSize: '11px', color: '#4ADE80', fontWeight: '600' }}>AI INSIGHT</span>
    </div>
    <p style={{ fontSize: '14px', color: '#FFFFFF', fontWeight: '500', lineHeight: 1.5 }}>
      High cognitive day detected. Extra omega-3 and B-vitamins added.
    </p>
  </div>
);
\`\`\`

### 5. Meal Card

\`\`\`tsx
const MealCard = () => (
  <div style={{
    background: '#FFFFFF',
    borderRadius: '16px',
    padding: '16px',
    boxShadow: '0 2px 12px rgba(0,0,0,0.04)',
    border: '1px solid rgba(0,0,0,0.04)',
  }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
      <div style={{
        width: '56px',
        height: '56px',
        borderRadius: '12px',
        background: 'linear-gradient(135deg, #F0FDF4 0%, #DCFCE7 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}>
        {/* Bowl icon placeholder */}
      </div>
      <div>
        <p style={{ fontSize: '16px', fontWeight: '600', color: '#18181B' }}>Omega Bowl</p>
        <p style={{ fontSize: '13px', color: '#71717A' }}>Wild salmon, avocado, quinoa</p>
      </div>
    </div>
  </div>
);
\`\`\`

### 6. Phone Mockup

\`\`\`tsx
const PhoneMockup = ({ children }) => (
  <div style={{
    position: 'relative',
    width: '290px',
    height: '600px',
  }}>
    {/* Rim lights */}
    <div style={{
      position: 'absolute',
      left: '-8px',
      top: '5%',
      bottom: '5%',
      width: '16px',
      background: 'linear-gradient(180deg, transparent, rgba(74,222,128,0.8) 20%, rgba(74,222,128,1) 50%, rgba(74,222,128,0.8) 80%, transparent)',
      filter: 'blur(8px)',
      borderRadius: '10px',
    }} />
    <div style={{
      position: 'absolute',
      right: '-8px',
      top: '5%',
      bottom: '5%',
      width: '16px',
      background: 'linear-gradient(180deg, transparent, rgba(13,148,136,0.7) 20%, rgba(13,148,136,0.9) 50%, rgba(13,148,136,0.7) 80%, transparent)',
      filter: 'blur(8px)',
      borderRadius: '10px',
    }} />

    {/* Phone frame */}
    <div style={{
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(165deg, #3A3A3A 0%, #1A1A1A 30%, #0D0D0D 70%, #1A1A1A 100%)',
      borderRadius: '52px',
      padding: '2px',
      boxShadow: '0 0 0 1px rgba(255,255,255,0.1)',
    }}>
      <div style={{
        width: '100%',
        height: '100%',
        background: '#000000',
        borderRadius: '50px',
        padding: '10px',
      }}>
        {/* Screen */}
        <div style={{
          width: '100%',
          height: '100%',
          background: 'linear-gradient(180deg, #FAFAFA 0%, #F5F5F5 100%)',
          borderRadius: '42px',
          overflow: 'hidden',
          position: 'relative',
          boxShadow: '0 0 60px rgba(74,222,128,0.3), 0 0 120px rgba(74,222,128,0.2)',
        }}>
          {/* Dynamic Island */}
          <div style={{
            position: 'absolute',
            top: '12px',
            left: '50%',
            transform: 'translateX(-50%)',
            width: '100px',
            height: '32px',
            background: '#000000',
            borderRadius: '20px',
            zIndex: 20,
          }} />
          {children}
        </div>
      </div>
    </div>
  </div>
);
\`\`\`

### 7. Spotlight Effect

\`\`\`tsx
const Spotlight = ({ x = 0, y = 0, size = 900 }) => (
  <div style={{
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: \`translate(calc(-50% + \${x}px), calc(-50% + \${y}px))\`,
    width: \`\${size}px\`,
    height: \`\${size}px\`,
    pointerEvents: 'none',
    zIndex: 10,
  }}>
    <div style={{
      position: 'absolute',
      inset: 0,
      background: 'radial-gradient(circle at center, rgba(74,222,128,0.2) 0%, rgba(74,222,128,0.12) 25%, rgba(13,148,136,0.06) 50%, transparent 70%)',
      animation: 'megaPulse 4s ease-in-out infinite',
    }} />
  </div>
);
\`\`\`

### 8. Dot Pattern Background

\`\`\`tsx
const DotPattern = ({ opacity = 0.5 }) => (
  <div style={{
    position: 'absolute',
    inset: 0,
    opacity: opacity,
    backgroundImage: 'radial-gradient(#E5E5E5 1px, transparent 1px)',
    backgroundSize: '32px 32px',
    maskImage: 'linear-gradient(to right, black 0%, transparent 60%)',
    WebkitMaskImage: 'linear-gradient(to right, black 0%, transparent 60%)',
  }} />
);
\`\`\`

### 9. Step Card

\`\`\`tsx
const StepCard = ({ number, title, body, micro, isHovered }) => (
  <div style={{
    width: '280px',
    background: '#FFFFFF',
    borderRadius: '24px',
    padding: '28px',
    boxShadow: isHovered
      ? '0 12px 40px rgba(0,0,0,0.12), 0 0 0 1px rgba(74,222,128,0.2)'
      : '0 4px 24px rgba(0,0,0,0.06)',
    transition: 'all 0.3s ease',
    transform: isHovered ? 'translateY(-4px)' : 'translateY(0)',
  }}>
    {/* Step number badge */}
    <div style={{
      width: '36px',
      height: '36px',
      borderRadius: '10px',
      background: 'linear-gradient(135deg, #4ADE80 0%, #0D9488 100%)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: '20px',
      boxShadow: '0 4px 12px rgba(74,222,128,0.3)',
    }}>
      <span style={{ color: '#FFFFFF', fontSize: '14px', fontWeight: '600' }}>{number}</span>
    </div>

    <h3 style={{
      fontFamily: "'Instrument Serif', serif",
      fontSize: '22px',
      color: '#18181B',
      marginBottom: '12px',
    }}>{title}</h3>

    <p style={{
      fontSize: '14px',
      color: '#71717A',
      lineHeight: 1.6,
      marginBottom: '16px',
    }}>{body}</p>

    <p style={{
      fontSize: '12px',
      color: '#0D9488',
      fontWeight: '500',
    }}>{micro}</p>
  </div>
);
\`\`\`

### 10. Download Button

\`\`\`tsx
const DownloadButton = ({ onClick }) => (
  <button
    onClick={onClick}
    style={{
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
      padding: '10px 20px',
      background: 'rgba(255, 255, 255, 0.8)',
      backdropFilter: 'blur(10px)',
      border: '1px solid #E5E5E5',
      borderRadius: '100px',
      cursor: 'pointer',
      fontFamily: "'DM Sans', sans-serif",
      fontSize: '14px',
      fontWeight: '500',
      color: '#18181B',
      boxShadow: '0 2px 8px rgba(0,0,0,0.05)',
      transition: 'all 0.2s ease',
    }}
  >
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="7 10 12 15 17 10" />
      <line x1="12" y1="15" x2="12" y2="3" />
    </svg>
    Download Guide
  </button>
);
\`\`\`

---

## Layout Patterns

### Scroll Container Structure

\`\`\`tsx
<div ref={containerRef} style={{ minHeight: '600vh', background: '#FFFFFF', position: 'relative' }}>
  {/* Fixed viewport container */}
  <div style={{ position: 'fixed', top: 0, left: 0, right: 0, height: '100vh', overflow: 'hidden' }}>
    {/* Layer 1: Background patterns */}
    <DotPattern />

    {/* Layer 2: Spotlight effects */}
    <Spotlight />

    {/* Layer 3: Navigation */}
    <Navigation />

    {/* Layer 4: Content that transforms */}
    <HeroContent scrollProgress={scrollProgress} />
    <PhoneWithCards scrollProgress={scrollProgress} />
    <FloatingCards scrollProgress={scrollProgress} />

    {/* Layer 5: Section headers */}
    <SectionHeader scrollProgress={scrollProgress} />
  </div>
</div>
\`\`\`

### Section Timeline (Scroll Progress)

| Phase | Progress Range | Content |
|-------|----------------|---------|
| Hero | 0.00 - 0.15 | Title, badge, CTA, phone visible |
| Lift | 0.08 - 0.25 | Cards begin lifting from phone |
| Travel | 0.15 - 0.60 | Cards animate to comparison positions |
| Comparison | 0.25 - 0.65 | "What if" headline visible |
| Grid Transition | 0.65 - 0.75 | Cards morph to step cards, move to grid |
| How It Works | 0.75 - 1.00 | Three-column grid, section header |

### Position Constants

\`\`\`javascript
const PHONE_WIDTH = 290;
const PHONE_HEIGHT = 600;
const PHONE_CENTER_X_OFFSET = 280;  // Offset from center to the right

const CARD_POSITIONS_IN_PHONE = {
  metrics: { x: 14, y: 90, width: 262, height: 120 },
  insight: { x: 14, y: 220, width: 262, height: 90 },
  meal: { x: 14, y: 320, width: 262, height: 100 },
};

const CARD_FINAL_POSITIONS = {
  metrics: { x: 280, y: -180 },
  insight: { x: 300, y: 20 },
  meal: { x: 280, y: 220 },
};

const GRID_POSITIONS = {
  metrics: { x: -320, y: 80 },
  insight: { x: 0, y: 80 },
  meal: { x: 320, y: 80 },
};
\`\`\`

---

## Spacing Scale

| Token | Value | Usage |
|-------|-------|-------|
| space-1 | 4px | Tight gaps, icon padding |
| space-2 | 8px | Icon gaps, tight padding |
| space-3 | 12px | Small component padding |
| space-4 | 16px | Standard padding |
| space-5 | 20px | Medium gaps |
| space-6 | 24px | Card padding, section gaps |
| space-7 | 28px | Larger gaps |
| space-8 | 32px | Component separation |
| space-10 | 40px | Step badge positioning |
| space-12 | 48px | Section padding |
| space-14 | 56px | Page edge padding |
| space-20 | 80px | Major section breaks |

---

## Border Radius Scale

| Element | Radius |
|---------|--------|
| Small buttons | 8px |
| Input fields | 10px |
| Icons/Avatars | 10-14px |
| Buttons | 14px |
| Small cards | 16px |
| Cards | 24px |
| Pills/Badges | 100px |
| Phone screen | 42px |
| Phone frame | 52px |

---

## Z-Index Scale

| Layer | Z-Index | Contents |
|-------|---------|----------|
| Background | 1 | Section backgrounds |
| Patterns | 5 | Dot patterns |
| Spotlight | 10 | Glow effects |
| Content | 15 | Phone, base content |
| Hero | 20 | Hero text, CTAs |
| Comparison | 25 | Comparison section |
| Cards | 30 | Floating cards |
| Navigation | 50 | Fixed nav |
| Indicators | 50 | Scroll dots |

---

## Interactive States

### Hover States

\`\`\`css
/* Cards */
.card:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 40px rgba(0,0,0,0.12), 0 0 0 1px rgba(74,222,128,0.2);
}

/* Buttons */
.button:hover {
  transform: translateY(-2px);
  box-shadow: inset 0 1px 1px rgba(255,255,255,0.4),
              0 10px 30px -5px rgba(74,222,128,0.5);
}

/* Links */
.link:hover {
  color: #18181B;  /* from #71717A */
}
\`\`\`

### Focus States

\`\`\`css
.interactive:focus {
  outline: none;
  box-shadow: 0 0 0 2px rgba(74, 222, 128, 0.4);
}
\`\`\`

### Active/Pressed States

\`\`\`css
.button:active {
  transform: translateY(1px);
  background: linear-gradient(180deg, #1D8B54 0%, #2AA06A 50%, #34D480 100%);
  box-shadow: inset 0 2px 4px rgba(0,0,0,0.2);
}
\`\`\`

---

## Iconography

### Usage Rules

- Use SVG icons only, no emoji
- Stroke width: 2px for standard icons
- Fill for solid icons (brand logos, badges)
- Color: inherit from parent or explicit (#71717A for muted, #18181B for primary)

### Sizing Scale

| Size | Dimensions | Usage |
|------|------------|-------|
| xs | 12x12 | Inline indicators |
| sm | 16x16 | Buttons, badges |
| md | 20x20 | Navigation, cards |
| lg | 24x24 | Feature icons |
| xl | 32x32 | Hero icons |

### Icon Definitions

\`\`\`tsx
// Download
<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
  <polyline points="7 10 12 15 17 10" />
  <line x1="12" y1="15" x2="12" y2="3" />
</svg>

// Sparkle (for AI badge)
<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
  <path d="M12 2L14 10L22 12L14 14L12 22L10 14L2 12L10 10L12 2Z" />
</svg>

// Check
<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
  <polyline points="20 6 9 17 4 12" />
</svg>

// Arrow Right
<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
  <line x1="5" y1="12" x2="19" y2="12" />
  <polyline points="12 5 19 12 12 19" />
</svg>

// Leaf (nutrition)
<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
  <path d="M6.5 12C6.5 8 10 2.5 17 2.5C17 9.5 11.5 14 6.5 12Z" />
  <path d="M6.5 12C6.5 16 10 21.5 2 21.5" />
</svg>

// Clock
<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
  <circle cx="12" cy="12" r="10" />
  <polyline points="12 6 12 12 16 14" />
</svg>
\`\`\`

---

## Background Patterns

### Dot Pattern

\`\`\`css
background-image: radial-gradient(#E5E5E5 1px, transparent 1px);
background-size: 32px 32px;
mask-image: linear-gradient(to right, black 0%, transparent 60%);
\`\`\`

### Section Transition (Gradient Overlay)

\`\`\`css
/* Fade to surface color as scroll progresses */
background: linear-gradient(
  180deg,
  rgba(250, 250, 250, var(--progress)) 0%,
  rgba(250, 250, 250, var(--progress)) 50%,
  rgba(245, 245, 245, var(--progress)) 100%
);
\`\`\`

---

## Content Guidelines

### Headline Hierarchy

1. **Hero (H1)**: One impactful statement, often split across two lines
   - Example: "You've optimized everything. / Except what you eat."
2. **Section (H2)**: Question or statement that introduces the section
   - Example: "What if your food actually knew you?"
3. **Card (H3)**: Action-oriented, benefit-focused
   - Example: "Connect your life"

### Body Copy Rules

- Max 2-3 sentences per paragraph
- Lead with benefit, follow with how
- Use numbers when possible ("7 days", "2-minute setup")
- Avoid jargon unless it's industry-standard

### Micro-copy Patterns

- Reassurance: "Free for 7 days · No credit card required"
- Time indicators: "2-minute setup", "Updates every morning"
- Social proof: "2,847 founders eating smarter"

---

## Voice & Tone

### Do
- Confident but not arrogant
- Specific but not verbose
- Premium but not exclusive
- Technical but accessible

### Don't
- Use superlatives without backing ("the best")
- Be vague about benefits
- Use aggressive sales language
- Include emoji or exclamation marks

### Examples

Good: "Meals that adapt to your body, your schedule, your goals."
Bad: "The BEST meal service you'll ever try!!!"

Good: "Our AI builds a living profile of your needs."
Bad: "Revolutionary AI technology transforms your eating experience!"

---

## Quality Checklist

Before shipping, verify:

- [ ] All shadows are color-tinted (green/teal), never pure black
- [ ] Typography follows the scale exactly
- [ ] Animations use specified easing functions
- [ ] No emoji anywhere in the UI
- [ ] Spotlight effect pulses subtly
- [ ] Cards have proper hover states with elevation change
- [ ] Phone mockup has rim lighting on both sides
- [ ] Scroll progress drives all transforms smoothly
- [ ] Button has 3D gradient effect with shimmer
- [ ] Badge has pulsing indicator dot
- [ ] Navigation is fixed with glassmorphism
- [ ] Download button is visible and functional
- [ ] Content transforms (not cuts) between sections
- [ ] Generous whitespace throughout

---

## Allowed vs Not Allowed

### Allowed
- Green/teal color palette with specified values
- Multi-layer color-tinted shadows
- Subtle gradients on buttons, cards, badges
- Scroll-driven animations
- SVG icons
- Serif headlines (Instrument Serif)
- Sans-serif body (DM Sans)
- Glassmorphism on navigation
- Floating/breathing ambient animations
- Progressive disclosure through scroll

### Not Allowed
- Emoji (use SVG icons instead)
- Pure black shadows
- Flat design without depth
- Abrupt cuts between sections
- Bold headlines (use the serif typeface elegance)
- Skeleton loading states
- Excessive animation (every element bouncing)
- Color outside the defined palette
- Generic stock photography
- Gradients on page backgrounds

---

## Tech Stack

### Dependencies

\`\`\`json
{
  "react": "^18.x",
  "typescript": "^5.x"
}
\`\`\`

### Fonts (Google Fonts)

\`\`\`html
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
\`\`\`

### CSS Reset

\`\`\`css
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html {
  scroll-behavior: smooth;
}
\`\`\`

---

## Component Hierarchy

\`\`\`
LightGreenLandingPage
├── <style> (keyframes, reset)
├── Scroll Container (600vh)
│   └── Fixed Viewport (100vh)
│       ├── SectionBackground
│       ├── DotPattern
│       ├── Navigation
│       │   ├── Logo
│       │   ├── NavLinks
│       │   ├── DownloadButton
│       │   └── SignInButton
│       ├── HeroContent
│       │   ├── AIPoweredBadge
│       │   ├── Headline (H1)
│       │   ├── Subheadline
│       │   ├── Premium3DButton
│       │   └── SocialProof
│       ├── PersistentSpotlight
│       ├── PhoneWithCards
│       │   └── Phone Frame
│       │       ├── RimLights
│       │       ├── Screen
│       │       │   ├── DynamicIsland
│       │       │   ├── MetricsCard
│       │       │   ├── InsightCard
│       │       │   └── MealCard
│       ├── FloatingCards
│       │   ├── FloatingCard (metrics)
│       │   ├── FloatingCard (insight)
│       │   └── FloatingCard (meal)
│       ├── ComparisonSection
│       ├── HowItWorksHeader
│       └── StepConnectingLine
└── ScrollProgressIndicator
\`\`\`

---

## File Structure

\`\`\`
src/design-systems/light-green/
├── LightGreenLandingPage.tsx    # Main component
├── designGuideData.ts           # This design guide content
└── components/
    ├── Premium3DButton.tsx
    ├── ScrollAnimations.tsx
    └── TitaniumDevice.tsx
\`\`\`

---

## Best Practices Summary

1. **Scroll Progress**: Calculate once, pass to all components
2. **Easing**: Use cubic-bezier for smooth transforms
3. **Shadows**: Always tint with green/teal
4. **Typography**: Serif for headlines, sans-serif for body
5. **Animation**: Purpose-driven, never decorative
6. **Whitespace**: Generous, intentional
7. **Depth**: Layer shadows, gradients, and lighting
8. **Transitions**: Morph content, never cut
9. **Icons**: SVG only, stroke-based
10. **Quality**: Check against the checklist before shipping
`;

