

export const Spotlight = () => {
    return (
        <div style={{
            position: 'absolute',
            width: '900px',
            height: '900px',
            pointerEvents: 'none',
            left: '50%',
            top: '50%',
            transform: 'translate(-50%, -50%)',
            zIndex: 0
        }}>
            <div className="absolute inset-0 rounded-full animate-[pulse_4s_ease-in-out_infinite]"
                style={{
                    background: 'radial-gradient(circle at center, rgba(74, 222, 128, 0.2) 0%, rgba(74, 222, 128, 0.12) 25%, rgba(13, 148, 136, 0.06) 50%, transparent 70%)',
                }}
            />
            <div className="absolute inset-[20%] rounded-full animate-[pulse_3s_ease-in-out_infinite]"
                style={{
                    background: 'radial-gradient(ellipse at center, rgba(74, 222, 128, 0.25) 0%, transparent 60%)',
                    filter: 'blur(30px)',
                }}
            />
        </div>
    );
};

export const HandDrawnCircle = ({ isActive, delay = 0 }: { isActive: boolean; delay?: number }) => {
    return (
        <svg
            viewBox="0 0 100 50"
            preserveAspectRatio="none"
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[calc(100%+24px)] h-[calc(100%+24px)] pointer-events-none"
        >
            <ellipse
                cx="50" cy="25" rx="48" ry="22"
                stroke="#4ADE80"
                strokeWidth="2"
                fill="none"
                style={{
                    strokeDasharray: 350,
                    strokeDashoffset: isActive ? 0 : 350,
                    transition: `stroke-dashoffset 0.8s cubic-bezier(0.4, 0, 0.2, 1)`,
                    transitionDelay: `${delay}s`
                }}
            />
        </svg>
    );
};

export const ConnectingLine = ({ progress }: { progress: number }) => {
    return (
        <div style={{ position: 'relative', width: '100%', maxWidth: '640px', height: '4px', margin: '40px auto' }}>
            {/* Background track */}
            <div style={{
                position: 'absolute', top: '50%', left: 0, right: 0, height: '2px',
                background: '#E5E5E5', borderRadius: '2px', transform: 'translateY(-50%)',
            }} />

            {/* Progress fill */}
            <div style={{
                position: 'absolute', top: '50%', left: 0, width: `${progress * 100}%`, height: '2px',
                background: 'linear-gradient(90deg, #4ADE80 0%, #0D9488 100%)',
                borderRadius: '2px', transform: 'translateY(-50%)',
                boxShadow: progress > 0.1 ? '0 0 12px rgba(74, 222, 128, 0.5)' : 'none',
                transition: 'width 0.1s linear'
            }} />

            {/* Progress dots */}
            {[0, 0.5, 1].map((pos, i) => (
                <div
                    key={i}
                    style={{
                        position: 'absolute', top: '50%', left: `${pos * 100}%`,
                        transform: 'translate(-50%, -50%)',
                        width: '12px', height: '12px', borderRadius: '50%',
                        background: progress >= pos ? 'linear-gradient(135deg, #4ADE80 0%, #0D9488 100%)' : '#E5E5E5',
                        border: '3px solid #FFFFFF',
                        boxShadow: progress >= pos ? '0 0 0 3px rgba(74, 222, 128, 0.2)' : '0 1px 3px rgba(0,0,0,0.1)',
                        transition: 'all 0.3s ease',
                    }}
                />
            ))}
        </div>
    );
};
