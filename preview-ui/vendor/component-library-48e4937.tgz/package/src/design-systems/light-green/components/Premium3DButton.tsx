import React, { useState } from 'react';
import { cn } from '../../../utils/cn';

export const Premium3DButton = ({ children, className, onClick }: { children: React.ReactNode; className?: string; onClick?: () => void }) => {
    const [isHovered, setIsHovered] = useState(false);
    const [isPressed, setIsPressed] = useState(false);

    // Design Guide Gradients
    const gradientDefault = 'linear-gradient(180deg, #4ADE80 0%, #3ACC72 50%, #2AB862 100%)';
    const gradientHover = 'linear-gradient(180deg, #3BD975 0%, #2EBE68 50%, #25A85C 100%)';
    const gradientPressed = 'linear-gradient(180deg, #1D8B54 0%, #2AA06A 50%, #34D480 100%)';

    const shadowDefault = 'inset 0 1px 1px rgba(255,255,255,0.3), 0 4px 12px -2px rgba(74, 222, 128, 0.4), 0 8px 25px -5px rgba(13, 148, 136, 0.2)';
    const shadowHover = 'inset 0 1px 1px rgba(255,255,255,0.4), 0 10px 30px -5px rgba(74, 222, 128, 0.5), 0 20px 50px -10px rgba(13, 148, 136, 0.3)';
    const shadowPressed = 'inset 0 2px 4px rgba(0,0,0,0.2), 0 1px 2px rgba(0,0,0,0.1)';

    return (
        <button
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => { setIsHovered(false); setIsPressed(false); }}
            onMouseDown={() => setIsPressed(true)}
            onMouseUp={() => setIsPressed(false)}
            onClick={onClick}
            className={cn("relative font-semibold font-dm-sans overflow-hidden group select-none", className)}
            style={{
                padding: '20px 40px',
                fontSize: '15px',
                color: '#FFFFFF',
                background: isPressed ? gradientPressed : isHovered ? gradientHover : gradientDefault,
                border: 'none',
                borderRadius: '14px',
                cursor: 'pointer',
                transform: isPressed ? 'translateY(2px) scale(0.98)' : isHovered ? 'translateY(-2px)' : 'translateY(0)',
                boxShadow: isPressed ? shadowPressed : isHovered ? shadowHover : shadowDefault,
                transition: 'all 0.15s ease',
            }}
        >
            {/* Top highlight line */}
            <div className="absolute top-[1px] left-[10%] right-[10%] h-[1px] bg-gradient-to-r from-transparent via-white/60 to-transparent" />

            {/* Shimmer Effect - CSS only */}
            <div className="absolute inset-0 w-[50%] h-full bg-gradient-to-r from-transparent to-white/20 skew-x-[-20deg] left-[-100%] group-hover:transition-[left] group-hover:duration-[1000ms] group-hover:ease-in-out group-hover:left-[200%]" />

            <span className="relative z-10 flex items-center justify-center gap-2">{children}</span>
        </button>
    );
};
