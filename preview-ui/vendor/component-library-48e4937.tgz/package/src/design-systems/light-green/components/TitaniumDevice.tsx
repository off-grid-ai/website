import React from 'react';
import { cn } from '../../../utils/cn';

export const TitaniumDevice = ({ children, className }: { children: React.ReactNode; className?: string }) => {
    return (
        <div className={cn("relative mx-auto rounded-[52px]", className)}
            style={{
                width: '100%',
                maxWidth: '320px',
                aspectRatio: '320 / 640',
                background: 'linear-gradient(135deg, #3A3A3A 0%, #1A1A1A 50%, #0D0D0D 100%)',
                boxShadow: `
          0 0 0 1px #000000, 
          0 0 60px rgba(74, 222, 128, 0.3),
          0 0 120px rgba(74, 222, 128, 0.2)
        `
            }}
        >
            {/* Rim Lighting - Left */}
            <div style={{
                position: 'absolute', left: '-8px', top: '5%', bottom: '5%', width: '16px',
                background: `linear-gradient(180deg, transparent 0%, rgba(74, 222, 128, 0.8) 20%, rgba(74, 222, 128, 1) 50%, rgba(74, 222, 128, 0.8) 80%, transparent 100%)`,
                filter: 'blur(8px)', opacity: 0.8
            }} />

            {/* Rim Lighting - Right */}
            <div style={{
                position: 'absolute', right: '-8px', top: '5%', bottom: '5%', width: '16px',
                background: `linear-gradient(180deg, transparent 0%, rgba(13, 148, 136, 0.7) 20%, rgba(13, 148, 136, 0.9) 50%, rgba(13, 148, 136, 0.7) 80%, transparent 100%)`,
                filter: 'blur(8px)', opacity: 0.8
            }} />

            {/* Buttons */}
            <div className="absolute -left-[3px] top-[18%] w-[3px] h-[5%] bg-[#2A2A2A] rounded-l-md" /> {/* Silent */}
            <div className="absolute -left-[3px] top-[26%] w-[3px] h-[7.5%] bg-[#2A2A2A] rounded-l-md" /> {/* Vol Up */}
            <div className="absolute -left-[3px] top-[36%] w-[3px] h-[7.5%] bg-[#2A2A2A] rounded-l-md" /> {/* Vol Down */}
            <div className="absolute -right-[3px] top-[30%] w-[3px] h-[12.5%] bg-[#2A2A2A] rounded-r-md" /> {/* Power */}

            {/* Screen Bezel - Inner Black Border */}
            <div className="absolute inset-[10px] rounded-[42px] bg-black overflow-hidden">
                {/* Dynamic Island */}
                <div className="absolute top-3 left-1/2 -translate-x-1/2 h-[32px] w-[100px] bg-black rounded-full z-50 flex items-center justify-center">
                    <div className="w-full h-full rounded-full bg-neutral-900 border border-neutral-800" />
                </div>

                {/* Screen Content */}
                <div className="w-full h-full bg-white relative overflow-hidden">
                    {children}
                </div>
            </div>
        </div>
    );
};
