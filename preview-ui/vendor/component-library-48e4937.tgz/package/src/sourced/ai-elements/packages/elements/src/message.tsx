// Source: https://github.com/vercel/ai-elements/blob/6a9d5b1822ffb10bba4bd97175f01edd7d8651cd/packages/elements/src/message.tsx
// Operator UI: the upstream module is split. message-core.tsx holds the light parts
// (Message, MessageContent, actions, branches, toolbar) without the markdown renderer;
// message-response.tsx holds MessageResponse (Streamdown with cjk, code, math, mermaid).
// This entry re-exports both so existing imports keep working.
export {
  Message,
  MessageAction,
  MessageActions,
  MessageBranch,
  MessageBranchContent,
  MessageBranchNext,
  MessageBranchPage,
  MessageBranchPrevious,
  MessageBranchSelector,
  MessageContent,
  MessageToolbar,
  type MessageActionProps,
  type MessageActionsProps,
  type MessageBranchContentProps,
  type MessageBranchNextProps,
  type MessageBranchPageProps,
  type MessageBranchPreviousProps,
  type MessageBranchProps,
  type MessageBranchSelectorProps,
  type MessageContentProps,
  type MessageProps,
  type MessageToolbarProps,
} from "./message-core.js";
export {
  MessageResponse,
  type MessageResponseProps,
} from "./message-response.js";
