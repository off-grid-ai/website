"use client";

import { Slot, Slottable } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import * as React from "react";

const buttonVariants = cva("og-button", {
  variants: {
    variant: {
      default: "og-button--default",
      destructive: "og-button--destructive",
      outline: "og-button--outline",
      secondary: "og-button--secondary",
      ghost: "og-button--ghost",
      link: "og-button--link",
    },
    size: {
      default: "og-button--size-default",
      sm: "og-button--size-sm",
      lg: "og-button--size-lg",
      icon: "og-button--size-icon",
    },
  },
  defaultVariants: {
    variant: "default",
    size: "default",
  },
});

type ButtonVariantProps = VariantProps<typeof buttonVariants>;

export type ButtonProps = Omit<
  React.ComponentPropsWithoutRef<"button">,
  "disabled"
> &
  ButtonVariantProps & {
    /** Render behavior and styles onto one child, for example a Next Link. */
    asChild?: boolean;
    /** Prevents activation and exposes the disabled state on native and slotted controls. */
    disabled?: boolean;
    /** Keeps the label stable, prevents repeat activation, and exposes aria-busy. */
    loading?: boolean;
    /** Announced through a polite status region while loading. */
    loadingLabel?: string;
    /** Replaces the default visual spinner without changing loading semantics. */
    loadingIndicator?: React.ReactNode;
  };

function LoadingIndicator() {
  return (
    <span
      aria-hidden="true"
      className="og-button__spinner"
      data-slot="button-spinner"
    />
  );
}

function withoutChildClickCapture(
  children: React.ReactNode,
  isUnavailable: boolean,
) {
  if (!isUnavailable || !React.isValidElement(children)) return children;

  // Radix Slot composes a child's event handler before the slot handler. Strip
  // the child's capture handler while unavailable so our capture guard is the
  // first code that runs for both pointer- and keyboard-generated clicks.
  return React.cloneElement(
    children as React.ReactElement<{
      onClickCapture?: React.MouseEventHandler<HTMLElement>;
    }>,
    { onClickCapture: undefined },
  );
}

function Button({
  asChild = false,
  children,
  className,
  disabled = false,
  loading = false,
  loadingIndicator,
  loadingLabel = "Loading",
  onClick,
  onClickCapture,
  size = "default",
  type,
  variant = "default",
  ...props
}: ButtonProps) {
  const isUnavailable = disabled || loading;
  const Comp = asChild ? Slot : "button";
  const guardedChildren = asChild
    ? withoutChildClickCapture(children, isUnavailable)
    : children;

  const handleClick: React.MouseEventHandler<HTMLElement> = (event) => {
    onClick?.(event as unknown as React.MouseEvent<HTMLButtonElement>);
  };

  const handleClickCapture: React.MouseEventHandler<HTMLElement> = (event) => {
    if (isUnavailable) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }

    onClickCapture?.(event as unknown as React.MouseEvent<HTMLButtonElement>);
  };

  return (
    <>
      <Comp
        {...props}
        aria-busy={loading || undefined}
        aria-disabled={asChild && isUnavailable ? true : undefined}
        className={buttonVariants({ variant, size, className })}
        data-disabled={isUnavailable ? "" : undefined}
        data-loading={loading ? "" : undefined}
        data-size={size}
        data-slot="button"
        data-variant={variant}
        disabled={asChild ? undefined : isUnavailable}
        onClick={handleClick}
        onClickCapture={handleClickCapture}
        type={asChild ? undefined : (type ?? "button")}
      >
        {loading ? (
          loadingIndicator ? (
            <span aria-hidden="true" data-slot="button-loading-indicator">
              {loadingIndicator}
            </span>
          ) : (
            <LoadingIndicator />
          )
        ) : null}
        <Slottable>{guardedChildren}</Slottable>
      </Comp>
      {loading ? (
        <span
          aria-atomic="true"
          aria-live="polite"
          className="og-visually-hidden"
          role="status"
        >
          {loadingLabel}
        </span>
      ) : null}
    </>
  );
}

export { Button, buttonVariants };
