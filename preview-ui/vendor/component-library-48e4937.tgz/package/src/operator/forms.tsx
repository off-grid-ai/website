"use client";

import * as LabelPrimitive from "@radix-ui/react-label";
import * as React from "react";

function classNames(...values: Array<string | undefined>) {
  return values.filter(Boolean).join(" ");
}

export type InputProps = React.ComponentPropsWithoutRef<"input">;

const Input = React.forwardRef<HTMLInputElement, InputProps>(function Input(
  { className, type, ...props },
  ref,
) {
  return (
    <input
      ref={ref}
      className={classNames("og-input", className)}
      data-slot="input"
      type={type}
      {...props}
    />
  );
});

export type TextareaProps = React.ComponentPropsWithoutRef<"textarea">;

const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  function Textarea({ className, ...props }, ref) {
    return (
      <textarea
        ref={ref}
        className={classNames("og-textarea", className)}
        data-slot="textarea"
        {...props}
      />
    );
  },
);

export type LabelProps = React.ComponentPropsWithoutRef<
  typeof LabelPrimitive.Root
>;

const Label = React.forwardRef<
  React.ElementRef<typeof LabelPrimitive.Root>,
  LabelProps
>(function Label({ className, ...props }, ref) {
  return (
    <LabelPrimitive.Root
      ref={ref}
      className={classNames("og-label", className)}
      data-slot="label"
      {...props}
    />
  );
});

export type NativeSelectProps = React.ComponentPropsWithoutRef<"select">;

const NativeSelect = React.forwardRef<HTMLSelectElement, NativeSelectProps>(
  function NativeSelect({ className, children, ...props }, ref) {
    return (
      <span className="og-select-wrap" data-slot="select-wrap">
        <select
          ref={ref}
          className={classNames("og-select", className)}
          data-slot="select"
          {...props}
        >
          {children}
        </select>
        <span aria-hidden="true" className="og-select__chevron">
          ⌄
        </span>
      </span>
    );
  },
);

function Field({ className, ...props }: React.ComponentPropsWithoutRef<"div">) {
  return (
    <div
      className={classNames("og-field", className)}
      data-slot="field"
      {...props}
    />
  );
}

function FieldDescription({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"p">) {
  return (
    <p
      className={classNames("og-field__description", className)}
      data-slot="field-description"
      {...props}
    />
  );
}

function FieldError({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"p">) {
  return (
    <p
      className={classNames("og-field__error", className)}
      data-slot="field-error"
      role="alert"
      {...props}
    />
  );
}

export {
  Field,
  FieldDescription,
  FieldError,
  Input,
  Label,
  NativeSelect,
  Textarea,
};
