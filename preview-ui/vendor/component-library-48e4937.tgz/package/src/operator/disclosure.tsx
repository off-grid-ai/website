import * as React from "react";

function classNames(...values: Array<string | undefined>) {
  return values.filter(Boolean).join(" ");
}

function Disclosure({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"details">) {
  return (
    <details
      className={classNames("og-disclosure", className)}
      data-slot="disclosure"
      {...props}
    />
  );
}

function DisclosureTrigger({
  className,
  children,
  ...props
}: React.ComponentPropsWithoutRef<"summary">) {
  return (
    <summary
      className={classNames("og-disclosure__trigger", className)}
      data-slot="disclosure-trigger"
      {...props}
    >
      {children}
      <span aria-hidden="true" className="og-disclosure__chevron">
        ›
      </span>
    </summary>
  );
}

function DisclosureContent({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"div">) {
  return (
    <div
      className={classNames("og-disclosure__content", className)}
      data-slot="disclosure-content"
      {...props}
    />
  );
}

export { Disclosure, DisclosureContent, DisclosureTrigger };
