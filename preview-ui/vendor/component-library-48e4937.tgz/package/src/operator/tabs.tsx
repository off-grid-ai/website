"use client";

import * as TabsPrimitive from "@radix-ui/react-tabs";
import * as React from "react";

function classNames(...values: Array<string | undefined>) {
  return values.filter(Boolean).join(" ");
}
function Tabs({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Root>) {
  return (
    <TabsPrimitive.Root
      className={classNames("og-tabs", className)}
      data-slot="tabs"
      {...props}
    />
  );
}
function TabsList({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.List>) {
  return (
    <TabsPrimitive.List
      className={classNames("og-tabs__list", className)}
      data-slot="tabs-list"
      {...props}
    />
  );
}
function TabsTrigger({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Trigger>) {
  return (
    <TabsPrimitive.Trigger
      className={classNames("og-tabs__trigger", className)}
      data-slot="tabs-trigger"
      {...props}
    />
  );
}
function TabsContent({
  className,
  ...props
}: React.ComponentProps<typeof TabsPrimitive.Content>) {
  return (
    <TabsPrimitive.Content
      className={classNames("og-tabs__content", className)}
      data-slot="tabs-content"
      {...props}
    />
  );
}
export { Tabs, TabsContent, TabsList, TabsTrigger };
