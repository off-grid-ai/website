import * as React from "react";

function classNames(...values: Array<string | undefined>) {
  return values.filter(Boolean).join(" ");
}

function Spinner({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"span">) {
  return (
    <span
      aria-hidden="true"
      className={classNames("og-spinner", className)}
      data-slot="spinner"
      {...props}
    />
  );
}

function LoadingBlock({
  label = "Loading…",
  className,
  ...props
}: React.ComponentPropsWithoutRef<"div"> & { label?: string }) {
  return (
    <div
      aria-live="polite"
      className={classNames("og-loading", className)}
      data-ai-state="working"
      data-slot="loading"
      role="status"
      {...props}
    >
      <Spinner />
      <span>{label}</span>
    </div>
  );
}

function Skeleton({
  className,
  ...props
}: React.ComponentPropsWithoutRef<"div">) {
  return (
    <div
      aria-hidden="true"
      className={classNames("og-skeleton", className)}
      data-slot="skeleton"
      {...props}
    />
  );
}

function Progress({
  className,
  max = 100,
  value = 0,
  ...props
}: React.ComponentPropsWithoutRef<"progress">) {
  const safeMax = Number(max) > 0 ? Number(max) : 100;
  const safeValue = Math.min(safeMax, Math.max(0, Number(value) || 0));
  return (
    <progress
      className={classNames("og-progress", className)}
      data-slot="progress"
      max={safeMax}
      value={safeValue}
      {...props}
    />
  );
}

type StateProps = React.ComponentPropsWithoutRef<"section"> & {
  title: string;
  description?: string;
  action?: React.ReactNode;
};

function State({
  action,
  className,
  description,
  title,
  ...props
}: StateProps) {
  return (
    <section
      className={classNames("og-state", className)}
      data-slot="state"
      {...props}
    >
      <h2 className="og-state__title">{title}</h2>
      {description ? (
        <p className="og-state__description">{description}</p>
      ) : null}
      {action ? <div className="og-state__action">{action}</div> : null}
    </section>
  );
}

function EmptyState(props: StateProps) {
  return <State data-state="empty" {...props} />;
}

function ErrorState(props: StateProps) {
  return (
    <State aria-live="polite" data-state="error" role="alert" {...props} />
  );
}

export { EmptyState, ErrorState, LoadingBlock, Progress, Skeleton, Spinner };
